-- PANTHEON Admin System v2.0 - Enhanced Initialization System

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Phase 1: Core Bootstrap                                      ║
-- ╚═══════════════════════════════════════════════════════════════╝

local startTime = SysTime()
local PANTHEON_VERSION = "2.0.0"

-- Initialize namespace
pas = pas or {}
PLAYER = FindMetaTable('Player')

-- Early logging function
function pas.print(...)
	MsgC(Color(138, 43, 226), '[PANTHEON] ', Color(255, 255, 255), ... .. '\n')
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Phase 2: Load LIBS (Library System)                          ║
-- ╚═══════════════════════════════════════════════════════════════╝

if SERVER then
	AddCSLuaFile('libs/init.lua')
end

local libsSuccess, libsError = pcall(include, 'libs/init.lua')
if not libsSuccess then
	ErrorNoHalt('[PANTHEON] CRITICAL: Failed to load LIBS system!\n')
	ErrorNoHalt('Error: ' .. tostring(libsError) .. '\n')
	return
end

-- Wait for loader to be available
if not loader then
	ErrorNoHalt('[PANTHEON] CRITICAL: Loader system not available!\n')
	return
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Phase 3: Load Required Libraries                             ║
-- ╚═══════════════════════════════════════════════════════════════╝

local requiredLibs = {
	shared = {'nw', 'xfn', 'pon', 'pon2', 'netstream'},
	server = {'ptmysql', 'sha2'},
	client = {'cvar'}
}

-- Load shared libraries
for _, lib in ipairs(requiredLibs.shared) do
	local success, err = pcall(require, lib)
	if not success then
		pas.print('Warning: Failed to load library: ' .. lib .. ' - ' .. tostring(err))
	end
end

-- Load realm-specific libraries
local realmLibs = SERVER and requiredLibs.server or requiredLibs.client
for _, lib in ipairs(realmLibs) do
	local success, err = pcall(require, lib)
	if not success then
		pas.print('Warning: Failed to load library: ' .. lib .. ' - ' .. tostring(err))
	end
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Phase 4: Setup File Loading Helpers                          ║
-- ╚═══════════════════════════════════════════════════════════════╝

-- Legacy compatibility wrappers using new loader
pas.include_sv = function(path)
	if SERVER then
		path = loader.normalizePath(path)
		return loader.loadServer(path)
	end
end

pas.include_cl = function(path)
	path = loader.normalizePath(path)
	if SERVER then
		AddCSLuaFile(path)
	end
	return loader.loadClient(path)
end

pas.include_sh = function(path)
	path = loader.normalizePath(path)
	return loader.loadShared(path)
end

pas.include = function(path)
	path = loader.normalizePath(path)
	return loader.load(path)
end

-- Enhanced directory loader with filtering
pas.include_dir = function(dir, options)
	options = options or {}
	local basePath = 'pas/' .. dir
	
	-- Configure loader options
	local loaderOpts = {
		recursive = options.recursive ~= false,
		exclude = options.exclude or {},
		cache = options.cache ~= false
	}
	
	return loader.loadDir(basePath, loaderOpts)
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Phase 5: Load Core System                                    ║
-- ╚═══════════════════════════════════════════════════════════════╝

local coreSuccess, coreError = pcall(function()
	pas.include_sh('pas/core/core_init.lua')
end)

if not coreSuccess then
	ErrorNoHalt('[PANTHEON] CRITICAL: Failed to load core system!\n')
	ErrorNoHalt('Error: ' .. tostring(coreError) .. '\n')
	return
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Phase 6: Display Startup Banner                              ║
-- ╚═══════════════════════════════════════════════════════════════╝

local loadTime = (SysTime() - startTime) * 1000
local loaderStats = loader.getStats()

local banner = {
	'',
	'╔════════════════════════════════════════════════════════════╗',
	'║  ____   _    _   _ _____ _   _ _____ ___  _   _           ║',
	'║ |  _ \\ / \\  | \\ | |_   _| | | | ____/ _ \\| \\ | |          ║',
	'║ | |_) / _ \\ |  \\| | | | | |_| |  _|| | | |  \\| |          ║',
	'║ |  __/ ___ \\| |\\  | | | |  _  | |__| |_| | |\\  |          ║',
	'║ |_| /_/   \\_\\_| \\_| |_| |_| |_|_____\\___/|_| \\_|          ║',
	'║                                                            ║',
	'║              PANTHEON Admin System v' .. PANTHEON_VERSION .. '                 ║',
	'╚════════════════════════════════════════════════════════════╝',
	''
}

for _, line in ipairs(banner) do
	MsgC(Color(138, 43, 226), line .. '\n')
end

-- Print statistics
MsgC(Color(46, 204, 113), '[✓] ', Color(255, 255, 255), 
	string.format('System loaded successfully in %.2fms\n', loadTime))
MsgC(Color(52, 152, 219), '[ℹ] ', Color(255, 255, 255),
	string.format('Files loaded: %d | Cached: %d\n', 
		loaderStats.filesLoaded, loaderStats.cacheSize))

if loaderStats.errors > 0 then
	MsgC(Color(241, 196, 15), '[⚠] ', Color(255, 255, 255),
		string.format('Warnings: %d errors encountered during load\n', loaderStats.errors))
end

MsgC(Color(138, 43, 226), '════════════════════════════════════════════════════════════\n\n')

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Phase 7: Post-Load Hook                                      ║
-- ╚═══════════════════════════════════════════════════════════════╝

hook.Call('PANTHEON_Loaded', pas)

-- Store initialization data
pas._initData = {
	version = PANTHEON_VERSION,
	loadTime = loadTime,
	loaderStats = loaderStats,
	startTime = os.date('%Y-%m-%d %H:%M:%S', os.time())
}
