-- PANTHEON UI System v2.0 - Enhanced Initialization
-- Implements proper dependency resolution and optimized loading

if SERVER then
	-- Send all UI files to clients
	local uiFiles = {
		'ui/colors.lua',
		'ui/icons.lua',
		'ui/theme.lua',
		'ui/util.lua',
		'ui/components.lua',
		'ui/notifications.lua',
		'ui/autocomplete.lua',
		'ui/animations.lua',
		'ui/layout.lua'
	}
	
	for _, file in ipairs(uiFiles) do
		AddCSLuaFile(file)
	end
	return
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  CLIENT-SIDE INITIALIZATION                                   ║
-- ╚═══════════════════════════════════════════════════════════════╝

-- Prevent multiple loads
if PANTHEON_UI_LOADED then 
	MsgC(Color(241, 196, 15), '[PANTHEON UI] ', Color(255, 255, 255), 
		'Already loaded, skipping re-initialization\n')
	return 
end

local startTime = SysTime()

-- UI component dependencies in correct load order
local loadOrder = {
	{path = 'ui/colors.lua', name = 'Colors', deps = {}},
	{path = 'ui/icons.lua', name = 'Icons', deps = {}},
	{path = 'ui/autocomplete.lua', name = 'Autocomplete', deps = {}},
	{path = 'ui/util.lua', name = 'Utilities', deps = {'Colors'}},
	{path = 'ui/animations.lua', name = 'Animations', deps = {'Colors', 'Utilities'}},
	{path = 'ui/components.lua', name = 'Components', deps = {'Colors', 'Utilities'}},
	{path = 'ui/layout.lua', name = 'Layout', deps = {'Colors', 'Components'}},
	{path = 'ui/theme.lua', name = 'Theme', deps = {'Colors', 'Utilities'}},
	{path = 'ui/notifications.lua', name = 'Notifications', deps = {'Components', 'Theme'}}
}

-- Load UI components with dependency tracking
local loaded = {}
local failed = {}

for i, component in ipairs(loadOrder) do
	-- Check dependencies
	local canLoad = true
	for _, dep in ipairs(component.deps) do
		if not loaded[dep] then
			canLoad = false
			table.insert(failed, component.name .. ' (missing dependency: ' .. dep .. ')')
			break
		end
	end
	
	if canLoad then
		local success, err = pcall(include, component.path)
		if success then
			loaded[component.name] = true
			MsgC(Color(46, 204, 113), '[✓] ', Color(255, 255, 255), 
				'UI: ' .. component.name .. ' loaded\n')
		else
			table.insert(failed, component.name .. ' (error: ' .. tostring(err) .. ')')
			MsgC(Color(231, 76, 60), '[✗] ', Color(255, 255, 255), 
				'UI: Failed to load ' .. component.name .. '\n')
			ErrorNoHalt('  Error: ' .. tostring(err) .. '\n')
		end
	else
		MsgC(Color(241, 196, 15), '[⚠] ', Color(255, 255, 255), 
			'UI: Skipped ' .. component.name .. ' (dependency not met)\n')
	end
end

-- Mark as loaded
PANTHEON_UI_LOADED = true

-- Post-initialization hook
hook.Add('InitPostEntity', 'PANTHEON_UI_PostInit', function()
	-- Refresh derma skins to register PANTHEON skin
	if derma and derma.RefreshSkins then
		derma.RefreshSkins()
	end
	
	local loadTime = (SysTime() - startTime) * 1000
	local loadedCount = table.Count(loaded)
	local failedCount = #failed
	
	-- Print summary
	MsgC(Color(138, 43, 226), '\n╔════════════════════════════════════════════╗\n')
	MsgC(Color(138, 43, 226), '║     PANTHEON UI System Initialized         ║\n')
	MsgC(Color(138, 43, 226), '╚════════════════════════════════════════════╝\n')
	MsgC(Color(52, 152, 219), '[ℹ] ', Color(255, 255, 255),
		string.format('Components loaded: %d/%d\n', loadedCount, #loadOrder))
	MsgC(Color(52, 152, 219), '[ℹ] ', Color(255, 255, 255),
		string.format('Load time: %.2fms\n', loadTime))
	
	if failedCount > 0 then
		MsgC(Color(241, 196, 15), '[⚠] ', Color(255, 255, 255),
			string.format('Failed components: %d\n', failedCount))
		for _, failure in ipairs(failed) do
			MsgC(Color(231, 76, 60), '  └─ ', Color(255, 255, 255), failure .. '\n')
		end
	end
	
	MsgC(Color(138, 43, 226), '════════════════════════════════════════════\n\n')
	
	-- Call loaded hook
	hook.Call('PANTHEON_UI_Loaded', nil, {
		loadTime = loadTime,
		componentsLoaded = loadedCount,
		componentsFailed = failedCount
	})
	
	-- Remove this hook so it doesn't run again
	hook.Remove('InitPostEntity', 'PANTHEON_UI_PostInit')
end)
