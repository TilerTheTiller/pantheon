-- PANTHEON Admin System - Flags System (Client)

-- Store other players' flags for UI purposes
pas.flags.playerFlags = pas.flags.playerFlags or {}

-- Wait for netstream to be loaded
hook.Add('InitPostEntity', 'pas_flags_InitNetstream', function()
	-- Check if netstream is available
	if not netstream then
		timer.Simple(1, function()
			hook.Run('InitPostEntity')
		end)
		return
	end
	
	-- Receive our own flags from server
	netstream.Hook('pas_player_flags', function(data)
		LocalPlayer().pas_CustomFlags = data.flags or {}
	end)

	-- Receive all player flags (for admin UI)
	netstream.Hook('pas_all_player_flags', function(data)
		pas.flags.playerFlags = data.players or {}
	end)
end)

-- Get flags for a specific player by SteamID (for UI)
function pas.flags.GetPlayerFlagsBySteamID(steamid)
	return pas.flags.playerFlags[steamid] or {}
end

-- Get flags as a formatted string for display
function pas.flags.GetFlagsString(ply)
	local flags = pas.flags.GetPlayerFlags(ply)
	local flagStr = ''
	
	for flag, _ in pairs(flags) do
		local info = pas.flags.GetFlagInfo(flag)
		if info then
			flagStr = flagStr .. flag .. ' '
		end
	end
	
	return flagStr:Trim()
end
