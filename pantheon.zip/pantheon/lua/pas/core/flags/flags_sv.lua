-- PANTHEON Admin System - Flags System (Server)

-- Give a player an individual flag (separate from rank)
function pas.flags.GivePlayerFlag(ply, flag)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if not pas.flags.list[flag] then 
		pas.print('Unknown flag: ' .. flag)
		return false 
	end
	
	ply.pas_CustomFlags = ply.pas_CustomFlags or {}
	ply.pas_CustomFlags[flag] = true
	
	-- Save to database
	pas.data.SavePlayerFlags(ply)
	
	-- Network to client
	pas.flags.NetworkPlayerFlags(ply)
	
	pas.print(ply:Nick() .. ' was given flag: ' .. flag)
	return true
end

-- Remove a player's individual flag
function pas.flags.RemovePlayerFlag(ply, flag)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	
	ply.pas_CustomFlags = ply.pas_CustomFlags or {}
	ply.pas_CustomFlags[flag] = nil
	
	-- Save to database
	pas.data.SavePlayerFlags(ply)
	
	-- Network to client
	pas.flags.NetworkPlayerFlags(ply)
	
	pas.print(ply:Nick() .. ' had flag removed: ' .. flag)
	return true
end

-- Load player flags from database
function pas.flags.LoadPlayerFlags(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	if not pas.data or not pas.data.Query then 
		-- Database not ready yet, try again later
		timer.Simple(1, function()
			if IsValid(ply) then
				pas.flags.LoadPlayerFlags(ply)
			end
		end)
		return
	end
	
	local steamid = ply:SteamID()
	
	pas.data.Query('SELECT custom_flags FROM pas_players WHERE steamid = ?', {steamid}, function(data)
		if data and data[1] and data[1].custom_flags then
			local flagsData = data[1].custom_flags
			if flagsData and flagsData ~= '' then
				ply.pas_CustomFlags = util.JSONToTable(flagsData) or {}
			else
				ply.pas_CustomFlags = {}
			end
		else
			ply.pas_CustomFlags = {}
		end
		
		-- Network to client
		pas.flags.NetworkPlayerFlags(ply)
	end)
end

-- Save player flags to database
function pas.data.SavePlayerFlags(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	
	local steamid = ply:SteamID()
	local flagsJSON = util.TableToJSON(ply.pas_CustomFlags or {})
	
	-- First check if player exists, only create if they don't exist (preserve password data)
	pas.data.Query('SELECT steamid FROM pas_players WHERE steamid = ?', {steamid}, 
		function(data)
			if not data or #data == 0 then
				-- Player doesn't exist, create new record
				pas.data.Query('INSERT INTO pas_players (steamid, usergroup) VALUES (?, ?)', 
					{steamid, ply:GetUserGroup()})
			end
			
			-- Always update flags (this won't affect password fields)
			pas.data.Query('UPDATE pas_players SET custom_flags = ? WHERE steamid = ?', 
				{flagsJSON, steamid})
		end
	)
end

-- Network player flags to client
function pas.flags.NetworkPlayerFlags(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	if not netstream then return end
	
	local flags = ply.pas_CustomFlags or {}
	
	netstream.Start(ply, 'pas_player_flags', {
		flags = flags
	})
end

-- Network all player flags to a player (when they join)
function pas.flags.NetworkAllFlags(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	if not netstream then return end
	
	local allPlayerFlags = {}
	
	for _, pl in ipairs(player.GetAll()) do
		if pl.pas_CustomFlags then
			allPlayerFlags[pl:SteamID()] = pl.pas_CustomFlags
		end
	end
	
	netstream.Start(ply, 'pas_all_player_flags', {
		players = allPlayerFlags
	})
end

-- Make sure custom_flags column exists in database
hook.Add('pas_DatabaseReady', 'pas_flags_InitDatabase', function()
	-- Check if column exists, if not add it
	pas.data.Query([[
		SELECT custom_flags FROM pas_players LIMIT 1
	]], {}, function()
		-- Column exists, do nothing
	end, function(err)
		-- Column doesn't exist, add it
		pas.data.Query([[
			ALTER TABLE pas_players ADD COLUMN custom_flags TEXT DEFAULT '{}'
		]])
		pas.print('Added custom_flags column to database')
	end)
end)

-- Grant all flags in singleplayer mode
local function GrantSingleplayerFlags(ply)
	if not game.SinglePlayer() or not IsValid(ply) then return end
	
	timer.Simple(4, function()
		if not IsValid(ply) then return end
		
		-- Give all available flags
		ply.pas_CustomFlags = {}
		
		-- Grant all flags from the flag list
		for flag, _ in pairs(pas.flags.list) do
			ply.pas_CustomFlags[flag] = true
		end
		
		-- Special flags for superadmin access
		ply.pas_CustomFlags['*'] = true -- Universal access
		
		-- Save to database
		pas.data.SavePlayerFlags(ply)
		
		-- Network to client
		pas.flags.NetworkPlayerFlags(ply)
		
		pas.print('[PANTHEON] Singleplayer: Granted all flags to ' .. ply:Nick())
	end)
end

-- Load player flags when they spawn
hook.Add('PlayerInitialSpawn', 'pas_flags_LoadOnJoin', function(ply)
	timer.Simple(1, function()
		if IsValid(ply) then
			pas.flags.LoadPlayerFlags(ply)
			pas.flags.NetworkAllFlags(ply)
			
			-- Grant singleplayer flags
			-- DISABLED: Auto-admin on spawn
			-- GrantSingleplayerFlags(ply)
		end
	end)
end)

-- Metatable functions
function PLAYER:GiveFlag(flag)
	return pas.flags.GivePlayerFlag(self, flag)
end

function PLAYER:RemoveFlag(flag)
	return pas.flags.RemovePlayerFlag(self, flag)
end

function PLAYER:GetCustomFlags()
	return self.pas_CustomFlags or {}
end
