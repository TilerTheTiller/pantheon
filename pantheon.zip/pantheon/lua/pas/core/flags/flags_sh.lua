-- PANTHEON Admin System - Flags/Permissions System

pas.flags = pas.flags or {}

-- ===========================================================================
-- DONT TOUCH FLAGS UNLESS YOU KNOW WHAT YOU'RE DOING!!!!!!!
-- ===========================================================================
pas.flags.list = {
	-- Basic permissions
	['u'] = { name = 'User', 			desc = 'Basic user access' },
	['v'] = { name = 'VIP', 			desc = 'VIP features and perks' },
	['m'] = { name = 'Moderator', 		desc = 'Basic moderation (kick, freeze, noclip)' },
	['k'] = { name = 'Kick', 			desc = 'Kick players from server' },
	['b'] = { name = 'Ban', 			desc = 'Ban and unban players' },
	['w'] = { name = 'Warn', 			desc = 'Warn and manage player warnings' },
	['a'] = { name = 'Admin', 			desc = 'Admin features (slay, god, teleport)' },
	['s'] = { name = 'Superadmin', 		desc = 'Superadmin features (manage ranks)' },
	['r'] = { name = 'Root', 			desc = 'Root/RCON access and server management' },
	['l'] = { name = 'Logs', 			desc = 'View admin logs' },
	['c'] = { name = 'Chat', 			desc = 'Admin chat access' },
	['p'] = { name = 'Physgun', 		desc = 'Admin physgun permissions' },
	['t'] = { name = 'Tools', 			desc = 'Access to admin tools' },
    ['g'] = { name = 'Gamemaster',      desc = 'Gamemaster features (spawn entities, edit maps)' },
	['*'] = { name = 'All', 			desc = 'All permissions (wildcard)' },
}

-- Check if a player has a specific flag
function pas.flags.HasFlag(ply, flag)
	if not IsValid(ply) then return false end
	
	-- Console always has all flags
	if not ply:IsPlayer() then return true end
	
	-- Singleplayer override - player always has all flags in singleplayer
	if game.SinglePlayer() then return true end
	
	-- Get player's rank table (not just the name)
	local rank = ply:GetRankTable()
	if not rank then return false end
	
	-- Check for wildcard flag
	if rank:HasFlag('*') then return true end
	
	-- Check if rank has this specific flag
	if rank:HasFlag(flag) then return true end
	
	-- Check individual player flags (stored on player object)
	if ply.pas_CustomFlags and ply.pas_CustomFlags[flag] then
		return true
	end
	
	return false
end

-- Check if player has ANY of the given flags
function pas.flags.HasAnyFlag(ply, ...)
	local flags = {...}
	for _, flag in ipairs(flags) do
		if pas.flags.HasFlag(ply, flag) then
			return true
		end
	end
	return false
end

-- Check if player has ALL of the given flags
function pas.flags.HasAllFlags(ply, ...)
	local flags = {...}
	for _, flag in ipairs(flags) do
		if not pas.flags.HasFlag(ply, flag) then
			return false
		end
	end
	return true
end

-- Get all flags for a player (from rank and individual)
function pas.flags.GetPlayerFlags(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return {} end
	
	local allFlags = {}
	
	-- Get flags from rank table
	local rank = ply:GetRankTable()
	if rank then
		local rankFlags = rank:GetFlags() or {}
		for _, flag in ipairs(rankFlags) do
			allFlags[flag] = true
		end
	end
	
	-- Get individual flags
	if ply.pas_CustomFlags then
		for flag, _ in pairs(ply.pas_CustomFlags) do
			allFlags[flag] = true
		end
	end
	
	return allFlags
end

-- Get flag info
function pas.flags.GetFlagInfo(flag)
	return pas.flags.list[flag]
end

-- Get all flags
function pas.flags.GetAllFlags()
	return pas.flags.list
end

-- Check if a player can run a command based on its flag
function pas.flags.CanRunCommand(ply, cmd)
	if not IsValid(ply) then return true end -- Console can run all
	if not ply:IsPlayer() then return true end
	
	local flag = cmd:GetFlag()
	if not flag then return true end -- No flag requirement
	
	return pas.flags.HasFlag(ply, flag)
end

-- Metatable functions for easy flag checking
function PLAYER:HasFlag(flag)
	return pas.flags.HasFlag(self, flag)
end

function PLAYER:HasAnyFlag(...)
	return pas.flags.HasAnyFlag(self, ...)
end

function PLAYER:HasAllFlags(...)
	return pas.flags.HasAllFlags(self, ...)
end

function PLAYER:GetFlags()
	return pas.flags.GetPlayerFlags(self)
end

function PLAYER:CanRunCommand(cmd)
	return pas.flags.CanRunCommand(self, cmd)
end
