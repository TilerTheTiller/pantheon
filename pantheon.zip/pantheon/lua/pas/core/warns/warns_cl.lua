-- PANTHEON Warns System - Client
-- Responsive UI for warning management matching the logs system design

if (SERVER) then return end

-- Ensure pas.warns exists (should be created by shared file, but just in case)
pas = pas or {}
pas.warns = pas.warns or {}
pas.warns.categories = pas.warns.categories or {}

-- Fallback helper functions if shared file hasn't loaded yet
pas.warns.GetCategory = pas.warns.GetCategory or function(id)
	return pas.warns.categories[id] or pas.warns.categories.general or {
		name = 'Unknown',
		color = Color(128, 128, 128),
		icon = 'error'
	}
end

pas.warns.TimeAgo = pas.warns.TimeAgo or function(timestamp)
	local diff = os.time() - timestamp
	
	if diff < 60 then
		return diff .. ' second' .. (diff ~= 1 and 's' or '') .. ' ago'
	elseif diff < 3600 then
		local mins = math.floor(diff / 60)
		return mins .. ' minute' .. (mins ~= 1 and 's' or '') .. ' ago'
	elseif diff < 86400 then
		local hours = math.floor(diff / 3600)
		return hours .. ' hour' .. (hours ~= 1 and 's' or '') .. ' ago'
	elseif diff < 2592000 then
		local days = math.floor(diff / 86400)
		return days .. ' day' .. (days ~= 1 and 's' or '') .. ' ago'
	else
		local months = math.floor(diff / 2592000)
		return months .. ' month' .. (months ~= 1 and 's' or '') .. ' ago'
	end
end

-- Store callbacks for warn requests
local warnRequestCallbacks = {}

-- Set up network receiver for warnings data
net.Receive('pas.warns.receive', function()
	local warns = net.ReadTable()
	local total = net.ReadUInt(32)
	
	-- Call all waiting callbacks
	for _, callback in ipairs(warnRequestCallbacks) do
		if callback then
			callback(warns, total)
		end
	end
	
	-- Clear callbacks
	warnRequestCallbacks = {}
end)

-- Listen for warnings updates
net.Receive('pas.warns.update', function()
	-- Refresh the warns viewer if it's open
	if IsValid(pas.warns.viewer) then
		if pas.warns.viewer.RefreshWarns and type(pas.warns.viewer.RefreshWarns) == "function" then
			pas.warns.viewer.RefreshWarns()
		end
	end
end)

-- Listen for menu open requests
net.Receive('pas.warns.open_menu', function()
	if pas.warns and pas.warns.OpenMenu and type(pas.warns.OpenMenu) == "function" then
		pas.warns.OpenMenu()
	else
		ErrorNoHalt('[PANTHEON WARNS] OpenMenu function not available on client!\n')
		if IsValid(LocalPlayer()) then
			LocalPlayer():ChatPrint('[ERROR] Warns menu not ready. Please try again in a moment.')
		end
	end
end)

-- Request warns from server
function pas.warns.Request(category, search, steamid, active_only, limit, offset, callback)
	if callback then
		table.insert(warnRequestCallbacks, callback)
	end
	
	net.Start('pas.warns.get')
		net.WriteString(category or 'all')
		net.WriteString(search or '')
		net.WriteString(steamid or '')
		net.WriteBool(active_only or false)
		net.WriteUInt(limit or 100, 16)
		net.WriteUInt(offset or 0, 16)
	net.SendToServer()
end

-- Add a warning
function pas.warns.AddWarning(steamid, reason, category, callback)
	net.Start('pas.warns.add')
		net.WriteString(steamid)
		net.WriteString(reason)
		net.WriteString(category or 'general')
	net.SendToServer()
	
	if callback then
		timer.Simple(0.5, callback)
	end
end

-- Remove a warning
function pas.warns.RemoveWarning(warn_id, reason, callback)
	net.Start('pas.warns.remove')
		net.WriteUInt(warn_id, 32)
		net.WriteString(reason or 'No reason provided')
	net.SendToServer()
	
	if callback then
		timer.Simple(0.5, callback)
	end
end

-- Clear all warnings
function pas.warns.ClearWarnings(steamid, callback)
	net.Start('pas.warns.clear')
		net.WriteString(steamid)
	net.SendToServer()
	
	if callback then
		timer.Simple(0.5, callback)
	end
end

-- Create warns viewer UI (matching logs system design)
function pas.warns.OpenMenu()
	print('[PANTHEON WARNS] OpenMenu() called')
	
	-- Check if UI library is loaded
	if not ui then
		print('[PANTHEON WARNS] UI library not loaded yet, waiting...')
		
		-- Check if PANTHEON_UI_LOADED flag exists
		if not PANTHEON_UI_LOADED then
			LocalPlayer():ChatPrint('[INFO] Loading UI system, please wait...')
			
			-- Wait for UI to load with hook
			local hookName = 'PANTHEON_WARNS_WaitForUI_' .. math.random(1, 999999)
			hook.Add('PANTHEON_UI_Loaded', hookName, function()
				print('[PANTHEON WARNS] UI system now loaded, opening menu')
				timer.Simple(0.1, function()
					pas.warns.OpenMenu()
				end)
				hook.Remove('PANTHEON_UI_Loaded', hookName)
			end)
			
			-- Fallback: try again after a short delay
			timer.Simple(1, function()
				if ui and ui.CreateFrame then
					print('[PANTHEON WARNS] UI loaded via fallback timer')
					hook.Remove('PANTHEON_UI_Loaded', hookName)
					pas.warns.OpenMenu()
				else
					ErrorNoHalt('[PANTHEON WARNS] UI library failed to load after waiting!\n')
					LocalPlayer():ChatPrint('[ERROR] UI system failed to load. Please report this issue.')
				end
			end)
			
			return
		else
			ErrorNoHalt('[PANTHEON WARNS] UI library (ui) not loaded!\n')
			LocalPlayer():ChatPrint('[ERROR] UI system not ready. Please wait a moment and try again.')
			return
		end
	end
	print('[PANTHEON WARNS] UI library loaded')
	
	if not ui.CreateFrame then
		ErrorNoHalt('[PANTHEON WARNS] ui.CreateFrame not available!\n')
		LocalPlayer():ChatPrint('[ERROR] UI components not fully loaded. Please wait a moment and try again.')
		return
	end
	print('[PANTHEON WARNS] ui.CreateFrame exists')
	
	if not ui.col then
		ErrorNoHalt('[PANTHEON WARNS] ui.col (color system) not available!\n')
		LocalPlayer():ChatPrint('[ERROR] UI color system not loaded. Please wait a moment and try again.')
		return
	end
	print('[PANTHEON WARNS] ui.col exists')
	
	if not pas.warns.categories then
		ErrorNoHalt('[PANTHEON WARNS] Warning categories not loaded! Shared file may not be loaded yet.\n')
		LocalPlayer():ChatPrint('[ERROR] Warns system not fully initialized. Please wait a moment and try again.')
		return
	end
	print('[PANTHEON WARNS] pas.warns.categories exists')
	
	if IsValid(pas.warns.viewer) then
		print('[PANTHEON WARNS] Removing existing viewer')
		pas.warns.viewer:Remove()
	end
	
	print('[PANTHEON WARNS] Creating main frame...')
	-- Create main frame with icon
	local frame = ui.CreateFrame('Warning Management', 1400, 700, 'error')
	pas.warns.viewer = frame
	print('[PANTHEON WARNS] Main frame created successfully')
	
	-- Particle system for background (matching logs)
	local particles = {}
	for i = 1, 20 do
		table.insert(particles, {
			x = math.random(0, frame:GetWide()),
			y = math.random(0, frame:GetTall()),
			size = math.random(2, 6),
			speedX = math.Rand(-0.3, 0.3),
			speedY = math.Rand(-0.5, -0.1),
			alpha = math.random(30, 80)
		})
	end
	
	-- Override frame paint to add grid background and particles
	local basePaint = frame.Paint
	frame.Paint = function(self, w, h)
		-- Draw semi-transparent blurred background
		draw.RoundedBox(8, 0, 0, w, h, ColorAlpha(ui.col.BackgroundDark, 240))
		
		-- Draw grid background overlay
		local gridMat = ui.GetIcon('grid-bg')
		if gridMat then
			surface.SetDrawColor(255, 255, 255, 15)
			surface.SetMaterial(gridMat)
			surface.DrawTexturedRect(0, 0, w, h)
		end
		
		-- Draw vignette overlay
		local vignetteMat = ui.GetIcon('vignette')
		if vignetteMat then
			surface.SetDrawColor(0, 0, 0, 60)
			surface.SetMaterial(vignetteMat)
			surface.DrawTexturedRect(0, 0, w, h)
		end
		
		-- Draw and update particles
		for _, p in ipairs(particles) do
			-- Update position
			p.x = p.x + p.speedX
			p.y = p.y + p.speedY
			
			-- Wrap around
			if p.y < -10 then p.y = h + 10 end
			if p.y > h + 10 then p.y = -10 end
			if p.x < -10 then p.x = w + 10 end
			if p.x > w + 10 then p.x = -10 end
			
			-- Draw particle glow first (larger)
			local glowSize = p.size * 3
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, p.alpha * 0.4)
			surface.DrawRect(p.x - glowSize/2, p.y - glowSize/2, glowSize, glowSize)
			
			-- Draw particle core (brighter)
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, p.alpha * 1.5)
			surface.DrawRect(p.x - p.size/2, p.y - p.size/2, p.size, p.size)
		end
		
		-- Draw top header bar
		draw.RoundedBoxEx(8, 0, 0, w, 35, ColorAlpha(ui.col.BackgroundCard, 200), true, true, false, false)
		
		-- Icon and title
		ui.DrawIcon('error', 18, 17, 20, ui.col.PANTHEON)
		draw.SimpleText('Warning Management', 'PANTHEON.20', 45, 17, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	-- Search and filter container
	local filterPanel = ui.CreatePanel(frame, 10, 45, frame:GetWide() - 20, 60)
	filterPanel:SetPaintBackground(false)
	
	function filterPanel:Paint(w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Top accent line
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, 0, w, 2)
	end
	
	-- Category filter
	local categoryLabel = vgui.Create('DLabel', filterPanel)
	categoryLabel:SetPos(10, 15)
	categoryLabel:SetSize(70, 30)
	categoryLabel:SetText('Category:')
	categoryLabel:SetFont('PANTHEON.16')
	categoryLabel:SetTextColor(ui.col.TextDim)
	
	local categoryBox = ui.CreateComboBox(filterPanel, 85, 15, 140, 30)
	categoryBox:SetValue('All Categories')
	categoryBox:AddChoice('All Categories', 'all')
	
	for id, cat in SortedPairsByMemberValue(pas.warns.categories, 'name') do
		categoryBox:AddChoice(cat.name, id)
	end
	
	-- Search box
	local searchLabel = vgui.Create('DLabel', filterPanel)
	searchLabel:SetPos(240, 15)
	searchLabel:SetSize(60, 30)
	searchLabel:SetText('Search:')
	searchLabel:SetFont('PANTHEON.16')
	searchLabel:SetTextColor(ui.col.TextDim)
	
	local searchBox = ui.CreateTextEntry(filterPanel, 305, 15, 200, 30, 'Search warnings...')
	
	-- SteamID filter
	local steamidLabel = vgui.Create('DLabel', filterPanel)
	steamidLabel:SetPos(520, 15)
	steamidLabel:SetSize(65, 30)
	steamidLabel:SetText('SteamID:')
	steamidLabel:SetFont('PANTHEON.16')
	steamidLabel:SetTextColor(ui.col.TextDim)
	
	local steamidBox = ui.CreateTextEntry(filterPanel, 590, 15, 160, 30, 'Filter by SteamID...')
	
	-- Active only checkbox
	local activeOnlyCheck = ui.CreateCheckBox(filterPanel, 'Active Only', 765, 15)
	activeOnlyCheck:SetChecked(true)
	activeOnlyCheck:SetFont('PANTHEON.16')
	activeOnlyCheck:SetTextColor(ui.col.TextDim)
	
	-- Refresh button
	local refreshBtn = ui.CreateButton(filterPanel, 'Refresh', 880, 15, 90, 30, nil, 'arrow-right')
	
	-- Add warning button
	local addBtn = vgui.Create('DButton', filterPanel)
	addBtn:SetPos(980, 15)
	addBtn:SetSize(130, 30)
	addBtn:SetText('Add Warning')
	addBtn:SetFont('PANTHEON.16')
	
	addBtn.OnCursorEntered = function()
		-- Button hover effect handled by skin
	end
	
	-- Main warns panel
	local warnsPanel = ui.CreatePanel(frame, 10, 115, frame:GetWide() - 20, frame:GetTall() - 170)
	warnsPanel:SetPaintBackground(false)
	
	function warnsPanel:Paint(w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Header with gradient
		draw.RoundedBox(6, 0, 0, w, 40, ui.col.BackgroundCard)
		
		-- Accent line
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, h - 2, w, 2)
		
		-- Icon and title
		ui.DrawIcon('error', 18, 20, 20, ui.col.PANTHEON)
		draw.SimpleText('Warning Entries', 'PANTHEON.18', 45, 20, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	-- Warn list
	local warnList = ui.CreateList(warnsPanel, 8, 48, warnsPanel:GetWide() - 16, warnsPanel:GetTall() - 56)
	warnList:AddColumn('ID', 40)
	warnList:AddColumn('Time', 130)
	warnList:AddColumn('Player', 140)
	warnList:AddColumn('Category', 110)
	warnList:AddColumn('Reason', 340)
	warnList:AddColumn('Admin', 130)
	warnList:AddColumn('Status', 80)
	
	-- Store expanded state for each line
	local expandedLines = {}
	
	-- Custom list paint for category colors
	warnList.OnRowRightClick = function(self, index, line)
		local menu = DermaMenu()
		menu:SetSkin('PANTHEON')
		menu:SetMinimumWidth(180)
		
		local copyOption = menu:AddOption('Copy Reason', function()
			SetClipboardText(line:GetValue(5))
			ui.Notify('Reason copied to clipboard', NOTIFY_GENERIC, 3)
		end)
		
		local copyText = copyOption:GetText()
		copyOption:SetText('')
		copyOption:SetContentAlignment(4)
		copyOption.Paint = function(pnl, w, h)
			if pnl:IsHovered() then
				surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 30)
				surface.DrawRect(0, 0, w, h)
			end
			
			ui.DrawIcon('paste', 10, h/2, 16, ui.col.TEXT)
			draw.SimpleText(copyText, 'PANTHEON.14', 35, h/2, ui.col.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			return true
		end
		
		-- Show remove option for active warnings
		if line.active then
			menu:AddSpacer()
			
			local removeOption = menu:AddOption('Remove Warning', function()
				-- Create custom styled dialog
				local confirmFrame = vgui.Create('DFrame')
				confirmFrame:SetSize(450, 200)
				confirmFrame:Center()
				confirmFrame:SetTitle('')
				confirmFrame:SetDraggable(true)
				confirmFrame:ShowCloseButton(false)
				confirmFrame:MakePopup()
				
				confirmFrame.Paint = function(self, w, h)
					-- Background
					draw.RoundedBox(8, 0, 0, w, h, ui.col.BackgroundDark)
					
					-- Header with red accent
					draw.RoundedBoxEx(8, 0, 0, w, 40, ColorAlpha(Color(220, 53, 69), 200), true, true, false, false)
					ui.DrawIcon('cancel', 15, 20, 20, ui.col.White)
					draw.SimpleText('Remove Warning', 'PANTHEON.18', 45, 20, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					
					-- Border
					surface.SetDrawColor(220, 53, 69, 150)
					surface.DrawOutlinedRect(0, 0, w, h, 2)
				end
				
				-- Warning message
				local msgLabel = vgui.Create('DLabel', confirmFrame)
				msgLabel:SetPos(20, 55)
				msgLabel:SetSize(410, 20)
				msgLabel:SetFont('PANTHEON.14')
				msgLabel:SetText('Reason for removing this warning:')
				msgLabel:SetTextColor(ui.col.TEXT)
				
				-- Reason input
				local reasonBox = vgui.Create('DTextEntry', confirmFrame)
				reasonBox:SetPos(20, 80)
				reasonBox:SetSize(410, 30)
				reasonBox:SetFont('PANTHEON.14')
				reasonBox:SetText('Mistake/Invalid')
				reasonBox:SelectAllText()
				reasonBox:RequestFocus()
				
				reasonBox.Paint = function(self, w, h)
					draw.RoundedBox(4, 0, 0, w, h, ui.col.BackgroundCard)
					surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 100)
					surface.DrawOutlinedRect(0, 0, w, h, 1)
					self:DrawTextEntryText(ui.col.TEXT, ui.col.PANTHEON, ui.col.TEXT)
				end
				
				-- Confirm button
				local confirmBtn = vgui.Create('DButton', confirmFrame)
				confirmBtn:SetPos(245, 150)
				confirmBtn:SetSize(185, 35)
				confirmBtn:SetText('')
				confirmBtn:SetFont('PANTHEON.16')
				
				confirmBtn.Paint = function(self, w, h)
					local col = ColorAlpha(Color(220, 53, 69), self:IsHovered() and 220 or 180)
					draw.RoundedBox(6, 0, 0, w, h, col)
					
					ui.DrawIcon('check', 25, h/2, 16, ui.col.White)
					draw.SimpleText('Remove Warning', 'PANTHEON.14', w/2 + 8, h/2, ui.col.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				
				confirmBtn.DoClick = function()
					local reason = reasonBox:GetValue()
					if not reason or reason:Trim() == '' then
						reason = 'No reason provided'
					end
					
					pas.warns.RemoveWarning(line.warnId, reason, function()
						timer.Simple(0.5, function()
							if IsValid(frame) then
								refreshBtn:DoClick()
							end
						end)
					end)
					
					confirmFrame:Close()
				end
				
				-- Cancel button
				local cancelBtn = vgui.Create('DButton', confirmFrame)
				cancelBtn:SetPos(20, 150)
				cancelBtn:SetSize(185, 35)
				cancelBtn:SetText('')
				cancelBtn:SetFont('PANTHEON.16')
				
				cancelBtn.Paint = function(self, w, h)
					local col = ColorAlpha(ui.col.BackgroundCard, self:IsHovered() and 255 or 200)
					draw.RoundedBox(6, 0, 0, w, h, col)
					surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 100)
					surface.DrawOutlinedRect(0, 0, w, h, 1)
					
					ui.DrawIcon('close', 25, h/2, 16, ui.col.TEXT)
					draw.SimpleText('Cancel', 'PANTHEON.14', w/2 + 8, h/2, ui.col.TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				
				cancelBtn.DoClick = function()
					confirmFrame:Close()
				end
				
				-- Enter key support
				reasonBox.OnEnter = function()
					confirmBtn:DoClick()
				end
			end)
			
		local removeText = removeOption:GetText()
		removeOption:SetText('')
		removeOption:SetContentAlignment(4)
		removeOption.Paint = function(pnl, w, h)
			if pnl:IsHovered() then
				surface.SetDrawColor(220, 53, 69, 30)
				surface.DrawRect(0, 0, w, h)
			end
			
			ui.DrawIcon('delete', 10, h/2, 16, Color(220, 53, 69))
			draw.SimpleText(removeText, 'PANTHEON.14', 35, h/2, ui.col.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			return true
		end
	end
	
	menu:AddSpacer()		local idOption = menu:AddOption('Copy Warning ID', function()
			SetClipboardText(tostring(line.warnId or 'Unknown'))
			ui.Notify('Warning ID copied to clipboard', NOTIFY_GENERIC, 3)
		end)
		
		local idText = idOption:GetText()
		idOption:SetText('')
		idOption:SetContentAlignment(4)
		idOption.Paint = function(pnl, w, h)
			if pnl:IsHovered() then
				surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 30)
				surface.DrawRect(0, 0, w, h)
			end
			
			ui.DrawIcon('key', 10, h/2, 16, ui.col.TEXT)
			draw.SimpleText(idText, 'PANTHEON.14', 35, h/2, ui.col.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			return true
		end
		
		-- Copy Target SteamID
		local targetSteamOption = menu:AddOption('Copy Target SteamID', function()
			SetClipboardText(line.targetSteamID or 'Unknown')
			ui.Notify('Target SteamID copied to clipboard', NOTIFY_GENERIC, 3)
		end)
		
		local targetSteamText = targetSteamOption:GetText()
		targetSteamOption:SetText('')
		targetSteamOption:SetContentAlignment(4)
		targetSteamOption.Paint = function(pnl, w, h)
			if pnl:IsHovered() then
				surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 30)
				surface.DrawRect(0, 0, w, h)
			end
			
			ui.DrawIcon('user', 10, h/2, 16, ui.col.TEXT)
			draw.SimpleText(targetSteamText, 'PANTHEON.14', 35, h/2, ui.col.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			return true
		end
		
		-- Copy Admin SteamID
		local adminSteamOption = menu:AddOption('Copy Admin SteamID', function()
			SetClipboardText(line.adminSteamID or 'Unknown')
			ui.Notify('Admin SteamID copied to clipboard', NOTIFY_GENERIC, 3)
		end)
		
		local adminSteamText = adminSteamOption:GetText()
		adminSteamOption:SetText('')
		adminSteamOption:SetContentAlignment(4)
		adminSteamOption.Paint = function(pnl, w, h)
			if pnl:IsHovered() then
				surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 30)
				surface.DrawRect(0, 0, w, h)
			end
			
			ui.DrawIcon('shield', 10, h/2, 16, Color(138, 43, 226))
			draw.SimpleText(adminSteamText, 'PANTHEON.14', 35, h/2, ui.col.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			return true
		end
		
		menu:Open()
	end
	
	-- Footer panel
	local footerPanel = ui.CreatePanel(frame, 10, frame:GetTall() - 45, frame:GetWide() - 20, 35)
	footerPanel:SetPaintBackground(false)
	
	function footerPanel:Paint(w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Top accent line
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, 0, w, 2)
	end
	
	-- Page info
	local pageLabel = vgui.Create('DLabel', footerPanel)
	pageLabel:SetPos(15, 10)
	pageLabel:SetSize(400, 20)
	pageLabel:SetText('Showing 0 - 0 of 0 warnings')
	pageLabel:SetFont('PANTHEON.16')
	pageLabel:SetTextColor(ui.col.TextDim)
	
	-- Pagination
	local currentPage = 1
	local warnsPerPage = 100
	local totalWarns = 0
	
	local prevBtn = ui.CreateButton(footerPanel, 'Previous', footerPanel:GetWide() - 220, 5, 105, 25, nil, 'arrow-left')
	local nextBtn = ui.CreateButton(footerPanel, 'Next', footerPanel:GetWide() - 110, 5, 105, 25, nil, 'arrow-right')
	
	-- Load warns function
	local function LoadWarns()
		warnList:Clear()
		
		local _, catValue = categoryBox:GetSelected()
		local search = searchBox:GetValue()
		local steamid = steamidBox:GetValue()
		local active_only = activeOnlyCheck:GetChecked()
		local offset = (currentPage - 1) * warnsPerPage
		
		pas.warns.Request(catValue, search, steamid, active_only, warnsPerPage, offset, function(warns, total)
			-- Validate that the frame still exists
			if not IsValid(frame) or not IsValid(warnList) then return end
			
			totalWarns = total
			
			for _, warn in ipairs(warns) do
				local timeStr = os.date('%Y-%m-%d %H:%M:%S', warn.timestamp)
				local category = pas.warns.GetCategory(warn.category)
				
				-- Handle player names with fallback to SteamID
				local playerName = warn.target_name
				if not playerName or playerName == '' or playerName == 'NULL' then
					playerName = warn.steamid or 'Unknown'
				end
				
				local adminName = warn.admin_name
				if not adminName or adminName == '' or adminName == 'NULL' then
					adminName = warn.admin_steamid or 'Unknown Admin'
				end
				
				-- Convert active to number for consistent comparison
				local activeNum = tonumber(warn.active)
				local isActive = (activeNum == 1)
				local status = isActive and 'Active' or 'Removed'
				
				local line = warnList:AddLine(
					warn.id,
					timeStr,
					playerName,
					category.name,
					warn.reason,
					adminName,
					status
				)
				
			line.category = warn.category
			line.warnId = warn.id
			line.active = isActive
			line.fullReason = warn.reason
			line.fullPlayerName = playerName
			line.fullAdminName = adminName
			line.targetSteamID = warn.steamid or 'Unknown'
			line.adminSteamID = warn.admin_steamid or 'Unknown'
		line.timestamp = warn.timestamp
		line.removeReason = warn.remove_reason
		line.removeAdmin = warn.remove_admin_steamid
		line.expanded = false
		line.HoverFraction = 0
		
		-- Click to expand/collapse
		line.OnMousePressed = function(self, keyCode)
			if keyCode == MOUSE_LEFT then
				self.expanded = not self.expanded
				-- Force the line to update its size
				self:InvalidateLayout(true)
				-- Force the list to recalculate layout
				if IsValid(warnList) then
					warnList:InvalidateLayout(true)
				end
			elseif keyCode == MOUSE_RIGHT then
				-- Trigger right-click menu directly
				if warnList.OnRowRightClick then
					warnList:OnRowRightClick(nil, self)
				end
			end
		end
		
		-- Override PerformLayout to update size
		line.PerformLayout = function(self, w, h)
			self:SetTall(self.expanded and 180 or 24)
		end			-- Custom line colors based on category and status
			-- Use PaintOver instead of Paint to preserve text drawing
			line.PaintOver = function(self, w, h)
				local cat = pas.warns.GetCategory(self.category)
				local baseColor = cat.color
				
				-- Category indicator stripe
				surface.SetDrawColor(baseColor.r, baseColor.g, baseColor.b, self.active and 200 or 80)
				surface.DrawRect(0, 0, 4, h)
				
				-- Draw expand indicator
				if self:IsHovered() then
					local iconName = self.expanded and 'chevron-up' or 'chevron-down'
					ui.DrawIcon(iconName, w - 25, h/2, 16, ui.col.TEXT_DIM)
				end
			end
			
			-- Override GetTall to handle expansion
			line.GetTall = function(self)
				return self.expanded and 180 or 24
			end
			
			-- Override the base Paint to customize background colors
			local basePaint = line.Paint
			line.Paint = function(self, w, h)
				local cat = pas.warns.GetCategory(self.category)
				local baseColor = cat.color
				
				if not self.active then
					baseColor = ColorAlpha(Color(128, 128, 128), 50)
				end
				
				-- Custom background based on category
				self.HoverFraction = Lerp(FrameTime() * 12, self.HoverFraction, (self:IsHovered() or self.Selected) and 1 or 0)
				
				-- Background with category tint
				local bgColor = ColorAlpha(baseColor, self.active and 20 or 10)
				
				if self.Selected then
					bgColor = ColorAlpha(ui.col.PANTHEON, 180)
				elseif self.HoverFraction > 0 then
					bgColor = ColorAlpha(baseColor, 60 * self.HoverFraction)
				end
				
				surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, bgColor.a or 255)
				surface.DrawRect(0, 0, w, h)
				
				-- Left accent bar for selected
				if self.Selected then
					surface.SetDrawColor(ui.col.PANTHEON_LIGHT.r, ui.col.PANTHEON_LIGHT.g, ui.col.PANTHEON_LIGHT.b, 255)
					surface.DrawRect(0, 0, 3, h)
				end
				
				-- Separator line
				if not self.Selected then
					surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 40)
					surface.DrawRect(0, h - 1, w, 1)
				end
			
			-- Draw content based on expanded state
			local xPos = warnList.Padding or 8
			
			if self.expanded then
			-- Expanded view with detailed information
			local padding = 12
			local yOffset = 10
			local textColor = ui.col.TEXT
			local labelColor = ui.col.TEXT_DIM
			local labelFont = 'PANTHEON.12'
			local valueFont = 'PANTHEON.14'
			
			-- Row 1: ID and Status (top bar)
			draw.SimpleText('Warning #' .. tostring(self.Values[1]), 'PANTHEON.16', padding, yOffset, ui.col.White)
			
			local statusColor = self.active and Color(46, 204, 113) or Color(220, 53, 69)
			local statusText = tostring(self.Values[7])
			surface.SetFont('PANTHEON.14')
			local statusW = surface.GetTextSize(statusText)
			draw.SimpleText(statusText, 'PANTHEON.14', w - padding - statusW, yOffset + 2, statusColor)
			
			yOffset = yOffset + 26
			
			-- Separator line
			surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
			surface.DrawRect(padding, yOffset, w - padding * 2, 1)
			
			yOffset = yOffset + 10
			
			-- Row 2: Date/Time
			draw.SimpleText('Date:', labelFont, padding, yOffset, labelColor)
			draw.SimpleText(tostring(self.Values[2]), valueFont, padding + 60, yOffset, textColor)
			
			yOffset = yOffset + 20
			
			-- Row 3: Player
			draw.SimpleText('Player:', labelFont, padding, yOffset, labelColor)
			draw.SimpleText(self.fullPlayerName, valueFont, padding + 60, yOffset, textColor)
			
			-- Category on same row (right side)
			local cat = pas.warns.GetCategory(self.category)
			local catX = math.floor(w * 0.55)
			draw.SimpleText('Category:', labelFont, catX, yOffset, labelColor)
			
			-- Draw category pill/badge
			local catTextW = surface.GetTextSize(cat.name)
			local pillW = catTextW + 16
			local pillX = catX + 75
			surface.SetDrawColor(cat.color.r, cat.color.g, cat.color.b, 30)
			draw.RoundedBox(4, pillX, yOffset - 2, pillW, 18, Color(cat.color.r, cat.color.g, cat.color.b, 30))
			draw.SimpleText(cat.name, labelFont, pillX + 8, yOffset, cat.color)
			
			yOffset = yOffset + 24
			
			-- Row 4: Admin
			draw.SimpleText('Admin:', labelFont, padding, yOffset, labelColor)
			draw.SimpleText(self.fullAdminName, valueFont, padding + 60, yOffset, textColor)
			
			yOffset = yOffset + 24
			
			-- Row 5: Reason section with background
			surface.SetDrawColor(ui.col.BackgroundDark.r, ui.col.BackgroundDark.g, ui.col.BackgroundDark.b, 40)
			local reasonBoxH = h - yOffset - padding - (self.active and 0 or 20)
			surface.DrawRect(padding, yOffset, w - padding * 2, reasonBoxH)
			
			yOffset = yOffset + 6
			draw.SimpleText('Reason:', labelFont, padding + 6, yOffset, labelColor)
			
			yOffset = yOffset + 18
			
			-- Draw wrapped reason text with better spacing
			local reasonText = self.fullReason or 'No reason provided'
			local maxWidth = w - padding * 3
			surface.SetFont(valueFont)
			local words = string.Explode(' ', reasonText)
			local textLine = ''
			local lineY = yOffset
			
			for i, word in ipairs(words) do
				local testLine = textLine .. (textLine == '' and '' or ' ') .. word
				local tw = surface.GetTextSize(testLine)
				
				if tw > maxWidth and textLine ~= '' then
					draw.SimpleText(textLine, valueFont, padding + 6, lineY, textColor)
					lineY = lineY + 18
					textLine = word
				else
					textLine = testLine
				end
			end
			
			if textLine ~= '' then
				draw.SimpleText(textLine, valueFont, padding + 6, lineY, textColor)
			end
			
			-- Show removal info if not active
			if not self.active and self.removeReason then
				surface.SetDrawColor(220, 53, 69, 20)
				surface.DrawRect(padding, h - padding - 16, w - padding * 2, 16)
				draw.SimpleText('Removed: ' .. (self.removeReason or 'No reason provided'), 'PANTHEON.12', padding + 6, h - padding - 14, Color(220, 53, 69))
			end
		else
			-- Collapsed view - draw columns with truncation
			for i, value in ipairs(self.Values) do
				if warnList.ColumnWidths[i] then
					local textColor = self.Selected and ui.col.White or (self.active and ui.col.TEXT or ui.col.TEXT_DIM)
					local font = self.Selected and 'PANTHEON.16' or 'PANTHEON.14'
					
					draw.SimpleText(tostring(value), font, xPos, h/2, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					xPos = xPos + warnList.ColumnWidths[i]
				end
			end
		end
	end
			end -- Close for _, warn in ipairs(warns) do

			-- Update page info
			if IsValid(pageLabel) then
				if total > 0 then
					local startNum = offset + 1
					local endNum = math.min(offset + #warns, total)
					pageLabel:SetText(string.format('Showing %d - %d of %d warnings', startNum, endNum, total))
				else
					pageLabel:SetText('No warnings found')
				end
			end
			
			-- Update button states
			if IsValid(prevBtn) then
				prevBtn:SetEnabled(currentPage > 1)
			end
			if IsValid(nextBtn) then
				nextBtn:SetEnabled(currentPage * warnsPerPage < total)
			end
		end)
	end -- Close LoadWarns function
	
	-- Store refresh function for external access
	frame.RefreshWarns = LoadWarns
	
	-- Button actions
	function refreshBtn:DoClick()
		currentPage = 1
		LoadWarns()
	end
	
	function prevBtn:DoClick()
		if currentPage > 1 then
			currentPage = currentPage - 1
			LoadWarns()
		end
	end
	
	function nextBtn:DoClick()
		if currentPage * warnsPerPage < totalWarns then
			currentPage = currentPage + 1
			LoadWarns()
		end
	end
	
	function categoryBox:OnSelect(index, value, data)
		currentPage = 1
		LoadWarns()
	end
	
	function searchBox:OnEnter()
		currentPage = 1
		LoadWarns()
	end
	
	function searchBox:OnChange()
		-- Debounce the search - only search after 500ms of no typing
		timer.Remove("warns_search_debounce")
		timer.Create("warns_search_debounce", 0.5, 1, function()
			if IsValid(self) then
				currentPage = 1
				LoadWarns()
			end
		end)
	end
	
	function steamidBox:OnEnter()
		currentPage = 1
		LoadWarns()
	end
	
	function steamidBox:OnChange()
		-- Debounce the steamid search
		timer.Remove("warns_steamid_debounce")
		timer.Create("warns_steamid_debounce", 0.5, 1, function()
			if IsValid(self) then
				currentPage = 1
				LoadWarns()
			end
		end)
	end
	
	function activeOnlyCheck:OnChange(val)
		currentPage = 1
		LoadWarns()
	end
	
	function addBtn:DoClick()
		if pas.warns and pas.warns.ShowAddDialog then
			pas.warns.ShowAddDialog(function()
				timer.Simple(0.5, function()
					if IsValid(frame) then
						refreshBtn:DoClick()
					end
				end)
			end)
		end
	end
	
	-- Initial load
	LoadWarns()
end -- Close pas.warns.OpenMenu()

-- Add warning dialog
function pas.warns.ShowAddDialog(callback)
	-- Check if UI library is loaded
	if not ui or not ui.CreateComboBox then
		ErrorNoHalt('[PANTHEON WARNS] UI library not loaded! Cannot open add dialog.\n')
		LocalPlayer():ChatPrint('[ERROR] UI system not ready. Please wait a moment and try again.')
		return
	end
	
	local frame = vgui.Create('DFrame')
	frame:SetTitle('')
	frame:SetSize(500, 350)
	frame:Center()
	frame:MakePopup()
	frame:SetSkin('PANTHEON')
	
	frame.Paint = function(self, w, h)
		local bgCol = ui.col and ui.col.Background or Color(30, 30, 35)
		local cardCol = ui.col and ui.col.BackgroundCard or Color(40, 40, 45)
		local pantheonCol = ui.col and ui.col.PANTHEON or Color(103, 58, 183)
		local whiteCol = ui.col and ui.col.White or Color(255, 255, 255)
		
		draw.RoundedBox(8, 0, 0, w, h, bgCol)
		
		-- Header
		draw.RoundedBoxEx(8, 0, 0, w, 35, cardCol, true, true, false, false)
		if ui.DrawIcon then
			ui.DrawIcon('plus', 18, 17, 20, pantheonCol)
		end
		draw.SimpleText('Add Warning', 'PANTHEON.18', 45, 17, whiteCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	-- Close button
	local closeBtn = vgui.Create('DButton', frame)
	closeBtn:SetText('×')
	closeBtn:SetSize(28, 28)
	closeBtn:SetPos(frame:GetWide() - 33, 3)
	closeBtn:SetFont('PANTHEON.24')
	closeBtn.DoClick = function() frame:Close() end
	
	-- Player dropdown
	local playerLabel = vgui.Create('DLabel', frame)
	playerLabel:SetPos(20, 50)
	playerLabel:SetSize(100, 25)
	playerLabel:SetText('Player:')
	playerLabel:SetFont('PANTHEON.16')
	playerLabel:SetTextColor(ui.col and ui.col.TEXT or Color(200, 200, 200))
	
	local playerBox = ui.CreateComboBox(frame, 20, 75, 460, 30)
	playerBox:SetValue('Select a player...')
	
	for _, ply in ipairs(player.GetAll()) do
		playerBox:AddChoice(ply:Nick(), ply:SteamID())
	end
	
	-- Category dropdown
	local catLabel = vgui.Create('DLabel', frame)
	catLabel:SetPos(20, 115)
	catLabel:SetSize(100, 25)
	catLabel:SetText('Category:')
	catLabel:SetFont('PANTHEON.16')
	catLabel:SetTextColor(ui.col and ui.col.TEXT or Color(200, 200, 200))
	
	local catBox = ui.CreateComboBox(frame, 20, 140, 460, 30)
	catBox:SetValue('General Warning')
	
	for id, cat in SortedPairsByMemberValue(pas.warns.categories, 'name') do
		catBox:AddChoice(cat.name, id)
	end
	
	-- Reason text entry
	local reasonLabel = vgui.Create('DLabel', frame)
	reasonLabel:SetPos(20, 180)
	reasonLabel:SetSize(100, 25)
	reasonLabel:SetText('Reason:')
	reasonLabel:SetFont('PANTHEON.16')
	reasonLabel:SetTextColor(ui.col and ui.col.TEXT or Color(200, 200, 200))
	
	local reasonBox = vgui.Create('DTextEntry', frame)
	reasonBox:SetPos(20, 205)
	reasonBox:SetSize(460, 80)
	reasonBox:SetMultiline(true)
	reasonBox:SetFont('PANTHEON.14')
	
	-- Submit button
	local submitBtn = vgui.Create('DButton', frame)
	submitBtn:SetPos(20, 300)
	submitBtn:SetSize(220, 35)
	submitBtn:SetText('Add Warning')
	submitBtn:SetFont('PANTHEON.16')
	
	submitBtn.DoClick = function()
		local _, steamid = playerBox:GetSelected()
		local _, category = catBox:GetSelected()
		local reason = reasonBox:GetValue()
		
		if not steamid or steamid == '' then
			ui.Notify('Please select a player', NOTIFY_ERROR, 5)
			return
		end
		
		if not reason or reason:Trim() == '' then
			ui.Notify('Please enter a reason', NOTIFY_ERROR, 5)
			return
		end
		
		pas.warns.AddWarning(steamid, reason, category, callback)
		frame:Close()
	end
	
	-- Cancel button
	local cancelBtn = vgui.Create('DButton', frame)
	cancelBtn:SetPos(260, 300)
	cancelBtn:SetSize(220, 35)
	cancelBtn:SetText('Cancel')
	cancelBtn:SetFont('PANTHEON.16')
	
	cancelBtn.DoClick = function()
		frame:Close()
	end
end

if pas.print then
	pas.print('[PANTHEON] Warns system (client) loaded')
else
	print('[PANTHEON] Warns system (client) loaded')
end
