-- PANTHEON Warns System - Shared
-- Handles warning management for players

pas.warns = pas.warns or {}

-- Warning categories with visual styling
pas.warns.categories = {
	general = {
		name = 'General Warning',
		color = Color(108, 117, 125),
		icon = 'error'
	},
	exploiting = {
		name = 'Exploiting',
		color = Color(220, 53, 69),
		icon = 'bug'
	},
	rdm = {
		name = 'RDM',
		color = Color(255, 87, 34),
		icon = 'skull'
	},
	toxicity = {
		name = 'Toxicity',
		color = Color(156, 39, 176),
		icon = 'chat-ban'
	},
	spam = {
		name = 'Spam',
		color = Color(255, 193, 7),
		icon = 'spam'
	},
	failrp = {
		name = 'FailRP',
		color = Color(33, 150, 243),
		icon = 'theater'
	},
	ltap = {
		name = 'LTAP',
		color = Color(244, 67, 54),
		icon = 'logout'
	},
	metagaming = {
		name = 'Metagaming',
		color = Color(139, 195, 74),
		icon = 'eye'
	},
	other = {
		name = 'Other',
		color = Color(158, 158, 158),
		icon = 'info'
	}
}

-- Get category info
function pas.warns.GetCategory(id)
	return pas.warns.categories[id] or pas.warns.categories.general
end

-- Helper function to get warn severity based on count
function pas.warns.GetSeverity(count)
	if count >= 5 then
		return 'critical', Color(220, 53, 69)
	elseif count >= 3 then
		return 'high', Color(255, 152, 0)
	elseif count >= 1 then
		return 'medium', Color(255, 193, 7)
	else
		return 'low', Color(76, 175, 80)
	end
end

-- Format time ago
function pas.warns.TimeAgo(timestamp)
	local diff = os.time() - timestamp
	
	if diff < 60 then
		return diff .. ' second' .. (diff ~= 1 and 's' or '') .. ' ago'
	elseif diff < 3600 then
		local mins = math.floor(diff / 60)
		return mins .. ' minute' .. (mins ~= 1 and 's' or '') .. ' ago'
	elseif diff < 86400 then
		local hours = math.floor(diff / 3600)
		return hours .. ' hour' .. (hours ~= 1 and 's' or '') .. ' ago'
	elseif diff < 2592000 then
		local days = math.floor(diff / 86400)
		return days .. ' day' .. (days ~= 1 and 's' or '') .. ' ago'
	else
		local months = math.floor(diff / 2592000)
		return months .. ' month' .. (months ~= 1 and 's' or '') .. ' ago'
	end
end

if SERVER then
	-- Network strings
	util.AddNetworkString('pas.warns.get')
	util.AddNetworkString('pas.warns.receive')
	util.AddNetworkString('pas.warns.add')
	util.AddNetworkString('pas.warns.remove')
	util.AddNetworkString('pas.warns.clear')
	util.AddNetworkString('pas.warns.open_menu')
	util.AddNetworkString('pas.warns.update')
end

pas.print('[PANTHEON] Warns system (shared) loaded')
