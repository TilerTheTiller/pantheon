-- PANTHEON Warns System - Server
-- SQL-based warning system with comprehensive database operations

if (CLIENT) then return end

-- Create warns table in database
function pas.warns.CreateTable()
	local db = pas.data.GetDB()
	if not db then 
		ErrorNoHalt('[PANTHEON WARNS] ERROR: No database connection!\n')
		return
	end
	
	-- Create warns table with proper schema
	db:query([[
		CREATE TABLE IF NOT EXISTS pas_warns (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			steamid VARCHAR(32) NOT NULL,
			admin_steamid VARCHAR(32) NOT NULL,
			reason TEXT NOT NULL,
			category VARCHAR(32) DEFAULT 'general',
			timestamp INTEGER NOT NULL,
			active INTEGER DEFAULT 1,
			removed_by VARCHAR(32) DEFAULT NULL,
			removed_at INTEGER DEFAULT NULL,
			removed_reason TEXT DEFAULT NULL
		)
	]])
	
	-- Create indexes for performance
	db:query([[
		CREATE INDEX IF NOT EXISTS idx_pas_warns_steamid ON pas_warns(steamid)
	]])
	
	db:query([[
		CREATE INDEX IF NOT EXISTS idx_pas_warns_active ON pas_warns(active)
	]])
	
	db:query([[
		CREATE INDEX IF NOT EXISTS idx_pas_warns_timestamp ON pas_warns(timestamp)
	]])
	
	db:query([[
		CREATE INDEX IF NOT EXISTS idx_pas_warns_category ON pas_warns(category)
	]])
	
	pas.print('[PANTHEON] Warns table created/verified')
end

-- Add a warning
function pas.warns.Add(steamid, admin_steamid, reason, category, callback)
	local db = pas.data.GetDB()
	if not db then 
		if callback then callback(false, 'No database connection') end
		return
	end
	
	category = category or 'general'
	local timestamp = os.time()
	
	-- Validate category
	if not pas.warns.categories[category] then
		category = 'general'
	end
	
	db:query_ex(
		'INSERT INTO pas_warns(steamid, admin_steamid, reason, category, timestamp, active) VALUES(?, ?, ?, ?, ?, 1)',
		{steamid, admin_steamid, reason, category, timestamp},
		function(result)
			if result then
				-- Log the warning
				local admin_name = 'Console'
				local target_name = 'Unknown'
				
				for _, ply in ipairs(player.GetAll()) do
					if ply:SteamID64() == admin_steamid or ply:SteamID() == admin_steamid then
						admin_name = ply:Nick()
					end
					if ply:SteamID() == steamid or ply:SteamID64() == steamid then
						target_name = ply:Nick()
					end
				end
				
				-- Notify the warned player if online
				local target = player.GetBySteamID(steamid)
				if IsValid(target) then
					pas.notify(target, 'You have been warned by ' .. admin_name .. ' for: ' .. reason, 1, 10)
					-- Send update to client
					net.Start('pas.warns.update')
					net.Send(target)
				end
				
				-- Check for auto-punishments based on warn count
				pas.warns.GetCount(steamid, true, function(count)
					if count >= 5 then
						-- Auto-ban for 5+ warnings
						local target = player.GetBySteamID(steamid)
						if IsValid(target) then
							target:Ban(1440, true) -- 24 hour ban
						end
					elseif count >= 3 then
						-- Auto-kick for 3+ warnings
						local target = player.GetBySteamID(steamid)
						if IsValid(target) then
							target:Kick('You have been kicked for accumulating ' .. count .. ' warnings. Rejoin in 5 minutes.')
						end
					end
				end)
				
				if callback then callback(true, 'Warning added successfully') end
			else
				if callback then callback(false, 'Database error') end
			end
		end
	)
end

-- Remove/revoke a warning
function pas.warns.Remove(warn_id, admin_steamid, reason, callback)
	local db = pas.data.GetDB()
	if not db then
		if callback then callback(false, 'No database connection') end
		return
	end
	
	reason = reason or 'No reason provided'
	local timestamp = os.time()
	
	-- First check if warning exists and is active
	db:query_ex(
		'SELECT * FROM pas_warns WHERE id = ? AND active = 1',
		{warn_id},
		function(results)
			if not results or #results == 0 then
				if callback then callback(false, 'Warning not found or already removed') end
				return
			end
			
			local warn_data = results[1]
			
			-- Update the warning to inactive
			db:query_ex(
				'UPDATE pas_warns SET active = 0, removed_by = ?, removed_at = ?, removed_reason = ? WHERE id = ?',
				{admin_steamid, timestamp, reason, warn_id},
				function(result)
					if result then
						-- Log the removal
						local admin_name = 'Console'
						local target_name = 'Unknown'
						
						for _, ply in ipairs(player.GetAll()) do
							if ply:SteamID64() == admin_steamid or ply:SteamID() == admin_steamid then
								admin_name = ply:Nick()
							end
							if ply:SteamID() == warn_data.steamid or ply:SteamID64() == warn_data.steamid then
								target_name = ply:Nick()
							end
						end
						
						pas.log.Add('warns', admin_name .. ' removed warning #' .. warn_id .. ' from ' .. target_name .. ': ' .. reason, admin_steamid, warn_data.steamid)
						
						-- Notify the player if online
						local target = player.GetBySteamID(warn_data.steamid)
						if IsValid(target) then
							pas.notify(target, 'One of your warnings has been removed by ' .. admin_name, 0, 5)
							-- Send update to client
							net.Start('pas.warns.update')
							net.Send(target)
						end
						
						if callback then callback(true, 'Warning removed successfully') end
					else
						if callback then callback(false, 'Database error') end
					end
				end
			)
		end
	)
end

-- Clear all warnings for a player
function pas.warns.Clear(steamid, admin_steamid, callback)
	local db = pas.data.GetDB()
	if not db then
		if callback then callback(false, 'No database connection') end
		return
	end
	
	local timestamp = os.time()
	
	db:query_ex(
		'UPDATE pas_warns SET active = 0, removed_by = ?, removed_at = ?, removed_reason = ? WHERE steamid = ? AND active = 1',
		{admin_steamid, timestamp, 'Bulk clear by admin', steamid},
		function(result)
			if result then
				-- Log the clear
				local admin_name = 'Console'
				local target_name = 'Unknown'
				
				for _, ply in ipairs(player.GetAll()) do
					if ply:SteamID64() == admin_steamid or ply:SteamID() == admin_steamid then
						admin_name = ply:Nick()
					end
					if ply:SteamID() == steamid or ply:SteamID64() == steamid then
						target_name = ply:Nick()
					end
				end
				
				pas.log.Add('warns', admin_name .. ' cleared all warnings from ' .. target_name, admin_steamid, steamid)
				
				-- Notify the player if online
				local target = player.GetBySteamID(steamid)
				if not IsValid(target) then
					target = player.GetBySteamID64(steamid)
				end
				
				if IsValid(target) then
					pas.notify(target, 'All your warnings have been cleared by ' .. admin_name, 0, 5)
					-- Send update to client
					net.Start('pas.warns.update')
					net.Send(target)
				end
				
				if callback then callback(true, 'All warnings cleared') end
			else
				if callback then callback(false, 'Database error') end
			end
		end
	)
end

-- Get warnings for a player
function pas.warns.Get(steamid, active_only, callback)
	local db = pas.data.GetDB()
	if not db then
		if callback then callback({}) end
		return
	end
	
	local query = 'SELECT w.*, u1.name as admin_name, u2.name as target_name FROM pas_warns w ' ..
				  'LEFT JOIN pas_users u1 ON w.admin_steamid = u1.steamid ' ..
				  'LEFT JOIN pas_users u2 ON w.steamid = u2.steamid ' ..
				  'WHERE w.steamid = ?'
	
	if active_only then
		query = query .. ' AND w.active = 1'
	end
	
	query = query .. ' ORDER BY w.timestamp DESC'
	
	db:query_ex(query, {steamid}, function(results)
		-- Normalize the active field to ensure it's a number
		if results then
			for _, warn in ipairs(results) do
				warn.active = tonumber(warn.active) or 0
			end
		end
		if callback then callback(results or {}) end
	end)
end

-- Get warning count for a player
function pas.warns.GetCount(steamid, active_only, callback)
	local db = pas.data.GetDB()
	if not db then
		if callback then callback(0) end
		return
	end
	
	local query = 'SELECT COUNT(*) as count FROM pas_warns WHERE steamid = ?'
	
	if active_only then
		query = query .. ' AND active = 1'
	end
	
	db:query_ex(query, {steamid}, function(results)
		if callback then
			local count = results and results[1] and results[1].count or 0
			callback(tonumber(count) or 0)
		end
	end)
end

-- Get all warnings with filters (for admin menu)
function pas.warns.GetAll(category, search, steamid, active_only, limit, offset, callback)
	local db = pas.data.GetDB()
	if not db then
		if callback then callback({}, 0) end
		return
	end
	
	local query = 'SELECT w.*, u1.name as admin_name, u2.name as target_name FROM pas_warns w ' ..
				  'LEFT JOIN pas_users u1 ON w.admin_steamid = u1.steamid ' ..
				  'LEFT JOIN pas_users u2 ON w.steamid = u2.steamid ' ..
				  'WHERE 1=1'
	local params = {}
	
	if category and category ~= '' and category ~= 'all' then
		query = query .. ' AND w.category = ?'
		table.insert(params, category)
	end
	
	if search and search ~= '' then
		query = query .. ' AND (w.reason LIKE ? OR u2.name LIKE ?)'
		table.insert(params, '%' .. search .. '%')
		table.insert(params, '%' .. search .. '%')
	end
	
	if steamid and steamid ~= '' then
		query = query .. ' AND w.steamid = ?'
		table.insert(params, steamid)
	end
	
	if active_only then
		query = query .. ' AND w.active = 1'
	end
	
	query = query .. ' ORDER BY w.timestamp DESC'
	
	-- Get total count
	local countQuery = 'SELECT COUNT(*) as count FROM pas_warns w ' ..
					   'LEFT JOIN pas_users u2 ON w.steamid = u2.steamid ' ..
					   'WHERE 1=1'
	local countParams = {}
	
	if category and category ~= '' and category ~= 'all' then
		countQuery = countQuery .. ' AND w.category = ?'
		table.insert(countParams, category)
	end
	
	if search and search ~= '' then
		countQuery = countQuery .. ' AND (w.reason LIKE ? OR u2.name LIKE ?)'
		table.insert(countParams, '%' .. search .. '%')
		table.insert(countParams, '%' .. search .. '%')
	end
	
	if steamid and steamid ~= '' then
		countQuery = countQuery .. ' AND w.steamid = ?'
		table.insert(countParams, steamid)
	end
	
	if active_only then
		countQuery = countQuery .. ' AND w.active = 1'
	end
	
	db:query_ex(countQuery, countParams, function(countResults)
		local total = tonumber(countResults and countResults[1] and countResults[1].count or 0) or 0
		
		if limit then
			query = query .. ' LIMIT ?'
			table.insert(params, limit)
			
			if offset then
				query = query .. ' OFFSET ?'
				table.insert(params, offset)
			end
		end
		
		db:query_ex(query, params, function(results)
			-- Normalize the active field to ensure it's a number
			if results then
				for _, warn in ipairs(results) do
					warn.active = tonumber(warn.active) or 0
				end
			end
			if callback then callback(results or {}, total) end
		end)
	end)
end

-- Network handlers
net.Receive('pas.warns.get', function(len, ply)
	if not ply:HasFlag('w') then return end
	local category = net.ReadString()
	local search = net.ReadString()
	local steamid = net.ReadString()
	local active_only = net.ReadBool()
	local limit = net.ReadUInt(16)
	local offset = net.ReadUInt(16)
	
	pas.warns.GetAll(category, search, steamid, active_only, limit, offset, function(warns, total)
		net.Start('pas.warns.receive')
			net.WriteTable(warns or {})
			net.WriteUInt(total or 0, 32)
		net.Send(ply)
	end)
end)

net.Receive('pas.warns.add', function(len, ply)
	if not ply:HasFlag('w') then return end
	
	local steamid = net.ReadString()
	local reason = net.ReadString()
	local category = net.ReadString()
	
	pas.warns.Add(steamid, ply:SteamID64(), reason, category, function(success, message)
		pas.notify(ply, message or 'Unknown result', success and 0 or 1)
	end)
end)

net.Receive('pas.warns.remove', function(len, ply)
	if not ply:HasFlag('w') then return end
	
	local warn_id = net.ReadUInt(32)
	local reason = net.ReadString()
	
	pas.warns.Remove(warn_id, ply:SteamID64(), reason, function(success, message)
		pas.notify(ply, message or 'Unknown result', success and 0 or 1)
	end)
end)

net.Receive('pas.warns.clear', function(len, ply)
	if not ply:HasFlag('w') then return end
	
	local steamid = net.ReadString()
	
	pas.warns.Clear(steamid, ply:SteamID64(), function(success, message)
		pas.notify(ply, message or 'Unknown result', success and 0 or 1)
	end)
end)

net.Receive('pas.warns.open_menu', function(len, ply)
	if not ply:HasFlag('w') then return end
	
	-- Just send a signal back to open the menu
	net.Start('pas.warns.open_menu')
	net.Send(ply)
end)

-- Create table on database ready
hook.Add('pas_DatabaseReady', 'PANTHEON_CreateWarnsTable', function()
	pas.warns.CreateTable()
end)

-- Fallback in case hook doesn't fire
timer.Simple(2, function()
	if pas.data.GetDB() then
		pas.warns.CreateTable()
	end
end)

-- Player spawn notification of active warnings
hook.Add('PlayerInitialSpawn', 'PANTHEON_NotifyWarns', function(ply)
	timer.Simple(5, function()
		if not IsValid(ply) then return end
		
		pas.warns.GetCount(ply:SteamID64(), true, function(count)
			if count > 0 and IsValid(ply) then
				pas.notify(ply, 'You have ' .. count .. ' active warning' .. (count > 1 and 's' or '') .. '. Type !checkwarns for details.', 1, 10)
			end
		end)
	end)
end)

pas.print('[PANTHEON] Warns system (server) loaded')
