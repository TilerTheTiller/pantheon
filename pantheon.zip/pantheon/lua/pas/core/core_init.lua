-- PANTHEON Core System v2.0 - Modular Initialization
-- Enhanced loading system with dependency management

local coreStartTime = SysTime()

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Core Component Registry                                      ║
-- ╚═══════════════════════════════════════════════════════════════╝

local coreComponents = {
	-- Utilities and foundational systems (no dependencies)
	{
		name = 'Notifications',
		load = function() pas.include_dir('core/util/notifications') end,
		deps = {}
	},
	{
		name = 'Terms',
		load = function() pas.include_sh('pas/core/terms_sh.lua') end,
		deps = {}
	},
	{
		name = 'Data',
		load = function() pas.include_sv('pas/core/data_sv.lua') end,
		deps = {},
		serverOnly = true
	},
	{
		name = 'Utilities',
		load = function() pas.include_dir('core/util') end,
		deps = {}
	},
	{
		name = 'Player Meta',
		load = function() pas.include_sh('pas/core/player_sh.lua') end,
		deps = {}
	},
	
	-- Flags system (required by auth and commands)
	{
		name = 'Flags',
		load = function()
			pas.include_sh('pas/core/flags/flags_sh.lua')
			pas.include_sv('pas/core/flags/flags_sv.lua')
			pas.include_cl('pas/core/flags/flags_cl.lua')
		end,
		deps = {'Player Meta'}
	},
	
	-- Ranks system (required by auth)
	{
		name = 'Ranks',
		load = function()
			-- Load groups_sh first to initialize pas.ranks table
			pas.include_sh('pas/core/ranks/groups_sh.lua')
			-- Then load setup which uses pas.ranks
			pas.include_sh('pas/core/ranks/setup_sh.lua')
			
			if SERVER then
				pas.include_sv('pas/core/ranks/groups_sv.lua')
			end
		end,
		deps = {'Flags'} -- Data only needed server-side
	},
	
	-- Authentication (depends on ranks and flags)
	{
		name = 'Authentication',
		load = function()
			pas.include_sh('pas/core/auth/auth_sh.lua')
			pas.include_sv('pas/core/auth/auth_sv.lua')
			pas.include_cl('pas/core/auth/auth_cl.lua')
		end,
		deps = {'Ranks', 'Flags'}
	},
	
	-- Commands system (MUST load before plugins that use pas.cmd)
	{
		name = 'Commands',
		load = function()
			pas.include_sh('pas/core/commands/parser_sh.lua')
			pas.include_sh('pas/core/commands/commands_sh.lua')
			
			if SERVER then
				pas.include_sv('pas/core/commands/commands_sv.lua')
			end
			
			-- Ensure pas.cmd is available globally
			if not pas.cmd then
				pas.print('[ERROR] Commands system failed to initialize pas.cmd')
			end
		end,
		deps = {'Authentication', 'Flags'}
	},
	
	-- Bans system
	{
		name = 'Bans',
		load = function() pas.include_sv('pas/core/bans_sv.lua') end,
		deps = {'Data', 'Authentication'},
		serverOnly = true
	},
	
	-- UI systems
	{
		name = 'UI',
		load = function()
			pas.include_cl('pas/core/ui/main_cl.lua')
			pas.include_sh('pas/core/ui/main_sh.lua')
		end,
		deps = {'Notifications'}
	},
	{
		name = 'Chatbox',
		load = function()
			pas.include_sh('pas/core/ui/chattags_config.lua')
			pas.include_sv('pas/core/ui/chatbox_sv.lua')
			pas.include_cl('pas/core/ui/chatbox_cl.lua')
		end,
		deps = {'UI', 'Ranks'}
	},
	
	-- Logging system
	{
		name = 'Logging',
		load = function()
			pas.include_sh('pas/core/logging/logs_sh.lua')
			pas.include_sv('pas/core/logging/logs_sv.lua')
			pas.include_cl('pas/core/logging/logs_cl.lua')
		end,
		deps = {'Authentication'} -- Data only needed server-side, loaded in logs_sv.lua
	},
	
	-- Warnings system
	{
		name = 'Warnings',
		load = function()
			-- Load shared first to ensure categories and functions are available
			pas.include_sh('pas/core/warns/warns_sh.lua')
			pas.include_sv('pas/core/warns/warns_sv.lua')
			pas.include_cl('pas/core/warns/warns_cl.lua')
		end,
		deps = {'Authentication', 'Notifications'} -- Data is server-only, not needed for client
	},
	
	-- Anti-Cheat system
	{
		name = 'Anti-Cheat',
		load = function()
			pas.include_sh('pas/core/anticheat/anticheat_sh.lua')
			pas.include_sv('pas/core/anticheat/anticheat_sv.lua')
			pas.include_cl('pas/core/anticheat/anticheat_cl.lua')
		end,
		deps = {'Logging', 'Flags'}
	}
}

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Dependency Resolution & Loading                              ║
-- ╚═══════════════════════════════════════════════════════════════╝

local loaded = {}
local failed = {}
local skipped = {}

-- Recursive dependency loader
local function canLoad(component)
	-- Check realm restrictions
	if component.serverOnly and CLIENT then return false, 'server-only' end
	if component.clientOnly and SERVER then return false, 'client-only' end
	
	-- Check if already loaded
	if loaded[component.name] then return false, 'already-loaded' end
	
	-- Check dependencies
	for _, dep in ipairs(component.deps or {}) do
		if not loaded[dep] then
			return false, 'missing-dep-' .. dep
		end
	end
	
	return true, 'ok'
end

-- Track which components we've already processed
local processed = {}

-- Load components in dependency order
local maxIterations = #coreComponents * 2 -- Prevent infinite loops
local iteration = 0

while table.Count(loaded) + #failed + table.Count(processed) < #coreComponents and iteration < maxIterations do
	iteration = iteration + 1
	local loadedThisIteration = false
	
	for _, component in ipairs(coreComponents) do
		if not processed[component.name] and not loaded[component.name] then
			local can, reason = canLoad(component)
			
			if can then
				local compStartTime = SysTime()
				local success, err = pcall(component.load)
				local loadTime = (SysTime() - compStartTime) * 1000
				
				if success then
					loaded[component.name] = true
					processed[component.name] = true
					loadedThisIteration = true
					
					if loader and loader.config.verbose then
						pas.print(string.format('[✓] %s loaded (%.2fms)', component.name, loadTime))
					end
				else
					processed[component.name] = true
					table.insert(failed, {name = component.name, error = err})
					pas.print('[✗] Failed to load: ' .. component.name)
					ErrorNoHalt('  Error: ' .. tostring(err) .. '\n')
				end
			elseif reason == 'server-only' or reason == 'client-only' then
				-- Mark as processed and skipped due to realm
				processed[component.name] = true
				table.insert(skipped, component.name .. ' (' .. reason .. ')')
				loadedThisIteration = true -- Allow iteration to continue
			end
		end
	end
	
	-- If nothing loaded this iteration and we're not done, we have unmet dependencies
	if not loadedThisIteration then
		for _, component in ipairs(coreComponents) do
			if not loaded[component.name] and not processed[component.name] then
				local can, reason = canLoad(component)
				
				if not can then
					processed[component.name] = true
					
					-- Check if it's a dependency issue
					if reason:find('missing-dep') then
						local missingDep = reason:gsub('missing%-dep%-', '')
						table.insert(failed, {
							name = component.name,
							error = 'Missing dependency: ' .. missingDep
						})
						pas.print('[✗] Cannot load ' .. component.name .. ': missing dependency ' .. missingDep)
					end
				end
			end
		end
		break
	end
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Load Module System & Plugins                                 ║
-- ╚═══════════════════════════════════════════════════════════════╝

-- Load module loader
local moduleSuccess, moduleErr = pcall(function()
	pas.include_sh('pas/core/module_loader.lua')
end)

if not moduleSuccess then
	pas.print('[✗] Failed to load module system')
	ErrorNoHalt('  Error: ' .. tostring(moduleErr) .. '\n')
end

-- Load plugins (only after Commands system is ready)
local pluginCount = 0
local pluginFailed = 0

if not loaded['Commands'] then
	pas.print('[WARNING] Commands system not loaded, plugins may fail!')
end

local plugin_files, _ = file.Find('pas/plugins/*.lua', 'LUA')
table.sort(plugin_files) -- Consistent load order

for _, f in ipairs(plugin_files) do
	-- Define plugins that don't need pas.cmd
	local safePlugins = {
		['chatcommands.lua'] = true,
		['viewstaff.lua'] = true
	}
	
	-- Skip plugins that require pas.cmd if Commands didn't load
	if not pas.cmd and not safePlugins[f] then
		pas.print('[⚠] Skipped plugin (Commands not available): ' .. f)
		skipped[#skipped + 1] = 'Plugin: ' .. f
	else
		local success, err = pcall(pas.include, 'pas/plugins/' .. f)
		if success then
			pluginCount = pluginCount + 1
		else
			pluginFailed = pluginFailed + 1
			pas.print('[✗] Failed to load plugin: ' .. f)
			ErrorNoHalt('  Error: ' .. tostring(err) .. '\n')
		end
	end
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Initialization Summary                                       ║
-- ╚═══════════════════════════════════════════════════════════════╝

local coreLoadTime = (SysTime() - coreStartTime) * 1000

pas.print(string.format('[PANTHEON] Core systems loaded in %.2fms', coreLoadTime))
pas.print(string.format('  └─ Components: %d loaded, %d failed, %d skipped', 
	table.Count(loaded), #failed, #skipped))
pas.print(string.format('  └─ Plugins: %d loaded, %d failed', pluginCount, pluginFailed))

-- Store core initialization data
pas._coreInit = {
	loadTime = coreLoadTime,
	components = {
		loaded = loaded,
		failed = failed,
		skipped = skipped
	},
	plugins = {
		loaded = pluginCount,
		failed = pluginFailed
	}
}
