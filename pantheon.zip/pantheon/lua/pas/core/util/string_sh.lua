-- String utilities for PANTHEON

function string.Nicen(str)
	return str:gsub("^%l", string.upper)
end

function string.NicenAll(str)
	return str:gsub("(%a)([%w_']*)", function(first, rest)
		return first:upper() .. rest:lower()
	end)
end

function string.TimeToString(time)
	return pas.parser.FormatTime(time)
end
