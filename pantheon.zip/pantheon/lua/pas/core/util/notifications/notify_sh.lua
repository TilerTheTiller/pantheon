-- Notification system for PANTHEON

if (SERVER) then
	-- Network strings kept for compatibility but no longer used
	-- util.AddNetworkString('pas.Notify')
	-- util.AddNetworkString('pas.NotifyEnhanced')
	
	-- Legacy notify function for backward compatibility - REPLACED WITH CHATPRINT
	function pas.notify(pl, msg, type)
		if not IsValid(pl) or not pl:IsPlayer() then return end
		
		-- Convert type to prefix for ChatPrint
		local prefix = ""
		if type == 1 then -- ERROR
			prefix = "[ERROR] "
		elseif type == 0 then -- SUCCESS/INFO
			prefix = "[INFO] "
		else
			prefix = "[NOTICE] "
		end
		
		pl:ChatPrint(prefix .. tostring(msg))
	end
	
	function pas.notify_all(msg, ...)
		local args = {...}
		local formatted = msg
		local notificationType = 0 -- Default type
		
		for i = 1, #args do
			local arg = args[i]
			if pas.IsPlayer(arg) then
				formatted = formatted:gsub('$' .. i, arg:Nick())
			elseif type(arg) == "number" and i == #args then
				-- If last argument is a number, treat it as notification type
				notificationType = arg
				break
			else
				formatted = formatted:gsub('$' .. i, tostring(arg))
			end
		end
		
		-- Convert to ChatPrint for all players
		local prefix = ""
		if notificationType == 1 then -- ERROR
			prefix = "[ERROR] "
		elseif notificationType == 0 then -- SUCCESS/INFO
			prefix = "[INFO] "
		else
			prefix = "[NOTICE] "
		end
		
		for _, ply in pairs(player.GetAll()) do
			if IsValid(ply) then
				ply:ChatPrint(prefix .. formatted)
			end
		end
		
		-- Also print to console
		print("[BROADCAST] " .. formatted)
	end
	
	-- Enhanced notification system
	pas.notifications = pas.notifications or {}
	
	function pas.notifications.Send(ply, message, notifType, duration)
		if not IsValid(ply) then return end
		
		notifType = notifType or "info"
		duration = duration or 5
		
		net.Start("pas.NotifyEnhanced")
			net.WriteString(tostring(message))
			net.WriteString(notifType)
			net.WriteUInt(math.Clamp(duration, 1, 255), 8)
		net.Send(ply)
	end
	
	function pas.notifications.SendAll(message, notifType, duration)
		notifType = notifType or "info"
		duration = duration or 5
		
		net.Start("pas.NotifyEnhanced")
			net.WriteString(tostring(message))
			net.WriteString(notifType)
			net.WriteUInt(math.Clamp(duration, 1, 255), 8)
		net.Broadcast()
	end
	
	-- Convenience functions
	function pas.notifications.Success(ply, message, duration)
		if ply == "all" then
			pas.notifications.SendAll(message, "success", duration)
		else
			pas.notifications.Send(ply, message, "success", duration)
		end
	end
	
	function pas.notifications.Error(ply, message, duration)
		if ply == "all" then
			pas.notifications.SendAll(message, "error", duration)
		else
			pas.notifications.Send(ply, message, "error", duration)
		end
	end
	
	function pas.notifications.Warning(ply, message, duration)
		if ply == "all" then
			pas.notifications.SendAll(message, "warning", duration)
		else
			pas.notifications.Send(ply, message, "warning", duration)
		end
	end
	
	function pas.notifications.Info(ply, message, duration)
		if ply == "all" then
			pas.notifications.SendAll(message, "info", duration)
		else
			pas.notifications.Send(ply, message, "info", duration)
		end
	end
	
else
	-- Client-side legacy notification function - DISABLED (using server ChatPrint)
	function pas.notify(pl, msg, type)
		-- Notifications are now handled via ChatPrint from server
		-- This function is kept for compatibility but does nothing on client
	end
	
	function pas.notify_all(msg, ...)
		-- Notifications are now handled via ChatPrint from server
		-- This function is kept for compatibility but does nothing on client
	end
	
	-- Legacy network receiver - DISABLED (using server ChatPrint)
	net.Receive('pas.Notify', function()
		local msg = net.ReadString()
		local type = net.ReadUInt(3)
		-- Notifications are now handled by ChatPrint on server side
		-- This receive handler is kept for compatibility but does nothing
	end)
	
	-- Enhanced notification network receiver - DISABLED (using server ChatPrint)
	net.Receive("pas.NotifyEnhanced", function()
		local message = net.ReadString()
		local notifType = net.ReadString()
		local duration = net.ReadUInt(8)
		-- Notifications are now handled by ChatPrint on server side
		-- This receive handler is kept for compatibility but does nothing
	end)
end
