if (CLIENT) then return end

-- Network strings kept for compatibility but no longer used
-- util.AddNetworkString('pas.Notify')
-- util.AddNetworkString('pas.NotifyEnhanced')

--[[
	Legacy notification function - REPLACED WITH CHATPRINT
	Now uses ChatPrint instead of notification system
]]--
function pas.notify(pl, msg, type)
	if not IsValid(pl) or not pl:IsPlayer() then return end
	
	-- Convert type to prefix for ChatPrint
	local prefix = ""
	local color = Color(255, 255, 255)
	
	if type == 1 then -- ERROR
		prefix = "[ERROR] "
		color = Color(255, 100, 100)
	elseif type == 0 then -- SUCCESS/INFO
		prefix = "[INFO] "
		color = Color(100, 150, 255)
	else
		prefix = "[NOTICE] "
		color = Color(255, 255, 100)
	end
	
	local fullMsg = prefix .. tostring(msg)
	
	-- Use SendLua to call chat.AddText on client (works with PANTHEON chatbox)
	pl:SendLua('chat.AddText(Color(' .. color.r .. ',' .. color.g .. ',' .. color.b .. '), ' .. string.format('%q', fullMsg) .. ')')
	
	-- Debug output
	print("[CHAT DEBUG] Sent to " .. pl:Nick() .. " via SendLua: " .. fullMsg)
end

-- Helper function for sending ChatPrint to players with 'm' flag
function pas.ChatPrintToAdmins(msg, includeConsole)
	local fullMsg = "[ADMIN] " .. tostring(msg)
	local color = Color(255, 150, 0) -- Orange for admin messages
	
	if includeConsole then
		print(fullMsg)
	end
	
	for _, ply in pairs(player.GetAll()) do
		if IsValid(ply) and ply:HasFlag('m') then
			-- Use SendLua to call chat.AddText on client (works with PANTHEON chatbox)
			ply:SendLua('chat.AddText(Color(' .. color.r .. ',' .. color.g .. ',' .. color.b .. '), ' .. string.format('%q', fullMsg) .. ')')
		end
	end
end

function pas.notify_all(msg, ...)
	local args = {...}
	local formatted = tostring(msg)
	local notificationType = 0 -- Default type
	
	-- Process replacement args if any exist
	for i = 1, #args do
		local arg = args[i]
		local replacement = tostring(arg)
		
		-- Special handling for player objects
		if type(arg) == "Player" and IsValid(arg) then
			replacement = arg:Nick()
		elseif type(arg) == "number" and i == #args then
			-- If last argument is a number, treat it as notification type
			notificationType = arg
			break
		end
		
		formatted = formatted:gsub('$' .. i, replacement)
	end
	
	-- Convert to chat message for all players
	local prefix = ""
	local color = Color(255, 255, 255)
	
	if notificationType == 1 then -- ERROR
		prefix = "[ERROR] "
		color = Color(255, 100, 100)
	elseif notificationType == 0 then -- SUCCESS/INFO
		prefix = "[INFO] "
		color = Color(100, 150, 255)
	else
		prefix = "[NOTICE] "
		color = Color(255, 255, 100)
	end
	
	local fullMsg = prefix .. formatted
	
	for _, ply in pairs(player.GetAll()) do
		if IsValid(ply) then
			-- Use SendLua to call chat.AddText on client (works with PANTHEON chatbox)
			ply:SendLua('chat.AddText(Color(' .. color.r .. ',' .. color.g .. ',' .. color.b .. '), ' .. string.format('%q', fullMsg) .. ')')
		end
	end
	
	-- Also print to console
	print("[BROADCAST] " .. formatted)
end

--[[
	Enhanced Notification System
	Modern notification API with type-based styling
]]--

pas.notifications = pas.notifications or {}

-- Send enhanced notification to a specific player - REPLACED WITH CHATPRINT
function pas.notifications.Send(ply, message, notifType, duration)
	if not IsValid(ply) then return end
	
	notifType = notifType or "info"
	
	-- Convert notification type to prefix and color
	local prefix = ""
	local color = Color(255, 255, 255)
	
	if notifType == "error" then
		prefix = "[ERROR] "
		color = Color(255, 100, 100)
	elseif notifType == "success" then
		prefix = "[SUCCESS] "
		color = Color(100, 255, 100)
	elseif notifType == "warning" then
		prefix = "[WARNING] "
		color = Color(255, 200, 100)
	else
		prefix = "[INFO] "
		color = Color(100, 150, 255)
	end
	
	local fullMsg = prefix .. tostring(message)
	
	-- Use SendLua to call chat.AddText on client (works with PANTHEON chatbox)
	ply:SendLua('chat.AddText(Color(' .. color.r .. ',' .. color.g .. ',' .. color.b .. '), ' .. string.format('%q', fullMsg) .. ')')
end

-- Send enhanced notification to all players - REPLACED WITH CHATPRINT
function pas.notifications.SendAll(message, notifType, duration)
	notifType = notifType or "info"
	
	-- Convert notification type to prefix
	local prefix = ""
	if notifType == "error" then
		prefix = "[ERROR] "
	elseif notifType == "success" then
		prefix = "[SUCCESS] "
	elseif notifType == "warning" then
		prefix = "[WARNING] "
	else
		prefix = "[INFO] "
	end
	
	for _, ply in pairs(player.GetAll()) do
		if IsValid(ply) then
			ply:ChatPrint(prefix .. tostring(message))
		end
	end
	
	-- Also print to console
	print("[BROADCAST] " .. tostring(message))
end

-- Send to players with specific permission/flag - REPLACED WITH CHATPRINT
function pas.notifications.SendToAdmins(message, notifType, duration, flag)
	notifType = notifType or "info"
	flag = flag or "m"
	
	-- Convert notification type to prefix
	local prefix = ""
	if notifType == "error" then
		prefix = "[ERROR] "
	elseif notifType == "success" then
		prefix = "[SUCCESS] "
	elseif notifType == "warning" then
		prefix = "[WARNING] "
	else
		prefix = "[INFO] "
	end
	
	for _, ply in ipairs(player.GetAll()) do
		if IsValid(ply) and ply:HasFlag(flag) then
			ply:ChatPrint(prefix .. tostring(message))
		end
	end
end

--[[
	Convenience functions for different notification types
]]--

function pas.notifications.Success(ply, message, duration)
	if ply == "all" then
		pas.notifications.SendAll(message, "success", duration)
	else
		pas.notifications.Send(ply, message, "success", duration)
	end
end

function pas.notifications.Error(ply, message, duration)
	if ply == "all" then
		pas.notifications.SendAll(message, "error", duration)
	else
		pas.notifications.Send(ply, message, "error", duration)
	end
end

function pas.notifications.Warning(ply, message, duration)
	if ply == "all" then
		pas.notifications.SendAll(message, "warning", duration)
	else
		pas.notifications.Send(ply, message, "warning", duration)
	end
end

function pas.notifications.Info(ply, message, duration)
	if ply == "all" then
		pas.notifications.SendAll(message, "info", duration)
	else
		pas.notifications.Send(ply, message, "info", duration)
	end
end

--[[
	Example Usage:
	
	-- New enhanced system (recommended):
	pas.notifications.Success(player, "Character saved successfully!", 5)
	pas.notifications.Error(player, "Failed to save data", 5)
	pas.notifications.Warning(player, "Server restarting soon", 10)
	pas.notifications.Info(player, "Welcome to the server!", 5)
	
	-- Send to all players:
	pas.notifications.Success("all", "Event starting now!", 5)
	pas.notifications.SendAll("Server message", "info", 5)
	
	-- Send to admins:
	pas.notifications.SendToAdmins("Player reported for RDM", "warning", 5)
	
	-- Legacy system (still works):
	pas.notify(player, "Old style notification", NOTIFY_GENERIC)
	pas.notify_all("Broadcast message")
]]--
