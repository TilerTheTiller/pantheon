	if (SERVER) then return end

-- Legacy notification receive (backward compatibility) - REPLACED WITH CHATPRINT
net.Receive('pas.Notify', function()
	local msg = net.ReadString()
	local type = net.ReadUInt(3)
	-- Notifications are now handled by ChatPrint on server side
	-- This receive handler is kept for compatibility but does nothing
	-- as pas.notify now sends ChatPrint directly to players
end)

-- Enhanced notification receive - REPLACED WITH CHATPRINT
net.Receive("pas.NotifyEnhanced", function()
	local message = net.ReadString()
	local notifType = net.ReadString()
	local duration = net.ReadUInt(8)
	-- Notifications are now handled by ChatPrint on server side
	-- This receive handler is kept for compatibility but does nothing
	-- as pas.notifications functions now send ChatPrint directly to players
end)
