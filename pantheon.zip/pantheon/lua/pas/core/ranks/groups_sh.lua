pas.ranks 			= pas.ranks 		or {}
pas.ranks.Stored 	= pas.ranks.Stored 	or {}

local rank_mt 		= {}
rank_mt.__index 	= rank_mt

function pas.ranks.Create(name, id)	
	local r = {
		Name 		= name:lower():gsub(' ', ''),
		NiceName	= name,
		ID 			= id,
		Immunity 	= 0,
		Flags 		= {},
		Global 		= false,
		VIP 		= false,
		Admin 		= false,
		SuperAdmin 	= false,
		Root 		= false
	}
	setmetatable(r, rank_mt)
	pas.ranks.Stored[r.ID] 		= r
	pas.ranks.Stored[r.Name] 	= r
	pas.ranks.Stored[r.NiceName] = r
	return r
end

function pas.ranks.GetTable()
	return pas.ranks.Stored
end

function pas.ranks.Get(rank)
	return pas.ranks.Stored[isstring(rank) and rank:lower() or rank]
end

function pas.ranks.CanTarget(pl, targ)
	if (not pas.IsPlayer(pl)) or pl:IsRoot() or ((pl:IsSuperAdmin()) and (not targ:IsRoot())) then return true end
	return (pl:GetImmunity() > targ:GetImmunity())
end

-- Set
function rank_mt:SetImmunity(amt)
	self.Immunity = amt
	return self
end

function rank_mt:SetGlobal(bool)
	self.Global = bool
	return self
end

function rank_mt:SetFlags(f)
	for i = 1, #f do
		self.Flags[f[i]] = true
		self.Flags[i] = f[i]
	end
	return self
end

function rank_mt:SetVIP(bool)
	self.VIP = bool
	return self
end

function rank_mt:SetAdmin(bool)
	if (bool == true) then
		self:SetVIP(bool)
	end
	self.Admin = bool
	return self
end

function rank_mt:SetSuperAdmin(bool)
	if (bool == true) then
		self:SetVIP(bool)
		self:SetAdmin(bool)
	end
	self.SuperAdmin = bool
	return self
end

function rank_mt:SetRoot(bool)
	if (bool == true) then
		self:SetGlobal(bool)
		self:SetVIP(bool)
		self:SetAdmin(bool)
		self:SetSuperAdmin(bool)
	end
	self.Root = bool
	return self
end

-- Get
function rank_mt:GetID()
	return self.ID
end

function rank_mt:GetName()
	return self.Name
end

function rank_mt:GetNiceName()
	return self.NiceName
end

function rank_mt:GetImmunity()
	return self.Immunity
end

function rank_mt:IsGlobal()
	return self.Global
end

function rank_mt:HasFlag(flag)
	return (self.Flags[flag:lower()] or self.Flags['*'] or self:IsRoot())
end

function rank_mt:GetFlags()
	return self.Flags
end

function rank_mt:CanTarget(rank)
	return self:IsRoot() or (self:GetImmunity() > rank:GetImmunity())
end

function rank_mt:IsVIP()
	return self.VIP
end

function rank_mt:IsAdmin()
	return self.Admin
end

function rank_mt:IsSuperAdmin()
	return self.SuperAdmin
end

function rank_mt:IsRoot()
	return self.Root
end

-- Player
function PLAYER:GetRankTable()
	-- Return cached rank table if available
	if self._RankTableCache then
		return self._RankTableCache
	end
	
	local userGroup
	if self.GetNetVar then
		userGroup = self:GetNetVar('UserGroup')
	else
		userGroup = self:GetNWInt('UserGroup', 1)
	end
	
	-- Ensure we have a valid userGroup (not nil or 0)
	if not userGroup or userGroup == 0 then
		userGroup = 1 -- Default to user rank
	end
	
	local rank = pas.ranks.Get(userGroup)
	
	-- Safety fallback - always return at least the User rank
	if not rank then
		rank = pas.ranks.Get(1) or pas.ranks.Get('user')
	end
	
	-- Cache the result to prevent repeated lookups
	if rank then
		self._RankTableCache = rank
	end
	
	return rank
end

function PLAYER:GetRank()
	return self:GetRankTable():GetName()
end 
PLAYER.GetUserGroup = PLAYER.GetRank

function PLAYER:GetImmunity()
	return self:GetRankTable():GetImmunity()
end

function PLAYER:HasFlag(flag)
	-- Singleplayer override - grant all flags
	if game.SinglePlayer() then 
		return true 
	end
	
	if (hook.Call('PlayerAdminCheck', GAMEMODE, self) == false) then return false end
	
	local rankTable = self:GetRankTable()
	if not rankTable then 
		-- Only print warning once per player to avoid spam
		if not self._RankWarningShown then
			self._RankWarningShown = true
			print("[PANTHEON] Warning: Player " .. tostring(self) .. " has no rank table")
		end
		return false 
	end
	
	local result = rankTable:HasFlag(flag)
	
	-- Optional debug - only enable if needed for troubleshooting
	-- Uncomment the lines below if you need to debug flag checking
	--[[
	print("[PANTHEON FLAG DEBUG] Player " .. self:Nick() .. " checking flag '" .. flag .. "': " .. tostring(result))
	print("[PANTHEON FLAG DEBUG]   Rank: " .. rankTable:GetName() .. " (ID: " .. rankTable:GetID() .. ")")
	print("[PANTHEON FLAG DEBUG]   UserGroup NetVar: " .. (self:GetNetVar('UserGroup') or 'nil'))
	print("[PANTHEON FLAG DEBUG]   Is Root: " .. tostring(rankTable:IsRoot()))
	print("[PANTHEON FLAG DEBUG]   Rank Flags: " .. table.concat(rankTable:GetFlags() or {}, ', '))
	--]]
	
	return result
end
PLAYER.HasAccess = PLAYER.HasFlag

function PLAYER:IsRank(group)
	return (self:GetRank() == group)
end
PLAYER.IsUserGroup = PLAYER.IsRank

function PLAYER:IsVIP()
	return ((hook.Call('PlayerVIPCheck', GAMEMODE, self) == true) or self:GetRankTable():IsVIP())
end

-- Clear cached rank table when player disconnects or rank changes
if SERVER then
	hook.Add("PlayerDisconnected", "PAS.ClearRankCache", function(ply)
		if IsValid(ply) then
			ply._RankTableCache = nil
			ply._RankWarningShown = nil
		end
	end)
	
	-- Clear cache when rank is updated
	hook.Add("PAS.RankUpdated", "PAS.ClearRankCache", function(ply)
		if IsValid(ply) then
			ply._RankTableCache = nil
			ply._RankWarningShown = nil
		end
	end)
end

function PLAYER:IsAdmin()
	if (hook.Call('PlayerAdminCheck', GAMEMODE, self) == false) then return false end

	return self:GetRankTable():IsAdmin()
end

function PLAYER:IsSuperAdmin()
	if (hook.Call('PlayerAdminCheck', GAMEMODE, self) == false) then return false end

	return self:GetRankTable():IsSuperAdmin()
end

function PLAYER:IsRoot()
	return self:GetRankTable():IsRoot()
end

nw.Register 'UserGroup'
	:Write(net.WriteUInt, 4)
	:Read(net.ReadUInt, 4)
	:SetPlayer()
