if (CLIENT) then return end

-- Server variable system
pas.svar = pas.svar or {}
pas.svar.vars = pas.svar.vars or {}

function pas.svar.Set(key, val)
	pas.svar.vars[key] = val
end

function pas.svar.Get(key)
	return pas.svar.vars[key]
end

-- Set a unique server ID (you should change this for each server)
pas.svar.Set('sv_id', 'PANTHEON_SERVER_1')

-- Singleplayer auto-admin function
local function SetupSingleplayerAdmin(pl)
	if not game.SinglePlayer() or not IsValid(pl) then return end
	
	timer.Simple(3, function()
		if not IsValid(pl) then return end
		
		-- Check if already has superadmin
		if pl:IsSuperAdmin() then return end
		
		-- Set GMod usergroup
		pl:SetUserGroup("superadmin")
		
		-- Set PANTHEON rank
		if pas.data and pas.data.SetRank then
			pas.data.SetRank(pl, 'superadmin', 'user', 0, function()
				pas.print('[PANTHEON] Singleplayer: Set ' .. pl:Nick() .. ' to superadmin rank')
			end)
		end
		
		-- Log the action
		if pas.log and pas.log.Add then
			pas.log.Add('ranks', '[SINGLEPLAYER] Auto-granted superadmin to ' .. pl:Nick(), '', pl:SteamID())
		end
		
		pas.print('[PANTHEON] Singleplayer mode detected - auto-granted superadmin to ' .. pl:Nick())
	end)
end

-- Hooks for player data
hook.Add('PlayerInitialSpawn', 'PANTHEON_LoadRank', function(pl)
	timer.Simple(1, function()
		if IsValid(pl) and pas.data and pas.data.LoadPlayer then
			pas.data.LoadPlayer(pl)
		end
		
		-- Setup singleplayer admin
		SetupSingleplayerAdmin(pl)
		
		-- Ensure player has at least default rank after data loading
		timer.Simple(2, function()
			if IsValid(pl) and (not pl:GetNetVar('UserGroup') or pl:GetNetVar('UserGroup') == 0) then
				pas.print('[PANTHEON] Player ' .. pl:Nick() .. ' has no rank, assigning default user rank')
				pl:SetNetVar('UserGroup', 1) -- Set to user rank (ID 1)
			end
		end)
	end)
end)

hook.Add('PlayerDisconnect', 'PANTHEON_SaveData', function(pl)
	if pas.data and pas.data.UpdatePlayTime then
		pas.data.UpdatePlayTime(pl)
	end
	if pas.notify_all then
		pas.notify_all(pas.Term('PlayerDisconnect'), pl)
	end
end)

timer.Create('PANTHEON_SavePlaytime', 300, 0, function()
	if pas.data and pas.data.UpdatePlayTime then
		for k, v in ipairs(player.GetAll()) do
			pas.data.UpdatePlayTime(v)
		end
	end
end)

-- Console command to set player rank from server console
concommand.Add('pas_setrank', function(ply, cmd, args)
	-- Only allow from server console (ply will be NULL)
	if IsValid(ply) then
		print('[PANTHEON] This command can only be used from the server console!')
		return
	end
	
	if #args < 2 then
		print('[PANTHEON] Usage: pas_setrank <steamid/name> <rank>')
		print('[PANTHEON] Example: pas_setrank STEAM_0:1:12345678 admin')
		print('[PANTHEON] Example: pas_setrank "Player Name" moderator')
		print('[PANTHEON] Available ranks: user, vip, moderator, admin, superadmin, root')
		return
	end
	
	local target_identifier = args[1]
	local rank_name = string.lower(args[2])
	
	-- Find the target player
	local target_ply = nil
	
	-- First try to find by SteamID
	for _, pl in ipairs(player.GetAll()) do
		if pl:SteamID() == target_identifier or pl:SteamID64() == target_identifier then
			target_ply = pl
			break
		end
	end
	
	-- If not found, try to find by name (partial match)
	if not target_ply then
		local search_name = string.lower(target_identifier)
		for _, pl in ipairs(player.GetAll()) do
			if string.find(string.lower(pl:Nick()), search_name, 1, true) then
				target_ply = pl
				break
			end
		end
	end
	
	if not target_ply then
		print('[PANTHEON] Player not found: ' .. target_identifier)
		print('[PANTHEON] Online players:')
		for _, pl in ipairs(player.GetAll()) do
			print('  - ' .. pl:Nick() .. ' (' .. pl:SteamID() .. ')')
		end
		return
	end
	
	-- Validate rank exists
	local rank_obj = pas.ranks.Get(rank_name)
	if not rank_obj then
		print('[PANTHEON] Invalid rank: ' .. rank_name)
		print('[PANTHEON] Available ranks:')
		for k, v in pairs(pas.ranks.stored) do
			print('  - ' .. k)
		end
		return
	end
	
	-- Set the rank
	print('[PANTHEON] Setting ' .. target_ply:Nick() .. ' (' .. target_ply:SteamID() .. ') to rank: ' .. rank_name)
	
	pas.data.SetRank(target_ply, rank_name, 'user', 0, function()
		print('[PANTHEON] Successfully set ' .. target_ply:Nick() .. ' to rank: ' .. rank_name)
		
		-- Log the rank change
		if pas.log and pas.log.Add then
			pas.log.Add('ranks', '[CONSOLE] Set ' .. target_ply:Nick() .. ' to rank: ' .. rank_name, '', target_ply:SteamID())
		end
		
		-- Notify all staff
		for _, pl in ipairs(player.GetAll()) do
			if pl:HasFlag('m') then
				pas.notify(pl, '[CONSOLE] Set ' .. target_ply:Nick() .. ' to rank: ' .. rank_name, 0)
			end
		end
		
		-- Notify the target player
		pas.notify(target_ply, 'Your rank has been set to: ' .. rank_name, 0)
	end)
end)

-- Console command to remove authentication lockout
concommand.Add('pas_removelockout', function(ply, cmd, args)
	-- Only allow from server console (ply will be NULL)
	if IsValid(ply) then
		print('[PANTHEON] This command can only be used from the server console!')
		return
	end
	
	if #args < 1 then
		print('[PANTHEON] Usage: pas_removelockout <steamid/name>')
		print('[PANTHEON] Example: pas_removelockout STEAM_0:1:12345678')
		print('[PANTHEON] Example: pas_removelockout "Player Name"')
		return
	end
	
	local target_identifier = args[1]
	
	-- Find the target player
	local target_ply = nil
	
	-- First try to find by SteamID
	for _, pl in ipairs(player.GetAll()) do
		if pl:SteamID() == target_identifier or pl:SteamID64() == target_identifier then
			target_ply = pl
			break
		end
	end
	
	-- If not found, try to find by name (partial match)
	if not target_ply then
		local search_name = string.lower(target_identifier)
		for _, pl in ipairs(player.GetAll()) do
			if string.find(string.lower(pl:Nick()), search_name, 1, true) then
				target_ply = pl
				break
			end
		end
	end
	
	if not target_ply then
		print('[PANTHEON] Player not found: ' .. target_identifier)
		print('[PANTHEON] Online players:')
		for _, pl in ipairs(player.GetAll()) do
			print('  - ' .. pl:Nick() .. ' (' .. pl:SteamID() .. ')')
		end
		return
	end
	
	-- Check if auth system is loaded
	if not pas.auth or not pas.auth.ClearLockout then
		print('[PANTHEON] Authentication system not loaded!')
		return
	end
	
	-- Clear the lockout
	pas.auth.ClearLockout(target_ply)
	
	print('[PANTHEON] Removed authentication lockout for ' .. target_ply:Nick() .. ' (' .. target_ply:SteamID() .. ')')
	pas.notify(target_ply, 'Your authentication lockout has been removed by console', 0)
end)

-- Console command to manually grant admin privileges (useful for listen servers)
concommand.Add('pas_grantadmin', function(ply, cmd, args)
	-- Only allow from server console (ply will be NULL)
	if IsValid(ply) then
		print('[PANTHEON] This command can only be used from the server console!')
		return
	end
	
	if #args < 1 then
		print('[PANTHEON] Usage: pas_grantadmin <steamid/name>')
		print('[PANTHEON] Example: pas_grantadmin STEAM_0:1:12345678')
		print('[PANTHEON] Example: pas_grantadmin "Player Name"')
		print('[PANTHEON] This grants superadmin rank and all flags (useful for listen servers)')
		return
	end
	
	local target_identifier = args[1]
	
	-- Find the target player
	local target_ply = nil
	
	-- First try to find by SteamID
	for _, pl in ipairs(player.GetAll()) do
		if pl:SteamID() == target_identifier or pl:SteamID64() == target_identifier then
			target_ply = pl
			break
		end
	end
	
	-- If not found, try to find by name (partial match)
	if not target_ply then
		local search_name = string.lower(target_identifier)
		for _, pl in ipairs(player.GetAll()) do
			if string.find(string.lower(pl:Nick()), search_name, 1, true) then
				target_ply = pl
				break
			end
		end
	end
	
	if not target_ply then
		print('[PANTHEON] Player not found: ' .. target_identifier)
		print('[PANTHEON] Online players:')
		for _, pl in ipairs(player.GetAll()) do
			print('  - ' .. pl:Nick() .. ' (' .. pl:SteamID() .. ')')
		end
		return
	end
	
	-- Grant admin privileges (similar to singleplayer auto-grant)
	print('[PANTHEON] Granting admin privileges to ' .. target_ply:Nick() .. ' (' .. target_ply:SteamID() .. ')')
	
	-- Set GMod usergroup
	target_ply:SetUserGroup("superadmin")
	
	-- Set PANTHEON rank
	if pas.data and pas.data.SetRank then
		pas.data.SetRank(target_ply, 'superadmin', 'user', 0, function()
			print('[PANTHEON] Set ' .. target_ply:Nick() .. ' to superadmin rank')
		end)
	end
	
	-- Auto-authenticate for admin commands
	if target_ply.pas_AuthData then
		target_ply.pas_AuthData.authenticated = true
		target_ply.pas_AuthData.authTime = CurTime()
	end
	
	-- Grant all flags
	if pas.flags and pas.flags.list then
		target_ply.pas_CustomFlags = {}
		
		-- Grant all available flags
		for flag, _ in pairs(pas.flags.list) do
			target_ply.pas_CustomFlags[flag] = true
		end
		
		-- Special universal access flag
		target_ply.pas_CustomFlags['*'] = true
		
		-- Save flags
		if pas.data and pas.data.SavePlayerFlags then
			pas.data.SavePlayerFlags(target_ply)
		end
		
		-- Network to client
		if pas.flags.NetworkPlayerFlags then
			pas.flags.NetworkPlayerFlags(target_ply)
		end
	end
	
	-- Log the action
	if pas.log and pas.log.Add then
		pas.log.Add('ranks', '[CONSOLE] Manually granted admin to ' .. target_ply:Nick(), '', target_ply:SteamID())
	end
	
	-- Notify player
	timer.Simple(1, function()
		if IsValid(target_ply) then
			pas.notify(target_ply, 'Admin privileges granted by console!', 0)
			pas.notify(target_ply, 'You now have superadmin rank with all permissions.', 1)
			pas.notify(target_ply, 'Type !help to see available admin commands.', 2)
		end
	end)
	
	print('[PANTHEON] Successfully granted admin privileges to ' .. target_ply:Nick())
end)

