-- Default rank setup for PANTHEON
pas.ranks.Create('user', 1)
	:SetImmunity(0)
	:SetFlags({'u'})

pas.ranks.Create('vip', 2)
	:SetImmunity(1)
	:SetVIP(true)
	:SetFlags({'u', 'v'})

pas.ranks.Create('tgamemaster', 3)
	:SetImmunity(2)
	:SetVIP(true)
	:SetFlags({'u', 'g'})

pas.ranks.Create('gamemaster', 4)
	:SetImmunity(3)
	:SetVIP(true)
	:SetFlags({'u', 'g'})

pas.ranks.Create('jrmoderator', 5)
	:SetImmunity(4)
	:SetAdmin(true)
	:SetFlags({'u', 'm', 'k', 'l', 'c'})

pas.ranks.Create('srmoderator', 6)
	:SetImmunity(5)
	:SetAdmin(true)
	:SetFlags({'u', 'm', 'k', 'a', 'l', 'c', 'p'})

pas.ranks.Create('jradmin', 7)
	:SetImmunity(6)
	:SetAdmin(true)
	:SetFlags({'u', 'm', 'k', 'b', 'a', 'l', 'c', 'p'})

pas.ranks.Create('sradmin', 8)
	:SetImmunity(7)
	:SetSuperAdmin(true)
	:SetFlags({'u', 'm', 'k', 'b', 'a', 's', 'l', 'c', 'p', 't'})

pas.ranks.Create('hgamemaster', 9)
	:SetImmunity(8)
	:SetVIP(true)
	:SetFlags({'u', 'm', 'k', 'b', 'a', 's', 'l', 'c', 'p', 't', 'g'})

pas.ranks.Create('council', 10)
	:SetImmunity(9)
	:SetSuperAdmin(true)
	:SetFlags({'*'})

pas.ranks.Create('sudoroot', 11)
	:SetImmunity(10)
	:SetSuperAdmin(true)
	:SetFlags({'*'})

pas.ranks.Create('superadmin', 12)
	:SetImmunity(11)
	:SetSuperAdmin(true)
	:SetGlobal(true)
	:SetFlags({'*'})

pas.ranks.Create('root', 13)
	:SetImmunity(12)
	:SetRoot(true)
	:SetGlobal(true)
	:SetFlags({'*'})
