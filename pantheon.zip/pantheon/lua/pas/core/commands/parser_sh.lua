-- Command parser for PANTHEON
pas.parser = pas.parser or {}

function pas.parser.ParsePlayer(str, caller)
	if not str then return {} end
	
	str = str:lower()
	local targets = {}
	
	-- Special selectors
	if str == '*' or str == 'all' then
		return player.GetAll()
	elseif str == '^' or str == 'self' then
		if CLIENT then
			return {LocalPlayer()}
		else
			return IsValid(caller) and {caller} or {}
		end
	elseif str:sub(1, 1) == '#' then
		-- Find by UserID
		local uid = tonumber(str:sub(2))
		local pl = Player(uid)
		if IsValid(pl) then
			return {pl}
		end
	elseif str:sub(1, 1) == '@' then
		-- Find by rank
		local rank = str:sub(2)
		for k, v in ipairs(player.GetAll()) do
			if v:GetRank() == rank then
				table.insert(targets, v)
			end
		end
		return targets
	else
		-- Find by name (partial match)
		for k, v in ipairs(player.GetAll()) do
			if v:Nick():lower():find(str, 1, true) then
				table.insert(targets, v)
			end
		end
	end
	
	return targets
end

function pas.parser.ParseTime(str)
	if not str then return 0 end
	
	local total = 0
	
	-- Parse format like: 1d2h30m
	for num, unit in str:gmatch('(%d+)([smhdwMy])') do
		num = tonumber(num)
		if unit == 's' then
			total = total + num
		elseif unit == 'm' then
			total = total + (num * 60)
		elseif unit == 'h' then
			total = total + (num * 3600)
		elseif unit == 'd' then
			total = total + (num * 86400)
		elseif unit == 'w' then
			total = total + (num * 604800)
		elseif unit == 'M' then
			total = total + (num * 2592000)
		elseif unit == 'y' then
			total = total + (num * 31536000)
		end
	end
	
	return total
end

function pas.parser.FormatTime(seconds)
	if seconds == 0 then return 'Permanent' end
	
	local units = {
		{31536000, 'year'},
		{2592000, 'month'},
		{604800, 'week'},
		{86400, 'day'},
		{3600, 'hour'},
		{60, 'minute'},
		{1, 'second'}
	}
	
	local result = {}
	
	for _, unit in ipairs(units) do
		local value = math.floor(seconds / unit[1])
		if value > 0 then
			table.insert(result, value .. ' ' .. unit[2] .. (value > 1 and 's' or ''))
			seconds = seconds - (value * unit[1])
		end
	end
	
	return table.concat(result, ', ')
end
