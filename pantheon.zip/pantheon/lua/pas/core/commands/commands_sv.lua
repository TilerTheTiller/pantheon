if (CLIENT) then return end

util.AddNetworkString('pas.RunCommand')
util.AddNetworkString('pas.AuthRequired')
util.AddNetworkString('pas.SyncCommands')

-- Sync all commands to a client
function pas.cmd.SyncToClient(pl)
	local commandList = {}
	
	for name, cmd in pairs(pas.cmd.Stored) do
		-- Only sync the command once (not aliases)
		if name == cmd.Name then
			table.insert(commandList, {
				name = cmd.Name,
				help = cmd.Help,
				flag = cmd.Flag,
				flags = cmd.Flags
			})
		end
	end
	
	net.Start('pas.SyncCommands')
		net.WriteUInt(#commandList, 16)
		for _, cmd in ipairs(commandList) do
			net.WriteString(cmd.name)
			net.WriteString(cmd.help or '')
			net.WriteString(cmd.flag or 'u')
			
			-- Send flags array if it exists
			if cmd.flags then
				net.WriteUInt(#cmd.flags, 8)
				for _, flag in ipairs(cmd.flags) do
					net.WriteString(flag)
				end
			else
				net.WriteUInt(0, 8)
			end
		end
	net.Send(pl)
end

-- Sync commands when player spawns
hook.Add('PlayerInitialSpawn', 'PANTHEON_SyncCommands', function(pl)
	timer.Simple(2, function()
		if IsValid(pl) then
			pas.cmd.SyncToClient(pl)
		end
	end)
end)

-- Command execution
function pas.cmd.Execute(pl, cmd, args)
	print("[PANTHEON CMD DEBUG] Execute called - Player: " .. tostring(pl:Nick()) .. ", Command: " .. cmd)
	
	local command = pas.cmd.Get(cmd)
	
	if not command then
		print("[PANTHEON CMD DEBUG] Command not found in Get()")
		return false, "Command not found"
	end
	
	print("[PANTHEON CMD DEBUG] Command found: " .. cmd)
	print("[PANTHEON CMD DEBUG] Command.Flags: " .. tostring(command.Flags))
	print("[PANTHEON CMD DEBUG] Command:GetFlag(): " .. tostring(command:GetFlag()))
	
	-- Check if player has any of the required flags
	local hasAccess = false
	if command.Flags then
		-- Check multiple flags
		print("[PANTHEON CMD DEBUG] Checking multiple flags:")
		for _, flag in ipairs(command.Flags) do
			print("[PANTHEON CMD DEBUG]   Checking flag: " .. flag)
			local hasFlagResult = pl:HasFlag(flag)
			print("[PANTHEON CMD DEBUG]   Player has flag '" .. flag .. "': " .. tostring(hasFlagResult))
			if hasFlagResult then
				hasAccess = true
				break
			end
		end
	elseif command:GetFlag() then
		-- Backwards compatibility - single flag
		print("[PANTHEON CMD DEBUG] Checking single flag: " .. command:GetFlag())
		hasAccess = pl:HasFlag(command:GetFlag())
		print("[PANTHEON CMD DEBUG] Has flag result: " .. tostring(hasAccess))
	else
		hasAccess = true -- No flag required
		print("[PANTHEON CMD DEBUG] No flag required")
	end
	
	if not hasAccess then
		print("[PANTHEON CMD DEBUG] Player lacks required flags")
		pas.notify(pl, "You don't have access to this command", 1)
		return false, "No access"
	end
	
	print("[PANTHEON CMD DEBUG] Flag check passed")
	
	-- Determine if this command requires admin authentication
	-- Only require auth for commands that need admin flags (not just 'u')
	local requiresAuth = false
	if command.Flags then
		for _, flag in ipairs(command.Flags) do
			if flag ~= 'u' then
				requiresAuth = true
				break
			end
		end
	elseif command:GetFlag() and command:GetFlag() ~= 'u' then
		requiresAuth = true
	end
	
	print("[PANTHEON CMD DEBUG] Requires auth: " .. tostring(requiresAuth))
	
	-- Check authentication only if command requires admin flags
	if requiresAuth then
		-- Check if auth module is loaded
		if not pas.auth or not pas.auth.IsAuthenticated then
			print("[PANTHEON CMD DEBUG] Auth module not loaded yet, skipping auth check")
		else
			local isAuth = pas.auth.IsAuthenticated(pl)
			
			print("[PANTHEON CMD DEBUG] Command '" .. cmd .. "' requires auth, checking player " .. pl:Nick())
			print("[PANTHEON CMD DEBUG] Auth check result: " .. tostring(isAuth))
			
			-- Debug auth data
			if pl.pas_AuthData then
				print("[PANTHEON CMD DEBUG] AuthData exists:")
				print("  authenticated: " .. tostring(pl.pas_AuthData.authenticated))
				print("  authTime: " .. tostring(pl.pas_AuthData.authTime))
				print("  CurTime: " .. tostring(CurTime()))
				if pl.pas_AuthData.authTime then
					local elapsed = CurTime() - pl.pas_AuthData.authTime
					print("  elapsed: " .. tostring(elapsed))
					print("  SESSION_TIMEOUT: " .. tostring(pas.auth.SESSION_TIMEOUT))
					print("  elapsed < timeout: " .. tostring(elapsed < pas.auth.SESSION_TIMEOUT))
				end
			else
				print("[PANTHEON CMD DEBUG] AuthData is NIL!")
			end
			
			if not isAuth then
				-- Store the pending command to execute after authentication
				pl.pas_PendingCommand = {
					cmd = cmd,
					args = args
				}
				
				-- If password info hasn't finished loading from DB, queue and request it
				if not pl.pas_PasswordLoaded then
					pas.notify(pl, "Loading authentication data, please wait...", 1)
					-- Trigger a load (safe to call; will retry internally)
					if pas.auth and pas.auth.LoadPassword then
						pas.auth.LoadPassword(pl)
					end
					-- We'll execute once auth completes (pas.auth.LoadPassword will set pas.pas_PasswordLoaded and SendAuthStatus)
					return false, "Authentication data loading"
				end
				
				-- Check if player needs to set up password
				local needsSetup = pas.auth.NeedsSetup and pas.auth.NeedsSetup(pl)
				print("[PANTHEON CMD DEBUG] NeedsSetup check: " .. tostring(needsSetup))
				
				-- Always send current auth status first to ensure client is synchronized
				pas.auth.SendAuthStatus(pl)
				
				-- Small delay to ensure status reaches client before auth prompt
				timer.Simple(0.1, function()
					if not IsValid(pl) then return end
					
					if needsSetup then
						pas.notify(pl, "You need to set up your admin password first.", 1) -- 1 = error/red
						
						print("[PANTHEON CMD DEBUG] Sending setup prompt to client")
						-- Tell client to show setup prompt
						net.Start("pas.AuthRequired")
							net.WriteBool(true) -- needs setup
						net.Send(pl)
					else
						-- Check if locked out
						local locked, timeLeft = false, 0
						if pas.auth.IsLockedOut then
							locked, timeLeft = pas.auth.IsLockedOut(pl)
						end
						
						if locked then
							pas.notify(pl, "You are locked out. Try again in " .. math.ceil(timeLeft) .. " seconds.", 1)
						else
							pas.notify(pl, "Authentication required. Use: /pas_login", 1)
							
							print("[PANTHEON CMD DEBUG] Sending login prompt to client")
							-- Tell client to show login prompt
							net.Start("pas.AuthRequired")
								net.WriteBool(false) -- needs login
							net.Send(pl)
						end
					end
				end)
				return false, "Authentication required"
			end
		end
	else
		print("[PANTHEON CMD DEBUG] Skipping auth check for basic user command")
	end
	
	print("[PANTHEON CMD DEBUG] About to Init command")
	command:Init(pl, args)
	
	-- Log command usage
	if pas.log and pas.log.Add then
		local argStr = table.concat(args, ' ')
		local logMsg = pl:Nick() .. ' used /' .. cmd .. (argStr ~= '' and ' ' .. argStr or '')
		pas.log.Add('commands', logMsg, pl:SteamID())
	end
	
	return true
end

-- Network command handler (for custom chatbox)
net.Receive('pas.RunCommand', function(len, pl)
	local cmd = net.ReadString()
	local args = net.ReadTable()
	
	print("[PANTHEON CMD DEBUG] Network command received - Player: " .. pl:Nick() .. ", Command: " .. cmd)
	
	if pas.cmd.Exists(cmd) then
		print("[PANTHEON CMD DEBUG] Executing network command: " .. cmd)
		pas.cmd.Execute(pl, cmd, args)
	else
		print("[PANTHEON CMD DEBUG] Network command not found: " .. cmd)
		pas.notify(pl, "Command not found: " .. cmd, 1)
	end
end)

-- Chat command handler (fallback for default chat)
hook.Add('PlayerSay', 'PANTHEON_ChatCommands', function(pl, text)
	print("[PANTHEON CMD DEBUG] PlayerSay fired: " .. tostring(text))
	
	if text:sub(1, 1) == '!' or text:sub(1, 1) == '/' then
		local args = string.Explode(' ', text:sub(2))
		local cmd = table.remove(args, 1)
		
		print("[PANTHEON CMD DEBUG] Command extracted: " .. tostring(cmd))
		print("[PANTHEON CMD DEBUG] Exists check: " .. tostring(pas.cmd.Exists(cmd)))
		
		if pas.cmd.Exists(cmd) then
			print("[PANTHEON CMD DEBUG] Executing command: " .. cmd)
			pas.cmd.Execute(pl, cmd, args)
			return ''
		else
			print("[PANTHEON CMD DEBUG] Command not found in storage")
		end
	end
end)
