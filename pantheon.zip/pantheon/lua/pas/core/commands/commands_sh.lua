pas.cmd 			= pas.cmd 		or {}
pas.cmd.Stored 	= pas.cmd.Stored or {}

local cmd_mt 	= {}
cmd_mt.__index 	= cmd_mt

function pas.cmd.Create(name, callback)
	local c = {
		Name  		= name:lower():gsub(' ', ''),
		NiceName 	= name,
		Args		= {},
		Flag	 	= 'u',
		Icon 		= 'icon16/group.png',
		Callback	= callback or function() end
	}
	setmetatable(c, cmd_mt)
	pas.cmd.Stored[c.Name] = c
	return c
end

function pas.cmd.GetTable()
	return pas.cmd.Stored
end

function pas.cmd.Get(name)
	return pas.cmd.Stored[name:lower()]
end

function pas.cmd.Exists(name)
	return (pas.cmd.Stored[name:lower()] ~= nil)
end

-- Set
function cmd_mt:AddAlias(name)
	pas.cmd.Stored[name:lower()] = self
	return self
end

function cmd_mt:RunOnClient(callback)
	self.ClientCallback = callback
	return self
end

function cmd_mt:AddArg(param, key, flag)
	self.Args[#self.Args + 1] = {
		Param 	= param,
		Key 	= key,
		Flag 	= flag,
	}
	return self
end
cmd_mt.AddParam = cmd_mt.AddArg

function cmd_mt:SetFlag(flag)
	-- Support both single flag and table of flags
	if type(flag) == "table" then
		self.Flags = flag
		self.Flag = flag[1] -- Keep first flag for backwards compatibility
	else
		self.Flag = flag
		self.Flags = {flag}
	end
	return self
end

function cmd_mt:SetHelp(help)
	self.Help = help
	return self
end

function cmd_mt:SetIcon(icon)
	self.Icon = icon
	return self
end

-- Get
function cmd_mt:GetName()
	return self.Name
end

function cmd_mt:GetNiceName()
	return self.Name
end

function cmd_mt:GetArgs()
	return self.Args
end

function cmd_mt:GetFlag()
	return self.Flag
end

function cmd_mt:GetHelp()
	return self.Help
end

function cmd_mt:GetIcon()
	return self.Icon
end

-- Internal
function cmd_mt:Init(pl, args)
	if (SERVER) then
		if self.ClientCallback then
			net.Start('pas.RunCommand')
				net.WriteString(self:GetName())
				net.WriteTable(args)
			net.Send(pl)
		end
		
		-- Try to execute the command, and show usage if it fails with specific error patterns
		local success, result = pcall(self.Callback, pl, args)
		
		if not success then
			-- If the command failed, show usage information automatically
			print("[COMMAND ERROR] " .. self.Name .. " failed: " .. tostring(result))
			self:ShowUsage(pl)
		elseif result == false then
			-- Command returned false (indicating invalid usage)
			self:ShowUsage(pl)
		end
		
		return result
	else
		return self.ClientCallback(pl)
	end
end

-- Function to show command usage
function cmd_mt:ShowUsage(pl)
	if not IsValid(pl) then return end
	
	local usageMsg = '[USAGE] !' .. self.Name
	
	-- Add arguments if any
	if self.Args and #self.Args > 0 then
		for _, arg in ipairs(self.Args) do
			if arg.Flag then -- Optional argument  
				usageMsg = usageMsg .. ' [' .. arg.Param .. ']'
			else
				usageMsg = usageMsg .. ' <' .. arg.Param .. '>'
			end
		end
	end
	
	pas.notify(pl, usageMsg, 1) -- Show as error (red)
	
	if self.Help then
		pas.notify(pl, '[INFO] ' .. self.Help, 0)
	end
end

if (CLIENT) then
	net.Receive('pas.RunCommand', function()
		local cmd 	= net.ReadString()
		local args 	= net.ReadTable()
		pas.cmd.Get(cmd):Init(args)
	end)
	
	-- Receive synced commands from server for autocomplete
	net.Receive('pas.SyncCommands', function()
		local count = net.ReadUInt(16)
		
		for i = 1, count do
			local name = net.ReadString()
			local help = net.ReadString()
			local flag = net.ReadString()
			
			-- Read flags array
			local flagCount = net.ReadUInt(8)
			local flags = nil
			if flagCount > 0 then
				flags = {}
				for j = 1, flagCount do
					table.insert(flags, net.ReadString())
				end
			end
			
			-- Only add if it doesn't already exist (prevent overwriting client-side commands)
			if not pas.cmd.Stored[name] then
				pas.cmd.Stored[name] = {
					Name = name,
					Help = help ~= '' and help or nil,
					Flag = flag,
					Flags = flags,
					_serverOnly = true -- Mark as server-synced
				}
			end
		end
		
		print('[PANTHEON] Synced ' .. count .. ' commands from server for autocomplete')
	end)
end
