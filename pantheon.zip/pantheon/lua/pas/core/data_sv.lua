if (CLIENT) then return end

pas.data = pas.data or {
	IP 		= '91.229.114.43',
	User 	= 'u10402_o8SrvyQc38',
	Pass 	= 'SNBIyK@aC2BEx^DFHn2+tStU',
	Table 	= 's10402_swrp_pantheon',
	Port 	= 3306,
	_uid 	= util.CRC(GetConVarString('ip') .. ':' .. GetConVarString('hostport'))
}

-- Try to connect to MySQL, but don't crash if it fails
local function initDB()
	if pas.data._db then return pas.data._db end
	
	local success, db = pcall(function()
		return ptmysql.newdb(pas.data.IP, pas.data.User, pas.data.Pass, pas.data.Table, pas.data.Port)
	end)
	
	if success and db then
		pas.data._db = db
		pas.print('[PANTHEON] Connected to MySQL database')
		return db
	else
		pas.print('[PANTHEON] Failed to connect to MySQL, using local fallback')
		pas.data._db = false -- Mark as failed
		return false
	end
end

pas.data._db = pas.data._db or initDB()

-- Initialize database tables
hook.Add('Initialize', 'PANTHEON_InitDB', function()
	timer.Simple(1, function()
		local db = pas.data.GetDB()
		if db then
			-- Ensure pas_users table exists
			db:query([[
				CREATE TABLE IF NOT EXISTS pas_users (
					steamid VARCHAR(32) PRIMARY KEY,
					name VARCHAR(128),
					firstjoined INT,
					lastseen INT,
					playtime INT DEFAULT 0
				)
			]])
			
			-- Ensure pas_players table exists (for authentication)
			db:query([[
				CREATE TABLE IF NOT EXISTS pas_players (
					steamid VARCHAR(32) PRIMARY KEY,
					usergroup VARCHAR(64),
					custom_flags TEXT,
					password_hash TEXT DEFAULT '',
					password_salt TEXT DEFAULT '',
					auth_token TEXT DEFAULT NULL,
					auth_token_expires INT DEFAULT 0
				)
			]])
			
			-- Ensure pas_ranks table exists
			db:query([[
				CREATE TABLE IF NOT EXISTS pas_ranks (
					steamid VARCHAR(32),
					sv_id VARCHAR(64),
					rank INT DEFAULT 1,
					expire_rank INT DEFAULT 1,
					expire_time INT DEFAULT 0,
					PRIMARY KEY (steamid, sv_id)
				)
			]])
			
			-- Ensure pas_keys table exists
			db:query([[
				CREATE TABLE IF NOT EXISTS pas_keys (
					Date INT,
					Key VARCHAR(128)
				)
			]])
			
			pas.print('[PANTHEON] Database tables initialized')
			
			-- Call hook to notify that database is ready
			hook.Call("pas_DatabaseReady", nil)
		end
	end)
end)

--
-- Misc
--
function pas.data.GetDB()
	if pas.data._db == false then
		-- Database connection failed, return nil
		return nil
	end
	return pas.data._db
end

-- Wrapper for database queries with parameter support
function pas.data.Query(query, params, callback)
	local db = pas.data.GetDB()
	if not db then return end
	
	if params and #params > 0 then
		db:query_ex(query, params, callback)
	else
		db:query(query, callback)
	end
end

function pas.data.GetID()
	return (pas.svar.Get('sv_id') or 'NOT_SET')
end

function pas.data.GetUID()
	return pas.data._uid
end


--
-- 	Auth keys
--
local db = pas.data.GetDB()

function pas.data.CreateKey(pl, cback)
	local time = os.time()
	local key = pl:HashID()
	pl:SetBVar('LastKey', key)
	db:query('INSERT INTO pas_keys(`Date`, `Key`) VALUES(' .. time .. ', "' .. key .. '");', cback)
	return key
end

function pas.data.DestroyKey(key, cback)
	db:query('DELETE * FROM pas_keys WHERE `Key`="' .. key .. '";', cback)
end


--
-- Player data
--
function pas.data.LoadPlayer(pl, cback)
	-- Ensure ranks are loaded before processing player data
	if not pas.ranks or not pas.ranks.Get then
		-- Retry after a short delay if ranks aren't ready
		timer.Simple(0.5, function()
			if IsValid(pl) then
				pas.data.LoadPlayer(pl, cback)
			end
		end)
		return
	end
	
	-- Check if user rank exists, if not create a fallback
	local user_rank = pas.ranks.Get(1)
	if not user_rank then
		pas.print('[PANTHEON ERROR] User rank (ID 1) not found! This is critical.')
		-- Set a basic UserGroup as fallback
		pl:SetNetVar('UserGroup', 1)
		if cback then cback(nil) end
		return
	end
	
	-- Check database connectivity with fallback for local testing
	local db = pas.data.GetDB()
	if not db then
		pas.print('[PANTHEON] No database connection - using fallback mode for ' .. pl:Nick())
		-- TEMPORARY: Give admin permissions for testing when database is down
		local admin_rank = pas.ranks.Get(12) -- superadmin
		if admin_rank then
			pl:SetNetVar('UserGroup', admin_rank:GetID())
			pas.print('[PANTHEON] Assigned temporary admin rank to ' .. pl:Nick() .. ' (database offline)')
		else
			pl:SetNetVar('UserGroup', 1)
		end
		pl:SetBVar('DataLoaded', true)
		if cback then cback(nil) end
		return
	end
	
	local steamid 	= (pl:SteamID64() or '0')
	local name 		= pl:Name()

	db:query_ex('SELECT * FROM pas_users WHERE steamid=?', {steamid}, function(_data)
		-- Handle potential nil data from database errors
		if not _data then
			pas.print('[PANTHEON ERROR] Database query failed for user data: ' .. steamid)
			if cback then cback(nil) end
			return
		end
		
		local d 	= (_data[1]		or {})
		d.lastseen 	= (d.lastseen	or os.time())
		d.playtime	= (d.playtime	or 0)

		pl:SetNetVar('PlayTime', d.playtime)
		pl:SetNetVar('FirstJoined', CurTime())

		if (#_data < 1) then
			db:query_ex('INSERT INTO pas_users(steamid, name, firstjoined, lastseen, playtime) VALUES(?, ?, ?, ?, 0)', {steamid, name, os.time(), os.time()})
			pas.notify_all(pas.Term('PlayerFirstConnect'), pl)
		else
			db:query_ex('UPDATE pas_users SET name=?, lastseen=? WHERE steamid=?;', {name, os.time(), steamid})
			pas.notify_all(pas.Term('PlayerConnect'), pl, os.date("%m/%d/%Y" , d.lastseen))
		end

		if not d.firstjoined then
			db:query_ex('UPDATE pas_users SET firstjoined=? WHERE steamid=?;', {os.time(), steamid})
		end

		-- Simplified approach: try to load rank data, but always ensure player has a valid rank
		db:query_ex('SELECT * FROM pas_ranks WHERE steamid=? AND (sv_id=? OR sv_id=?);', {steamid, pas.data.GetID(), "NO_ID"}, function(data)
			-- Handle potential nil data from database errors
			if not data then
				pas.print('[PANTHEON ERROR] Database query failed for rank data: ' .. steamid)
				-- Still set a default rank to prevent total failure
				pl:SetNetVar('UserGroup', 1)
				if cback then cback(nil) end
				return
			end
			
			local _d = (data and data[1]) or {}
			local rank_id = 1 -- Default to user rank
			
			-- If player has existing rank data, try to use it
			if _d.rank then
				local existing_rank = pas.ranks.Get(tonumber(_d.rank))
				if existing_rank then
					rank_id = existing_rank:GetID()
				end
			end
			
			-- Always set the UserGroup, ensuring player has a rank
			pl:SetNetVar('UserGroup', rank_id)
			
			-- Clear rank cache to force refresh
			pl._RankTableCache = nil
			pl._RankWarningShown = nil
			
			-- Set other player data with proper type conversion
			local expire_time = tonumber(_d.expire_time or 0) or 0
			pl:SetBVar('expire_rank', _d.expire_rank or 'user')
			pl:SetBVar('expire_time', expire_time)

			-- If no rank data exists, create default entry
			if not data or #data < 1 then
				db:query_ex('INSERT INTO pas_ranks(steamid, sv_id, rank, expire_rank, expire_time) VALUES(?,?,?,?,?)', {steamid, pas.data.GetID(), 1, 1, 0}, function()
					pas.print('[PANTHEON] Created default rank entry for ' .. pl:Nick())
				end)
			end

			-- Check for rank expiration with proper number comparison
			if (expire_time ~= 0) and (expire_time < os.time()) then
				pas.data.SetRank(pl, _d.expire_rank or 'user', _d.expire_rank or 'user', 0, hook.Call('playerRankExpire', pas, pl, _d.expire_rank))
			end

			if cback then cback(data) end

			pl:SetBVar('DataLoaded', true)

			hook.Call('playerRankLoaded', pas, pl, _d)
		end)
	end)
end

function pas.data.SetRank(pl, rank, expire_rank, expire_time, cback)
	-- Ensure ranks are loaded before setting ranks
	if not pas.ranks or not pas.ranks.Get then
		ErrorNoHalt('[PANTHEON] SetRank called before rank system is loaded!')
		if cback then cback(false) end
		return
	end
	
	local steamid 	= pas.InfoTo64(pl)
	local sv_id 	= pas.data.GetID()
	local r 		= (rank 		or 1)
	local exr 		= (expire_rank 	or 'user')
	local ext 		= (expire_time 	or 0)
	local rank_obj 	= pas.ranks.Get(r)
	local rank_ex_obj = pas.ranks.Get(exr)
	
	-- Validate rank objects exist
	if not rank_obj then
		ErrorNoHalt('[PANTHEON] SetRank: Invalid rank "' .. tostring(r) .. '"')
		rank_obj = pas.ranks.Get(1) or pas.ranks.Get('user')
		if not rank_obj then
			ErrorNoHalt('[PANTHEON] SetRank: Could not fallback to user rank!')
			if cback then cback(false) end
			return
		end
	end
	
	if not rank_ex_obj then
		ErrorNoHalt('[PANTHEON] SetRank: Invalid expire rank "' .. tostring(exr) .. '"')
		rank_ex_obj = pas.ranks.Get(1) or pas.ranks.Get('user')
		if not rank_ex_obj then
			ErrorNoHalt('[PANTHEON] SetRank: Could not fallback to user expire rank!')
			if cback then cback(false) end
			return
		end
	end

	local rank_id = rank_obj:GetID()
	local rank_ex_id = rank_ex_obj:GetID()

	if rank_obj:IsGlobal() then
		sv_id = 'NO_ID'

		db:query_ex('DELETE FROM pas_ranks WHERE steamid=?', {steamid}, function(data)
			db:query_ex('INSERT INTO pas_ranks(steamid, sv_id, rank, expire_rank, expire_time) VALUES(?,?,?,?,?)', {steamid, sv_id, rank_id, rank_ex_id, ext}, function(data)
				if pas.IsPlayer(pl) then
					pl:SetBVar('expire_rank', exr)
					pl:SetBVar('expire_time', ext)
					-- Always set UserGroup, even for rank ID 1 (user)
					pl:SetNetVar('UserGroup', rank_id)
					-- Clear cached rank table to force refresh
					pl._RankTableCache = nil
					pl._RankWarningShown = nil
					-- Force immediate rank refresh
					timer.Simple(0.1, function()
						if IsValid(pl) then
							pl._RankTableCache = nil
							pl:SetNetVar('UserGroup', rank_id)
						end
					end)
				end
				hook.Call('playerSetRank', pas, pl, r, exr, ext)
				if cback then cback(data) end
			end)
		end)
	else
		db:query_ex('REPLACE INTO pas_ranks(steamid, sv_id, rank, expire_rank, expire_time) VALUES(?,?,?,?,?)', {steamid, sv_id, rank_id, rank_ex_id, ext}, function(data)
			if pas.IsPlayer(pl) then
				pl:SetBVar('expire_rank', exr)
				pl:SetBVar('expire_time', ext)
				-- Always set UserGroup, even for rank ID 1 (user)
				pl:SetNetVar('UserGroup', rank_id)
				-- Clear cached rank table to force refresh
				pl._RankTableCache = nil
				pl._RankWarningShown = nil
				-- Force immediate rank refresh
				timer.Simple(0.1, function()
					if IsValid(pl) then
						pl._RankTableCache = nil
						pl:SetNetVar('UserGroup', rank_id)
					end
				end)
			end
			hook.Call('playerSetRank', pas, pl, r, exr, ext)
			-- Fire hook to clear rank cache
			hook.Call('PAS.RankUpdated', GAMEMODE, pl)
			if cback then cback(data) end
		end)
	end
end

function pas.data.UpdatePlayTime(pl)
	if not IsValid(pl) or not pl:GetBVar('DataLoaded') then return end
	db:query('UPDATE pas_users SET lastseen=' .. os.time() .. ', playtime=' .. pl:GetPlayTime() .. ' WHERE steamid=' .. pl:SteamID64() .. ';')
end

-- Sync queries
function pas.data.GetRank(steamid64)
	local data = db:query_sync('SELECT rank FROM pas_ranks WHERE steamid=? AND (sv_id="?" OR sv_id="NO_ID");', {steamid64, pas.data.GetID()})
	return (data[1] and data[1].rank or 'user')
end

function pas.data.GetName(steamid64)
	local data = db:query_sync('SELECT name FROM pas_users WHERE steamid=?;', {steamid64})
	return (data[1] and data[1].name)
end
