function PLAYER:GetPlayTime()
	return (self:GetNetVar('PlayTime') or 0) + (CurTime() - (self:GetNetVar('FirstJoined') or CurTime()))
end

-- Enhanced player functions from D3A
function PLAYER:HasAccess(flag)
	return pas.flags.HasFlag(self, flag)
end

function PLAYER:GetDataVar(name)
	return SERVER and (self._Vars and self._Vars[name]) or self:GetNetVar(name)
end

function PLAYER:GetGroupWeight()
	if not IsValid(self) then return 0 end
	local rank = pas.ranks.Get(self:GetUserGroup())
	return rank and rank.Weight or 0
end

function PLAYER:IsAdmin()
	return self:HasFlag('a')
end

function PLAYER:IsSuperAdmin()
	return self:HasFlag('s')
end

function PLAYER:IsUserGroup(group)
	return self:GetUserGroup():lower() == group:lower()
end

function PLAYER:NameID()
	return self:Name() .. " (" .. self:SteamID() .. ")"
end

-- Admin mode functionality
function PLAYER:SetAdminMode(enabled)
	if SERVER then
		self:SetNetVar('AdminMode', enabled)
		
		if enabled then
			-- Store original job/model
			self._OriginalModel = self:GetModel()
			
			-- Set admin appearance
			self:SetModel("models/player/combine_super_soldier.mdl")
			self:GodEnable()
			
			-- Give admin tools based on permissions
			local adminTools = {
				["weapon_physgun"] = "p",
				["gmod_tool"] = "t",
				["gmod_camera"] = "t"
			}
			
			for weapon, flag in pairs(adminTools) do
				if self:HasFlag(flag) then
					self:Give(weapon)
				end
			end
		else
			-- Restore original appearance
			if self._OriginalModel then
				self:SetModel(self._OriginalModel)
				self._OriginalModel = nil
			end
			
			self:GodDisable()
			
			-- Remove admin tools
			local adminTools = {"weapon_physgun", "gmod_tool"}
			for _, weapon in pairs(adminTools) do
				self:StripWeapon(weapon)
			end
		end
	end
end

function PLAYER:GetAdminMode()
	return self:GetNetVar('AdminMode') or false
end

nw.Register 'PlayTime'
	:Write(net.WriteUInt, 32)
	:Read(net.ReadUInt, 32)
	:SetPlayer()

nw.Register 'FirstJoined'
	:Write(net.WriteUInt, 32)
	:Read(net.ReadUInt, 32)
	:SetPlayer()

nw.Register 'AdminMode'
	:Write(net.WriteBool)
	:Read(net.ReadBool)
	:SetPlayer()

-- Add BVar (server-only variables) support
if SERVER then
	function PLAYER:SetBVar(key, value)
		self._BVars = self._BVars or {}
		self._BVars[key] = value
	end

	function PLAYER:GetBVar(key, default)
		if not self._BVars then return default end
		return self._BVars[key] or default
	end
else
	-- Client side BVars are not synced
	function PLAYER:SetBVar(key, value)
		self._BVars = self._BVars or {}
		self._BVars[key] = value
	end

	function PLAYER:GetBVar(key, default)
		if not self._BVars then return default end
		return self._BVars[key] or default
	end
end

-- Initialize AdminMode to false on player spawn
if SERVER then
	hook.Add('PlayerInitialSpawn', 'pas_InitAdminMode', function(ply)
		ply:SetNetVar('AdminMode', false)
	end)
end
