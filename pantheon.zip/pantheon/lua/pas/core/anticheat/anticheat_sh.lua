-- PANTHEON Anti-Cheat System (Shared)
if (SERVER) then
	AddCSLuaFile()
end

pas.ac = pas.ac or {}

-- Anti-cheat categories
pas.ac.categories = {
	aimbot = {
		name = 'Aimbot',
		color = Color(255, 50, 50),
		enabled = true,
		severity = 3 -- 1=Low, 2=Medium, 3=High, 4=Critical
	},
	speedhack = {
		name = 'Speed Hack',
		color = Color(255, 100, 50),
		enabled = true,
		severity = 3
	},
	noclip = {
		name = 'Unauthorized Noclip',
		color = Color(255, 150, 50),
		enabled = true,
		severity = 2
	},
	bhop = {
		name = 'Bunny Hop',
		color = Color(255, 200, 50),
		enabled = true,
		severity = 1
	},
	namestealer = {
		name = 'Name Stealer',
		color = Color(150, 100, 255),
		enabled = true,
		severity = 2
	},
	spam = {
		name = 'Chat Spam',
		color = Color(100, 150, 255),
		enabled = true,
		severity = 1
	},
	exploits = {
		name = 'Exploit Attempt',
		color = Color(200, 50, 200),
		enabled = true,
		severity = 4
	},
	suspicious = {
		name = 'Suspicious Activity',
		color = Color(255, 255, 100),
		enabled = true,
		severity = 2
	},
	wallhack = {
		name = 'Wallhack/ESP',
		color = Color(255, 70, 150),
		enabled = true,
		severity = 3
	},
	triggerbot = {
		name = 'Triggerbot',
		color = Color(255, 120, 80),
		enabled = true,
		severity = 3
	},
	norecoil = {
		name = 'No Recoil',
		color = Color(255, 180, 100),
		enabled = true,
		severity = 2
	},
	rapidfire = {
		name = 'Rapid Fire',
		color = Color(255, 90, 60),
		enabled = true,
		severity = 3
	},
	flyhack = {
		name = 'Fly Hack',
		color = Color(100, 200, 255),
		enabled = true,
		severity = 3
	},
	godmode = {
		name = 'God Mode',
		color = Color(255, 215, 0),
		enabled = true,
		severity = 4
	},
	convar = {
		name = 'ConVar Manipulation',
		color = Color(180, 100, 200),
		enabled = true,
		severity = 2
	}
}

-- Get category info
function pas.ac.GetCategory(category)
	return pas.ac.categories[category] or pas.ac.categories['suspicious']
end

-- Detection actions
pas.ac.actions = {
	LOG = 1,      -- Just log it
	WARN = 2,     -- Warn admins
	NOTIFY = 3,   -- Notify player
	KICK = 4,     -- Kick player
	BAN = 5       -- Ban player
}

print('[PANTHEON] Anti-Cheat system (shared) loaded')
