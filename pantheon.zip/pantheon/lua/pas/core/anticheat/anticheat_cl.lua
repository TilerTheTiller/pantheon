-- PANTHEON Anti-Cheat System (Client)
if (SERVER) then return end

pas.ac = pas.ac or {}
pas.ac.detectionCache = pas.ac.detectionCache or {}
pas.ac.playerStats = pas.ac.playerStats or {}

-- Receive detection notifications
net.Receive('pas.ACDetection', function()
	local playerName = net.ReadString()
	local steamid = net.ReadString()
	local category = net.ReadString()
	local details = net.ReadString()
	local count = net.ReadUInt(16)
	
	-- Create detection object
	local detection = {
		time = os.time(),
		playerName = playerName,
		steamid = steamid,
		category = category,
		details = details,
		count = count
	}
	
	-- Store in cache
	table.insert(pas.ac.detectionCache, detection)
	
	-- Update player stats
	pas.ac.playerStats[steamid] = pas.ac.playerStats[steamid] or {name = playerName, detections = {}}
	pas.ac.playerStats[steamid].detections[category] = (pas.ac.playerStats[steamid].detections[category] or 0) + 1
	pas.ac.playerStats[steamid].totalDetections = (pas.ac.playerStats[steamid].totalDetections or 0) + 1
	pas.ac.playerStats[steamid].lastDetection = os.time()
	
	-- Call hook for UI updates
	if pas.ac.OnDetection then
		pas.ac.OnDetection(detection)
	end
	
	-- Only show notifications to admins
	if not LocalPlayer():HasFlag('m') then return end
	
	local cat = pas.ac.GetCategory(category)
	
	-- Play alert sound based on severity
	if cat.severity >= 3 then
		surface.PlaySound('buttons/button10.wav')
	else
		surface.PlaySound('buttons/button17.wav')
	end
	
	-- Show notification
	local severityText = {'INFO', 'WARN', 'KICK', 'BAN'}
	notification.AddLegacy(string.format('[AC %s] %s: %s (%dx)', 
		severityText[cat.severity] or 'INFO', 
		playerName, 
		cat.name, 
		count), 
		cat.severity >= 3 and NOTIFY_ERROR or NOTIFY_HINT, 
		8
	)
end)

-- Receive player notification
net.Receive('pas.ACNotify', function()
	local category = net.ReadString()
	local cat = pas.ac.GetCategory(category)
	
	-- Warning to player
	chat.AddText(Color(255, 100, 100), '[PANTHEON] ', color_white, 
		string.format('Warning: %s detected. Continued violations will result in punishment.', cat.name))
	surface.PlaySound('ambient/alarms/warningbell1.wav')
end)

-- Anti-cheat viewer UI
function pas.ac.OpenViewer()
	if IsValid(pas.ac.viewer) then
		pas.ac.viewer:Remove()
	end
	
	-- Create main frame
	local frame = ui.CreateFrame('Anti-Cheat Monitor', 1400, 800, 'lock')
	pas.ac.viewer = frame
	
	-- Detection history for graphs
	local detectionHistory = {}
	for i = 1, 60 do
		table.insert(detectionHistory, 0)
	end
	
	-- Particle system for background
	local particles = {}
	for i = 1, 20 do
		table.insert(particles, {
			x = math.random(0, frame:GetWide()),
			y = math.random(0, frame:GetTall()),
			size = math.random(2, 6),
			speedX = math.Rand(-0.3, 0.3),
			speedY = math.Rand(-0.5, -0.1),
			alpha = math.random(30, 80)
		})
	end
	
	-- Override frame paint to add grid background and particles
	local basePaint = frame.Paint
	frame.Paint = function(self, w, h)
		-- Draw semi-transparent blurred background
		draw.RoundedBox(8, 0, 0, w, h, ColorAlpha(ui.col.BackgroundDark, 240))
		
		-- Draw grid background overlay
		local gridMat = ui.GetIcon('grid-bg')
		if gridMat then
			surface.SetDrawColor(255, 255, 255, 15)
			surface.SetMaterial(gridMat)
			surface.DrawTexturedRect(0, 0, w, h)
		end
		
		-- Draw vignette overlay
		local vignetteMat = ui.GetIcon('vignette')
		if vignetteMat then
			surface.SetDrawColor(0, 0, 0, 60)
			surface.SetMaterial(vignetteMat)
			surface.DrawTexturedRect(0, 0, w, h)
		end
		
		-- Draw and update particles
		for _, p in ipairs(particles) do
			-- Update position
			p.x = p.x + p.speedX
			p.y = p.y + p.speedY
			
			-- Wrap around
			if p.y < -10 then p.y = h + 10 end
			if p.y > h + 10 then p.y = -10 end
			if p.x < -10 then p.x = w + 10 end
			if p.x > w + 10 then p.x = -10 end
			
			-- Draw particle glow first (larger)
			local glowSize = p.size * 3
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, p.alpha * 0.4)
			surface.DrawRect(p.x - glowSize/2, p.y - glowSize/2, glowSize, glowSize)
			
			-- Draw particle core (brighter)
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, p.alpha * 1.5)
			surface.DrawRect(p.x - p.size/2, p.y - p.size/2, p.size, p.size)
		end
		
		-- Draw top header bar
		draw.RoundedBoxEx(8, 0, 0, w, 35, ColorAlpha(ui.col.BackgroundCard, 200), true, true, false, false)
		
		-- Icon and title
		ui.DrawIcon('lock', 20, 17.5, 16, ui.col.PANTHEON)
		draw.SimpleText('Anti-Cheat Monitor', 'PANTHEON.20', 35, 17.5, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	-- Stats header panel
	local statsHeader = vgui.Create('DPanel', frame)
	statsHeader:SetPos(10, 45)
	statsHeader:SetSize(frame:GetWide() - 20, 100)
	statsHeader.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Top accent line with gradient effect
		for i = 0, 3 do
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150 - i * 30)
			surface.DrawRect(0, i, w, 1)
		end
		
		-- Dividers with glow
		for i = 1, 4 do
			local x = w * i / 5
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 100)
			surface.DrawRect(x, 20, 2, h - 40)
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 50)
			surface.DrawRect(x - 1, 20, 1, h - 40)
			surface.DrawRect(x + 2, 20, 1, h - 40)
		end
		
		-- Total detections
		local totalDetections = #pas.ac.detectionCache
		draw.SimpleText('TOTAL DETECTIONS', 'PANTHEON.14', w/10, 22, ui.col.TextDim, TEXT_ALIGN_CENTER)
		local pulseDetect = math.abs(math.sin(CurTime() * 1.5)) * 0.2 + 0.8
		draw.SimpleText(tostring(totalDetections), 'PANTHEON.32', w/10, 62, ColorAlpha(ui.col.PANTHEON, 255 * pulseDetect), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		
		-- Flagged players
		local activeThreats = table.Count(pas.ac.playerStats)
		draw.SimpleText('FLAGGED PLAYERS', 'PANTHEON.14', w*3/10, 22, ui.col.TextDim, TEXT_ALIGN_CENTER)
		local threatColor = activeThreats > 5 and Color(255, 50, 50) or activeThreats > 2 and Color(255, 150, 50) or Color(255, 200, 100)
		draw.SimpleText(tostring(activeThreats), 'PANTHEON.32', w*3/10, 62, threatColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		
		-- Online players
		local onlinePlayers = #player.GetAll()
		draw.SimpleText('ONLINE PLAYERS', 'PANTHEON.14', w/2, 22, ui.col.TextDim, TEXT_ALIGN_CENTER)
		draw.SimpleText(tostring(onlinePlayers), 'PANTHEON.32', w/2, 62, Color(100, 255, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		
		-- Critical detections (severity 3+)
		local criticalCount = 0
		for _, detection in ipairs(pas.ac.detectionCache) do
			local cat = pas.ac.GetCategory(detection.category)
			if cat.severity >= 3 then
				criticalCount = criticalCount + 1
			end
		end
		draw.SimpleText('CRITICAL', 'PANTHEON.14', w*7/10, 22, ui.col.TextDim, TEXT_ALIGN_CENTER)
		local pulseCrit = math.abs(math.sin(CurTime() * 3)) * 0.3 + 0.7
		draw.SimpleText(tostring(criticalCount), 'PANTHEON.32', w*7/10, 62, Color(255 * pulseCrit, 50, 50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		
		-- Detection rate (per minute)
		local recentDetections = 0
		local now = os.time()
		for _, detection in ipairs(pas.ac.detectionCache) do
			if now - detection.time < 60 then
				recentDetections = recentDetections + 1
			end
		end
		draw.SimpleText('PER MINUTE', 'PANTHEON.14', w*9/10, 22, ui.col.TextDim, TEXT_ALIGN_CENTER)
		draw.SimpleText(tostring(recentDetections), 'PANTHEON.32', w*9/10, 62, Color(150, 200, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	-- Graph panel (top visualization)
	local graphPanel = vgui.Create('DPanel', frame)
	graphPanel:SetPos(10, 155)
	graphPanel:SetSize(frame:GetWide() - 20, 120)
	graphPanel.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Header
		draw.RoundedBoxEx(6, 0, 0, w, 30, ui.col.BackgroundCard, true, true, false, false)
		ui.DrawIcon('chart', 17, 15, 14, ui.col.PANTHEON)
		draw.SimpleText('Detection Activity (Last 60 seconds)', 'PANTHEON.16', 32, 15, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		
		-- Graph area
		local graphX, graphY = 15, 40
		local graphW, graphH = w - 30, h - 50
		
		-- Grid lines
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 20)
		for i = 0, 5 do
			local y = graphY + (graphH / 5) * i
			surface.DrawRect(graphX, y, graphW, 1)
		end
		
		-- Draw graph
		local maxVal = 1
		for _, v in ipairs(detectionHistory) do
			maxVal = math.max(maxVal, v)
		end
		
		local barWidth = graphW / #detectionHistory
		
		for i, value in ipairs(detectionHistory) do
			local barHeight = (value / maxVal) * graphH
			local x = graphX + (i - 1) * barWidth
			local y = graphY + graphH - barHeight
			
			-- Bar with gradient
			local alpha = 100 + (value / maxVal) * 155
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, alpha * 0.5)
			surface.DrawRect(x, y, barWidth - 1, barHeight)
			
			-- Top glow
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, alpha)
			surface.DrawRect(x, y, barWidth - 1, 2)
		end
		
		-- Current value indicator
		local currentVal = detectionHistory[#detectionHistory] or 0
		if currentVal > 0 then
			draw.SimpleText(tostring(currentVal), 'PANTHEON.14', w - 20, graphY + 5, ui.col.PANTHEON, TEXT_ALIGN_RIGHT)
		end
	end
	
	-- Update graph every second
	timer.Create('PANTHEON_AC_GraphUpdate', 1, 0, function()
		if not IsValid(frame) then 
			timer.Remove('PANTHEON_AC_GraphUpdate')
			return 
		end
		
		-- Count detections in last second
		local recentCount = 0
		local now = os.time()
		for _, detection in ipairs(pas.ac.detectionCache) do
			if now - detection.time < 1 then
				recentCount = recentCount + 1
			end
		end
		
		-- Shift history and add new value
		table.remove(detectionHistory, 1)
		table.insert(detectionHistory, recentCount)
	end)
	
	-- Live detections panel (left side)
	local livePanel = ui.CreatePanel(frame, 10, 285, 850, frame:GetTall() - 380)
	livePanel:SetPaintBackground(false)
	
	livePanel.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Header with gradient
		draw.RoundedBoxEx(6, 0, 0, w, 40, ui.col.BackgroundCard, true, true, false, false)
		
		-- Pulsing accent line
		local pulse = math.abs(math.sin(CurTime() * 2)) * 0.4 + 0.6
		for i = 0, 2 do
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150 * pulse - i * 30)
			surface.DrawRect(0, h - 2 + i, w, 1)
		end
		
		-- Icon and title with glow
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 30)
		surface.DrawRect(10, 10, 30, 30)
		ui.DrawIcon('warning', 25, 25, 16, ui.col.PANTHEON)
		draw.SimpleText('Live Detection Feed', 'PANTHEON.18', 48, 20, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		
		-- Detection count badge
		local liveCount = math.min(#pas.ac.detectionCache, 999)
		draw.RoundedBox(12, w - 80, 12, 65, 24, ColorAlpha(ui.col.PANTHEON, 80))
		draw.SimpleText(tostring(liveCount), 'PANTHEON.16', w - 47, 20, ui.col.PANTHEON, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	local liveList = ui.CreateListView(livePanel, 8, 48, livePanel:GetWide() - 18, livePanel:GetTall() - 56)
	liveList:AddColumn('Time', 75)
	liveList:AddColumn('Player', 140)
	liveList:AddColumn('Type', 130)
	liveList:AddColumn('Details', 330)
	liveList:AddColumn('Count', 45)
	liveList:AddColumn('Severity', 60)
	liveList:SetMultiSelect(false)
	
	-- Populate with cached detections
	local severityNames = {'LOW', 'MED', 'HIGH', 'CRIT'}
	
	for i = math.max(1, #pas.ac.detectionCache - 100), #pas.ac.detectionCache do
		local detection = pas.ac.detectionCache[i]
		local cat = pas.ac.GetCategory(detection.category)
		local timeStr = os.date('%H:%M:%S', detection.time)
		local severityText = severityNames[cat.severity] or 'UNK'
		
		local line = liveList:AddLine(timeStr, detection.playerName, cat.name, detection.details, detection.count, severityText)
		
		-- Color code by severity with enhanced visuals
		line.Paint = function(self, w, h)
			local baseAlpha = 25
			local hoverAlpha = 80
			local selectAlpha = 120
			
			if self:IsSelected() then
				draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(ui.col.PANTHEON, selectAlpha))
				-- Left accent bar
				surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 255)
				surface.DrawRect(0, 0, 3, h)
			elseif self:IsHovered() then
				draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(cat.color, hoverAlpha))
				-- Left accent bar
				surface.SetDrawColor(cat.color.r, cat.color.g, cat.color.b, 200)
				surface.DrawRect(0, 0, 3, h)
			else
				draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(cat.color, baseAlpha))
				-- Left accent bar (subtle)
				surface.SetDrawColor(cat.color.r, cat.color.g, cat.color.b, 100)
				surface.DrawRect(0, 0, 2, h)
			end
			
			-- Severity indicator dot
			local dotX = w - 45
			local dotY = h / 2
			surface.SetDrawColor(cat.color.r, cat.color.g, cat.color.b, 255)
			draw.NoTexture()
			surface.DrawCircle(dotX, dotY, 4, cat.color)
		end
		
		-- Store category data for right-click menu
		line.detectionData = detection
	end
	
	-- Player stats panel (right side)
	local statsPanel = ui.CreatePanel(frame, 870, 285, 520, frame:GetTall() - 380)
	statsPanel:SetPaintBackground(false)
	
	statsPanel.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Header with gradient
		draw.RoundedBoxEx(6, 0, 0, w, 40, ui.col.BackgroundCard, true, true, false, false)
		
		-- Accent line with pulse
		local pulse = math.abs(math.sin(CurTime() * 2)) * 0.4 + 0.6
		for i = 0, 2 do
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150 * pulse - i * 30)
			surface.DrawRect(0, h - 2 + i, w, 1)
		end
		
		-- Icon with glow
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 30)
		surface.DrawRect(10, 10, 30, 30)
		ui.DrawIcon('user', 25, 25, 16, ui.col.PANTHEON)
		draw.SimpleText('Player Statistics', 'PANTHEON.18', 48, 20, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		
		-- Player count badge
		local playerCount = table.Count(pas.ac.playerStats)
		draw.RoundedBox(12, w - 70, 12, 55, 24, ColorAlpha(ui.col.Red, 80))
		draw.SimpleText(tostring(playerCount), 'PANTHEON.16', w - 42, 20, ui.col.Red, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	local statsList = ui.CreateListView(statsPanel, 8, 48, statsPanel:GetWide() - 18, statsPanel:GetTall() - 56)
	statsList:AddColumn('Player', w)
	statsList:AddColumn('Total', w)
	statsList:AddColumn('Risk', w)
	statsList:AddColumn('Last Seen', w)
	statsList:SetMultiSelect(false)
	
	-- Populate player stats
	local function RefreshStats()
		statsList:Clear()
		
		-- Sort by total detections
		local sortedStats = {}
		for steamid, data in pairs(pas.ac.playerStats) do
			table.insert(sortedStats, {steamid = steamid, data = data})
		end
		table.sort(sortedStats, function(a, b) 
			return (a.data.totalDetections or 0) > (b.data.totalDetections or 0)
		end)
		
		for _, entry in ipairs(sortedStats) do
			local data = entry.data
			local lastSeen = data.lastDetection and os.date('%H:%M:%S', data.lastDetection) or 'N/A'
			
			-- Calculate risk level
			local riskLevel = 'LOW'
			local riskColor = Color(100, 255, 150)
			local detectionCount = data.totalDetections or 0
			
			if detectionCount >= 20 then
				riskLevel = 'CRITICAL'
				riskColor = Color(255, 50, 50)
			elseif detectionCount >= 10 then
				riskLevel = 'HIGH'
				riskColor = Color(255, 100, 50)
			elseif detectionCount >= 5 then
				riskLevel = 'MEDIUM'
				riskColor = Color(255, 200, 50)
			end
			
			local line = statsList:AddLine(data.name, detectionCount, riskLevel, lastSeen)
			
			line.Paint = function(self, w, h)
				if self:IsSelected() then
					draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(ui.col.PANTHEON, 120))
					surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 255)
					surface.DrawRect(0, 0, 4, h)
				elseif self:IsHovered() then
					draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(riskColor, 70))
					surface.SetDrawColor(riskColor.r, riskColor.g, riskColor.b, 200)
					surface.DrawRect(0, 0, 4, h)
				else
					draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(riskColor, 20))
					surface.SetDrawColor(riskColor.r, riskColor.g, riskColor.b, 100)
					surface.DrawRect(0, 0, 2, h)
				end
				
				-- Risk level indicator
				local dotX = w - 55
				local dotY = h / 2
				surface.SetDrawColor(riskColor.r, riskColor.g, riskColor.b, 255)
				draw.NoTexture()
				surface.DrawCircle(dotX, dotY, 5, riskColor)
				
				-- Glow effect for critical
				if riskLevel == 'CRITICAL' then
					local pulse = math.abs(math.sin(CurTime() * 3)) * 100 + 100
					surface.SetDrawColor(riskColor.r, riskColor.g, riskColor.b, pulse)
					surface.DrawCircle(dotX, dotY, 8, ColorAlpha(riskColor, pulse))
				end
			end
			
			line.playerData = {steamid = entry.steamid, data = data}
		end
	end
	
	RefreshStats()
	
	-- Footer with controls
	local footerPanel = vgui.Create('DPanel', frame)
	footerPanel:SetPos(10, frame:GetTall() - 85)
	footerPanel:SetSize(frame:GetWide() - 20, 75)
	footerPanel.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Top accent line with gradient
		for i = 0, 3 do
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150 - i * 30)
			surface.DrawRect(0, i, w, 1)
		end
	end
	
	-- Info panel in footer
	local infoPanel = vgui.Create('DPanel', footerPanel)
	infoPanel:SetPos(8, 8)
	infoPanel:SetSize(footerPanel:GetWide() - 350, 38)
	infoPanel.Paint = function(self, w, h)
		draw.RoundedBox(4, 0, 0, w, h, ui.col.BackgroundCard)
		
		-- Info icon box with glow
		draw.RoundedBox(3, 8, 7, 24, 24, ColorAlpha(ui.col.Blue, 50))
		surface.SetDrawColor(ui.col.Blue.r, ui.col.Blue.g, ui.col.Blue.b, 200)
		surface.DrawOutlinedRect(8, 7, 24, 24, 1)
		ui.DrawIcon('information', 20, 19, 12, ui.col.Blue)
		
		-- Info text
		draw.SimpleText('Auto-refresh enabled - Updates every 3 seconds', 'PANTHEON.14', 42, 11, ui.col.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText('System status: ', 'PANTHEON.14', 42, 25, ui.col.TextDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		
		-- Pulsing active indicator
		local pulse = math.abs(math.sin(CurTime() * 2)) * 0.3 + 0.7
		local statusColor = Color(100 * pulse, 255 * pulse, 150 * pulse)
		draw.SimpleText('ACTIVE', 'PANTHEON.14', 130, 25, statusColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		
		-- Active dot with glow
		local dotPulse = math.abs(math.sin(CurTime() * 3)) * 100 + 155
		surface.SetDrawColor(statusColor.r, statusColor.g, statusColor.b, dotPulse)
		draw.NoTexture()
		surface.DrawCircle(123, 29, 5, ColorAlpha(statusColor, dotPulse * 0.5))
		surface.DrawCircle(123, 29, 3, statusColor)
	end
	
	-- Buttons with enhanced styling
	local btnY = 50
	local btnH = 20
	local btnStartX = footerPanel:GetWide() - 340
	
	local exportBtn = ui.CreateButton(footerPanel, 'Export Log', btnStartX, btnY, 105, btnH, function()
		-- Export detection log to file
		local logData = '=== PANTHEON Anti-Cheat Log ===\n'
		logData = logData .. 'Generated: ' .. os.date('%Y-%m-%d %H:%M:%S') .. '\n\n'
		
		for _, detection in ipairs(pas.ac.detectionCache) do
			local cat = pas.ac.GetCategory(detection.category)
			logData = logData .. string.format('[%s] %s - %s: %s (x%d)\n', 
				os.date('%H:%M:%S', detection.time),
				detection.playerName,
				cat.name,
				detection.details,
				detection.count
			)
		end
		
		file.Write('pantheon_ac_log.txt', logData)
		ui.Notify('Log exported to garrysmod/data/pantheon_ac_log.txt', NOTIFY_GENERIC, 5)
	end, 'save')
	
	local refreshBtn = ui.CreateButton(footerPanel, 'Refresh', btnStartX + 115, btnY, 100, btnH, function()
		RefreshStats()
		ui.Notify('Statistics refreshed', NOTIFY_GENERIC, 3)
	end, 'arrow-right')
	
	local clearBtn = ui.CreateButton(footerPanel, 'Clear All', btnStartX + 225, btnY, 105, btnH, function()
		liveList:Clear()
		pas.ac.detectionCache = {}
		pas.ac.playerStats = {}
		RefreshStats()
		ui.Notify('All data cleared', NOTIFY_GENERIC, 3)
	end, 'trash-bin')
	
	-- Auto-refresh timer (faster updates)
	timer.Create('PANTHEON_AC_AutoRefresh', 3, 0, function()
		if IsValid(frame) and IsValid(statsList) then
			RefreshStats()
		else
			timer.Remove('PANTHEON_AC_AutoRefresh')
			timer.Remove('PANTHEON_AC_GraphUpdate')
		end
	end)
	
	-- Update live list when new detections come in (hook into existing receiver)
	local oldACDetection = pas.ac.OnDetection
	pas.ac.OnDetection = function(detection)
		-- Call original handler if it exists
		if oldACDetection then
			oldACDetection(detection)
		end
		
		-- Update live list if viewer is open
		if not IsValid(frame) then return end
		
		local cat = pas.ac.GetCategory(detection.category)
		local timeStr = os.date('%H:%M:%S', detection.time)
		local severityNames = {'LOW', 'MED', 'HIGH', 'CRIT'}
		local severityText = severityNames[cat.severity] or 'UNK'
		
		local line = liveList:AddLine(timeStr, detection.playerName, cat.name, detection.details, detection.count, severityText)
		
		-- Enhanced color coding by severity
		line.Paint = function(self, w, h)
			local baseAlpha = 25
			local hoverAlpha = 80
			local selectAlpha = 120
			
			if self:IsSelected() then
				draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(ui.col.PANTHEON, selectAlpha))
				surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 255)
				surface.DrawRect(0, 0, 3, h)
			elseif self:IsHovered() then
				draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(cat.color, hoverAlpha))
				surface.SetDrawColor(cat.color.r, cat.color.g, cat.color.b, 200)
				surface.DrawRect(0, 0, 3, h)
			else
				draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(cat.color, baseAlpha))
				surface.SetDrawColor(cat.color.r, cat.color.g, cat.color.b, 100)
				surface.DrawRect(0, 0, 2, h)
			end
			
			-- Severity indicator dot
			local dotX = w - 45
			local dotY = h / 2
			surface.SetDrawColor(cat.color.r, cat.color.g, cat.color.b, 255)
			draw.NoTexture()
			surface.DrawCircle(dotX, dotY, 4, cat.color)
		end
		
		line.detectionData = detection
		
		-- Auto-scroll to bottom
		liveList:ClearSelection()
		
		-- Refresh stats
		RefreshStats()
		
		-- Update stats header
		statsHeader:InvalidateLayout(true)
	end
	
	-- Cleanup on close
	frame.OnRemove = function()
		timer.Remove('PANTHEON_AC_AutoRefresh')
		timer.Remove('PANTHEON_AC_GraphUpdate')
	end
	
	frame:MakePopup()
	frame:Center()
end

print('[PANTHEON] Anti-Cheat system (client) loaded')

