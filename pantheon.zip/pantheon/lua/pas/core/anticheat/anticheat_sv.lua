-- PANTHEON Anti-Cheat System (Server)
if (CLIENT) then return end

util.AddNetworkString('pas.ACDetection')
util.AddNetworkString('pas.ACNotify')

-- Configuration
pas.ac.config = {
	-- Speed hack detection
	maxSpeed = 500,              -- Fallback max speed if job doesn't have one
	speedMultiplier = 1.15,      -- Allow 15% over max job speed (for lag compensation)
	speedCheckInterval = 0.5,    -- Check every 0.5s
	
	-- Admin immunity
	immuneRanks = {              -- Ranks immune to AC
		['superadmin'] = true,
		['admin'] = true,
		['moderator'] = false    -- Moderators still get checked
	},
	immuneFlags = {'r', 'a'},    -- Flags that grant immunity
	
	-- Aimbot detection
	aimbotAngleThreshold = 0.95, -- Snap angle (cosine similarity)
	aimbotCheckInterval = 0.1,   -- Check every 0.1s
	aimbotMinSnaps = 5,          -- Detections before action
	
	-- Bunny hop detection
	bhopMaxJumps = 10,           -- Max consecutive jumps
	bhopResetTime = 2,           -- Reset counter after 2s
	
	-- Name stealer
	checkNameStealing = true,
	
	-- Chat spam
	maxMessagesPerSecond = 3,
	spamBanDuration = 60,        -- Minutes
	
	-- Actions per severity
	actions = {
		[1] = pas.ac.actions.LOG,        -- Low: Just log
		[2] = pas.ac.actions.WARN,       -- Medium: Warn admins
		[3] = pas.ac.actions.KICK,       -- High: Kick player
		[4] = pas.ac.actions.BAN         -- Critical: Ban player
	},
	
	-- Auto-ban durations (minutes)
	banDurations = {
		[1] = 0,
		[2] = 0,
		[3] = 30,
		[4] = 1440  -- 24 hours
	}
}

-- Player detection data
pas.ac.playerData = pas.ac.playerData or {}

-- Check if player is immune to anticheat
local function IsPlayerImmune(ply)
	if not IsValid(ply) then return true end
	
	-- Bots are immune
	if ply:IsBot() then return true end
	
	-- Check if whitelisted
	local data = pas.ac.playerData[ply]
	if data and data.whitelisted then return true end
	
	-- Check immune flags
	for _, flag in ipairs(pas.ac.config.immuneFlags) do
		if ply:HasFlag(flag) then return true end
	end
	
	-- Check immune ranks
	local rank = ply:GetUserGroup()
	if pas.ac.config.immuneRanks[rank] then return true end
	
	return false
end

-- Get player's maximum allowed speed
local function GetPlayerMaxSpeed(ply)
	if not IsValid(ply) then return pas.ac.config.maxSpeed end
	
	-- Try to get from DarkRP job
	if ply.GetWalkSpeed and ply.GetRunSpeed then
		local walkSpeed = ply:GetWalkSpeed() or 200
		local runSpeed = ply:GetRunSpeed() or 400
		return math.max(walkSpeed, runSpeed) * pas.ac.config.speedMultiplier
	end
	
	-- Try to get from team table (DarkRP)
	if RPExtraTeams and ply:Team() then
		local team = RPExtraTeams[ply:Team()]
		if team then
			local maxSpeed = math.max(team.walkspeed or 200, team.runspeed or 400)
			return maxSpeed * pas.ac.config.speedMultiplier
		end
	end
	
	-- Try to get from PLAYER metatable methods
	if ply.GetMaxSpeed then
		return ply:GetMaxSpeed() * pas.ac.config.speedMultiplier
	end
	
	-- Fallback to default
	return pas.ac.config.maxSpeed
end

-- Initialize player data
local function InitPlayerData(ply)
	pas.ac.playerData[ply] = {
		-- Speed tracking
		lastSpeed = 0,
		speedViolations = 0,
		lastSpeedCheck = 0,
		
		-- Aimbot tracking
		lastAimAngles = Angle(0, 0, 0),
		aimbotSnaps = 0,
		lastAimbotCheck = 0,
		
		-- Bhop tracking
		consecutiveJumps = 0,
		lastJumpTime = 0,
		onGround = true,
		
		-- Chat tracking
		messages = {},
		lastMessageTime = 0,
		
		-- Wallhack/ESP tracking
		wallLookCount = 0,
		lastWallCheck = 0,
		
		-- Triggerbot tracking
		instantShots = 0,
		lastShotTime = 0,
		
		-- Recoil tracking
		lastRecoil = Vector(0, 0, 0),
		recoilViolations = 0,
		
		-- Fire rate tracking
		shotTimes = {},
		
		-- Fly hack tracking
		airTime = 0,
		lastGroundTime = 0,
		
		-- God mode tracking
		lastHealth = 100,
		damageTaken = 0,
		immortalCount = 0,
		
		-- Detection counts
		detections = {},
		totalDetections = 0,
		
		-- Whitelisted
		whitelisted = false
	}
end

-- Record detection
function pas.ac.RecordDetection(ply, category, details, autoAction)
	if not IsValid(ply) then return end
	
	local data = pas.ac.playerData[ply]
	if not data then InitPlayerData(ply) return end
	
	-- Increment detection counter
	data.detections[category] = (data.detections[category] or 0) + 1
	data.totalDetections = data.totalDetections + 1
	
	local cat = pas.ac.GetCategory(category)
	local detectionCount = data.detections[category]
	
	-- Create log entry
	local message = string.format('%s detected (%dx) - %s', cat.name, detectionCount, details)
	pas.log.Add('admin', message, ply:SteamID())
	
	-- Notify admins with 'm' flag
	for _, admin in ipairs(player.GetAll()) do
		if admin:HasFlag('m') then
			pas.notify(admin, '[AC] ' .. message, 1)
		end
	end
	
	-- Take action based on severity
	if autoAction then
		local action = pas.ac.config.actions[cat.severity] or pas.ac.actions.LOG
		local banDuration = pas.ac.config.banDurations[cat.severity] or 0
		
		if action == pas.ac.actions.BAN and banDuration > 0 then
			pas.ban(ply, banDuration, string.format('Anti-Cheat: %s', cat.name))
		elseif action == pas.ac.actions.KICK then
			ply:Kick(string.format('Anti-Cheat: %s detected', cat.name))
		elseif action == pas.ac.actions.NOTIFY then
			net.Start('pas.ACNotify')
				net.WriteString(cat.name)
			net.Send(ply)
		end
	end
	
	-- Send to AC viewer if open
	net.Start('pas.ACDetection')
		net.WriteString(ply:Nick())
		net.WriteString(ply:SteamID())
		net.WriteString(category)
		net.WriteString(details)
		net.WriteUInt(detectionCount, 16)
	net.Broadcast()
end

-- Speed hack detection
hook.Add('Think', 'PANTHEON_AC_SpeedCheck', function()
	local now = CurTime()
	
	for _, ply in ipairs(player.GetAll()) do
		if not IsValid(ply) or not ply:Alive() then continue end
		
		-- Check immunity
		if IsPlayerImmune(ply) then continue end
		
		local data = pas.ac.playerData[ply]
		if not data then continue end
		
		-- Don't check if in noclip, in vehicle, or using special movement
		if ply:GetMoveType() == MOVETYPE_NOCLIP then continue end
		
		if now - data.lastSpeedCheck >= pas.ac.config.speedCheckInterval then
			data.lastSpeedCheck = now
			
			local vel = ply:GetVelocity()
			local speed = vel:Length2D()
			
			-- Ignore if in vehicle
			if IsValid(ply:GetVehicle()) then continue end
			
			-- Get dynamic max speed based on job
			local maxSpeed = GetPlayerMaxSpeed(ply)
			
			-- Check for speed hack
			if speed > maxSpeed then
				data.speedViolations = data.speedViolations + 1
				
				if data.speedViolations >= 3 then
					pas.ac.RecordDetection(ply, 'speedhack', 
						string.format('Speed: %.0f (max: %.0f)', speed, maxSpeed),
						true)
					data.speedViolations = 0
				end
			else
				-- Reset violations if speed normal
				data.speedViolations = math.max(0, data.speedViolations - 1)
			end
			
			data.lastSpeed = speed
		end
	end
end)

-- Aimbot detection (simple snap detection)
hook.Add('Think', 'PANTHEON_AC_AimbotCheck', function()
	local now = CurTime()
	
	for _, ply in ipairs(player.GetAll()) do
		if not IsValid(ply) or not ply:Alive() then continue end
		
		-- Check immunity
		if IsPlayerImmune(ply) then continue end
		
		local data = pas.ac.playerData[ply]
		if not data then continue end
		
		if now - data.lastAimbotCheck >= pas.ac.config.aimbotCheckInterval then
			data.lastAimbotCheck = now
			
			local currentAngles = ply:EyeAngles()
			local angleDiff = math.abs(currentAngles.y - data.lastAimAngles.y)
			
			-- Detect sudden large angle changes (snapping)
			if angleDiff > 30 and angleDiff < 180 then
				local target = ply:GetEyeTrace().Entity
				if IsValid(target) and target:IsPlayer() then
					data.aimbotSnaps = data.aimbotSnaps + 1
					
					if data.aimbotSnaps >= pas.ac.config.aimbotMinSnaps then
						pas.ac.RecordDetection(ply, 'aimbot',
							string.format('Snap: %.1f° to %s', angleDiff, target:Nick()),
							true)
						data.aimbotSnaps = 0
					end
				end
			else
				-- Decay counter
				data.aimbotSnaps = math.max(0, data.aimbotSnaps - 0.1)
			end
			
			data.lastAimAngles = currentAngles
		end
	end
end)

-- Bunny hop detection
hook.Add('OnPlayerHitGround', 'PANTHEON_AC_BhopCheck', function(ply)
	if IsPlayerImmune(ply) then return end
	
	local data = pas.ac.playerData[ply]
	if not data then return end
	
	data.onGround = true
	
	local now = CurTime()
	if now - data.lastJumpTime > pas.ac.config.bhopResetTime then
		data.consecutiveJumps = 0
	end
end)

hook.Add('PlayerButtonDown', 'PANTHEON_AC_BhopJump', function(ply, button)
	if button ~= KEY_SPACE then return end
	if not ply:OnGround() then return end
	
	if IsPlayerImmune(ply) then return end
	
	local data = pas.ac.playerData[ply]
	if not data then return end
	
	local now = CurTime()
	
	if data.onGround then
		data.consecutiveJumps = data.consecutiveJumps + 1
		data.lastJumpTime = now
		data.onGround = false
		
		if data.consecutiveJumps >= pas.ac.config.bhopMaxJumps then
			pas.ac.RecordDetection(ply, 'bhop',
				string.format('%d consecutive jumps', data.consecutiveJumps),
				true)
			data.consecutiveJumps = 0
		end
	end
end)

-- Wallhack/ESP detection (checking through walls)
hook.Add('Think', 'PANTHEON_AC_WallhackCheck', function()
	local now = CurTime()
	
	for _, ply in ipairs(player.GetAll()) do
		if not IsValid(ply) or not ply:Alive() then continue end
		if IsPlayerImmune(ply) then continue end
		
		local data = pas.ac.playerData[ply]
		if not data then continue end
		
		if now - data.lastWallCheck >= 1 then
			data.lastWallCheck = now
			
			local trace = ply:GetEyeTrace()
			local target = trace.Entity
			
			-- Check if looking at player through wall
			if IsValid(target) and target:IsPlayer() and not trace.HitWorld then
				local directTrace = util.TraceLine({
					start = ply:EyePos(),
					endpos = target:EyePos(),
					filter = {ply, target}
				})
				
				-- If there's a wall between them but still looking at them
				if directTrace.Hit then
					data.wallLookCount = data.wallLookCount + 1
					
					if data.wallLookCount >= 15 then
						pas.ac.RecordDetection(ply, 'wallhack',
							string.format('Looking at %s through walls (%dx)', target:Nick(), data.wallLookCount),
							true)
						data.wallLookCount = 0
					end
				end
			else
				data.wallLookCount = math.max(0, data.wallLookCount - 0.5)
			end
		end
	end
end)

-- Triggerbot detection (instant shooting when crosshair on target)
hook.Add('EntityFireBullets', 'PANTHEON_AC_TriggerbotCheck', function(ply, data)
	if not IsValid(ply) or IsPlayerImmune(ply) then return end
	
	local plyData = pas.ac.playerData[ply]
	if not plyData then return end
	
	local now = CurTime()
	local trace = ply:GetEyeTrace()
	
	-- Check if shot instantly when crosshair landed on player
	if IsValid(trace.Entity) and trace.Entity:IsPlayer() then
		local timeSinceLastShot = now - plyData.lastShotTime
		
		-- Very fast reaction time (less than 50ms) repeatedly
		if timeSinceLastShot < 0.05 and timeSinceLastShot > 0 then
			plyData.instantShots = plyData.instantShots + 1
			
			if plyData.instantShots >= 5 then
				pas.ac.RecordDetection(ply, 'triggerbot',
					string.format('%d instant shots on target', plyData.instantShots),
					true)
				plyData.instantShots = 0
			end
		end
	else
		plyData.instantShots = math.max(0, plyData.instantShots - 1)
	end
	
	plyData.lastShotTime = now
end)

-- Rapid fire detection
hook.Add('EntityFireBullets', 'PANTHEON_AC_RapidFireCheck', function(ply, data)
	if not IsValid(ply) or IsPlayerImmune(ply) then return end
	
	local plyData = pas.ac.playerData[ply]
	if not plyData then return end
	
	local now = CurTime()
	table.insert(plyData.shotTimes, now)
	
	-- Keep only last 10 shots
	if #plyData.shotTimes > 10 then
		table.remove(plyData.shotTimes, 1)
	end
	
	-- Check if firing too fast (10 shots in less than 0.5 seconds)
	if #plyData.shotTimes >= 10 then
		local timeDiff = plyData.shotTimes[#plyData.shotTimes] - plyData.shotTimes[1]
		
		if timeDiff < 0.5 then
			local weapon = ply:GetActiveWeapon()
			local wepName = IsValid(weapon) and weapon:GetClass() or 'Unknown'
			
			pas.ac.RecordDetection(ply, 'rapidfire',
				string.format('10 shots in %.2fs with %s', timeDiff, wepName),
				true)
			plyData.shotTimes = {}
		end
	end
end)

-- Fly hack detection
hook.Add('Think', 'PANTHEON_AC_FlyCheck', function()
	local now = CurTime()
	
	for _, ply in ipairs(player.GetAll()) do
		if not IsValid(ply) or not ply:Alive() then continue end
		if IsPlayerImmune(ply) then continue end
		
		local data = pas.ac.playerData[ply]
		if not data then continue end
		
		-- Skip if in noclip or vehicle
		if ply:GetMoveType() == MOVETYPE_NOCLIP or IsValid(ply:GetVehicle()) then continue end
		
		if ply:OnGround() then
			data.lastGroundTime = now
			data.airTime = 0
		else
			data.airTime = now - data.lastGroundTime
			
			-- If in air for more than 5 seconds and moving upward
			if data.airTime > 5 then
				local vel = ply:GetVelocity()
				
				-- Check if maintaining altitude or going up
				if vel.z > -100 then
					pas.ac.RecordDetection(ply, 'flyhack',
						string.format('Airborne for %.1fs', data.airTime),
						true)
					data.airTime = 0
					data.lastGroundTime = now
				end
			end
		end
	end
end)

-- God mode detection
hook.Add('EntityTakeDamage', 'PANTHEON_AC_GodModeCheck', function(target, dmg)
	if not IsValid(target) or not target:IsPlayer() then return end
	if IsPlayerImmune(target) then return end
	
	local data = pas.ac.playerData[target]
	if not data then return end
	
	local damage = dmg:GetDamage()
	
	-- Store expected health
	data.lastHealth = target:Health()
	data.damageTaken = damage
	
	-- Check next tick if health didn't decrease
	timer.Simple(0.1, function()
		if not IsValid(target) then return end
		
		local currentHealth = target:Health()
		local expectedHealth = data.lastHealth - data.damageTaken
		
		-- If health didn't decrease despite taking damage
		if currentHealth >= data.lastHealth and data.damageTaken > 10 then
			data.immortalCount = data.immortalCount + 1
			
			if data.immortalCount >= 3 then
				pas.ac.RecordDetection(target, 'godmode',
					string.format('No damage taken (%dx, %.0f dmg ignored)', data.immortalCount, data.damageTaken),
					true)
				data.immortalCount = 0
			end
		else
			data.immortalCount = math.max(0, data.immortalCount - 1)
		end
	end)
end)

-- Unauthorized noclip detection
hook.Add('PlayerNoClip', 'PANTHEON_AC_NoclipCheck', function(ply, desiredState)
	if IsPlayerImmune(ply) then return end -- Immune players can noclip
	
	local data = pas.ac.playerData[ply]
	if not data then return end
	
	if desiredState then
		pas.ac.RecordDetection(ply, 'noclip', 'Attempted unauthorized noclip', true)
		return false -- Block noclip
	end
end)

-- Name stealer detection
hook.Add('PlayerInitialSpawn', 'PANTHEON_AC_NameCheck', function(ply)
	InitPlayerData(ply)
	
	if not pas.ac.config.checkNameStealing then return end
	
	local name = ply:Nick()
	
	-- Check for duplicate names
	for _, other in ipairs(player.GetAll()) do
		if other ~= ply and other:Nick() == name then
			pas.ac.RecordDetection(ply, 'namestealer',
				string.format('Same name as %s (%s)', other:Nick(), other:SteamID()),
				false)
		end
	end
	
	-- Check for admin impersonation
	for _, other in ipairs(player.GetAll()) do
		if other ~= ply and other:HasFlag('a') then
			local similarity = string.lower(name):find(string.lower(other:Nick()), 1, true)
			if similarity then
				pas.ac.RecordDetection(ply, 'namestealer',
					string.format('Similar to admin: %s', other:Nick()),
					false)
			end
		end
	end
end)

-- Chat spam detection
local playerChatTimes = {}

hook.Add('PlayerSay', 'PANTHEON_AC_ChatSpam', function(ply, text)
	if IsPlayerImmune(ply) then return end -- Skip immune players
	
	local data = pas.ac.playerData[ply]
	if not data then return end
	
	local now = CurTime()
	playerChatTimes[ply] = playerChatTimes[ply] or {}
	
	-- Add current message time
	table.insert(playerChatTimes[ply], now)
	
	-- Remove old messages (older than 1 second)
	for i = #playerChatTimes[ply], 1, -1 do
		if now - playerChatTimes[ply][i] > 1 then
			table.remove(playerChatTimes[ply], i)
		end
	end
	
	-- Check spam threshold
	if #playerChatTimes[ply] > pas.ac.config.maxMessagesPerSecond then
		pas.ac.RecordDetection(ply, 'spam',
			string.format('%d messages in 1 second', #playerChatTimes[ply]),
			true)
		playerChatTimes[ply] = {}
		return '' -- Block message
	end
end)

-- Cleanup on disconnect
hook.Add('PlayerDisconnected', 'PANTHEON_AC_Cleanup', function(ply)
	pas.ac.playerData[ply] = nil
	playerChatTimes[ply] = nil
end)

-- Console commands
concommand.Add('pas_ac_whitelist', function(ply, cmd, args)
	if IsValid(ply) and not ply:HasFlag('r') then return end
	
	local target = args[1]
	if not target then
		print('[PANTHEON AC] Usage: pas_ac_whitelist <player/steamid>')
		return
	end
	
	local targetPly = pas.FindPlayer(target)
	if IsValid(targetPly) then
		local data = pas.ac.playerData[targetPly]
		if data then
			data.whitelisted = true
			print('[PANTHEON AC] Whitelisted: ' .. targetPly:Nick())
		end
	end
end)

concommand.Add('pas_ac_reset', function(ply, cmd, args)
	if IsValid(ply) and not ply:HasFlag('r') then return end
	
	local target = args[1]
	if not target then
		print('[PANTHEON AC] Usage: pas_ac_reset <player>')
		return
	end
	
	local targetPly = pas.FindPlayer(target)
	if IsValid(targetPly) then
		InitPlayerData(targetPly)
		print('[PANTHEON AC] Reset detections for: ' .. targetPly:Nick())
	end
end)

print('[PANTHEON] Anti-Cheat system (server) loaded')
