--[[
	PANTHEON Admin System - Authentication Module (Shared)
	Provides admin password authentication for command execution
]]

pas.auth = pas.auth or {}

-- Constants
pas.auth.SESSION_TIMEOUT = 3600 -- 1 hour in seconds
pas.auth.GRACE_PERIOD = 1800 -- 30 minutes grace period on disconnect
pas.auth.MAX_LOGIN_ATTEMPTS = 3
pas.auth.LOCKOUT_TIME = 300 -- 5 minutes lockout after failed attempts

-- Network strings
if SERVER then
	util.AddNetworkString('pas.auth.Setup')
	util.AddNetworkString('pas.auth.Login')
	util.AddNetworkString('pas.auth.Logout')
	util.AddNetworkString('pas.auth.Status')
	util.AddNetworkString('pas.auth.SetupResponse')
	util.AddNetworkString('pas.auth.LoginResponse')
end
