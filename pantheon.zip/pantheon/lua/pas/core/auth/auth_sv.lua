--[[
	PANTHEON Admin System - Authentication Module (Server)
	Handles password hashing, verification, and session management
]]

if CLIENT then return end

pas.auth = pas.auth or {}

-- Store active sessions in memory
pas.auth.ActiveSessions = pas.auth.ActiveSessions or {}
pas.auth.DisconnectedSessions = pas.auth.DisconnectedSessions or {}

-- Password hashing using SHA256 with salt
function pas.auth.HashPassword(password, salt)
	if not salt then
		-- Generate random salt
		salt = util.SHA256(tostring(math.random()) .. tostring(os.time()) .. tostring(math.random()))
	end
	
	local hash = sha2.sha256(password .. salt)
	return hash, salt
end

-- Verify password against stored hash
function pas.auth.VerifyPassword(password, hash, salt)
	local testHash = sha2.sha256(password .. salt)
	return testHash == hash
end

-- Check if player needs to set up password (first time)
function pas.auth.NeedsSetup(pl)
	if not IsValid(pl) then return false end
	
	-- Check if password data is loaded
	if not pl.pas_PasswordLoaded then
		pas.print('[PANTHEON AUTH] NeedsSetup called for ' .. pl:Nick() .. ' but password data not loaded yet')
		return false -- Wait for data to load
	end
	
	local needsSetup = (not pl.pas_PasswordHash or pl.pas_PasswordHash == '')
	pas.print('[PANTHEON AUTH] NeedsSetup for ' .. pl:Nick() .. ': ' .. (needsSetup and 'YES' or 'NO') .. ' (Hash: "' .. (pl.pas_PasswordHash or 'nil') .. '")')
	
	-- If no hash stored, needs setup
	return needsSetup
end

-- Load password data from database
function pas.auth.LoadPassword(pl)
	if not IsValid(pl) then return end
	
	local steamid = pl:SteamID64()
	local db = pas.data.GetDB()
	
	local steamid32 = pl:SteamID()
	pas.print('[PANTHEON AUTH] LoadPassword called for ' .. pl:Nick() .. ' with SteamID64: ' .. steamid .. ', SteamID: ' .. steamid32)
	
	if not db then
		pas.print('[PANTHEON AUTH] No database connection - password features disabled')
		pl.pas_PasswordLoaded = true
		pl.pas_PasswordHash = nil
		pl.pas_PasswordSalt = nil
		return
	end
	
	-- Try both SteamID64 and regular SteamID formats to handle inconsistencies
	pas.print('[PANTHEON AUTH] Querying database for both SteamID formats')
	db:query_ex('SELECT password_hash, password_salt, steamid FROM pas_players WHERE (steamid=? OR steamid=?) AND steamid IS NOT NULL AND steamid != ""', {steamid, steamid32}, function(data)
		if not IsValid(pl) then return end
		
		pas.print('[PANTHEON AUTH] Database query result for ' .. pl:Nick() .. ':')
		pas.print('[PANTHEON AUTH] Searched for SteamID64: "' .. steamid .. '" OR SteamID: "' .. steamid32 .. '"')
		if data then
			pas.print('[PANTHEON AUTH] Query returned ' .. #data .. ' rows')
			for i, row in ipairs(data) do
				pas.print('[PANTHEON AUTH] Row ' .. i .. ' - SteamID: "' .. (row.steamid or 'NULL') .. '", Hash: "' .. (row.password_hash or 'NULL') .. '", Salt: "' .. (row.password_salt or 'NULL') .. '"')
			end
		else
			pas.print('[PANTHEON AUTH] Query returned NIL data')
		end
		
		if data and data[1] and data[1].steamid and data[1].steamid ~= '' then
			-- Ensure we handle empty strings vs NULL values properly
			local hash = data[1].password_hash or ''
			local salt = data[1].password_salt or ''
			local foundSteamID = data[1].steamid
			
			pl.pas_PasswordHash = hash
			pl.pas_PasswordSalt = salt
			
			pas.print('[PANTHEON AUTH] Loaded password data for ' .. pl:Nick() .. ' - Hash exists: ' .. (hash ~= '' and 'YES' or 'NO'))
			
			-- If we found an old SteamID32 entry, migrate it to SteamID64
			if foundSteamID ~= steamid then
				pas.print('[PANTHEON AUTH] Migrating old SteamID format "' .. foundSteamID .. '" to SteamID64: ' .. steamid)
				db:query_ex('UPDATE pas_players SET steamid=? WHERE steamid=?', {steamid, foundSteamID}, function()
					pas.print('[PANTHEON AUTH] Successfully migrated ' .. pl:Nick() .. ' to SteamID64')
				end)
			end
		else
			-- No valid entry exists, create one with empty password using SteamID64
			pl.pas_PasswordHash = ''
			pl.pas_PasswordSalt = ''
			
			pas.print('[PANTHEON AUTH] No existing entry found for ' .. pl:Nick() .. ', creating new record with SteamID64: ' .. steamid)
			-- First, delete any NULL steamid entries to clean up
			db:query('DELETE FROM pas_players WHERE steamid IS NULL OR steamid = ""', function()
				-- Now insert the new entry
				db:query_ex('INSERT INTO pas_players(steamid, password_hash, password_salt) VALUES(?, "", "")', {steamid}, function()
					pas.print('[PANTHEON AUTH] Created new player entry for ' .. pl:Nick())
				end)
			end)
		end
		
		pl.pas_PasswordLoaded = true
		
		-- Send auth status to client with small delay to ensure client is ready
		timer.Simple(0.1, function()
			if IsValid(pl) then
				pas.auth.SendAuthStatus(pl)
			end
		end)
		
		-- Check if there's a grace period session from previous disconnect
		pas.auth.CheckGracePeriod(pl)
	end)
end

-- Save password to database
function pas.auth.SavePassword(pl, password)
	if not IsValid(pl) then return false end
	
	-- Use SteamID64 for consistency
	local steamid = pl:SteamID64()
	local hash, salt = pas.auth.HashPassword(password)
	
	local db = pas.data.GetDB()
	if not db then
		pas.notify(pl, "Database unavailable - cannot save password", 1)
		return false
	end
	
	pas.print('[PANTHEON AUTH] Saving password for ' .. pl:Nick() .. ' with SteamID64: ' .. steamid)
	
	-- First, delete any old SteamID32 format entries for this player
	local steamid32 = pl:SteamID()
	db:query_ex('DELETE FROM pas_players WHERE steamid=? AND steamid!=?', {steamid32, steamid}, function()
		-- Now use REPLACE for SQLite/MySQL compatibility
		db:query_ex('REPLACE INTO pas_players(steamid, password_hash, password_salt) VALUES(?, ?, ?)', 
			{steamid, hash, salt}, function(success)
			if not IsValid(pl) then return end
			
			if success then
				pl.pas_PasswordHash = hash
				pl.pas_PasswordSalt = salt
				pl.pas_PasswordLoaded = true
				
				pas.notify(pl, "Password set successfully!", 0)
				pas.print('[PANTHEON AUTH] ' .. pl:Nick() .. ' set their admin password (Hash: ' .. string.sub(hash, 1, 8) .. '...)')
				pas.print('[PANTHEON AUTH] Saved to database with SteamID64: ' .. steamid)
				
				-- Send updated status to client
				pas.auth.SendAuthStatus(pl)
			else
				pas.notify(pl, "Failed to save password to database", 1)
				pas.print('[PANTHEON AUTH] Failed to save password for ' .. pl:Nick())
			end
		end)
	end)
	
	return true
end

-- Authenticate player with password
function pas.auth.Authenticate(pl, password)
	if not IsValid(pl) then return false end
	
	-- Check if locked out
	local locked, timeLeft = pas.auth.IsLockedOut(pl)
	if locked then
		pas.notify(pl, "Too many failed attempts. Try again in " .. math.ceil(timeLeft) .. " seconds.", 1)
		return false
	end
	
	-- Verify password
	if pas.auth.VerifyPassword(password, pl.pas_PasswordHash, pl.pas_PasswordSalt) then
		-- Success! Create session
		pl.pas_AuthData = {
			authenticated = true,
			authTime = CurTime(),
			steamid = pl:SteamID64()
		}
		
		-- Reset failed attempts
		pl.pas_FailedAttempts = 0
		pl.pas_LockoutTime = nil
		
		-- Store in active sessions
		pas.auth.ActiveSessions[pl:SteamID64()] = {
			authTime = os.time(),
			player = pl
		}
		
		pas.notify(pl, "Authentication successful! Session valid for 1 hour.", 0)
		pas.print('[PANTHEON AUTH] ' .. pl:Nick() .. ' authenticated successfully')
		
		-- Send status to client
		pas.auth.SendAuthStatus(pl)
		
		-- Check if there's a pending command to execute
		if pl.pas_PendingCommand then
			local cmd = pl.pas_PendingCommand
			pl.pas_PendingCommand = nil
			
			-- Execute the pending command
			timer.Simple(0.1, function()
				if IsValid(pl) then
					pas.cmd.Execute(pl, cmd.cmd, cmd.args)
				end
			end)
		end
		
		return true
	else
		-- Failed attempt
		pl.pas_FailedAttempts = (pl.pas_FailedAttempts or 0) + 1
		
		if pl.pas_FailedAttempts >= pas.auth.MAX_LOGIN_ATTEMPTS then
			pl.pas_LockoutTime = CurTime()
			pas.notify(pl, "Too many failed attempts! Locked out for " .. pas.auth.LOCKOUT_TIME .. " seconds.", 1)
			pas.print('[PANTHEON AUTH] ' .. pl:Nick() .. ' locked out after ' .. pl.pas_FailedAttempts .. ' failed attempts')
		else
			local remaining = pas.auth.MAX_LOGIN_ATTEMPTS - pl.pas_FailedAttempts
			pas.notify(pl, "Incorrect password. " .. remaining .. " attempts remaining.", 1)
		end
		
		-- Log failed attempt
		if pas.log and pas.log.Add then
			pas.log.Add('auth', pl:Nick() .. ' failed authentication attempt', pl:SteamID())
		end
		
		return false
	end
end

-- Check if player is locked out
function pas.auth.IsLockedOut(pl)
	if not IsValid(pl) then return false, 0 end
	
	if pl.pas_LockoutTime then
		local elapsed = CurTime() - pl.pas_LockoutTime
		if elapsed < pas.auth.LOCKOUT_TIME then
			return true, pas.auth.LOCKOUT_TIME - elapsed
		else
			-- Lockout expired
			pl.pas_LockoutTime = nil
			pl.pas_FailedAttempts = 0
		end
	end
	
	return false, 0
end

-- Check if player is authenticated
function pas.auth.IsAuthenticated(pl)
	if not IsValid(pl) then return false end
	
	-- Check if auth data exists
	if not pl.pas_AuthData or not pl.pas_AuthData.authenticated then
		return false
	end
	
	-- Check if session has expired (1 hour)
	local elapsed = CurTime() - pl.pas_AuthData.authTime
	if elapsed > pas.auth.SESSION_TIMEOUT then
		-- Session expired
		pl.pas_AuthData = nil
		pas.auth.ActiveSessions[pl:SteamID64()] = nil
		pas.notify(pl, "Authentication session expired. Please log in again.", 1)
		pas.auth.SendAuthStatus(pl)
		return false
	end
	
	return true
end

-- Deauthenticate player
function pas.auth.Deauthenticate(pl)
	if not IsValid(pl) then return end
	
	pl.pas_AuthData = nil
	pas.auth.ActiveSessions[pl:SteamID64()] = nil
	
	pas.notify(pl, "Logged out successfully.", 0)
	pas.print('[PANTHEON AUTH] ' .. pl:Nick() .. ' logged out')
	
	pas.auth.SendAuthStatus(pl)
end

-- Check grace period for returning players
function pas.auth.CheckGracePeriod(pl)
	if not IsValid(pl) then return end
	
	local steamid = pl:SteamID64()
	local session = pas.auth.DisconnectedSessions[steamid]
	
	if session then
		local elapsed = os.time() - session.disconnectTime
		
		if elapsed <= pas.auth.GRACE_PERIOD then
			-- Within grace period, restore session
			pl.pas_AuthData = {
				authenticated = true,
				authTime = CurTime() - (os.time() - session.authTime),
				steamid = steamid
			}
			
			pas.auth.ActiveSessions[steamid] = {
				authTime = session.authTime,
				player = pl
			}
			
			-- Remove from disconnected sessions
			pas.auth.DisconnectedSessions[steamid] = nil
			
			local remaining = pas.auth.SESSION_TIMEOUT - (os.time() - session.authTime)
			if remaining > 0 then
				pas.notify(pl, "Authentication session restored! Valid for " .. math.floor(remaining / 60) .. " more minutes.", 0)
				pas.print('[PANTHEON AUTH] ' .. pl:Nick() .. ' session restored from grace period')
				
				pas.auth.SendAuthStatus(pl)
			else
				-- Session expired during grace period
				pl.pas_AuthData = nil
				pas.auth.ActiveSessions[steamid] = nil
			end
		else
			-- Grace period expired
			pas.auth.DisconnectedSessions[steamid] = nil
		end
	end
end

-- Send authentication status to client
function pas.auth.SendAuthStatus(pl)
	if not IsValid(pl) then return end
	
	local isAuth = pas.auth.IsAuthenticated(pl)
	local needsSetup = pas.auth.NeedsSetup(pl)
	
	pas.print('[PANTHEON AUTH] Sending status to ' .. pl:Nick() .. ' - IsAuth: ' .. tostring(isAuth) .. ', NeedsSetup: ' .. tostring(needsSetup))
	
	net.Start('pas.auth.Status')
		net.WriteBool(isAuth)
		net.WriteBool(needsSetup)
	net.Send(pl)
end

-- Network handlers
net.Receive('pas.auth.Setup', function(len, pl)
	local password = net.ReadString()
	
	if not pl.pas_PasswordLoaded then
		pas.notify(pl, "Password data still loading, please wait...", 1)
		return
	end
	
	if not pas.auth.NeedsSetup(pl) then
		pas.notify(pl, "You already have a password set. Use /pas_setpass to change it.", 1)
		return
	end
	
	-- Validate password
	if #password < 6 then
		net.Start('pas.auth.SetupResponse')
			net.WriteBool(false)
			net.WriteString("Password must be at least 6 characters long")
		net.Send(pl)
		return
	end
	
	-- Save password
	pas.auth.SavePassword(pl, password)
	
	-- Automatically authenticate after setup
	timer.Simple(0.1, function()
		if IsValid(pl) then
			pas.auth.Authenticate(pl, password)
			
			net.Start('pas.auth.SetupResponse')
				net.WriteBool(true)
				net.WriteString("Password set and authenticated successfully!")
			net.Send(pl)
		end
	end)
end)

net.Receive('pas.auth.Login', function(len, pl)
	local password = net.ReadString()
	
	if not pl.pas_PasswordLoaded then
		pas.notify(pl, "Password data still loading, please wait...", 1)
		return
	end
	
	if pas.auth.NeedsSetup(pl) then
		pas.notify(pl, "You need to set up a password first.", 1)
		return
	end
	
	local success = pas.auth.Authenticate(pl, password)
	
	net.Start('pas.auth.LoginResponse')
		net.WriteBool(success)
		net.WriteString(success and "Login successful!" or "Incorrect password")
	net.Send(pl)
end)

net.Receive('pas.auth.Logout', function(len, pl)
	pas.auth.Deauthenticate(pl)
end)

-- Hooks
hook.Add('PlayerInitialSpawn', 'PANTHEON_AUTH_Init', function(pl)
	pas.print('[PANTHEON AUTH] PlayerInitialSpawn for ' .. pl:Nick() .. ' (' .. pl:SteamID64() .. ')')
	
	-- Initialize auth data
	pl.pas_AuthData = nil
	pl.pas_PasswordLoaded = false
	pl.pas_PasswordHash = nil
	pl.pas_PasswordSalt = nil
	pl.pas_FailedAttempts = 0
	pl.pas_LockoutTime = nil
	
	-- Load password data from database with shorter delay
	timer.Simple(1, function()
		if IsValid(pl) then
			pas.print('[PANTHEON AUTH] Loading password data for ' .. pl:Nick())
			pas.auth.LoadPassword(pl)
		end
	end)
end)

hook.Add('PlayerDisconnected', 'PANTHEON_AUTH_Disconnect', function(pl)
	local steamid = pl:SteamID64()
	local session = pas.auth.ActiveSessions[steamid]
	
	if session then
		-- Store session for grace period
		pas.auth.DisconnectedSessions[steamid] = {
			authTime = session.authTime,
			disconnectTime = os.time()
		}
		
		-- Remove from active sessions
		pas.auth.ActiveSessions[steamid] = nil
		
		pas.print('[PANTHEON AUTH] ' .. pl:Nick() .. ' disconnected - session saved for grace period')
	end
end)

-- Clean up expired grace period sessions every 5 minutes
timer.Create('PANTHEON_AUTH_CleanupGrace', 300, 0, function()
	local now = os.time()
	for steamid, session in pairs(pas.auth.DisconnectedSessions) do
		if now - session.disconnectTime > pas.auth.GRACE_PERIOD then
			pas.auth.DisconnectedSessions[steamid] = nil
		end
	end
end)

-- Clean up expired active sessions
timer.Create('PANTHEON_AUTH_CleanupActive', 60, 0, function()
	local now = os.time()
	for steamid, session in pairs(pas.auth.ActiveSessions) do
		if now - session.authTime > pas.auth.SESSION_TIMEOUT then
			pas.auth.ActiveSessions[steamid] = nil
			if IsValid(session.player) then
				session.player.pas_AuthData = nil
				pas.notify(session.player, "Authentication session expired.", 1)
			end
		end
	end
end)

-- Console command to check database entries
if SERVER then
	concommand.Add('pas_check_database', function(ply, cmd, args)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		
		local db = pas.data.GetDB()
		if not db then
			print('[PANTHEON AUTH DB] No database connection')
			return
		end
		
		print('[PANTHEON AUTH DB] Checking all pas_players entries:')
		db:query('SELECT steamid, password_hash, password_salt, usergroup FROM pas_players', function(data)
			if data then
				print('[PANTHEON AUTH DB] Found ' .. #data .. ' total entries:')
				for i, row in ipairs(data) do
					local hasHash = (row.password_hash and row.password_hash ~= '') and 'YES' or 'NO'
					print('  [' .. i .. '] SteamID: ' .. (row.steamid or 'NULL') .. ', HasPassword: ' .. hasHash .. ', UserGroup: ' .. (row.usergroup or 'NULL'))
				end
			else
				print('[PANTHEON AUTH DB] No data returned or query failed')
			end
		end)
	end)

	-- Debug command to check SteamID formats
	concommand.Add('pas_check_steamid', function(ply, cmd, args)
		if not IsValid(ply) then
			print('[PANTHEON AUTH] This command can only be used by players')
			return
		end
		
		print('[PANTHEON AUTH] SteamID formats for ' .. ply:Name() .. ':')
		print('  SteamID(): "' .. ply:SteamID() .. '"')
		print('  SteamID64(): "' .. ply:SteamID64() .. '"')
		print('  pas.InfoTo64(): "' .. pas.InfoTo64(ply) .. '"')
		print('  pas.InfoToID(): "' .. pas.InfoToID(ply) .. '"')
	end)

	-- Command to fix password data corruption
	concommand.Add('pas_fix_password_data', function(ply, cmd, args)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		
		local db = pas.data.GetDB()
		if not db then
			print('[PANTHEON AUTH FIX] No database connection')
			return
		end
		
		-- Check what records exist and fix NULL steamids
		print('[PANTHEON AUTH FIX] Checking for corrupted password records...')
		db:query('SELECT steamid, password_hash, password_salt, usergroup FROM pas_players WHERE steamid IS NULL OR steamid = "" OR (password_hash IS NOT NULL AND password_hash != "" AND steamid IS NULL)', function(data)
			if data and #data > 0 then
				print('[PANTHEON AUTH FIX] Found ' .. #data .. ' corrupted records:')
				for i, row in ipairs(data) do
					print('  [' .. i .. '] SteamID: "' .. (row.steamid or 'NULL') .. '", HasPassword: ' .. ((row.password_hash and row.password_hash ~= '') and 'YES' or 'NO'))
				end
				
				-- Delete corrupted records
				db:query('DELETE FROM pas_players WHERE steamid IS NULL OR steamid = ""', function()
					print('[PANTHEON AUTH FIX] Deleted corrupted records')
				end)
			else
				print('[PANTHEON AUTH FIX] No corrupted records found')
			end
		end)
	end)

	-- Console command to reset your own password
	concommand.Add('pas_reset_password', function(ply, cmd, args)
		if not IsValid(ply) then
			print('[PANTHEON AUTH RESET] This command can only be used by players')
			return
		end
		
		local steamid = ply:SteamID()
		local db = pas.data.GetDB()
		
		if not db then
			pas.notify(ply, "Database unavailable - cannot reset password", 1)
			return
		end
		
		-- Clear password from database
		db:query_ex('UPDATE pas_players SET password_hash="", password_salt="" WHERE steamid=?', {steamid}, function(success)
			if success then
				-- Clear local password data
				ply.pas_PasswordHash = ''
				ply.pas_PasswordSalt = ''
				ply.pas_AuthData = nil
				
				pas.notify(ply, "Password reset successfully! You can now set up a new password.", 0)
				pas.print('[PANTHEON AUTH RESET] ' .. ply:Nick() .. ' reset their password')
				
				-- Send updated status to client
				pas.auth.SendAuthStatus(ply)
			else
				pas.notify(ply, "Failed to reset password", 1)
				pas.print('[PANTHEON AUTH RESET] Failed to reset password for ' .. ply:Nick())
			end
		end)
	end)

	-- Admin command to reset another player's password
	concommand.Add('pas_reset_player_password', function(ply, cmd, args)
		if IsValid(ply) and not ply:IsSuperAdmin() then
			pas.notify(ply, "You don't have permission to use this command", 1)
			return
		end
		
		local target = args[1]
		if not target then
			local msg = 'Usage: pas_reset_player_password <player_name_or_steamid>'
			if IsValid(ply) then
				pas.notify(ply, msg, 1)
			else
				print('[PANTHEON AUTH RESET] ' .. msg)
			end
			return
		end
		
		local db = pas.data.GetDB()
		if not db then
			local msg = "Database unavailable - cannot reset password"
			if IsValid(ply) then
				pas.notify(ply, msg, 1)
			else
				print('[PANTHEON AUTH RESET] ' .. msg)
			end
			return
		end
		
		-- Try to find player by name first
		local targetPlayer = nil
		for _, p in ipairs(player.GetAll()) do
			if string.find(string.lower(p:Name()), string.lower(target)) then
				targetPlayer = p
				break
			end
		end
		
		local targetSteamID = target
		local targetName = target
		
		if targetPlayer then
			targetSteamID = targetPlayer:SteamID()
			targetName = targetPlayer:Name()
		elseif not string.match(target, "STEAM_") then
			-- If not a SteamID and no player found
			local msg = 'Player not found: ' .. target
			if IsValid(ply) then
				pas.notify(ply, msg, 1)
			else
				print('[PANTHEON AUTH RESET] ' .. msg)
			end
			return
		end
		
		-- Clear password from database
		db:query_ex('UPDATE pas_players SET password_hash="", password_salt="" WHERE steamid=?', {targetSteamID}, function(success)
			if success then
				-- If player is online, clear their local data too
				if targetPlayer then
					targetPlayer.pas_PasswordHash = ''
					targetPlayer.pas_PasswordSalt = ''
					targetPlayer.pas_AuthData = nil
					pas.notify(targetPlayer, "Your admin password has been reset by " .. (IsValid(ply) and ply:Name() or "Console"), 1)
					pas.auth.SendAuthStatus(targetPlayer)
				end
				
				local msg = 'Password reset for ' .. targetName .. ' (' .. targetSteamID .. ')'
				if IsValid(ply) then
					pas.notify(ply, msg, 0)
				else
					print('[PANTHEON AUTH RESET] ' .. msg)
				end
				
				pas.print('[PANTHEON AUTH RESET] ' .. (IsValid(ply) and ply:Name() or "Console") .. ' reset password for ' .. targetName)
			else
				local msg = 'Failed to reset password for ' .. targetName
				if IsValid(ply) then
					pas.notify(ply, msg, 1)
				else
					print('[PANTHEON AUTH RESET] ' .. msg)
				end
			end
		end)
	end)

	-- Debug console command for admins
	concommand.Add('pas_debug_auth', function(ply, cmd, args)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		
		local target = args[1]
		if not target then
			print('[PANTHEON AUTH DEBUG] Usage: pas_debug_auth <player_name>')
			return
		end
		
		local targets = {}
		for _, p in ipairs(player.GetAll()) do
			if string.find(string.lower(p:Name()), string.lower(target)) then
				table.insert(targets, p)
			end
		end
		
		if #targets == 0 then
			print('[PANTHEON AUTH DEBUG] Player not found: ' .. target)
			return
		end
		
		for _, p in ipairs(targets) do
			print('[PANTHEON AUTH DEBUG] === Player: ' .. p:Name() .. ' (' .. p:SteamID() .. ') ===')
			print('  SteamID64: ' .. p:SteamID64())
			print('  PasswordLoaded: ' .. tostring(p.pas_PasswordLoaded))
			print('  PasswordHash: "' .. (p.pas_PasswordHash or 'nil') .. '"')
			print('  PasswordSalt: "' .. (p.pas_PasswordSalt or 'nil') .. '"')
			print('  NeedsSetup: ' .. tostring(pas.auth.NeedsSetup(p)))
			print('  IsAuthenticated: ' .. tostring(pas.auth.IsAuthenticated(p)))
			
			if p.pas_AuthData then
				print('  AuthTime: ' .. tostring(p.pas_AuthData.authTime))
				local elapsed = CurTime() - p.pas_AuthData.authTime
				print('  SessionAge: ' .. math.floor(elapsed) .. ' seconds')
			else
				print('  AuthData: nil')
			end
		end
	end)
end

pas.print('[PANTHEON] Authentication module loaded')
