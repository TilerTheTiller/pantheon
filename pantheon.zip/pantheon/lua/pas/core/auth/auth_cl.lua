--[[
	PANTHEON Admin System - Authentication Module (Client)
	Handles password setup and login UI
]]

if SERVER then return end

pas.auth = pas.auth or {}

-- Current authentication status
pas.auth.IsAuth = false
pas.auth.NeedsSetup = false

-- Show password setup dialog
function pas.auth.ShowSetup(reason)
	if IsValid(pas.auth.SetupFrame) then
		pas.auth.SetupFrame:Remove()
	end
	
	-- Create frame using PANTHEON UI library
	local frame = ui.CreateFrame("Admin Password Setup", 550, 380, 'lock')
	pas.auth.SetupFrame = frame
	
	-- Header panel with gradient
	local headerPanel = vgui.Create("DPanel", frame)
	headerPanel:SetPos(10, 45)
	headerPanel:SetSize(frame:GetWide() - 20, 80)
	headerPanel.Paint = function(self, w, h)
		-- Gradient background
		draw.RoundedBox(8, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Purple accent line at bottom
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, h - 2, w, 2)
		
		-- Header text
		draw.SimpleText("First Time Setup", 'PANTHEON.20', 20, 20, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Secure your admin access with a password", 'PANTHEON.14', 20, 45, ui.col.TextDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	
	-- Info panel
	local infoPanel = vgui.Create("DPanel", frame)
	infoPanel:SetPos(10, 135)
	infoPanel:SetSize(frame:GetWide() - 20, 100)
	infoPanel.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundCard)
		
		-- Draw info box on left
		draw.RoundedBox(4, 12, 12, 30, 30, ColorAlpha(ui.col.Blue, 50))
		surface.SetDrawColor(ui.col.Blue.r, ui.col.Blue.g, ui.col.Blue.b, 200)
		surface.DrawOutlinedRect(12, 12, 30, 30, 2)
		
		-- Draw info "i" symbol
		draw.SimpleText("i", 'PANTHEON.20', 27, 27, ui.col.Blue, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	local info = vgui.Create("DLabel", infoPanel)
	info:SetPos(50, 8)
	info:SetSize(infoPanel:GetWide() - 60, 84)
	info:SetText("This is your first time using admin commands.\n\nPlease set up a password to secure your admin access. You will be automatically authenticated after setup.\n\nPassword must be at least 6 characters.")
	info:SetTextColor(ui.col.TEXT)
	info:SetFont('PANTHEON.14')
	info:SetWrap(true)
	info:SetAutoStretchVertical(true)
	
	-- Password input panel
	local inputPanel = vgui.Create("DPanel", frame)
	inputPanel:SetPos(10, 245)
	inputPanel:SetSize(frame:GetWide() - 20, 70)
	inputPanel.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
	end
	
	local passLabel = vgui.Create("DLabel", inputPanel)
	passLabel:SetPos(15, 12)
	passLabel:SetSize(200, 20)
	passLabel:SetText("Enter Password:")
	passLabel:SetTextColor(ui.col.TextDim)
	passLabel:SetFont('PANTHEON.14')
	
	local passEntry = ui.CreateTextEntry(inputPanel, 15, 35, inputPanel:GetWide() - 30, 30, "Enter at least 6 characters...")
	passEntry:SetFont('PANTHEON.16')
	passEntry:SetDrawLanguageID(false)
	
	-- Completely override Paint to control everything
	passEntry.Paint = function(self, w, h)
		-- Draw background
		draw.RoundedBox(4, 0, 0, w, h, ui.col.BackgroundDark or Color(30, 30, 35))
		
		-- Draw border
		surface.SetDrawColor(ui.col.PANTHEON or Color(103, 58, 183))
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		
		-- Draw bullets only (never the actual text)
		local text = self:GetText()
		if #text > 0 then
			local bullets = string.rep("• ", #text)
			draw.SimpleText(bullets, self:GetFont(), 8, h/2, ui.col.TEXT or Color(200, 200, 200), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	
	passEntry:RequestFocus()
	
	-- Submit function
	local function submitPassword()
		local pass = passEntry:GetValue()
		
		if #pass < 6 then
			ui.Notify("Password must be at least 6 characters!", NOTIFY_ERROR, 5)
			passEntry:SetText("")
			passEntry:RequestFocus()
			return
		end
		
		-- Send to server (setup also authenticates automatically)
		net.Start('pas.auth.Setup')
			net.WriteString(pass)
		net.SendToServer()
		
		-- Mark as authenticated locally
		pas.auth.IsAuth = true
		pas.auth.NeedsSetup = false
		
		frame:Close()
	end
	
	-- Button container
	local buttonPanel = vgui.Create("DPanel", frame)
	buttonPanel:SetPos(10, 325)
	buttonPanel:SetSize(frame:GetWide() - 20, 45)
	buttonPanel.Paint = function() end
	
	-- Submit button using PANTHEON UI library
	local submitBtn = ui.CreateButton(buttonPanel, "Set Password & Authenticate", 0, 0, buttonPanel:GetWide(), 40, submitPassword, 'lock', 'primary')
	
	-- Allow Enter key to submit
	passEntry.OnEnter = submitPassword
end

-- Show login dialog
function pas.auth.ShowLogin(reason)
	if IsValid(pas.auth.LoginFrame) then
		pas.auth.LoginFrame:Remove()
	end
	
	-- Create frame using PANTHEON UI library
	local frame = ui.CreateFrame("Admin Authentication", 550, 330, 'lock')
	pas.auth.LoginFrame = frame
	
	-- Header panel with gradient
	local headerPanel = vgui.Create("DPanel", frame)
	headerPanel:SetPos(10, 45)
	headerPanel:SetSize(frame:GetWide() - 20, 70)
	headerPanel.Paint = function(self, w, h)
		-- Gradient background
		draw.RoundedBox(8, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Purple accent line at bottom
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, h - 2, w, 2)
		
		-- Header text with icon (draw manually if ui.DrawIcon doesn't work)
		draw.SimpleText("Authentication Required", 'PANTHEON.20', 20, 15, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("Enter your admin password to continue", 'PANTHEON.14', 20, 42, ui.col.TextDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end
	
	-- Info panel
	local infoPanel = vgui.Create("DPanel", frame)
	infoPanel:SetPos(10, 125)
	infoPanel:SetSize(frame:GetWide() - 20, 70)
	infoPanel.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundCard)
		
		-- Draw warning box on left
		draw.RoundedBox(4, 12, 12, 30, 30, ColorAlpha(ui.col.Yellow, 50))
		surface.SetDrawColor(ui.col.Yellow.r, ui.col.Yellow.g, ui.col.Yellow.b, 200)
		surface.DrawOutlinedRect(12, 12, 30, 30, 2)
		
		-- Draw exclamation mark
		draw.SimpleText("!", 'PANTHEON.20', 27, 27, ui.col.Yellow, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	local info = vgui.Create("DLabel", infoPanel)
	info:SetPos(50, 12)
	info:SetSize(infoPanel:GetWide() - 60, 46)
	info:SetText("This action requires admin authentication.\n\nYour session will remain active for 1 hour after login.")
	info:SetTextColor(ui.col.TEXT)
	info:SetFont('PANTHEON.14')
	info:SetWrap(true)
	info:SetAutoStretchVertical(true)
	
	-- Password input panel
	local inputPanel = vgui.Create("DPanel", frame)
	inputPanel:SetPos(10, 205)
	inputPanel:SetSize(frame:GetWide() - 20, 70)
	inputPanel.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
	end
	
	local passLabel = vgui.Create("DLabel", inputPanel)
	passLabel:SetPos(15, 12)
	passLabel:SetSize(200, 20)
	passLabel:SetText("Admin Password:")
	passLabel:SetTextColor(ui.col.TextDim)
	passLabel:SetFont('PANTHEON.14')
	
	local passEntry = ui.CreateTextEntry(inputPanel, 15, 35, inputPanel:GetWide() - 30, 30, "Enter your password...")
	passEntry:SetFont('PANTHEON.16')
	passEntry:SetDrawLanguageID(false)
	
	-- Completely override Paint to control everything
	passEntry.Paint = function(self, w, h)
		-- Draw background
		draw.RoundedBox(4, 0, 0, w, h, ui.col.BackgroundDark or Color(30, 30, 35))
		
		-- Draw border
		surface.SetDrawColor(ui.col.PANTHEON or Color(103, 58, 183))
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		
		-- Draw bullets only (never the actual text)
		local text = self:GetText()
		if #text > 0 then
			local bullets = string.rep("• ", #text)
			draw.SimpleText(bullets, self:GetFont(), 8, h/2, ui.col.TEXT or Color(200, 200, 200), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
	
	passEntry:RequestFocus()
	
	-- Submit function
	local function submitPassword()
		local pass = passEntry:GetValue()
		
		if #pass == 0 then
			ui.Notify("Please enter your password!", NOTIFY_ERROR, 5)
			passEntry:RequestFocus()
			return
		end
		
		-- Send to server
		net.Start('pas.auth.Login')
			net.WriteString(pass)
		net.SendToServer()
		
		frame:Close()
	end
	
	-- Button container
	local buttonPanel = vgui.Create("DPanel", frame)
	buttonPanel:SetPos(10, 285)
	buttonPanel:SetSize(frame:GetWide() - 20, 40)
	buttonPanel.Paint = function() end
	
	-- Submit button using PANTHEON UI library
	local submitBtn = ui.CreateButton(buttonPanel, "Authenticate", 0, 0, buttonPanel:GetWide(), 40, submitPassword, 'lock', 'primary')
	
	-- Allow Enter key to submit
	passEntry.OnEnter = submitPassword
end

-- Network handlers
net.Receive('pas.auth.Status', function()
	local isAuth = net.ReadBool()
	local needsSetup = net.ReadBool()
	
	print("[PANTHEON AUTH CLIENT] Received Status update - IsAuth: " .. tostring(isAuth) .. ", NeedsSetup: " .. tostring(needsSetup))
	
	pas.auth.IsAuth = isAuth
	pas.auth.NeedsSetup = needsSetup
end)

net.Receive('pas.auth.SetupResponse', function()
	local success = net.ReadBool()
	local message = net.ReadString()
	
	if success then
		ui.Notify(message, NOTIFY_GENERIC, 5)
	else
		ui.Notify(message, NOTIFY_ERROR, 5)
	end
end)

net.Receive('pas.auth.LoginResponse', function()
	local success = net.ReadBool()
	local message = net.ReadString()
	
	if success then
		ui.Notify(message, NOTIFY_GENERIC, 5)
		pas.auth.IsAuth = true
	else
		ui.Notify(message, NOTIFY_ERROR, 5)
	end
end)

net.Receive('pas.AuthRequired', function()
	local needsSetup = net.ReadBool()
	
	print("[PANTHEON AUTH CLIENT] Received AuthRequired - needsSetup: " .. tostring(needsSetup))
	print("[PANTHEON AUTH CLIENT] Current client state - IsAuth: " .. tostring(pas.auth.IsAuth) .. ", NeedsSetup: " .. tostring(pas.auth.NeedsSetup))
	
	if needsSetup then
		print("[PANTHEON AUTH CLIENT] Showing setup dialog")
		pas.auth.ShowSetup()
	else
		print("[PANTHEON AUTH CLIENT] Showing login dialog")
		pas.auth.ShowLogin()
	end
end)

-- Console commands for easy access
concommand.Add("pas_login", function()
	if pas.auth.NeedsSetup then
		pas.auth.ShowSetup()
	else
		pas.auth.ShowLogin()
	end
end)

concommand.Add("pas_logout", function()
	net.Start('pas.auth.Logout')
	net.SendToServer()
	
	pas.auth.IsAuth = false
	ui.Notify("Logged out successfully", NOTIFY_GENERIC, 5)
end)

pas.print('[PANTHEON] Authentication client module loaded')
