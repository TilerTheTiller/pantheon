if (CLIENT) then return end

pas.bans = pas.bans or {}

-- Get database reference (with safety check)
local function getDB()
	if not pas.data or not pas.data.GetDB then
		return nil
	end
	return pas.data.GetDB()
end

function pas.bans.Add(steamid, admin, reason, length, cback)
	local db = getDB()
	if not db then return end
	
	local time = os.time()
	local expire = (length == 0) and 0 or (time + length)
	
	db:query_ex('INSERT INTO pas_bans(steamid, admin, reason, time, expire) VALUES(?, ?, "?", ?, ?)', 
		{steamid, admin, reason, time, expire}, cback)
end

function pas.bans.Remove(steamid, cback)
	local db = getDB()
	if not db then return end
	
	db:query_ex('DELETE FROM pas_bans WHERE steamid=?', {steamid}, cback)
end

function pas.bans.Get(steamid, cback)
	local db = getDB()
	if not db then return end
	
	db:query_ex('SELECT * FROM pas_bans WHERE steamid=?', {steamid}, cback)
end

function pas.bans.IsBanned(steamid)
	local db = getDB()
	if not db then return false end
	
	local data = db:query_sync('SELECT * FROM pas_bans WHERE steamid=?', {steamid})
	
	if #data > 0 then
		local ban = data[1]
		if ban.expire == 0 or ban.expire > os.time() then
			return true, ban
		else
			pas.bans.Remove(steamid)
			return false
		end
	end
	
	return false
end

-- Check bans on player connect
hook.Add('CheckPassword', 'PANTHEON_CheckBan', function(steamid64)
	local banned, ban = pas.bans.IsBanned(steamid64)
	
	if banned then
		local reason = ban.reason or 'No reason'
		local expire = ban.expire == 0 and 'Never' or os.date('%m/%d/%Y %H:%M', ban.expire)
		return false, 'You are banned!\nReason: ' .. reason .. '\nExpires: ' .. expire
	end
end)
