if (SERVER) then return end

-- Store callbacks for log requests
local logRequestCallbacks = {}

-- Set up network receiver once
net.Receive('pas.ReceiveLogs', function()
	local logs = net.ReadTable()
	local total = net.ReadUInt(32)
	
	-- Call all waiting callbacks
	for _, callback in ipairs(logRequestCallbacks) do
		if callback then
			callback(logs, total)
		end
	end
	
	-- Clear callbacks
	logRequestCallbacks = {}
end)

-- Request logs from server
function pas.log.Request(category, search, steamid, limit, offset, callback)
	if callback then
		table.insert(logRequestCallbacks, callback)
	end
	
	net.Start('pas.GetLogs')
		net.WriteString(category or 'all')
		net.WriteString(search or '')
		net.WriteString(steamid or '')
		net.WriteUInt(limit or 100, 16)
		net.WriteUInt(offset or 0, 16)
	net.SendToServer()
end

-- Delete logs
function pas.log.Delete(deleteType, days)
	net.Start('pas.DeleteLogs')
		net.WriteString(deleteType)
		net.WriteUInt(days or 0, 16)
	net.SendToServer()
end

-- Create logs viewer UI
function pas.log.OpenViewer()
	if IsValid(pas.log.viewer) then
		pas.log.viewer:Remove()
	end
	
	-- Create main frame with icon
	local frame = ui.CreateFrame('Server Logs', 1200, 700, 'logs')
	pas.log.viewer = frame
	
	-- Particle system for background
	local particles = {}
	for i = 1, 20 do
		table.insert(particles, {
			x = math.random(0, frame:GetWide()),
			y = math.random(0, frame:GetTall()),
			size = math.random(2, 6),
			speedX = math.Rand(-0.3, 0.3),
			speedY = math.Rand(-0.5, -0.1),
			alpha = math.random(30, 80)
		})
	end
	
	-- Override frame paint to add grid background and particles
	local basePaint = frame.Paint
	frame.Paint = function(self, w, h)
		-- Draw semi-transparent blurred background
		draw.RoundedBox(8, 0, 0, w, h, ColorAlpha(ui.col.BackgroundDark, 240))
		
		-- Draw grid background overlay
		local gridMat = ui.GetIcon('grid-bg')
		if gridMat then
			surface.SetDrawColor(255, 255, 255, 15)
			surface.SetMaterial(gridMat)
			surface.DrawTexturedRect(0, 0, w, h)
		end
		
		-- Draw vignette overlay
		local vignetteMat = ui.GetIcon('vignette')
		if vignetteMat then
			surface.SetDrawColor(0, 0, 0, 60)
			surface.SetMaterial(vignetteMat)
			surface.DrawTexturedRect(0, 0, w, h)
		end
		
		-- Draw and update particles
		for _, p in ipairs(particles) do
			-- Update position
			p.x = p.x + p.speedX
			p.y = p.y + p.speedY
			
			-- Wrap around
			if p.y < -10 then p.y = h + 10 end
			if p.y > h + 10 then p.y = -10 end
			if p.x < -10 then p.x = w + 10 end
			if p.x > w + 10 then p.x = -10 end
			
			-- Draw particle glow first (larger)
			local glowSize = p.size * 3
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, p.alpha * 0.4)
			surface.DrawRect(p.x - glowSize/2, p.y - glowSize/2, glowSize, glowSize)
			
			-- Draw particle core (brighter)
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, p.alpha * 1.5)
			surface.DrawRect(p.x - p.size/2, p.y - p.size/2, p.size, p.size)
		end
		
		-- Draw top header bar
		draw.RoundedBoxEx(8, 0, 0, w, 35, ColorAlpha(ui.col.BackgroundCard, 200), true, true, false, false)
		
		-- Icon and title
		ui.DrawIcon('logs', 18, 17, 20, ui.col.PANTHEON)
		draw.SimpleText('Server Logs', 'PANTHEON.20', 45, 17, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	-- Search and filter container
	local filterPanel = ui.CreatePanel(frame, 10, 45, frame:GetWide() - 20, 60)
	filterPanel:SetPaintBackground(false)
	
	function filterPanel:Paint(w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Top accent line
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, 0, w, 2)
	end
	
	-- Category filter
	local categoryLabel = vgui.Create('DLabel', filterPanel)
	categoryLabel:SetPos(10, 15)
	categoryLabel:SetSize(70, 30)
	categoryLabel:SetText('Category:')
	categoryLabel:SetFont('PANTHEON.16')
	categoryLabel:SetTextColor(ui.col.TextDim)
	
	local categoryBox = ui.CreateComboBox(filterPanel, 85, 15, 140, 30)
	categoryBox:SetValue('All Categories')
	categoryBox:AddChoice('All Categories', 'all')
	
	for id, cat in SortedPairsByMemberValue(pas.log.categories, 'name') do
		categoryBox:AddChoice(cat.name, id)
	end
	
	-- Search box
	local searchLabel = vgui.Create('DLabel', filterPanel)
	searchLabel:SetPos(240, 15)
	searchLabel:SetSize(60, 30)
	searchLabel:SetText('Search:')
	searchLabel:SetFont('PANTHEON.16')
	searchLabel:SetTextColor(ui.col.TextDim)
	
	local searchBox = ui.CreateTextEntry(filterPanel, 305, 15, 230, 30, 'Search logs...')
	
	-- SteamID filter
	local steamidLabel = vgui.Create('DLabel', filterPanel)
	steamidLabel:SetPos(550, 15)
	steamidLabel:SetSize(65, 30)
	steamidLabel:SetText('SteamID:')
	steamidLabel:SetFont('PANTHEON.16')
	steamidLabel:SetTextColor(ui.col.TextDim)
	
	local steamidBox = ui.CreateTextEntry(filterPanel, 620, 15, 190, 30, 'Filter by SteamID...')
	
	-- Refresh button
	local refreshBtn = ui.CreateButton(filterPanel, 'Refresh', 825, 15, 90, 30, nil, 'arrow-right')
	
	-- Delete old logs button (root only)
	if LocalPlayer():HasFlag('r') then
		local deleteBtn = vgui.Create('DButton', filterPanel)
		deleteBtn:SetPos(925, 15)
		deleteBtn:SetSize(140, 30)
		deleteBtn:SetText('')
		deleteBtn.HoverFraction = 0
		
		function deleteBtn:Paint(w, h)
			self.HoverFraction = Lerp(FrameTime() * 10, self.HoverFraction, self:IsHovered() and 1 or 0)
			
			local bgColor = ColorAlpha(Color(180, 50, 50), 180 + self.HoverFraction * 75)
			draw.RoundedBox(4, 0, 0, w, h, bgColor)
			
			if self.HoverFraction > 0 then
				local glowAlpha = self.HoverFraction * 25
				draw.RoundedBox(4, -1, -1, w + 2, h + 2, ColorAlpha(Color(180, 50, 50), glowAlpha))
			end
			
			draw.SimpleText('Delete Old Logs', 'PANTHEON.16', w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		
		function deleteBtn:DoClick()
			Derma_StringRequest(
				'Delete Old Logs',
				'Delete logs older than how many days?',
				'30',
				function(days)
					local numDays = tonumber(days)
					if numDays and numDays > 0 then
						pas.log.Delete('old', numDays)
						timer.Simple(0.5, function()
							if IsValid(frame) then
								refreshBtn:DoClick()
							end
						end)
					end
				end
			)
		end
	end
	
	-- Main logs panel
	local logsPanel = ui.CreatePanel(frame, 10, 115, frame:GetWide() - 20, frame:GetTall() - 170)
	logsPanel:SetPaintBackground(false)
	
	function logsPanel:Paint(w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Header with gradient
		draw.RoundedBox(6, 0, 0, w, 40, ui.col.BackgroundCard)
		
		-- Accent line
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, h - 2, w, 2)
		
		-- Icon and title
		ui.DrawIcon('logs', 18, 20, 20, ui.col.PANTHEON)
		draw.SimpleText('Log Entries', 'PANTHEON.18', 45, 20, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	-- Log list
	local logList = ui.CreateListView(logsPanel, 8, 48, logsPanel:GetWide() - 16, logsPanel:GetTall() - 56)
	logList:AddColumn('Time', 150)
	logList:AddColumn('Category', 130)
	logList:AddColumn('Message', 450)
	
	-- Custom list paint for category colors
	local oldLinePaint = logList.OnRowSelected
	logList.OnRowSelected = function(self, index, line)
		if oldLinePaint then oldLinePaint(self, index, line) end
	end
	
	logList.OnRowRightClick = function(self, index, line)
		local menu = DermaMenu()
		menu:SetSkin('PANTHEON')
		
		local copyOption = menu:AddOption('Copy Message', function()
			SetClipboardText(line:GetValue(3))
			ui.Notify('Message copied to clipboard', NOTIFY_GENERIC, 3)
		end)
		
		-- Use custom icon painting instead of SetIcon
		copyOption.Paint = function(pnl, w, h)
			if pnl:IsHovered() then
				surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 30)
				surface.DrawRect(0, 0, w, h)
			end
			
			ui.DrawIcon('paste', 10, h/2, 16, ui.col.TEXT)
			draw.SimpleText(pnl:GetText(), 'PANTHEON.14', 28, h/2, ui.col.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		
		if LocalPlayer():HasFlag('r') then
			menu:AddSpacer()
			local keyOption = menu:AddOption('Copy Log ID', function()
				SetClipboardText(tostring(line.logId or 'Unknown'))
			end)
			
			keyOption.Paint = function(pnl, w, h)
				if pnl:IsHovered() then
					surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 30)
					surface.DrawRect(0, 0, w, h)
				end
				
				ui.DrawIcon('key', 10, h/2, 16, ui.col.TEXT)
				draw.SimpleText(pnl:GetText(), 'PANTHEON.14', 28, h/2, ui.col.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		end
		
		menu:Open()
	end
	
	-- Footer panel
	local footerPanel = ui.CreatePanel(frame, 10, frame:GetTall() - 45, frame:GetWide() - 20, 35)
	footerPanel:SetPaintBackground(false)
	
	function footerPanel:Paint(w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Top accent line
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, 0, w, 2)
	end
	
	-- Page info
	local pageLabel = vgui.Create('DLabel', footerPanel)
	pageLabel:SetPos(15, 10)
	pageLabel:SetSize(400, 20)
	pageLabel:SetText('Showing 0 - 0 of 0 logs')
	pageLabel:SetFont('PANTHEON.16')
	pageLabel:SetTextColor(ui.col.TextDim)
	
	-- Pagination
	local currentPage = 1
	local logsPerPage = 100
	local totalLogs = 0
	
	local prevBtn = ui.CreateButton(footerPanel, 'Previous', footerPanel:GetWide() - 220, 5, 105, 25, nil, 'arrow-left')
	local nextBtn = ui.CreateButton(footerPanel, 'Next', footerPanel:GetWide() - 110, 5, 105, 25, nil, 'arrow-right')
	
	-- Load logs function
	local function LoadLogs()
		logList:Clear()
		
		local _, catValue = categoryBox:GetSelected()
		local search = searchBox:GetValue()
		local steamid = steamidBox:GetValue()
		local offset = (currentPage - 1) * logsPerPage
		
		pas.log.Request(catValue, search, steamid, logsPerPage, offset, function(logs, total)
			totalLogs = total
			
			for _, log in ipairs(logs) do
				local timeStr = os.date('%Y-%m-%d %H:%M:%S', log.timestamp)
				local category = pas.log.GetCategory(log.category)
				
				local line = logList:AddLine(timeStr, category.name, log.message)
				line.category = log.category
				line.logId = log.id
				
				-- Store the default paint function
				local defaultPaint = line.DefaultPaint
				
				-- Custom line colors based on category
				line.Paint = function(self, w, h)
					-- Call default paint first for text rendering
					defaultPaint(self, w, h)
					
					-- Add category color overlay
					local cat = pas.log.GetCategory(self.category)
					if not self:IsSelected() and not self:IsHovered() then
						surface.SetDrawColor(cat.color.r, cat.color.g, cat.color.b, 15)
						surface.DrawRect(0, 0, w, h)
					end
				end
			end
			
			-- Update page info
			if total > 0 then
				local startNum = offset + 1
				local endNum = math.min(offset + #logs, total)
				pageLabel:SetText(string.format('Showing %d - %d of %d logs', startNum, endNum, total))
			else
				pageLabel:SetText('No logs found')
			end
			
			-- Update button states
			prevBtn:SetEnabled(currentPage > 1)
			nextBtn:SetEnabled(currentPage * logsPerPage < total)
		end)
	end
	
	-- Button actions
	function refreshBtn:DoClick()
		currentPage = 1
		LoadLogs()
	end
	
	function prevBtn:DoClick()
		if currentPage > 1 then
			currentPage = currentPage - 1
			LoadLogs()
		end
	end
	
	function nextBtn:DoClick()
		if currentPage * logsPerPage < totalLogs then
			currentPage = currentPage + 1
			LoadLogs()
		end
	end
	
	function categoryBox:OnSelect(index, value, data)
		currentPage = 1
		LoadLogs()
	end
	
	function searchBox:OnEnter()
		currentPage = 1
		LoadLogs()
	end
	
	function steamidBox:OnEnter()
		currentPage = 1
		LoadLogs()
	end
	
	-- Initial load
	LoadLogs()
end

print('[PANTHEON] Logging system (client) loaded')
