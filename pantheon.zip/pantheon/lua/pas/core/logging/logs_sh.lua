-- Logging system for PANTHEON
if (SERVER) then
	AddCSLuaFile()
end

pas.log = pas.log or {}
pas.log.categories = pas.log.categories or {}

-- Log categories with metadata
pas.log.categories = {
	['Command'] = {
		name = 'Commands',
		color = Color(100, 150, 255),
		icon = 'code',
		enabled = true
	},
	['commands'] = {
		name = 'Commands',
		color = Color(100, 150, 255),
		icon = 'code',
		enabled = true
	},
	['connections'] = {
		name = 'Connections',
		color = Color(100, 255, 100),
		icon = 'wifi',
		enabled = true
	},
	['damage'] = {
		name = 'Damage',
		color = Color(255, 150, 50),
		icon = 'warning',
		enabled = true
	},
	['kills'] = {
		name = 'Kills/Deaths',
		color = Color(255, 50, 50),
		icon = 'combat',
		enabled = true
	},
	['chat'] = {
		name = 'Chat',
		color = Color(150, 150, 255),
		icon = 'message',
		enabled = true
	},
	['props'] = {
		name = 'Props',
		color = Color(200, 200, 100),
		icon = 'grid-icon',
		enabled = true
	},
	['gamemaster'] = {
		name = 'Gamemaster',
		color = Color(255, 200, 50),
		icon = 'star',
		enabled = true
	},
	['ranks'] = {
		name = 'Ranks',
		color = Color(150, 100, 255),
		icon = 'trophy',
		enabled = true
	},
	['bans'] = {
		name = 'Bans/Kicks',
		color = Color(200, 50, 50),
		icon = 'lock',
		enabled = true
	},
	['admin'] = {
		name = 'Admin Actions',
		color = Color(255, 100, 100),
		icon = 'tools',
		enabled = true
	},
	['misc'] = {
		name = 'Miscellaneous',
		color = Color(150, 150, 150),
		icon = 'information',
		enabled = true
	}
}

-- Get category info
function pas.log.GetCategory(category)
	return pas.log.categories[category] or pas.log.categories['misc']
end

-- Add a log entry
function pas.log.Add(category, message, steamid, target_steamid)
	if not pas.log.categories[category] then
		category = 'misc'
	end
	
	if not pas.log.categories[category].enabled then
		return
	end
	
	hook.Run('PANTHEON_Log', category, message, steamid, target_steamid)
	
	-- Send command logs to players with 'm' flag via chat.AddText
	if (SERVER) and (string.lower(category) == 'command' or category == 'Command') then
		-- Send to console
		print("[COMMAND LOG] " .. message)
		
		-- Send to players with 'm' flag
		local color = Color(255, 255, 0) -- Yellow for command logs
		local fullMsg = "[COMMAND] " .. message
		
		for _, ply in pairs(player.GetAll()) do
			if IsValid(ply) and ply:HasFlag('m') then
				-- Use SendLua to call chat.AddText on client (works with PANTHEON chatbox)
				ply:SendLua('chat.AddText(Color(' .. color.r .. ',' .. color.g .. ',' .. color.b .. '), ' .. string.format('%q', fullMsg) .. ')')
			end
		end
	end
	
	if (SERVER) then
		local db = pas.data.GetDB()
		if not db then 
			return 
		end
		
		db:query([[
			INSERT INTO pas_logs (category, message, steamid, target_steamid, timestamp)
			VALUES (?, ?, ?, ?, ?)
		]], {
			category,
			message,
			steamid or '',
			target_steamid or '',
			os.time()
		})
	end
end

-- Helper function to get player name and SteamID
function pas.log.FormatPlayer(ply)
	if IsValid(ply) and ply:IsPlayer() then
		return ply:Nick() .. ' (' .. ply:SteamID() .. ')'
	elseif isstring(ply) then
		return ply
	else
		return 'Unknown'
	end
end

print('[PANTHEON] Logging system (shared) loaded')
