if (CLIENT) then return end

util.AddNetworkString('pas.GetLogs')
util.AddNetworkString('pas.ReceiveLogs')
util.AddNetworkString('pas.DeleteLogs')

-- Create logs table
function pas.log.CreateTable()
	local db = pas.data.GetDB()
	if not db then return end
	
	-- Drop old table if it exists with wrong schema
	db:query('DROP TABLE IF EXISTS pas_logs')
	
	db:query([[
		CREATE TABLE pas_logs (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			category VARCHAR(32) NOT NULL,
			message TEXT NOT NULL,
			steamid VARCHAR(32),
			target_steamid VARCHAR(32),
			timestamp INTEGER NOT NULL
		)
	]])
	
	db:query([[
		CREATE INDEX IF NOT EXISTS idx_pas_logs_category ON pas_logs(category)
	]])
	
	db:query([[
		CREATE INDEX IF NOT EXISTS idx_pas_logs_timestamp ON pas_logs(timestamp)
	]])
	
	db:query([[
		CREATE INDEX IF NOT EXISTS idx_pas_logs_steamid ON pas_logs(steamid)
	]])
	
	print('[PANTHEON] Logs table created/verified')
end

-- Get logs with filters
function pas.log.Get(category, search, steamid, limit, offset, callback)
	local db = pas.data.GetDB()
	if not db then 
		print('[PANTHEON LOGS] ERROR: No database connection!')
		if callback then callback({}) end
		return 
	end
	
	local query = 'SELECT * FROM pas_logs WHERE 1=1'
	local params = {}
	
	if category and category ~= '' and category ~= 'all' then
		query = query .. ' AND category = ?'
		table.insert(params, category)
	end
	
	if search and search ~= '' then
		query = query .. ' AND message LIKE ?'
		table.insert(params, '%' .. search .. '%')
	end
	
	if steamid and steamid ~= '' then
		query = query .. ' AND (steamid = ? OR target_steamid = ?)'
		table.insert(params, steamid)
		table.insert(params, steamid)
	end
	
	query = query .. ' ORDER BY timestamp DESC'
	
	if limit then
		query = query .. ' LIMIT ?'
		table.insert(params, limit)
		
		if offset then
			query = query .. ' OFFSET ?'
			table.insert(params, offset)
		end
	end
	
	
	db:query(query, params, function(results)
		if callback then callback(results or {}) end
	end)
end

-- Get log count
function pas.log.GetCount(category, search, steamid, callback)
	local db = pas.data.GetDB()
	if not db then 
		if callback then callback(0) end
		return 
	end
	
	local query = 'SELECT COUNT(*) as count FROM pas_logs WHERE 1=1'
	local params = {}
	
	if category and category ~= '' and category ~= 'all' then
		query = query .. ' AND category = ?'
		table.insert(params, category)
	end
	
	if search and search ~= '' then
		query = query .. ' AND message LIKE ?'
		table.insert(params, '%' .. search .. '%')
	end
	
	if steamid and steamid ~= '' then
		query = query .. ' AND (steamid = ? OR target_steamid = ?)'
		table.insert(params, steamid)
		table.insert(params, steamid)
	end
	
	db:query(query, params, function(data)
		if callback then
			callback(data and data[1] and data[1].count or 0)
		end
	end)
end

-- Delete old logs
function pas.log.DeleteOld(days, callback)
	local db = pas.data.GetDB()
	if not db then 
		if callback then callback(0) end
		return 
	end
	
	local cutoff = os.time() - (days * 86400)
	
	db:query('DELETE FROM pas_logs WHERE timestamp < ?', {cutoff}, function(data)
		if callback then
			callback(data and data.affected or 0)
		end
	end)
end

-- Delete all logs
function pas.log.DeleteAll(callback)
	local db = pas.data.GetDB()
	if not db then 
		if callback then callback(false) end
		return 
	end
	
	db:query('DELETE FROM pas_logs', {}, function()
		if callback then callback(true) end
	end)
end

-- Network handlers
net.Receive('pas.GetLogs', function(len, ply)
	if not ply:HasFlag('m') then return end
	
	local category = net.ReadString()
	local search = net.ReadString()
	local steamid = net.ReadString()
	local limit = net.ReadUInt(16)
	local offset = net.ReadUInt(16)
	
	pas.log.Get(category, search, steamid, limit, offset, function(data)
		pas.log.GetCount(category, search, steamid, function(count)
			net.Start('pas.ReceiveLogs')
				net.WriteTable(data or {})
				net.WriteUInt(count or 0, 32)
			net.Send(ply)
		end)
	end)
end)

net.Receive('pas.DeleteLogs', function(len, ply)
	if not ply:HasFlag('r') then return end
	
	local deleteType = net.ReadString()
	local days = net.ReadUInt(16)
	
	if deleteType == 'old' then
		pas.log.DeleteOld(days, function(count)
			pas.notify(ply, 'Deleted ' .. count .. ' old log entries', 0)
			pas.log.Add('admin', ply:Nick() .. ' deleted logs older than ' .. days .. ' days', ply:SteamID())
		end)
	elseif deleteType == 'all' then
		pas.log.DeleteAll(function(success)
			if success then
				pas.notify(ply, 'All logs deleted', 0)
				pas.log.Add('admin', ply:Nick() .. ' deleted all logs', ply:SteamID())
			end
		end)
	end
end)

-- Create table on load
hook.Add('PANTHEON_DataReady', 'PANTHEON_CreateLogsTable', function()
	pas.log.CreateTable()
end)

-- Call it immediately since PANTHEON_DataReady might not exist
timer.Simple(1, function()
	pas.log.CreateTable()
end)

-- Connection logging
hook.Add('PlayerInitialSpawn', 'PANTHEON_LogConnect', function(ply)
	pas.log.Add('connections', ply:Nick() .. ' connected', ply:SteamID())
end)

hook.Add('PlayerDisconnected', 'PANTHEON_LogDisconnect', function(ply)
	pas.log.Add('connections', ply:Nick() .. ' disconnected', ply:SteamID())
end)

-- Chat logging
hook.Add('PlayerSay', 'PANTHEON_LogChat', function(ply, text)
	if string.sub(text, 1, 1) ~= '/' and string.sub(text, 1, 1) ~= '!' then
		pas.log.Add('chat', ply:Nick() .. ': ' .. text, ply:SteamID())
	end
end)

-- Kill/Death logging
hook.Add('PlayerDeath', 'PANTHEON_LogDeath', function(victim, inflictor, attacker)
	if IsValid(attacker) and attacker:IsPlayer() and attacker ~= victim then
		local weapon = 'unknown'
		if IsValid(inflictor) and inflictor:IsWeapon() then
			weapon = inflictor:GetClass()
		end
		pas.log.Add('kills', attacker:Nick() .. ' killed ' .. victim:Nick() .. ' with ' .. weapon, attacker:SteamID(), victim:SteamID())
	elseif victim:IsPlayer() then
		pas.log.Add('kills', victim:Nick() .. ' died', victim:SteamID())
	end
end)

-- Damage logging (limited to reduce spam)
local lastDamageLog = {}
hook.Add('EntityTakeDamage', 'PANTHEON_LogDamage', function(target, dmginfo)
	if not target:IsPlayer() then return end
	
	local attacker = dmginfo:GetAttacker()
	if not IsValid(attacker) or not attacker:IsPlayer() or attacker == target then return end
	
	local key = attacker:SteamID() .. ':' .. target:SteamID()
	local now = CurTime()
	
	-- Only log once per 5 seconds per attacker/victim pair
	if lastDamageLog[key] and now - lastDamageLog[key] < 5 then return end
	lastDamageLog[key] = now
	
	local damage = math.Round(dmginfo:GetDamage())
	pas.log.Add('damage', attacker:Nick() .. ' damaged ' .. target:Nick() .. ' for ' .. damage .. ' HP', attacker:SteamID(), target:SteamID())
end)

-- Prop spawn logging
hook.Add('PlayerSpawnedProp', 'PANTHEON_LogProp', function(ply, model, ent)
	local modelName = string.GetFileFromFilename(model)
	pas.log.Add('props', ply:Nick() .. ' spawned prop: ' .. modelName, ply:SteamID())
end)

print('[PANTHEON] Logging system (server) loaded')
