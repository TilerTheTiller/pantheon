-- PANTHEON Module System v2.0
-- Enhanced module loading with validation and dependency management

local modules = {}
local gmModules = {} -- Gamemode-specific modules
local loadedModules = {}
local failedModules = {}

-- Module metatable
local mod_mt = {}
mod_mt.__index = mod_mt

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Module Definition API                                        ║
-- ╚═══════════════════════════════════════════════════════════════╝

function pas.Module(name)
	if not name or name == '' then
		error('Module name cannot be empty')
	end
	
	local m = {
		Name = name,
		Files = {},
		Dependencies = {},
		Creator = 'Unknown',
		Version = '1.0.0',
		Description = '',
		Gamemode = nil,
		CustomCheckFunc = nil,
		Directory = '',
		Enabled = true,
		LoadTime = 0
	}
	
	setmetatable(m, mod_mt)
	table.insert(modules, m)
	
	return m
end

-- Set module author
function mod_mt:Author(name)
	self.Creator = name
	return self
end

-- Set module version
function mod_mt:Version(version)
	self.ModuleVersion = version
	return self
end

-- Set module description
function mod_mt:Description(desc)
	self.ModuleDescription = desc
	return self
end

-- Set gamemode restriction
function mod_mt:SetGM(name)
	self.Gamemode = name:lower()
	if not gmModules[self.Gamemode] then
		gmModules[self.Gamemode] = {}
	end
	table.insert(gmModules[self.Gamemode], self)
	return self
end

-- Set custom validation function
function mod_mt:CustomCheck(callback)
	if not isfunction(callback) then
		error('CustomCheck requires a function')
	end
	self.CustomCheckFunc = callback
	return self
end

-- Add module dependencies
function mod_mt:Require(deps)
	if istable(deps) then
		for _, dep in ipairs(deps) do
			table.insert(self.Dependencies, dep)
		end
	else
		table.insert(self.Dependencies, deps)
	end
	return self
end

-- Add files to load
function mod_mt:Include(files)
	if istable(files) then
		for _, file in ipairs(files) do
			table.insert(self.Files, file)
		end
	else
		table.insert(self.Files, files)
	end
	return self
end

-- Enable/disable module
function mod_mt:SetEnabled(enabled)
	self.Enabled = enabled
	return self
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Module Validation & Loading                                  ║
-- ╚═══════════════════════════════════════════════════════════════╝

-- Check if module should load
function mod_mt:ShouldLoad()
	-- Check if enabled
	if not self.Enabled then
		return false, 'Module disabled'
	end
	
	-- Check gamemode restriction
	if self.Gamemode then
		local currentGM = gmod.GetGamemode().Name:lower()
		if currentGM ~= self.Gamemode then
			return false, 'Wrong gamemode (requires: ' .. self.Gamemode .. ')'
		end
	end
	
	-- Check custom validation
	if self.CustomCheckFunc then
		local success, result = pcall(self.CustomCheckFunc)
		if not success or not result then
			return false, 'Custom check failed: ' .. tostring(result)
		end
	end
	
	-- Check dependencies
	for _, dep in ipairs(self.Dependencies) do
		if not loadedModules[dep] then
			return false, 'Missing dependency: ' .. dep
		end
	end
	
	return true
end

-- Initialize and load module
function mod_mt:Init()
	local canLoad, reason = self:ShouldLoad()
	
	if not canLoad then
		pas.print('[Module] Skipped: ' .. self.Name .. ' (' .. reason .. ')')
		return false
	end
	
	local startTime = SysTime()
	local filesLoaded = 0
	local filesFailed = 0
	
	-- Load all files
	for _, file in ipairs(self.Files) do
		local fullPath = self.Directory .. file
		local success, err = pcall(pas.include, fullPath)
		
		if success then
			filesLoaded = filesLoaded + 1
		else
			filesFailed = filesFailed + 1
			pas.print('[Module] Failed to load file: ' .. file)
			ErrorNoHalt('  Error: ' .. tostring(err) .. '\n')
		end
	end
	
	self.LoadTime = (SysTime() - startTime) * 1000
	
	-- Mark as loaded if at least one file loaded successfully
	if filesLoaded > 0 then
		loadedModules[self.Name] = self
		
		pas.print(string.format('[Module] ✓ %s (v%s) - %d files in %.2fms', 
			self.Name, 
			self.ModuleVersion or '1.0.0',
			filesLoaded,
			self.LoadTime
		))
		
		-- Call module loaded hook
		hook.Call('PANTHEON_ModuleLoaded', nil, self)
		
		return true
	else
		table.insert(failedModules, self.Name)
		pas.print('[Module] ✗ Failed: ' .. self.Name .. ' (no files loaded)')
		return false
	end
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Module Discovery & Registration                              ║
-- ╚═══════════════════════════════════════════════════════════════╝

-- Scan for modules in pas/modules directory
local function discoverModules()
	local _, dirs = file.Find('pas/modules/*', 'LUA')
	local discovered = 0
	
	for _, dir in ipairs(dirs) do
		local modulePath = 'pas/modules/' .. dir
		local moduleFile = modulePath .. '/_module.lua'
		
		if file.Exists(moduleFile, 'LUA') then
			local success, err = pcall(pas.include_sh, moduleFile)
			
			if success then
				-- Set directory for the last registered module
				if modules[#modules] then
					modules[#modules].Directory = modulePath .. '/'
					discovered = discovered + 1
				end
			else
				pas.print('[Module] Failed to load module definition: ' .. dir)
				ErrorNoHalt('  Error: ' .. tostring(err) .. '\n')
			end
		else
			pas.print('[Module] Warning: No _module.lua found in ' .. dir)
		end
	end
	
	return discovered
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Module Initialization Hook                                   ║
-- ╚═══════════════════════════════════════════════════════════════╝

hook.Add('PostGamemodeLoaded', 'PANTHEON_LoadModules', function()
	local moduleStartTime = SysTime()
	
	-- Discover modules
	local discovered = discoverModules()
	pas.print(string.format('[Module] Discovered %d module(s)', discovered))
	
	-- Load modules (supports dependency resolution via multiple passes)
	local maxPasses = 3
	local currentPass = 1
	local loadedThisPass = 0
	
	repeat
		loadedThisPass = 0
		
		for _, module in ipairs(modules) do
			if not loadedModules[module.Name] and not table.HasValue(failedModules, module.Name) then
				if module:Init() then
					loadedThisPass = loadedThisPass + 1
				end
			end
		end
		
		currentPass = currentPass + 1
	until loadedThisPass == 0 or currentPass > maxPasses
	
	local totalLoadTime = (SysTime() - moduleStartTime) * 1000
	
	-- Summary
	local loadedCount = table.Count(loadedModules)
	local failedCount = #failedModules
	
	pas.print(string.format('[Module] System initialized in %.2fms', totalLoadTime))
	pas.print(string.format('  └─ Loaded: %d | Failed: %d', loadedCount, failedCount))
	
	if failedCount > 0 then
		pas.print('  └─ Failed modules: ' .. table.concat(failedModules, ', '))
	end
	
	-- Call plugins loaded hook
	hook.Call('PantheonPluginsLoaded', nil, {
		loaded = loadedModules,
		failed = failedModules,
		loadTime = totalLoadTime
	})
end)

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Module Management API                                        ║
-- ╚═══════════════════════════════════════════════════════════════╝

-- Get module information
function pas.GetModule(name)
	return loadedModules[name]
end

-- Get all loaded modules
function pas.GetLoadedModules()
	return loadedModules
end

-- Get module statistics
function pas.GetModuleStats()
	return {
		total = #modules,
		loaded = table.Count(loadedModules),
		failed = #failedModules,
		gamemode = table.Count(gmModules)
	}
end

-- Reload a specific module (if supported)
function pas.ReloadModule(name)
	local module = loadedModules[name]
	if not module then
		return false, 'Module not found'
	end
	
	-- Clear from loaded
	loadedModules[name] = nil
	
	-- Reload
	local success = module:Init()
	
	if success then
		return true, 'Module reloaded successfully'
	else
		return false, 'Failed to reload module'
	end
end
