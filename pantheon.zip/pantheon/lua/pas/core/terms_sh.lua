pas.terms = pas.terms or {}

function pas.Term(term, ...)
	local args = {...}
	local str = pas.terms[term] or term

	for i = 1, #args do
		str = str:gsub('$' .. i, tostring(args[i]))
	end

	return str
end

pas.terms['PlayerFirstConnect'] = '$1 has connected for the first time!'
pas.terms['PlayerConnect'] = '$1 has connected. Last seen: $2'
pas.terms['PlayerDisconnect'] = '$1 has disconnected.'
pas.terms['PlayerKicked'] = '$1 has been kicked by $2. Reason: $3'
pas.terms['PlayerBanned'] = '$1 has been banned by $2. Reason: $3 | Duration: $4'
pas.terms['PlayerUnbanned'] = '$1 has been unbanned by $2.'
pas.terms['RankSet'] = '$1 has set $2\'s rank to $3'
pas.terms['RankSetExpire'] = '$1 has set $2\'s rank to $3 (expires to $4 in $5)'
