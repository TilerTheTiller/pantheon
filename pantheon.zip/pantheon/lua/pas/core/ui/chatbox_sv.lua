-- PANTHEON Chatbox System (Server)
if CLIENT then return end

pas.chat = pas.chat or {}

-- Include chat tags configuration
if loader then
	loader.load('pas/core/ui/chattags_config.lua')
else
	include('pas/core/ui/chattags_config.lua')
end

-- Network strings
util.AddNetworkString('pas.ChatMessage')
util.AddNetworkString('pas.AdminChat')
util.AddNetworkString('pas.Announcement')
util.AddNetworkString('pas.ChatTagsSync')
util.AddNetworkString('pas.ChatWithTags')

-- Chat types and colors
pas.chat.types = {
	['INFO'] = Color(100, 150, 255),
	['SUCCESS'] = Color(100, 255, 100), 
	['WARNING'] = Color(255, 200, 100),
	['ERROR'] = Color(255, 100, 100),
	['ADMIN'] = Color(255, 150, 0),
	['SYSTEM'] = Color(200, 200, 200)
}

-- Send a chat message to player(s)
function pas.chat.Send(target, messageType, ...)
	local recipients = {}
	
	if target == nil then
		-- Send to all players
		recipients = player.GetAll()
	elseif type(target) == 'Player' then
		recipients = {target}
	elseif type(target) == 'table' then
		recipients = target
	else
		return
	end
	
	local color = pas.chat.types[messageType] or Color(255, 255, 255)
	local args = {...}
	
	-- Add prefix based on message type
	local prefix = ''
	if messageType == 'ADMIN' then
		prefix = '[ADMIN] '
	elseif messageType == 'SYSTEM' then
		prefix = '[SYSTEM] '
	elseif messageType == 'ERROR' then
		prefix = '[ERROR] '
	elseif messageType == 'WARNING' then
		prefix = '[WARNING] '
	elseif messageType == 'SUCCESS' then
		prefix = '[SUCCESS] '
	end
	
	for _, ply in ipairs(recipients) do
		if IsValid(ply) then
			-- Send via standard chat system
			if prefix ~= '' then
				ply:ChatPrint(prefix .. table.concat(args, ' '))
			else
				ply:ChatPrint(table.concat(args, ' '))
			end
		end
	end
end

-- Admin chat system
function pas.chat.AdminChat(sender, message)
	if not IsValid(sender) or not sender:IsPlayer() then return end
	
	-- Check if sender has admin privileges
	local isAdmin = sender:HasFlag('c') -- Admin chat flag
	
	-- Send to all admins and the sender
	for _, ply in ipairs(player.GetAll()) do
		if IsValid(ply) and (ply:HasFlag('c') or ply == sender) then
			net.Start('pas.AdminChat')
			net.WriteBool(isAdmin)
			net.WriteString(sender:Nick())
			net.WriteString(message)
			net.Send(ply)
		end
	end
	
	-- Log admin chat
	pas.log.Add('AdminChat', sender:Nick() .. ': ' .. message)
end

-- Sync chat tags configuration to clients
function pas.chat.SyncTags(target)
	local recipients = {}
	
	if target == nil then
		recipients = player.GetAll() 
	elseif type(target) == 'Player' then
		recipients = {target}
	elseif type(target) == 'table' then
		recipients = target
	else
		return
	end
	
	-- Send configuration data
	net.Start('pas.ChatTagsSync')
	net.WriteTable(pas.chat.tags.config)
	
	if target == nil then
		net.Broadcast()
	else
		for _, ply in ipairs(recipients) do
			if IsValid(ply) then
				net.Send(ply)
			end
		end
	end
end

-- Global announcement system
function pas.chat.Announce(message, duration)
	duration = duration or 5
	
	net.Start('pas.Announcement')
	net.WriteString(message)
	net.WriteFloat(duration)
	net.Broadcast()
	
	-- Also send to server console
	print('[ANNOUNCEMENT] ' .. message)
end

-- Sync chat tags to player when they join
hook.Add('PlayerInitialSpawn', 'PANTHEON.SyncChatTags', function(ply)
	timer.Simple(1, function()
		if IsValid(ply) then
			pas.chat.SyncTags(ply)
		end
	end)
end)

-- Function to send chat with tags to clients
function pas.chat.SendChatWithTags(sender, text, isTeam, recipients)
	-- Determine recipients based on team chat
	if not recipients then
		if isTeam then
			-- Team chat - now based on battalion/job group instead of team
			recipients = {}
			local senderBattalion = sender.GetBattalion and sender:GetBattalion()
			local senderIsCivilian = sender.IsCivilian and sender:IsCivilian()
			
			for _, ply in ipairs(player.GetAll()) do
				if IsValid(ply) then
					-- Check if in same battalion or both civilians
					local isSameGroup = false
					if senderIsCivilian then
						isSameGroup = ply.IsCivilian and ply:IsCivilian()
					elseif senderBattalion then
						isSameGroup = ply.GetBattalion and ply:GetBattalion() == senderBattalion
					end
					
					if isSameGroup then
						table.insert(recipients, ply)
					end
				end
			end
		else
			-- Global chat - send to all players
			recipients = player.GetAll()
		end
	end
	
	-- Get sender's rank tag
	local rankTag = pas.chat.tags.GetPlayerTag(sender)
	
	net.Start('pas.ChatWithTags')
	net.WriteEntity(sender)
	net.WriteString(text)
	net.WriteBool(isTeam or false)
	net.WriteBool(not sender:Alive()) -- isDead
	
	-- Send tag information
	if rankTag and rankTag.enabled and rankTag.tag ~= '' then
		net.WriteBool(true) -- has tag
		net.WriteString(rankTag.tag)
		net.WriteColor(rankTag.color)
		if rankTag.textColor then
			net.WriteBool(true)
			net.WriteColor(rankTag.textColor)
		else
			net.WriteBool(false)
		end
	else
		net.WriteBool(false) -- no tag
	end
	
	for _, ply in ipairs(recipients) do
		if IsValid(ply) then
			net.Send(ply)
		end
	end
end

-- Hook into player chat  
hook.Add('PlayerSay', 'PANTHEON.ChatHandler', function(ply, text, team)
	-- Check for admin chat prefix
	if string.sub(text, 1, 1) == '@' then
		local message = string.sub(text, 2)
		pas.chat.AdminChat(ply, message)
		return '' -- Suppress normal chat
	end
	
	-- Send chat with tags to all clients
	pas.chat.SendChatWithTags(ply, text, team)
	
	-- Suppress the default chat message
	return ''
end)

-- Handle player join/leave messages
hook.Add('PlayerInitialSpawn', 'PANTHEON.JoinMessage', function(ply)
	timer.Simple(1, function()
		if IsValid(ply) then
			local message = ply:Nick() .. ' has joined the server'
			pas.chat.Send(nil, 'INFO', message)
		end
	end)
end)

hook.Add('PlayerDisconnected', 'PANTHEON.LeaveMessage', function(ply)
	local message = ply:Nick() .. ' has left the server'
	pas.chat.Send(nil, 'INFO', message)
end)

-- Team chat handling  
hook.Add('PlayerCanSeePlayersChat', 'PANTHEON.TeamChat', function(text, teamOnly, listener, speaker)
	if not teamOnly then return end
	
	-- Only allow team members to see team chat
	if listener:Team() == speaker:Team() then
		return true
	end
	
	-- Allow admins to see all team chat
	if listener:HasFlag('c') then
		return true
	end
	
	return false
end)

-- Admin commands for chat management
pas.cmd.Create('announce', function(pl, args)
	local message = table.concat(args, ' ')
	if message == '' then
		pas.notify(pl, 'Usage: !announce <message>', 1)
		return
	end
	
	pas.chat.Announce(message)
	pas.notify(pl, 'Announcement sent', 0)
	pas.log.Add('Command', pl:Nick() .. ' sent announcement: ' .. message)
end)
	:SetFlag('a')
	:SetHelp('Send a server-wide announcement')
	:SetIcon('icon16/sound.png')

pas.cmd.Create('adminmsg', function(pl, args)
	local message = table.concat(args, ' ')
	if message == '' then
		pas.notify(pl, 'Usage: !adminmsg <message>', 1)
		return
	end
	
	pas.chat.Send(nil, 'ADMIN', message)
	pas.notify(pl, 'Admin message sent', 0)
	pas.log.Add('Command', pl:Nick() .. ' sent admin message: ' .. message)
end)
	:SetFlag('a')
	:SetHelp('Send an admin message to all players')
	:SetIcon('icon16/user_suit.png')

pas.cmd.Create('psay', function(pl, args)
	local target = args[1]
	table.remove(args, 1)
	local message = table.concat(args, ' ')
	
	if not target or not message then
		pas.notify(pl, 'Usage: !psay <player> <message>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		pas.chat.Send(targ, 'ADMIN', 'Private message from ' .. pl:Nick() .. ': ' .. message)
		pas.notify(pl, 'Private message sent to ' .. targ:Nick(), 0)
		pas.log.Add('Command', pl:Nick() .. ' sent private message to ' .. targ:Nick() .. ': ' .. message)
	end
end)
	:SetFlag('c')
	:SetHelp('Send a private message to a player')
	:SetIcon('icon16/user_comment.png')

print('[PANTHEON] Chatbox system (server) loaded')