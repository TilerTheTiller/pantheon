--[[
    PANTHEON Admin Menu
    Multi-stage menu for player management and command execution
    Based on bAdmin menu structure with PANTHEON UI framework
]]--

if SERVER then
    AddCSLuaFile()
    return
end

-- Ensure UI framework is loaded before proceeding
if not ui or not ui.col or not ui.components then
    ErrorNoHalt('[PANTHEON Menu] UI framework not loaded! Menu cannot initialize.\n')
    return
end

pas = pas or {}
pas.menu = pas.menu or {}

local Menu

--[[
    ============================================================================
    PLAYER PANEL
    Individual player selection panel
    ============================================================================
]]--
local PANEL = {}

function PANEL:Init()
    self.Selected = false
    
    self.Avatar = vgui.Create('AvatarImage', self)
    self.Avatar:SetSize(32, 32)
    self.Avatar:SetPos(4, 4)
    
    self.Name = vgui.Create('DLabel', self)
    self.Name:SetFont('PANTHEON.16')
    self.Name:SetTextColor(ui.col.White)
    self.Name:SetPos(42, 12)
    
    self.RankLabel = vgui.Create('DLabel', self)
    self.RankLabel:SetFont('PANTHEON.12')
    self.RankLabel:SetTextColor(ui.col.TEXT_DIM)
    
    self.Checkbox = vgui.Create('DButton', self)
    self.Checkbox:SetText('')
    self.Checkbox:SetSize(20, 20)
    self.Checkbox.DoClick = function()
        if Menu.Player ~= self then
            if IsValid(Menu.Player) then
                Menu.Player.Selected = false
            end
            Menu.Player = self
            self.Selected = true
            Menu:SetStage(2)
        else
            if IsValid(Menu.CMD) then
                Menu.CMD.Selected = false
            end
            Menu.Player = nil
            self.Selected = false
            Menu:SetStage(1)
        end
    end
    
    self.Checkbox.Paint = function(pnl, w, h)
        -- Checkbox background
        draw.RoundedBox(4, 0, 0, w, h, ui.col.BackgroundLight)
        
        -- Border
        local borderColor = pnl:IsHovered() and ui.col.PANTHEON or ui.col.Outline
        surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, 255)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        
        -- Checkmark
        if self.Selected then
            draw.RoundedBox(2, 3, 3, w - 6, h - 6, ui.col.PANTHEON)
        end
    end
    
    self:SetTall(40)
    self.HoverFraction = 0
end

function PANEL:SetPlayer(pl)
    if not IsValid(pl) then return end
    
    self.Player = pl
    self.SteamID = pl:SteamID()
    self.Avatar:SetPlayer(pl, 32)
    self.Name:SetText(pl:Nick())
    self.Name:SizeToContents()
    
    -- Set rank label
    local rank = pl:GetUserGroup()
    self.RankLabel:SetText(rank or 'user')
    self.RankLabel:SizeToContents()
end

function PANEL:PerformLayout(w, h)
    self.Checkbox:SetPos(w - 26, 10)
    self.RankLabel:SetPos(42, 24)
end

function PANEL:Paint(w, h)
    -- Smooth hover animation
    self.HoverFraction = Lerp(FrameTime() * 10, self.HoverFraction, (self:IsHovered() or self.Selected) and 1 or 0)
    
    -- Background
    local bgColor = ui.col.TableRow
    if self.Selected then
        bgColor = ColorAlpha(ui.col.PANTHEON, 180)
    elseif self.HoverFraction > 0 then
        bgColor = Color(
            bgColor.r + (ui.col.PANTHEON.r - bgColor.r) * self.HoverFraction * 0.3,
            bgColor.g + (ui.col.PANTHEON.g - bgColor.g) * self.HoverFraction * 0.3,
            bgColor.b + (ui.col.PANTHEON.b - bgColor.b) * self.HoverFraction * 0.3,
            255
        )
    end
    
    surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, 255)
    surface.DrawRect(0, 0, w, h)
    
    -- Left accent bar for selected
    if self.Selected then
        surface.SetDrawColor(ui.col.PANTHEON_LIGHT.r, ui.col.PANTHEON_LIGHT.g, ui.col.PANTHEON_LIGHT.b, 255)
        surface.DrawRect(0, 0, 3, h)
    end
    
    -- Bottom separator
    surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
    surface.DrawRect(0, h - 1, w, 1)
end

vgui.Register('PantheonMenuPlayer', PANEL, 'DPanel')

--[[
    ============================================================================
    COMMAND PANEL
    Individual command selection panel
    ============================================================================
]]--
local PANEL = {}

function PANEL:Init()
    self.Selected = false
    
    self.Icon = vgui.Create('DImage', self)
    self.Icon:SetSize(16, 16)
    self.Icon:SetPos(8, 12)
    
    self.Name = vgui.Create('DLabel', self)
    self.Name:SetFont('PANTHEON.16')
    self.Name:SetTextColor(ui.col.White)
    self.Name:SetPos(32, 8)
    
    self.Help = vgui.Create('DLabel', self)
    self.Help:SetFont('PANTHEON.12')
    self.Help:SetTextColor(ui.col.TEXT_DIM)
    self.Help:SetPos(32, 22)
    
    self.Checkbox = vgui.Create('DButton', self)
    self.Checkbox:SetText('')
    self.Checkbox:SetSize(20, 20)
    self.Checkbox.DoClick = function()
        Menu:RemoveCont()
        if Menu.CMD ~= self then
            if IsValid(Menu.CMD) then
                Menu.CMD.Selected = false
            end
            Menu.CMD = self
            self.Selected = true
            Menu:CreateCont(self.Command)
            Menu:SetStage(3)
        else
            Menu.CMD = nil
            self.Selected = false
            Menu:SetStage(2)
        end
    end
    
    self.Checkbox.Paint = function(pnl, w, h)
        -- Checkbox background
        draw.RoundedBox(4, 0, 0, w, h, ui.col.BackgroundLight)
        
        -- Border
        local borderColor = pnl:IsHovered() and ui.col.PANTHEON or ui.col.Outline
        surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, 255)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        
        -- Checkmark
        if self.Selected then
            draw.RoundedBox(2, 3, 3, w - 6, h - 6, ui.col.PANTHEON)
        end
    end
    
    self:SetTall(40)
    self.HoverFraction = 0
end

function PANEL:SetCommand(cmd)
    if not cmd then return end
    
    self.Command = cmd
    
    -- Set icon
    local icon = cmd.Icon or 'icon16/application.png'
    self.Icon:SetImage(icon)
    
    -- Set name
    self.Name:SetText(cmd.Name or 'Unknown')
    self.Name:SizeToContents()
    
    -- Set help text
    local help = cmd.Help or 'No description'
    self.Help:SetText(help)
    self.Help:SizeToContents()
end

function PANEL:PerformLayout(w, h)
    self.Checkbox:SetPos(w - 26, 10)
end

function PANEL:Paint(w, h)
    -- Smooth hover animation
    self.HoverFraction = Lerp(FrameTime() * 10, self.HoverFraction, (self:IsHovered() or self.Selected) and 1 or 0)
    
    -- Background
    local bgColor = ui.col.TableRow
    if self.Selected then
        bgColor = ColorAlpha(ui.col.PANTHEON, 180)
    elseif self.HoverFraction > 0 then
        bgColor = Color(
            bgColor.r + (ui.col.PANTHEON.r - bgColor.r) * self.HoverFraction * 0.3,
            bgColor.g + (ui.col.PANTHEON.g - bgColor.g) * self.HoverFraction * 0.3,
            bgColor.b + (ui.col.PANTHEON.b - bgColor.b) * self.HoverFraction * 0.3,
            255
        )
    end
    
    surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, 255)
    surface.DrawRect(0, 0, w, h)
    
    -- Left accent bar for selected
    if self.Selected then
        surface.SetDrawColor(ui.col.PANTHEON_LIGHT.r, ui.col.PANTHEON_LIGHT.g, ui.col.PANTHEON_LIGHT.b, 255)
        surface.DrawRect(0, 0, 3, h)
    end
    
    -- Bottom separator
    surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
    surface.DrawRect(0, h - 1, w, 1)
end

vgui.Register('PantheonMenuCommand', PANEL, 'DPanel')

--[[
    ============================================================================
    COMMAND ARGUMENTS PANEL
    Shows arguments and execute button for selected command
    ============================================================================
]]--
local PANEL = {}

function PANEL:Init()
    self.ArgPanels = {}
    
    self.Header = vgui.Create('DPanel', self)
    self.Header:SetTall(40)
    self.Header:Dock(TOP)
    self.Header.Paint = function(pnl, w, h)
        -- Dark header background
        surface.SetDrawColor(ui.col.BackgroundDark.r, ui.col.BackgroundDark.g, ui.col.BackgroundDark.b, 220)
        surface.DrawRect(0, 0, w, h)
        
        -- Purple accent bottom line
        surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 180)
        surface.DrawRect(0, h - 2, w, 2)
    end
    
    self.Name = vgui.Create('DLabel', self.Header)
    self.Name:SetFont('PANTHEON.18')
    self.Name:SetTextColor(ui.col.White)
    self.Name:SetPos(12, 12)
    
    -- Scrollable args container
    self.ArgsScroll = vgui.Create('DScrollPanel', self)
    self.ArgsScroll:Dock(FILL)
    self.ArgsScroll:DockMargin(8, 8, 8, 8)
    self.ArgsScroll.Paint = function(pnl, w, h)
        draw.BlurredPanel(pnl, 4, ui.col.BackgroundDark, 240)
        surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    
    -- Custom scrollbar
    local sbar = self.ArgsScroll:GetVBar()
    sbar:SetWide(6)
    sbar.Paint = function() end
    sbar.btnGrip.Paint = function(pnl, w, h)
        pnl.HoverFraction = Lerp(FrameTime() * 8, pnl.HoverFraction or 0, pnl:IsHovered() and 1 or 0)
        local gripColor = ColorAlpha(ui.col.PANTHEON, 180 + 75 * pnl.HoverFraction)
        draw.RoundedBox(3, 0, 0, w, h, gripColor)
    end
    sbar.btnUp.Paint = function() end
    sbar.btnDown.Paint = function() end
    
    self.ArgsContainer = vgui.Create('DPanel', self.ArgsScroll)
    self.ArgsContainer:Dock(TOP)
    self.ArgsContainer:SetTall(0) -- Will auto-size based on children
    self.ArgsContainer.Paint = function() end
    
    self.RunButton = ui.components.CreateButton(self, 'Execute Command', 0, 0, 0, 35, function()
        self:ExecuteCommand()
    end, 'icon16/lightning.png', 'primary')
    self.RunButton:Dock(BOTTOM)
    self.RunButton:DockMargin(8, 0, 8, 8)
end

function PANEL:SetCommand(cmd)
    if not cmd then return end
    
    self.Command = cmd
    self.Name:SetText(cmd.Name or 'Unknown Command')
    self.Name:SizeToContents()
    
    -- Debug: Print command args structure
    print('[PANTHEON DEBUG] Command:', cmd.Name)
    print('[PANTHEON DEBUG] Args table:', cmd.Args)
    if cmd.Args then
        print('[PANTHEON DEBUG] Args count:', #cmd.Args)
        PrintTable(cmd.Args)
    end
    
    -- Clear existing arg panels
    for _, panel in ipairs(self.ArgPanels) do
        if IsValid(panel) then
            panel:Remove()
        end
    end
    self.ArgPanels = {}
    
    -- Clear container
    if IsValid(self.ArgsContainer) then
        self.ArgsContainer:Clear()
    end
    
    -- Create argument input fields using Dock for proper scrolling
    if cmd.Args and #cmd.Args > 0 then
        print('[PANTHEON DEBUG] Creating', #cmd.Args, 'argument panels')
        for i, arg in ipairs(cmd.Args) do
            print('[PANTHEON DEBUG] Creating arg', i, ':', arg.Key, arg.Param)
            local argPanel = vgui.Create('DPanel', self.ArgsContainer)
            argPanel:Dock(TOP)
            argPanel:DockMargin(4, 4, 4, 4)
            argPanel:SetTall(70)
            argPanel.Paint = function(pnl, w, h)
                -- Blurred dark background
                draw.BlurredPanel(pnl, 3, ui.col.BackgroundCard, 240)
                surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 80)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
            
            -- Argument label (use Key for display name, Param for type)
            local label = vgui.Create('DLabel', argPanel)
            label:SetFont('PANTHEON.14')
            label:SetTextColor(ui.col.PANTHEON_LIGHT)
            label:SetText(arg.Key or arg.Param or 'Argument ' .. i)
            label:SetPos(8, 8)
            label:SizeToContents()
            
            -- Argument input
            local input
            local paramType = arg.Param or arg.Type or ''
            print('[PANTHEON DEBUG] Param type:', paramType)
            if paramType == 'player' then
                -- Player is already selected, show it
                input = vgui.Create('DLabel', argPanel)
                input:SetFont('PANTHEON.16')
                input:SetTextColor(ui.col.White)
                if IsValid(Menu.Player) and IsValid(Menu.Player.Player) then
                    input:SetText(Menu.Player.Player:Nick())
                else
                    input:SetText('No player selected')
                end
                input:SetPos(8, 35)
                input:SizeToContents()
            else
                -- Text input for other argument types - use Dock to auto-size
                print('[PANTHEON DEBUG] Creating DTextEntry...')
                input = vgui.Create('DTextEntry', argPanel)
                print('[PANTHEON DEBUG] DTextEntry created, setting properties...')
                if not IsValid(input) then
                    print('[PANTHEON DEBUG ERROR] DTextEntry invalid!')
                    continue
                end
                
                input:SetPos(8, 35)
                input:SetSize(argPanel:GetWide() - 16, 28)
                print('[PANTHEON DEBUG] Set position and size')
                input:SetFont('PANTHEON.16')
                input:SetTextColor(ui.col.White)
                input:SetCursorColor(ui.col.PANTHEON)
                print('[PANTHEON DEBUG] Set font and colors')
                input:SetPlaceholderText(arg.Key or 'Enter ' .. (arg.Param or 'value'))
                input:SetPlaceholderColor(ui.col.TextDisabled or Color(100, 100, 100))
                print('[PANTHEON DEBUG] Set placeholder')
                
                input.FocusFraction = 0
                print('[PANTHEON DEBUG] About to set Paint function...')
                
                input.Paint = function(pnl, ew, eh)
                    pnl.FocusFraction = Lerp(FrameTime() * 10, pnl.FocusFraction, pnl:HasFocus() and 1 or 0)
                    
                    -- Blurred dark background
                    draw.BlurredPanel(pnl, 3, ui.col.BackgroundLight or Color(26, 26, 30), 240)
                    
                    -- Border with focus effect
                    local borderColor = ui.col.Outline
                    if pnl.FocusFraction > 0 then
                        borderColor = Color(
                            ui.col.Outline.r + (ui.col.PANTHEON.r - ui.col.Outline.r) * pnl.FocusFraction,
                            ui.col.Outline.g + (ui.col.PANTHEON.g - ui.col.Outline.g) * pnl.FocusFraction,
                            ui.col.Outline.b + (ui.col.PANTHEON.b - ui.col.Outline.b) * pnl.FocusFraction,
                            200 + 55 * pnl.FocusFraction
                        )
                    end
                    
                    surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, borderColor.a)
                    surface.DrawOutlinedRect(0, 0, ew, eh, 1)
                    
                    -- Glow when focused
                    if pnl.FocusFraction > 0 then
                        for i = 1, 2 do
                            local glowAlpha = (20 * pnl.FocusFraction) * (1 - (i / 2))
                            surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, glowAlpha)
                            surface.DrawOutlinedRect(-i, -i, ew + i*2, eh + i*2, 1)
                        end
                    end
                    
                    pnl:DrawTextEntryText(ui.col.White, ui.col.PANTHEON, ui.col.White)
                end
                
                -- Handle resizing
                argPanel.PerformLayout = function(pnl, w, h)
                    if IsValid(input) then
                        input:SetWide(w - 16)
                    end
                end
            end
            
            argPanel.Input = input
            argPanel.ArgData = arg
            
            table.insert(self.ArgPanels, argPanel)
            
            print('[PANTHEON DEBUG] Created argPanel, tall:', argPanel:GetTall(), 'parent:', self.ArgsContainer)
        end
        print('[PANTHEON DEBUG] Total ArgPanels created:', #self.ArgPanels)
        
        -- Resize container to fit all args
        local totalHeight = #self.ArgPanels * (70 + 8) -- panel height + margins
        self.ArgsContainer:SetTall(totalHeight)
        
        print('[PANTHEON DEBUG] ArgsContainer size:', self.ArgsContainer:GetWide(), 'x', self.ArgsContainer:GetTall())
        print('[PANTHEON DEBUG] ArgsScroll size:', self.ArgsScroll:GetWide(), 'x', self.ArgsScroll:GetTall())
    else
        -- No arguments needed
        local noArgs = vgui.Create('DLabel', self.ArgsContainer)
        noArgs:Dock(TOP)
        noArgs:DockMargin(8, 8, 8, 8)
        noArgs:SetFont('PANTHEON.16')
        noArgs:SetTextColor(ui.col.TEXT_DIM)
        noArgs:SetText('No additional arguments required')
        noArgs:SizeToContents()
    end
end

function PANEL:ExecuteCommand()
	if not self.Command then return end
	
	local args = {}
	
	-- Build command arguments
	if self.Command.Args and #self.Command.Args > 0 then
		for i, argPanel in ipairs(self.ArgPanels) do
			if not IsValid(argPanel) then continue end
			
			local arg = argPanel.ArgData
			local value
			local paramType = arg.Param or arg.Type or ''
			
			if paramType == 'player' then
				-- Use selected player
				if IsValid(Menu.Player) and IsValid(Menu.Player.Player) then
					value = Menu.Player.Player:Nick()
				else
					pas.notify(LocalPlayer(), 'No player selected!', 1)
					return
				end
			else
				-- Get text input value
				if argPanel.Input.GetValue then
					value = argPanel.Input:GetValue()
				elseif argPanel.Input.GetText then
					value = argPanel.Input:GetText()
				end
				
				-- Check if required and empty (Flag field indicates if optional)
				if not arg.Flag and (not value or value == '') then
					pas.notify(LocalPlayer(), 'Please fill in all required fields!', 1)
					return
				end
			end
			
			if value and value ~= '' then
				table.insert(args, value)
			end
		end
	else
		-- No args, but might need player target
		if IsValid(Menu.Player) and IsValid(Menu.Player.Player) then
			table.insert(args, Menu.Player.Player:Nick())
		end
	end
	
	-- Send command to server via network
	net.Start('pas.RunCommand')
		net.WriteString(self.Command.Name)
		net.WriteTable(args)
	net.SendToServer()
	
	-- Show notification
	pas.notify(LocalPlayer(), 'Command executed: ' .. self.Command.Name, 0)
end

function PANEL:Paint(w, h)
    -- Blurred dark background
    draw.BlurredPanel(self, 5, ui.col.BackgroundDark, 245)
    
    -- Border
    surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 100)
    surface.DrawOutlinedRect(0, 0, w, h, 1)
end

vgui.Register('PantheonMenuCommandArgs', PANEL, 'DPanel')

--[[
    ============================================================================
    MAIN MENU
    Multi-stage menu with player list, command list, and arguments
    ============================================================================
]]--
local PANEL = {}

function PANEL:Init()
    self.BaseWidth = ScrW() * 0.25
    self.BaseHeight = ScrH() * 0.6
    self.ExtendedHeight = ScrH() * 0.75
    
    self:SetSize(self.BaseWidth, self.BaseHeight)
    self:Center()
    self:SetTitle('')
    self:ShowCloseButton(false)
    self:MakePopup()
    self:SetSkin('PANTHEON')
    
    -- Custom title
    self.PantheonTitle = 'PANTHEON Admin'
    self.PantheonIcon = 'icon16/shield.png'
    self.OpenAnimation = 0
    self.PulseAnimation = 0
    
    -- Entrance animation
    self:SetAlpha(0)
    self:MoveTo(self.x, self.y - 30, 0.3, 0, 0.5, function()
        self:SetAlpha(255)
    end)
    ui.Animate(self, "OpenAnimation", 1, 0.3, ui.easings.easeOutCubic)
    
    -- Enhanced close button
    local closeBtn = vgui.Create('DButton', self)
    closeBtn:SetText('')
    closeBtn:SetSize(28, 28)
    closeBtn:SetPos(self:GetWide() - 33, 3)
    closeBtn.HoverFraction = 0
    closeBtn.ClickAnimation = 0
    
    closeBtn.Paint = function(pnl, bw, bh)
        pnl.HoverFraction = Lerp(FrameTime() * 15, pnl.HoverFraction, pnl:IsHovered() and 1 or 0)
        pnl.ClickAnimation = Lerp(FrameTime() * 20, pnl.ClickAnimation, 0)
        
        local alpha = 30 + pnl.HoverFraction * 120
        local bgColor = ColorAlpha(Color(244, 67, 54), alpha)
        local scale = 1 - pnl.ClickAnimation * 0.1
        local offset = (1 - scale) * bw * 0.5
        
        draw.RoundedBox(6, offset, offset, bw * scale, bh * scale, bgColor)
        
        if pnl.HoverFraction > 0 then
            draw.Glow(0, 0, bw, bh, 2, ColorAlpha(Color(244, 67, 54), 50 * pnl.HoverFraction))
        end
        
        surface.SetFont('PANTHEON.16')
        draw.SimpleText('×', 'PANTHEON.16', bw/2, bh/2, ColorAlpha(Color(255, 255, 255), 200 + pnl.HoverFraction * 55), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    
    closeBtn.DoClick = function(pnl)
        pnl.ClickAnimation = 1
        ui.Animate(self, "OpenAnimation", 0, 0.2, ui.easings.easeInCubic, function()
            self:MoveTo(self.x, self.y - 30, 0.2, 0, 0, function()
                self:Close()
            end)
        end)
    end
    
    self.CloseButton = closeBtn
    
    -- Player list scroll panel
    self.PlayerList = vgui.Create('DScrollPanel', self)
    self.PlayerList:SetPos(8, 40)
    self.PlayerList:SetSize(self.BaseWidth - 16, self.BaseHeight - 48)
    self.PlayerList.Paint = function(pnl, w, h)
        draw.BlurredPanel(pnl, 4, ui.col.BackgroundDark, 240)
        surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    
    -- Custom scrollbar for player list
    local sbar = self.PlayerList:GetVBar()
    sbar:SetWide(6)
    sbar.Paint = function() end
    sbar.btnGrip.Paint = function(pnl, w, h)
        pnl.HoverFraction = Lerp(FrameTime() * 8, pnl.HoverFraction or 0, pnl:IsHovered() and 1 or 0)
        local gripColor = ColorAlpha(ui.col.PANTHEON, 180 + 75 * pnl.HoverFraction)
        draw.RoundedBox(3, 0, 0, w, h, gripColor)
    end
    sbar.btnUp.Paint = function() end
    sbar.btnDown.Paint = function() end
    
    -- Populate player list
    for _, pl in ipairs(player.GetAll()) do
        local playerPanel = vgui.Create('PantheonMenuPlayer')
        playerPanel:SetPlayer(pl)
        playerPanel:Dock(TOP)
        playerPanel:DockMargin(0, 0, 0, 1)
        self.PlayerList:AddItem(playerPanel)
    end
    
    -- Command list scroll panel (initially hidden)
    self.CommandList = vgui.Create('DScrollPanel', self)
    self.CommandList:SetPos(self.BaseWidth + 8, 80)
    self.CommandList:SetSize(self.BaseWidth - 8, self.BaseHeight - 88)
    self.CommandList.Paint = function(pnl, w, h)
        draw.BlurredPanel(pnl, 4, ui.col.BackgroundDark, 240)
        surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    
    -- Command search box
    self.CommandSearch = vgui.Create('DTextEntry', self)
    self.CommandSearch:SetPos(self.BaseWidth, 40)
    self.CommandSearch:SetSize(self.BaseWidth, 32)
    self.CommandSearch:SetFont('PANTHEON.14')
    self.CommandSearch:SetPlaceholderText('Search commands...')
    self.CommandSearch:SetUpdateOnType(true)
    self.CommandSearch:SetCursorColor(ui.col.PANTHEON)
    
    self.CommandSearch.Paint = function(pnl, w, h)
        draw.RoundedBox(4, 0, 0, w, h, ui.col.BackgroundCard)
        surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 100)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        
        -- Search icon
        ui.DrawIcon('search', 8, h/2, 16, ui.col.TEXT_DIM)
        
        -- Manually draw text with proper offset
        local text = pnl:GetValue()
        local textX = 32
        
        if text and text ~= "" then
            draw.SimpleText(text, 'PANTHEON.14', textX, h/2, ui.col.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        else
            draw.SimpleText(pnl:GetPlaceholderText(), 'PANTHEON.14', textX, h/2, ui.col.TEXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
    end
    
    -- Override to position cursor correctly
    local oldOnGetFocus = self.CommandSearch.OnGetFocus
    self.CommandSearch.OnGetFocus = function(pnl)
        pnl:SetCaretPos(string.len(pnl:GetValue()))
        if oldOnGetFocus then oldOnGetFocus(pnl) end
    end
    
    self.CommandSearch.OnValueChange = function(pnl, value)
        self:FilterCommands(value)
    end
    
    -- Custom scrollbar for command list
    local csbar = self.CommandList:GetVBar()
    csbar:SetWide(6)
    csbar.Paint = function() end
    csbar.btnGrip.Paint = function(pnl, w, h)
        pnl.HoverFraction = Lerp(FrameTime() * 8, pnl.HoverFraction or 0, pnl:IsHovered() and 1 or 0)
        local gripColor = ColorAlpha(ui.col.PANTHEON, 180 + 75 * pnl.HoverFraction)
        draw.RoundedBox(3, 0, 0, w, h, gripColor)
    end
    csbar.btnUp.Paint = function() end
    csbar.btnDown.Paint = function() end
    
    -- Store all commands for filtering
    self.AllCommands = {}
    
    -- Populate command list
    if pas.cmd and pas.cmd.GetTable then
        for name, cmd in pairs(pas.cmd.GetTable()) do
            -- Only show commands player has access to
            local hasAccess = false
            if cmd.Flags then
                for _, flag in ipairs(cmd.Flags) do
                    if IsValid(LocalPlayer()) and LocalPlayer().HasFlag and LocalPlayer():HasFlag(flag) then
                        hasAccess = true
                        break
                    end
                end
            elseif cmd.Flag then
                if IsValid(LocalPlayer()) and LocalPlayer().HasFlag then
                    hasAccess = LocalPlayer():HasFlag(cmd.Flag)
                end
            else
                hasAccess = true
            end
            
            if hasAccess then
                table.insert(self.AllCommands, {
                    Name = name,
                    Help = cmd.Help or 'No description',
                    Icon = cmd.Icon or 'icon16/application.png',
                    Args = cmd.Args,
                    Flags = cmd.Flags or {cmd.Flag}
                })
            end
        end
    end
    
    -- Populate initial command list
    self:PopulateCommandList()
    
    -- Stage 1: Player list only
    self.Stage = 1
end

function PANEL:PopulateCommandList(filter)
    self.CommandList:Clear()
    
    local filterLower = filter and string.lower(filter) or ""
    
    for _, cmdData in ipairs(self.AllCommands) do
        local matches = true
        
        if filter and filter ~= "" then
            local nameLower = string.lower(cmdData.Name)
            local helpLower = string.lower(cmdData.Help)
            matches = string.find(nameLower, filterLower, 1, true) or string.find(helpLower, filterLower, 1, true)
        end
        
        if matches then
            local cmdPanel = vgui.Create('PantheonMenuCommand')
            cmdPanel:SetCommand(cmdData)
            cmdPanel:Dock(TOP)
            cmdPanel:DockMargin(0, 0, 0, 1)
            self.CommandList:AddItem(cmdPanel)
        end
    end
end

function PANEL:FilterCommands(filter)
    self:PopulateCommandList(filter)
end

function PANEL:Paint(w, h)
    -- Blurred dark background
    draw.BlurredPanel(self, 8, Color(18, 18, 22), 245)
    
    -- Enhanced shadow for depth
    draw.Shadow(0, 0, w, h, 16, 140)
    
    -- Subtle border
    surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 120)
    surface.DrawOutlinedRect(0, 0, w, h, 1)
    
    -- Pulse animation for header
    self.PulseAnimation = (self.PulseAnimation or 0) + FrameTime() * 1.5
    local pulse = math.sin(self.PulseAnimation) * 0.1 + 0.9
    
    -- Dark theme title bar with purple gradient
    local titleHeight = 34
    local col1 = ColorAlpha(ui.col.PANTHEON, 255)
    local col2 = ColorAlpha(ui.col.PANTHEON_DARK, 255)
    draw.AnimatedGradient(0, 0, w, titleHeight, col1, col2, "horizontal", 0.3)
    
    -- Enhanced purple glow effect
    draw.Glow(0, 0, w, titleHeight, 4, ColorAlpha(ui.col.PANTHEON, 40 * pulse), pulse)
    
    -- Draw title with entrance animation
    local scale = self.OpenAnimation or 1
    draw.SimpleText(self.PantheonTitle, 'PANTHEON.18', 12, 17, ColorAlpha(ui.col.White, 255 * scale), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    
    -- Bright accent line with animation
    surface.SetDrawColor(ui.col.PANTHEON_LIGHT.r, ui.col.PANTHEON_LIGHT.g, ui.col.PANTHEON_LIGHT.b, 200 * pulse)
    surface.DrawRect(0, titleHeight - 2, w, 2)
end

function PANEL:SetStage(stage)
    self.Stage = stage
    
    local newW, newH
    local listHeight = self.BaseHeight - 48
    
    if stage == 1 then
        -- Only player list visible
        newW = self.BaseWidth
        newH = self.BaseHeight
    elseif stage == 2 then
        -- Player list + command list
        newW = self.BaseWidth * 2 + 16
        newH = self.BaseHeight
    elseif stage == 3 then
        -- All three panels (with args)
        -- Shrink player/command lists to make room for args
        newW = self.BaseWidth * 2 + 16
        newH = self.ExtendedHeight
        listHeight = math.floor((self.ExtendedHeight - 48) * 0.4) -- 40% for lists, 60% for args
    end
    
    -- Resize player and command lists
    if IsValid(self.PlayerList) then
        self.PlayerList:SetSize(self.BaseWidth - 16, listHeight)
    end
    if IsValid(self.CommandList) then
        self.CommandList:SetSize(self.BaseWidth - 8, listHeight)
    end
    
    -- Calculate centered position
    local newX = (ScrW() - newW) / 2
    local newY = (ScrH() - newH) / 2
    
    -- Animate to new size and position (centered)
    self:MoveTo(newX, newY, 0.2, 0, 0.25)
    self:SizeTo(newW, newH, 0.2, 0, 0.25)
    
    -- Update close button position
    timer.Simple(0.21, function()
        if IsValid(self) and IsValid(self.CloseButton) then
            self.CloseButton:SetPos(self:GetWide() - 33, 3)
        end
    end)
end

function PANEL:CreateCont(cmd)
    if not cmd then return end
    
    self.Cont = vgui.Create('PantheonMenuCommandArgs', self)
    -- Position below the shrunk player/command panels
    local listHeight = math.floor((self.ExtendedHeight - 48) * 0.4)
    local yPos = 40 + listHeight + 8
    local availableHeight = self.ExtendedHeight - yPos - 8
    self.Cont:SetPos(8, yPos)
    self.Cont:SetSize(self.BaseWidth * 2, availableHeight)
    self.Cont:InvalidateLayout(true)
    self.Cont:SetCommand(cmd)
    
    -- Force layout update
    timer.Simple(0.01, function()
        if IsValid(self.Cont) then
            self.Cont:InvalidateLayout(true)
        end
    end)
end

function PANEL:RemoveCont()
    if IsValid(self.Cont) then
        self.Cont:Remove()
        self.Cont = nil
    end
end

vgui.Register('PantheonAdminMenu', PANEL, 'DFrame')

--[[
    ============================================================================
    PUBLIC FUNCTIONS
    ============================================================================
]]--

function pas.menu.Open()
    if IsValid(Menu) then
        Menu:Close()
    end
    
    Menu = vgui.Create('PantheonAdminMenu')
end

function pas.menu.Close()
    if IsValid(Menu) then
        Menu:Close()
    end
end

function pas.menu.Toggle()
    if IsValid(Menu) then
        pas.menu.Close()
    else
        pas.menu.Open()
    end
end

-- Console command for backward compatibility
concommand.Add('pas_menu', function()
    pas.menu.Open()
end)

-- Notify on spawn
hook.Add('HUDPaint', 'PANTHEON_MenuHint_Once', function()
    if IsValid(LocalPlayer()) and LocalPlayer().HasFlag and LocalPlayer():HasFlag('a') then
        -- Show hint once
        timer.Simple(2, function()
            if IsValid(LocalPlayer()) then
                pas.notify(LocalPlayer(), 'Type /menu to open PANTHEON Admin Menu', 0)
            end
        end)
        hook.Remove('HUDPaint', 'PANTHEON_MenuHint_Once')
    end
end)

if ui and ui.col then
    MsgC(ui.col.PANTHEON, '[PANTHEON] ', ui.col.White, 'Admin Menu loaded (Type /menu)\n')
else
    print('[PANTHEON] Admin Menu loaded (Type /menu)')
end
