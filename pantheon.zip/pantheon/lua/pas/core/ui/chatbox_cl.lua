-- PANTHEON Chatbox System (Client)
if SERVER then return end

pas.chat = pas.chat or {}
pas.chat.history = {}

-- Include chat tags configuration
if loader then
	loader.load('pas/core/ui/chattags_config.lua')
else
	include('pas/core/ui/chattags_config.lua')
end

-- Font definitions
surface.CreateFont('PANTHEON.Chat', {
	font = 'Funnel Sans',
	size = 18,
	weight = 400,
	antialias = true
})

surface.CreateFont('PANTHEON.ChatBold', {
	font = 'Funnel Sans',
	size = 18,
	weight = 700,
	antialias = true
})

surface.CreateFont('PANTHEON.ChatSmall', {
	font = 'Funnel Sans',
	size = 14,
	weight = 400,
	antialias = true
})

-- Hide default chat
hook.Add('HUDShouldDraw', 'PANTHEON.HideDefaultChat', function(name)
	if name == 'CHudChat' then
		return false
	end
end)

-- Custom chat message label
local CHAT_LABEL = {}

function CHAT_LABEL:Init()
	self.colors = {}
	self.text = ''
	self.bits = {}
	self.messageTime = CurTime()
	self.fadeStartTime = self.messageTime + 12 -- Messages fade after 12 seconds
	self:SetText('')
end

function CHAT_LABEL:SetMessage(...)
	local args = {...}
	self.bits = {}
	self.text = ''
	
	local currentColor = Color(255, 255, 255)
	
	for i, arg in ipairs(args) do
		if type(arg) == 'table' and arg.r and arg.g and arg.b then -- Color
			currentColor = arg
		elseif type(arg) == 'Player' then
			table.insert(self.bits, {
				text = arg:Nick(),
				color = arg.GetJobColor and arg:GetJobColor() or Color(255, 255, 255),
				pos = #self.text
			})
			self.text = self.text .. arg:Nick()
		elseif type(arg) == 'string' or type(arg) == 'number' then
			table.insert(self.bits, {
				text = tostring(arg),
				color = currentColor,
				pos = #self.text
			})
			self.text = self.text .. tostring(arg)
		end
	end
	
	self:SizeToContents()
end

function CHAT_LABEL:SizeToContents()
	surface.SetFont('PANTHEON.Chat')
	local w, h = surface.GetTextSize(self.text)
	-- Add padding and ensure minimum height
	local minHeight = 18 -- Minimum height for each message line
	h = math.max(h, minHeight)
	-- Don't set width here - let the parent container handle it
	self:SetTall(h + 4) -- Add vertical padding
end

function CHAT_LABEL:Paint(w, h)
	if not PANTHEON_CHATBOX or not PANTHEON_CHATBOX._open then
		-- Fade out when chat is closed
		local fadeTime = 3 -- 3 seconds to fade
		local timeSinceFadeStart = CurTime() - self.fadeStartTime
		
		if timeSinceFadeStart > fadeTime then
			return true -- Don't paint, message has faded
		elseif timeSinceFadeStart > 0 then
			local alpha = math.Clamp(1 - timeSinceFadeStart / fadeTime, 0, 1)
			surface.SetAlphaMultiplier(alpha)
		end
	end
	
	surface.SetFont('PANTHEON.Chat')
	
	local x = 2 -- Small left margin
	local y = 2 -- Small top margin for better readability
	for _, bit in ipairs(self.bits) do
		surface.SetTextColor(bit.color)
		surface.SetTextPos(x, y)
		surface.DrawText(bit.text)
		
		local tw, _ = surface.GetTextSize(bit.text)
		x = x + tw
	end
	
	surface.SetAlphaMultiplier(1)
	return true
end

derma.DefineControl('pantheon_chatlabel', 'PANTHEON Chat Label', CHAT_LABEL, 'DLabel')

-- Main chatbox panel
local CHATBOX = {}

function CHATBOX:Init()
	self._open = false
	self._teamChat = false
	self.messages = {}
	
	-- Message container
	self.messageContainer = vgui.Create('DScrollPanel', self)
	self.messageContainer:GetVBar():SetWide(0) -- Hide scrollbar initially
	
	-- Configure the canvas for proper message spacing
	local canvas = self.messageContainer:GetCanvas()
	canvas.PerformLayout = function(pnl, w, h)
		local y = 2 -- Start with small margin
		for _, child in ipairs(pnl:GetChildren()) do
			if IsValid(child) then
				child:SetPos(2, y)
				child:SetWide(w - 4)
				y = y + child:GetTall() + 2 -- Add 2px spacing between messages
			end
		end
		pnl:SetTall(y)
	end
	
	-- Ensure message container is visible even when chatbox is closed
	self.messageContainer:SetVisible(true)
	
	-- Text entry
	self.textEntry = vgui.Create('DTextEntry', self)
	self.textEntry:SetFont('PANTHEON.Chat')
	self.textEntry:SetVisible(false)
	self.textEntry:SetTextColor(Color(255, 255, 255))
	self.textEntry:SetCursorColor(Color(255, 255, 255))
	self.textEntry:SetHighlightColor(Color(100, 150, 255, 100))
	
	-- Autocomplete panel using custom component
	self.autocompletePanel = vgui.Create('pantheon_autocomplete', self)
	self.autocompletePanel:SetVisible(false)
	self.autocompletePanel:SetZPos(1000)
	self.autocompletePanel:SetItemHeight(25)
	self.autocompletePanel:SetVisibleItems(8)
	self.autocompleteSelected = 0
	
	-- Custom paint function for autocomplete items
	self.autocompletePanel.PaintItem = function(pnl, item, index, x, y, w, h, isSelected, isHovered)
		-- Command name
		local prefix = item.prefix or '/'
		draw.SimpleText(prefix .. item.name, 'PANTHEON.Chat', x + 3, y + h/2, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		
		-- Help text if available
		if item.help then
			draw.SimpleText(item.help, 'PANTHEON.ChatSmall', x + w - 3, y + h/2, Color(180, 180, 180), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end
	
	-- Handle item selection
	self.autocompletePanel.OnItemSelected = function(pnl, index, item)
		self:SelectAutocomplete(item)
	end
	
	-- Custom paint function for text entry to ensure visibility
	self.textEntry.Paint = function(pnl, w, h)
		-- Draw background
		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawRect(0, 0, w, h)
		
		-- Draw border
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 255)
		surface.DrawOutlinedRect(0, 0, w, h)
		
		-- Call default text entry paint
		pnl:DrawTextEntryText(Color(255, 255, 255), Color(100, 150, 255), Color(255, 255, 255))
	end
	
	-- Bind events
	self:SetupEvents()
	
	-- Welcome message (will be added later when chatbox is fully created)
	self._shouldShowWelcome = true
end

function CHATBOX:SetupEvents()
	-- Text entry events
	self.textEntry.OnKeyCodeTyped = function(entry, keyCode)
		if keyCode == KEY_ENTER then
			-- If autocomplete is visible and an item is selected, use it
			if self.autocompletePanel:IsVisible() and self.autocompletePanel:GetSelectedIndex() > 0 then
				local item = self.autocompletePanel:GetSelectedItem()
				self:SelectAutocomplete(item)
			else
				self:SendMessage()
			end
		elseif keyCode == KEY_ESCAPE then
			if self.autocompletePanel:IsVisible() then
				self:HideAutocomplete()
			else
				self:Close()
			end
		elseif keyCode == KEY_TAB then
			if self.autocompletePanel:IsVisible() and self.autocompletePanel:GetSelectedIndex() > 0 then
				local item = self.autocompletePanel:GetSelectedItem()
				self:SelectAutocomplete(item)
			else
				self:DoAutoComplete()
			end
		elseif keyCode == KEY_UP then
			if self.autocompletePanel:IsVisible() then
				self.autocompletePanel:Navigate(-1)
			else
				self:HistoryUp()
			end
		elseif keyCode == KEY_DOWN then
			if self.autocompletePanel:IsVisible() then
				self.autocompletePanel:Navigate(1)
			else
				self:HistoryDown()
			end
		end
	end
	
	self.textEntry.OnTextChanged = function(entry)
		local text = entry:GetText()
		if #text > 127 then
			entry:SetText(string.sub(text, 1, 127))
			entry:SetCaretPos(127)
		end
		
		-- Live command validation and autocomplete
		if string.sub(text, 1, 1) == '/' or string.sub(text, 1, 1) == '!' then
			self:ValidateCommand(text)
			self:UpdateAutocomplete(text)
		else
			self:HideAutocomplete()
		end
	end
	
	self.textEntry.OnLoseFocus = function(entry)
		-- Don't auto-refocus, let it lose focus naturally
		-- The chatbox should stay open even without focus
	end
end

function CHATBOX:ValidateCommand(text)
	-- Extract command from text
	local parts = string.Explode(' ', text)
	local cmd = string.sub(parts[1] or '', 2) -- Remove prefix
	
	if cmd and cmd ~= '' then
		local command = pas.cmd.Get(cmd)
		if command then
			-- Command exists - show green
			self.textEntry:SetTextColor(Color(100, 255, 100))
			-- Could show help tooltip here in the future
		else
			-- Command doesn't exist - show red
			self.textEntry:SetTextColor(Color(255, 100, 100))
		end
	else
		-- No command or empty - default color
		self.textEntry:SetTextColor(Color(255, 255, 255))
	end
end

function CHATBOX:UpdateAutocomplete(text)
	if not pas.cmd or not pas.cmd.Stored then
		self:HideAutocomplete()
		return
	end
	
	local parts = string.Explode(' ', text)
	local prefix = string.sub(text, 1, 1)
	local cmd = string.sub(parts[1] or '', 2):lower()
	
	-- Find matching commands
	local matches = {}
	for name, command in pairs(pas.cmd.Stored) do
		if cmd == '' or string.find(name:lower(), cmd, 1, true) == 1 then
			table.insert(matches, {
				name = name,
				help = command.Help,
				command = command,
				prefix = prefix
			})
		end
	end
	
	-- Sort alphabetically
	table.sort(matches, function(a, b) return a.name < b.name end)
	
	if #matches > 0 then
		self:ShowAutocomplete(matches)
	else
		self:HideAutocomplete()
	end
end

function CHATBOX:ShowAutocomplete(matches)
	-- Clear and populate the custom panel
	self.autocompletePanel:Clear()
	
	for i, match in ipairs(matches) do
		self.autocompletePanel:AddItem(match)
	end
	
	-- Set first item as selected
	self.autocompletePanel:SetSelectedIndex(1)
	
	-- Calculate height based on number of items
	local itemCount = math.min(#matches, 8)
	local height = itemCount * 25
	self.autocompletePanel:SetTall(height)
	
	-- Show panel
	self.autocompletePanel:SetVisible(true)
	self:InvalidateLayout()
end

function CHATBOX:HideAutocomplete()
	self.autocompletePanel:SetVisible(false)
	self.autocompletePanel:Clear()
end

function CHATBOX:SelectAutocomplete(item)
	if not item then return end
	
	local text = self.textEntry:GetText()
	local parts = string.Explode(' ', text)
	
	parts[1] = item.prefix .. item.name
	self.textEntry:SetText(table.concat(parts, ' ') .. ' ')
	self.textEntry:SetCaretPos(#self.textEntry:GetText())
	
	self:HideAutocomplete()
end

function CHATBOX:DoAutoComplete()
	-- This is now just a fallback - the main autocomplete happens via UpdateAutocomplete
	local text = self.textEntry:GetText()
	local parts = string.Explode(' ', text)
	
	-- Player name autocomplete (for command arguments)
	if string.sub(text, 1, 1) == '/' or string.sub(text, 1, 1) == '!' then
		-- Already handled by UpdateAutocomplete
		return
	end
	
	-- Player name autocomplete for regular chat
	local lastWord = parts[#parts]
	if lastWord and lastWord ~= '' then
		local matches = {}
		for _, ply in ipairs(player.GetAll()) do
			local name = ply:Nick():lower()
			if string.find(name, lastWord:lower(), 1, true) == 1 then
				table.insert(matches, ply:Nick())
			end
		end
		
		if #matches == 1 then
			parts[#parts] = matches[1]
			self.textEntry:SetText(table.concat(parts, ' ') .. ' ')
			self.textEntry:SetCaretPos(99)
		end
	end
end

function CHATBOX:HistoryUp()
	if #pas.chat.history == 0 then return end
	
	self.historyIndex = (self.historyIndex or 0) + 1
	if self.historyIndex > #pas.chat.history then
		self.historyIndex = #pas.chat.history
	end
	
	local msg = pas.chat.history[self.historyIndex]
	if msg then
		self.textEntry:SetText(msg)
		self.textEntry:SelectAll()
	end
end

function CHATBOX:HistoryDown()
	if #pas.chat.history == 0 then return end
	
	self.historyIndex = (self.historyIndex or 1) - 1
	if self.historyIndex < 1 then
		self.historyIndex = 0
		self.textEntry:SetText('')
		return
	end
	
	local msg = pas.chat.history[self.historyIndex]
	if msg then
		self.textEntry:SetText(msg)
		self.textEntry:SelectAll()
	end
end

function CHATBOX:SendMessage()
	local text = string.Trim(self.textEntry:GetText())
	if text == '' then
		-- Close chatbox when pressing enter with empty text
		self:Close()
		return
	end
	
	-- Add to history
	if text ~= pas.chat.history[1] then -- Don't duplicate last message
		table.insert(pas.chat.history, 1, text)
		if #pas.chat.history > 50 then -- Limit history
			table.remove(pas.chat.history, 51)
		end
	end
	
	-- Check if it's a command
	local prefix = string.sub(text, 1, 1)
	if prefix == '/' or prefix == '!' then
		-- It's a command - extract and send
		local cmd = string.sub(text, 2)
		local parts = string.Explode(' ', cmd)
		local commandName = parts[1]
		table.remove(parts, 1)
		
		-- Send command to server
		net.Start('pas.RunCommand')
		net.WriteString(commandName)
		net.WriteTable(parts)
		net.SendToServer()
	else
		-- Regular chat message
		local chatType = self._teamChat and 'say_team' or 'say'
		RunConsoleCommand(chatType, text)
	end
	
	self:Close()
end

function CHATBOX:AddMessage(...)
	-- Don't add messages if chatbox isn't properly initialized
	if not IsValid(self.messageContainer) then
		return
	end
	
	local label = vgui.Create('pantheon_chatlabel')
	label:SetMessage(...)
	
	self.messages = self.messages or {}
	table.insert(self.messages, label)
	
	-- Limit message count
	if #self.messages > 100 then
		local oldMsg = self.messages[1]
		if IsValid(oldMsg) then
			oldMsg:Remove()
		end
		table.remove(self.messages, 1)
	end
	
	-- Add to scroll panel
	self.messageContainer:AddItem(label)
	
	-- Force layout update and auto-scroll to bottom
	timer.Simple(0.01, function()
		if IsValid(self.messageContainer) then
			self.messageContainer:GetCanvas():InvalidateLayout(true)
			
			local vbar = self.messageContainer:GetVBar()
			if IsValid(vbar) then
				-- Always scroll to bottom for new messages
				vbar:SetScroll(vbar.CanvasSize)
			end
		end
	end)
	
	-- Play chat sound
	chat.PlaySound()
end

-- Enhanced function to add chat message with rank tags (legacy function, now using network-based approach)
function CHATBOX:AddChatMessage(ply, text, teamChat, isDead, isTeam)
	if not IsValid(ply) then return end
	
	local messageParts = {}
	
	-- Get player's rank tag
	local rankTag = pas.chat.tags.GetPlayerTag(ply)
	
	-- Add rank tag if enabled
	if rankTag and rankTag.enabled and rankTag.tag ~= '' then
		table.insert(messageParts, rankTag.color)
		table.insert(messageParts, rankTag.tag .. ' ')
	end
	
	-- Add dead prefix
	if isDead then
		table.insert(messageParts, Color(255, 100, 100))
		table.insert(messageParts, '*DEAD* ')
	end
	
	-- Add team prefix
	if teamChat or isTeam then
		table.insert(messageParts, Color(100, 255, 100))
		table.insert(messageParts, '(TEAM) ')
	end
	
	-- Add player name with appropriate color
	local playerColor = Color(255, 255, 255)
	if rankTag and rankTag.textColor then
		playerColor = rankTag.textColor
	else
		-- Use job color as fallback
		playerColor = ply.GetJobColor and ply:GetJobColor() or Color(255, 255, 255)
	end
	
	table.insert(messageParts, playerColor)
	table.insert(messageParts, ply:Nick())
	
	-- Add separator and message
	table.insert(messageParts, Color(255, 255, 255))
	table.insert(messageParts, ': ' .. text)
	
	-- Add the message to chatbox
	self:AddMessage(unpack(messageParts))
end

function CHATBOX:Open(teamChat)
	-- Don't open if not properly initialized
	if not IsValid(self.textEntry) or not IsValid(self.messageContainer) then
		return
	end
	
	self._open = true
	self._teamChat = teamChat or false
	self.historyIndex = 0
	
	self:SetVisible(true)
	self:SetMouseInputEnabled(true)
	self:SetKeyboardInputEnabled(true)
	self:MakePopup()
	
	self.textEntry:SetVisible(true)
	self.textEntry:SetText('')
	self.textEntry:SetTextColor(Color(255, 255, 255))
	self.textEntry:SetPlaceholderText(self._teamChat and "Say (Team)..." or "Say...")
	
	-- Show scrollbar when open
	self.messageContainer:GetVBar():SetWide(8)
	
	-- Delay focus request to prevent conflicts
	timer.Simple(0.01, function()
		if IsValid(self.textEntry) and self._open then
			self.textEntry:RequestFocus()
		end
	end)
end

function CHATBOX:Close()
	if not self._open then return end
	
	self._open = false
	
	-- Hide autocomplete
	self:HideAutocomplete()
	
	-- Don't hide the chatbox completely - messages should still be visible
	self:SetMouseInputEnabled(false)
	self:SetKeyboardInputEnabled(false)
	
	if IsValid(self.textEntry) then
		self.textEntry:SetVisible(false)
		self.textEntry:SetText('')
	end
	
	-- Hide scrollbar when closed
	if IsValid(self.messageContainer) then
		self.messageContainer:GetVBar():SetWide(0)
	end
	
	-- Move to back but keep visible for message display
	self:MoveToBack()
end

function CHATBOX:PerformLayout()
	local w, h = ScrW() * 0.4, ScrH() * 0.25
	self:SetSize(w, h)
	-- Position at left center, slightly lower
	self:SetPos(20, ScrH() / 2 - h / 2 + 50)
	
	-- Text entry at bottom
	local entryHeight = 25
	if IsValid(self.textEntry) then
		self.textEntry:SetPos(5, h - entryHeight - 5)
		self.textEntry:SetSize(w - 10, entryHeight)
	end
	
	-- Message container fills the rest
	if IsValid(self.messageContainer) then
		self.messageContainer:SetPos(5, 5)
		self.messageContainer:SetSize(w - 10, h - entryHeight - 15)
	end
	
	-- Position autocomplete panel above text entry
	if IsValid(self.autocompletePanel) then
		local acWidth = w - 10
		self.autocompletePanel:SetPos(5, h - entryHeight - 5 - self.autocompletePanel:GetTall() - 2)
		self.autocompletePanel:SetWide(acWidth)
	end
	
	-- Always ensure chatbox is visible for messages
	self:SetVisible(true)
end

function CHATBOX:Paint(w, h)
	-- Only draw background when chat is open
	if self._open then
		-- Background blur and color
		draw.Blur(self, 6)
		
		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawRect(0, 0, w, h)
		
		-- Border
		surface.SetDrawColor(ui.col.Outline)
		surface.DrawOutlinedRect(0, 0, w, h)
		
		-- Text entry background
		if IsValid(self.textEntry) then
			local ex, ey, ew, eh = self.textEntry:GetBounds()
			surface.SetDrawColor(0, 0, 0, 200)
			surface.DrawRect(ex - 2, ey - 2, ew + 4, eh + 4)
			
			-- Team chat indicator
			if self._teamChat then
				surface.SetDrawColor(100, 200, 100, 100)
			else
				surface.SetDrawColor(255, 255, 255, 50)
			end
			surface.DrawRect(ex, ey, ew, eh)
		end
	end
end

function CHATBOX:Think()
	-- Ensure chatbox stays in correct position when open
	if self._open then
		self:MoveToFront()
	else
		self:MoveToBack()
	end
end

derma.DefineControl('pantheon_chatbox', 'PANTHEON Chatbox', CHATBOX, 'EditablePanel')

-- Create the chatbox
function pas.chat.CreateChatbox()
	-- Don't recreate if it already exists and is valid
	if IsValid(PANTHEON_CHATBOX) then
		return PANTHEON_CHATBOX
	end
	
	PANTHEON_CHATBOX = vgui.Create('pantheon_chatbox')
	
	-- Add welcome message after chatbox is created
	if IsValid(PANTHEON_CHATBOX) and PANTHEON_CHATBOX._shouldShowWelcome then
		timer.Simple(0.1, function()
			if IsValid(PANTHEON_CHATBOX) then
				PANTHEON_CHATBOX:AddMessage(Color(100, 150, 255), '[PANTHEON] ', Color(255, 255, 255), 'Welcome to the server!')
				PANTHEON_CHATBOX._shouldShowWelcome = false
			end
		end)
	end
	
	return PANTHEON_CHATBOX
end

-- Override default chat functions
local oldAddText = chat.AddText
function chat.AddText(...)
	PANTHEON_CHATBOX = PANTHEON_CHATBOX or pas.chat.CreateChatbox()
	
	-- Ensure chatbox is valid before adding message
	if IsValid(PANTHEON_CHATBOX) then
		PANTHEON_CHATBOX:AddMessage(...)
	end
	
	-- Also call original for compatibility
	return oldAddText(...)
end

local oldGetChatBoxSize = chat.GetChatBoxSize
function chat.GetChatBoxSize()
	if IsValid(PANTHEON_CHATBOX) then
		return PANTHEON_CHATBOX:GetSize()
	end
	return oldGetChatBoxSize()
end

local oldGetChatBoxPos = chat.GetChatBoxPos  
function chat.GetChatBoxPos()
	if IsValid(PANTHEON_CHATBOX) then
		return PANTHEON_CHATBOX:GetPos()
	end
	return oldGetChatBoxPos()
end

-- Bind keys to open chat
hook.Add('PlayerBindPress', 'PANTHEON.OpenChat', function(ply, bind, pressed)
	if not pressed then return end
	
	PANTHEON_CHATBOX = PANTHEON_CHATBOX or pas.chat.CreateChatbox()
	
	if string.find(bind, 'messagemode2') then
		PANTHEON_CHATBOX:Open(true) -- Team chat
		return true
	elseif string.find(bind, 'messagemode') then
		PANTHEON_CHATBOX:Open(false) -- Global chat
		return true
	end
end)

-- Suppress join/leave messages and default chat (we handle chat via network now)
hook.Add('ChatText', 'PANTHEON.SuppressChatText', function(playerIndex, playerName, text, messageType)
	if messageType == 'joinleave' then
		return true
	end
	
	-- Suppress default chat since we handle it through our network system
	if messageType == 'chat' or messageType == 'teamchat' then
		return true
	end
end)

-- Network message handlers
net.Receive('pas.AdminChat', function()
	local isAdmin = net.ReadBool()
	local playerName = net.ReadString()
	local message = net.ReadString()
	
	PANTHEON_CHATBOX = PANTHEON_CHATBOX or pas.chat.CreateChatbox()
	
	local prefix = isAdmin and '[STAFF] ' or '[TO STAFF] '
	local color = isAdmin and Color(20, 209, 0) or Color(50, 200, 50)
	
	-- Properly separate color, prefix, name, and message to prevent encoding issues
	PANTHEON_CHATBOX:AddMessage(
		color, prefix,
		Color(255, 255, 255), playerName,
		Color(255, 255, 255), ': ',
		Color(255, 255, 255), message
	)
end)

net.Receive('pas.Announcement', function()
	local message = net.ReadString()
	local duration = net.ReadFloat()
	
	pas.chat.ShowAnnouncement(message, duration)
end)

net.Receive('pas.ChatTagsSync', function()
	local config = net.ReadTable()
	
	-- Update local configuration
	pas.chat.tags.config = config
	
	print('[PANTHEON] Chat tags configuration synchronized from server')
end)

-- Network receiver for chat messages with tag data
net.Receive('pas.ChatWithTags', function()
	local sender = net.ReadEntity()
	local text = net.ReadString()
	local isTeam = net.ReadBool()
	local isDead = net.ReadBool()
	
	PANTHEON_CHATBOX = PANTHEON_CHATBOX or pas.chat.CreateChatbox()
	
	local messageParts = {}
	
	-- Read tag information
	local hasTag = net.ReadBool()
	if hasTag then
		local tagText = net.ReadString()
		local tagColor = net.ReadColor()
		local hasTextColor = net.ReadBool()
		local textColor = hasTextColor and net.ReadColor() or nil
		
		-- Add tag
		table.insert(messageParts, tagColor)
		table.insert(messageParts, tagText .. ' ')
		
		-- Add dead prefix
		if isDead then
			table.insert(messageParts, Color(255, 100, 100))
			table.insert(messageParts, '*DEAD* ')
		end
		
		-- Add team prefix  
		if isTeam then
			table.insert(messageParts, Color(100, 255, 100))
			table.insert(messageParts, '(TEAM) ')
		end
		
		-- Add player name with custom color or job color
		local playerColor = textColor or (sender.GetJobColor and sender:GetJobColor() or Color(255, 255, 255))
		table.insert(messageParts, playerColor)
		
		-- Use SWRP character name if available, otherwise fall back to Nick
		local displayName = sender:GetNWString("SWRP_CharacterName", "")
		if displayName == "" then
			displayName = sender:Nick()
		end
		
		-- Debug: Print what we're about to display
		print("[PANTHEON CHATBOX] Sender: " .. sender:Name() .. 
		      ", TagText: '" .. tagText .. 
		      "', DisplayName: '" .. displayName .. 
		      "', Nick: '" .. sender:Nick() .. "'")
		
		table.insert(messageParts, displayName)
		
		-- Add message
		table.insert(messageParts, Color(255, 255, 255))
		table.insert(messageParts, ': ' .. text)
		
	else
		-- No tag, use simpler format
		if isDead then
			table.insert(messageParts, Color(255, 100, 100))
			table.insert(messageParts, '*DEAD* ')
		end
		
		if isTeam then
			table.insert(messageParts, Color(100, 255, 100))
			table.insert(messageParts, '(TEAM) ')
		end
		
		table.insert(messageParts, sender.GetJobColor and sender:GetJobColor() or Color(255, 255, 255))
		
		-- Use SWRP character name if available, otherwise fall back to Nick
		local displayName = sender:GetNWString("SWRP_CharacterName", "")
		if displayName == "" then
			displayName = sender:Nick()
		end
		table.insert(messageParts, displayName)
		table.insert(messageParts, Color(255, 255, 255))
		table.insert(messageParts, ': ' .. text)
	end
	
	-- Add the message to chatbox
	PANTHEON_CHATBOX:AddMessage(unpack(messageParts))
end)

-- Announcement system
pas.chat.announcements = {}

function pas.chat.ShowAnnouncement(text, duration)
	duration = duration or 5
	
	local panel = vgui.Create('DPanel')
	panel:ParentToHUD()
	panel:SetSize(450, 100)
	panel:SetPos(-ScrW(), ScrH() / 5)
	panel:SetAlpha(0)
	
	-- Animation properties
	panel.AppearAnimation = 0
	panel.PulseAnimation = 0
	panel.HoverFraction = 0
	
	-- Animate in with easing
	local targetX = ScrW() / 2 - panel:GetWide() / 2 - #pas.chat.announcements * 460
	panel:MoveTo(targetX, ScrH() / 5, 0.4, 0, 0.5)
	panel:AlphaTo(255, 0.3)
	ui.Animate(panel, "AppearAnimation", 1, 0.4, ui.easings.easeOutCubic)
	
	function panel:Paint(w, h)
		-- Smooth hover animation
		self.HoverFraction = Lerp(FrameTime() * 10, self.HoverFraction, self:IsHovered() and 1 or 0)
		
		-- Enhanced shadow for depth
		local shadowSize = 12 + self.HoverFraction * 4
		draw.Shadow(0, 0, w, h, shadowSize, 80 + self.HoverFraction * 40)
		
		-- Blurred dark background with glassmorphism
		draw.BlurredPanel(self, 8, Color(18, 18, 22), 250)
		
		-- Pulse animation
		self.PulseAnimation = (self.PulseAnimation or 0) + FrameTime() * 1.5
		local pulse = math.sin(self.PulseAnimation) * 0.1 + 0.9
		
		-- Left accent bar with glow
		local accentWidth = 4
		surface.SetDrawColor(ui.col.PANTHEON_LIGHT.r, ui.col.PANTHEON_LIGHT.g, ui.col.PANTHEON_LIGHT.b, 255)
		surface.DrawRect(0, 0, accentWidth, h)
		
		-- Accent glow effect
		for i = 1, 3 do
			local glowAlpha = (60 * pulse) * (1 - (i / 3))
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, glowAlpha)
			surface.DrawRect(accentWidth, 0, i, h)
		end
		
		-- Enhanced border with purple tint
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 180 + 75 * self.HoverFraction)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		
		-- Outer glow on hover
		if self.HoverFraction > 0 then
			draw.Glow(0, 0, w, h, 4, ColorAlpha(ui.col.PANTHEON, 50 * self.HoverFraction), self.HoverFraction)
		end
		
		-- Top gradient overlay for depth
		local gradientAlpha = 30 * (self.AppearAnimation or 1)
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, gradientAlpha)
		surface.DrawRect(accentWidth, 0, w - accentWidth, h / 3)
		
		-- Announcement icon (megaphone)
		if ui.DrawIcon then
			ui.DrawIcon('icon16/sound.png', 22, h/2, 20, ColorAlpha(ui.col.PANTHEON_LIGHT, 255 * (self.AppearAnimation or 1)))
		else
			-- Fallback icon - use simple circle
			surface.SetDrawColor(ColorAlpha(ui.col.PANTHEON_LIGHT, 255 * (self.AppearAnimation or 1)))
			draw.NoTexture()
			surface.DrawCircle(20, h/2, 8, 255, 255, 255)
		end
	end
	
	function panel:OnRemove()
		table.RemoveByValue(pas.chat.announcements, self)
		
		-- Move other announcements smoothly
		for i, ann in ipairs(pas.chat.announcements) do
			if IsValid(ann) then
				local newX = ScrW() / 2 - ann:GetWide() / 2 - (i - 1) * 460
				ann:MoveTo(newX, ScrH() / 5, 0.3, 0, 0.5)
			end
		end
	end
	
	-- Text content with enhanced styling
	local textLabel = panel:Add('DLabel')
	textLabel:SetPos(50, 0)
	textLabel:SetSize(panel:GetWide() - 20, panel:GetTall())
	textLabel:SetFont('PANTHEON.18')
	textLabel:SetTextColor(ui.col.White)
	textLabel:SetText(text)
	textLabel:SetContentAlignment(4) -- Left-center alignment
	textLabel:SetWrap(true)
	textLabel:SetAutoStretchVertical(false)
	
	table.insert(pas.chat.announcements, panel)
	
	-- Auto-remove after duration with enhanced animation
	timer.Simple(duration, function()
		if IsValid(panel) then
			panel:AlphaTo(0, 0.3)
			panel:MoveTo(ScrW() + 500, ScrH() / 5, 0.4, 0, 0.5, function()
				if IsValid(panel) then
					panel:Remove()
				end
			end)
		end
	end)
end

-- Initialize chatbox
hook.Add('InitPostEntity', 'PANTHEON.InitChatbox', function()
	if IsValid(PANTHEON_CHATBOX) then
		return
	end
	
	timer.Simple(1, function()
		pas.chat.CreateChatbox()
	end)
end)

print('[PANTHEON] Chatbox system (client) loaded')