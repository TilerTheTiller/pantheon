-- PANTHEON Rank Chat Tags Configuration

pas.chat = pas.chat or {}
pas.chat.tags = pas.chat.tags or {}

-- Chat tag configuration for each rank
-- Format: [rank_name] = {
--     tag = 'Text to display',
--     color = Color(r, g, b, a), -- Tag color
--     textColor = Color(r, g, b, a), -- Player name color (optional)
--     priority = number, -- Higher priority tags override lower ones
--     enabled = boolean -- Whether to show this tag
-- }

-- Function to automatically generate tags from SWRP rank system
local function GenerateSWRPRankTags()
    local generatedTags = {}
    
    -- Add standard admin/system ranks first
    generatedTags['root'] = {
        tag = 'ROOT |',
        color = Color(255, 0, 0, 255),
        textColor = Color(255, 200, 200, 255),
        priority = 100,
        enabled = true
    }
    
    generatedTags['superadmin'] = {
        tag = 'SA |',
        color = Color(255, 100, 0, 255),
        textColor = Color(255, 180, 100, 255),
        priority = 90,
        enabled = true
    }
    
    -- Generate tags for all SWRP battalion ranks
    if SWRP and SWRP.Ranks and SWRP.Ranks.Battalions then
        for battalionId, battalionData in pairs(SWRP.Ranks.Battalions) do
            if battalionData.ranks then
                for rankId, rankData in pairs(battalionData.ranks) do
                    -- Create tag for each rank
                    local tagKey = (battalionId .. "_" .. rankData.short_name):lower()
                    generatedTags[tagKey] = {
                        tag = battalionId .. " " .. rankData.short_name .. " |",
                        color = battalionData.color or Color(0, 150, 255, 255),
                        textColor = rankData.color or Color(255, 255, 255, 255),
                        priority = 100 - rankId, -- Higher rank = higher priority
                        enabled = true,
                        battalion = battalionId,
                        rank_id = rankId
                    }
                    
                    -- Also create a generic rank tag (for fallback)
                    local genericKey = rankData.short_name:lower()
                    if not generatedTags[genericKey] then
                        generatedTags[genericKey] = {
                            tag = rankData.short_name .. " |",
                            color = rankData.color or Color(169, 169, 169, 255),
                            textColor = Color(255, 255, 255, 255),
                            priority = 100 - rankId,
                            enabled = true
                        }
                    end
                end
            end
        end
        print("[SWRP Chat Tags] Generated " .. table.Count(generatedTags) .. " dynamic rank tags")
    else
        print("[SWRP Chat Tags] SWRP rank system not loaded, using static configuration")
    end
    
    -- Add fallback civilian tags
    generatedTags['recruit'] = {
        tag = 'RECRUIT |',
        color = Color(150, 150, 150, 255),
        textColor = Color(200, 200, 200, 255),
        priority = 15,
        enabled = true
    }
    
    generatedTags['clone_recruit'] = {
        tag = 'RECRUIT |',
        color = Color(150, 150, 150, 255),
        textColor = Color(200, 200, 200, 255),
        priority = 15,
        enabled = true
    }
    
    generatedTags['user'] = {
        tag = '',
        color = Color(255, 255, 255, 255),
        textColor = nil,
        priority = 1,
        enabled = false
    }
    
    return generatedTags
end

-- Generate dynamic tags or use static fallback
pas.chat.tags.config = GenerateSWRPRankTags() or {
    ['root'] = {
        tag = 'ROOT |',
        color = Color(255, 0, 0, 255),
        textColor = Color(255, 200, 200, 255),
        priority = 100,
        enabled = true
    },
    
    ['superadmin'] = {
        tag = 'SA |',
        color = Color(255, 100, 0, 255),
        textColor = Color(255, 180, 100, 255),
        priority = 90,
        enabled = true
    },
    
    ['sudoroot'] = {
        tag = 'SUDO ROOT |',
        color = Color(150, 0, 255, 255),
        textColor = Color(200, 150, 255, 255),
        priority = 85,
        enabled = true
    },
    
    ['council'] = {
        tag = 'COUNCIL |',
        color = Color(255, 215, 0, 255),
        textColor = Color(255, 235, 150, 255),
        priority = 80,
        enabled = true
    },
    
    ['hgamemaster'] = {
        tag = 'HGM |',
        color = Color(0, 255, 127, 255),
        textColor = Color(150, 255, 200, 255),
        priority = 75,
        enabled = true
    },
    
    ['sradmin'] = {
        tag = 'SR ADMIN |',
        color = Color(255, 69, 0, 255),
        textColor = Color(255, 150, 100, 255),
        priority = 70,
        enabled = true
    },
    
    ['jradmin'] = {
        tag = 'JR ADMIN |',
        color = Color(255, 140, 0, 255),
        textColor = Color(255, 200, 150, 255),
        priority = 65,
        enabled = true
    },
    
    ['srmoderator'] = {
        tag = 'SR MOD |',
        color = Color(50, 150, 255, 255),
        textColor = Color(150, 200, 255, 255),
        priority = 60,
        enabled = true
    },
    
    ['jrmoderator'] = {
        tag = 'JR MOD |',
        color = Color(100, 200, 255, 255),
        textColor = Color(180, 220, 255, 255),
        priority = 55,
        enabled = true
    },
    
    ['gamemaster'] = {
        tag = 'GM |',
        color = Color(0, 255, 0, 255),
        textColor = Color(150, 255, 150, 255),
        priority = 50,
        enabled = true
    },
    
    ['tgamemaster'] = {
        tag = 'TGM |',
        color = Color(100, 255, 100, 255),
        textColor = Color(180, 255, 180, 255),
        priority = 45,
        enabled = true
    },
    
    ['vip'] = {
        tag = 'VIP |',
        color = Color(255, 215, 0, 255),
        textColor = Color(255, 240, 150, 255),
        priority = 10,
        enabled = true
    },
    
    -- Static fallback configuration (used if SWRP rank system not loaded)
    ['user'] = {
        tag = '',
        color = Color(255, 255, 255, 255),
        textColor = nil,
        priority = 1,
        enabled = false
    },
    
    ['recruit'] = {
        tag = 'RECRUIT |',
        color = Color(150, 150, 150, 255),
        textColor = Color(200, 200, 200, 255),
        priority = 15,
        enabled = true
    },
    
    ['private'] = {
        tag = 'PVT |',
        color = Color(180, 180, 180, 255),
        textColor = Color(220, 220, 220, 255),
        priority = 20,
        enabled = true
    }
}

-- Function to refresh tags from SWRP system
function pas.chat.tags.RefreshSWRPTags()
    local newTags = GenerateSWRPRankTags()
    if newTags then
        pas.chat.tags.config = newTags
        print("[SWRP Chat Tags] Refreshed chat tags from SWRP rank system")
        return true
    end
    return false
end

-- Helper functions for managing chat tags
function pas.chat.tags.GetTag(rank)
    if not rank then return nil end
    
    local rankName = isstring(rank) and rank:lower() or ''
    if istable(rank) and rank.GetName then
        rankName = rank:GetName():lower()
    end
    
    return pas.chat.tags.config[rankName]
end

function pas.chat.tags.GetPlayerTag(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return nil end
    
    -- Get SWRP-specific data
    local characterName = ply:GetNWString("SWRP_CharacterName", "")
    local battalion = ply:GetNWString("SWRP_Battalion", "")
    local civJob = ply:GetNWString("SWRP_CivJob", "")
    
    print("[SWRP Chat Tags] Player: " .. ply:Name() .. 
          ", Battalion: '" .. battalion .. 
          "', CivJob: '" .. civJob .. 
          "', CharName: '" .. characterName .. "'")
    
    -- Create dynamic tag based on job type
    local tagData = {
        tag = "",
        color = Color(255, 255, 255, 255),
        textColor = nil,
        priority = 15,
        enabled = true
    }
    
    if civJob == "clone_recruit" then
        -- Clone Recruit: Just show basic recruit tag
        tagData.tag = "RECRUIT |"
        tagData.color = Color(150, 150, 150, 255)
        tagData.textColor = Color(200, 200, 200, 255)
        tagData.priority = 15
        print("[SWRP Chat Tags] Using recruit tag")
    elseif battalion ~= "" then
        -- Military Job: Get actual rank from SWRP rank system
        local rankAbbr = "PVT" -- Default fallback
        local rankColor = Color(169, 169, 169) -- Default gray
        
        -- Get player's actual rank in their battalion
        if SWRP and SWRP.RankManager and SWRP.RankManager.GetPlayerRank then
            local playerRank = SWRP.RankManager.GetPlayerRank(ply, battalion)
            if playerRank then
                rankAbbr = playerRank.short_name
                rankColor = playerRank.color
                print("[SWRP Chat Tags] Found player rank: " .. playerRank.name .. " (" .. playerRank.short_name .. ")")
            else
                print("[SWRP Chat Tags] No rank found for player in " .. battalion .. ", using default")
            end
        else
            -- Fallback: try to get rank from networked variable
            local rankId = ply:GetNWInt("SWRP_Rank_" .. battalion, 0)
            if rankId > 0 and SWRP and SWRP.Ranks and SWRP.Ranks.GetRankData then
                local rankData = SWRP.Ranks.GetRankData(battalion, rankId)
                if rankData then
                    rankAbbr = rankData.short_name
                    rankColor = rankData.color
                    print("[SWRP Chat Tags] Found rank from NW var: " .. rankData.name .. " (" .. rankData.short_name .. ")")
                end
            end
        end
        
        tagData.tag = battalion .. " " .. rankAbbr .. " |"
        
        -- Get battalion-specific colors from ranks config
        if SWRP and SWRP.Ranks and SWRP.Ranks.Battalions and SWRP.Ranks.Battalions[battalion] then
            local battalionData = SWRP.Ranks.Battalions[battalion]
            tagData.color = battalionData.color or Color(0, 150, 255, 255)
            tagData.textColor = rankColor -- Use rank color for text
        else
            -- Fallback battalion colors
            if battalion == "501st" then
                tagData.color = Color(0, 120, 220, 255)
                tagData.textColor = Color(120, 180, 255, 255)
            elseif battalion == "212th" then
                tagData.color = Color(255, 165, 0, 255)
                tagData.textColor = Color(255, 200, 120, 255)
            elseif battalion == "104th" then
                tagData.color = Color(128, 128, 128, 255)
                tagData.textColor = Color(180, 180, 180, 255)
            else
                tagData.color = Color(0, 150, 255, 255)
                tagData.textColor = Color(150, 200, 255, 255)
            end
        end
        
        tagData.priority = 30
        print("[SWRP Chat Tags] Using military tag: '" .. tagData.tag .. "'")
    else
        -- Fallback: Use standard rank-based tag
        tagData.tag = "USER |"
        tagData.color = Color(255, 255, 255, 255)
        tagData.enabled = false
        print("[SWRP Chat Tags] Using fallback tag")
    end
    
    return tagData
end

function pas.chat.tags.SetTagEnabled(rank, enabled)
    local tag = pas.chat.tags.GetTag(rank)
    if tag then
        tag.enabled = enabled
    end
end

function pas.chat.tags.SetTagText(rank, text)
    local tag = pas.chat.tags.GetTag(rank)
    if tag then
        tag.tag = text
    end
end

function pas.chat.tags.SetTagColor(rank, color)
    local tag = pas.chat.tags.GetTag(rank)
    if tag then
        tag.color = color
    end
end

function pas.chat.tags.SetTagTextColor(rank, color)
    local tag = pas.chat.tags.GetTag(rank)
    if tag then
        tag.textColor = color
    end
end

-- Admin commands to manage chat tags
if SERVER then
    pas.cmd.Create('chattags', function(ply, args)
        if args.action == 'reload' then
            -- Reload configuration
            include('pas/core/ui/chattags_config.lua')
            pas.chat.Send(ply, 'SUCCESS', 'Chat tags configuration reloaded!')
            
        elseif args.action == 'toggle' then
            local rank = args.rank:lower()
            local tag = pas.chat.tags.GetTag(rank)
            
            if not tag then
                pas.chat.Send(ply, 'ERROR', 'Rank "' .. rank .. '" not found!')
                return
            end
            
            tag.enabled = not tag.enabled
            pas.chat.Send(ply, 'SUCCESS', 'Chat tag for "' .. rank .. '" ' .. (tag.enabled and 'enabled' or 'disabled') .. '!')
            
        elseif args.action == 'settext' then
            local rank = args.rank:lower()
            local text = args.text or ''
            
            pas.chat.tags.SetTagText(rank, text)
            pas.chat.Send(ply, 'SUCCESS', 'Chat tag text for "' .. rank .. '" set to "' .. text .. '"!')
            
        elseif args.action == 'list' then
            pas.chat.Send(ply, 'INFO', '=== CHAT TAGS CONFIGURATION ===')
            
            for rankName, config in pairs(pas.chat.tags.config) do
                local status = config.enabled and 'ENABLED' or 'DISABLED'
                local tag = config.tag ~= '' and config.tag or '[NO TAG]'
                
                pas.chat.Send(ply, 'INFO', rankName:upper() .. ': ' .. tag .. ' (' .. status .. ')')
            end
        else
            pas.chat.Send(ply, 'INFO', 'Usage: /chattags <action> [args]')
            pas.chat.Send(ply, 'INFO', 'Actions: reload, toggle <rank>, settext <rank> <text>, list')
        end
    end)
    :AddParam('string', 'action')
    :AddParam('string', 'rank', true)
    :AddParam('string', 'text', true)
    :SetFlag('s') -- Super admin only
    :SetHelp('Manage chat tags configuration')
end

-- Hook to refresh tags when SWRP system loads
hook.Add("Initialize", "SWRP_RefreshChatTags", function()
    timer.Simple(3, function() -- Delay to ensure SWRP system is fully loaded
        if pas and pas.chat and pas.chat.tags and pas.chat.tags.RefreshSWRPTags then
            pas.chat.tags.RefreshSWRPTags()
        end
    end)
end)

-- Also refresh when the gamemode loads
if GAMEMODE then
    hook.Add("PostGamemodeLoaded", "SWRP_RefreshChatTags_PostLoad", function()
        timer.Simple(1, function()
            if pas and pas.chat and pas.chat.tags and pas.chat.tags.RefreshSWRPTags then
                pas.chat.tags.RefreshSWRPTags()
            end
        end)
    end)
end