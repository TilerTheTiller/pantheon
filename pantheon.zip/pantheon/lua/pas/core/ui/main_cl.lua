pas.ui = pas.ui or {}

-- UI components are now loaded via autorun/ui_init.lua
-- This ensures all UI components use the modern glassmorphism theme

-- Load admin menu system AFTER UI framework is ready
hook.Add('PANTHEON_UI_Loaded', 'LoadAdminMenu', function()
	-- Use include() directly to avoid path normalization issues in hooks
	if CLIENT then
		include('pas/core/ui/menu_cl.lua')
	end
	hook.Remove('PANTHEON_UI_Loaded', 'LoadAdminMenu')
end)

-- Fallback: If UI already loaded (hot reload case)
if PANTHEON_UI_LOADED and CLIENT then
	include('pas/core/ui/menu_cl.lua')
end

-- Example: Create main admin panel
function pas.ui.OpenAdminPanel()
	if IsValid(pas.ui.MainFrame) then
		pas.ui.MainFrame:Close()
	end
	
	-- Use new blurred frame
	local frame = ui.components.CreateFrame('PANTHEON Admin Panel', 1000, 700, 'shield')
	pas.ui.MainFrame = frame
	
	-- Create content panels using new component system
	local sidebar = ui.components.CreatePanel(frame, 10, 50, 200, 640, 'Navigation', 'menu-bar')
	local content = ui.components.CreateScrollPanel(frame, 220, 50, 770, 640)
	
	-- Example buttons
	local y = 60
	for i, btnData in ipairs({
		{text = 'Dashboard', icon = 'home'},
		{text = 'Players', icon = 'users'},
		{text = 'Logs', icon = 'list'},
		{text = 'Settings', icon = 'settings'},
	}) do
		local btn = ui.components.CreateButton(sidebar, btnData.text, 10, y, 180, 35, function()
			ui.notifications.Info('Clicked ' .. btnData.text)
		end, btnData.icon, 'glass')
		y = y + 40
	end
	
	return frame
end
