-- Shared UI configuration
if (SERVER) then
	AddCSLuaFile()
	-- Send admin menu to clients (loaded after UI framework)
	AddCSLuaFile('pas/core/ui/menu_cl.lua')
end

pas.ui = pas.ui or {}
pas.ui.config = {
	PrimaryColor = Color(138, 43, 226),
	SecondaryColor = Color(75, 0, 130),
	BackgroundColor = Color(30, 30, 30, 240)
}
