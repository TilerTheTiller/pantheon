-- Admin chat for PANTHEON
if (SERVER) then
	AddCSLuaFile()
	util.AddNetworkString('pas.AdminChat')
end

if (SERVER) then
	hook.Add('PlayerSay', 'PANTHEON_AdminChat', function(pl, text)
		-- Only handle @ messages and /a admin chat (not other / commands)
		if text:sub(1, 1) == '@' then
			
			local msg = text:sub(2)
			
			-- Trim whitespace from message
			msg = string.Trim(msg)
			
			print("[PANTHEON DEBUG] Message after trim: '" .. msg .. "'")
			print("[PANTHEON DEBUG] Player has 'm' flag: " .. tostring(pl:HasFlag('m')))
			
			-- Check if player is staff
			if not pl:HasFlag('m') then
				-- Create a report instead
				if msg == "" then
					pas.notify(pl, 'Usage: @ <message>', 1)
					return ''
				end
				
				if pas.reports and pas.reports.Create then
					pas.reports.Create(pl, msg)
				else
					pas.notify(pl, 'You must be a staff member to use admin chat. Use !report <message> to contact staff.', 1)
				end
				return ''
			end
			
			-- Staff admin chat
			if msg == "" then
				pas.notify(pl, 'Usage: @ <message>', 1)
				return ''
			end
			
			net.Start('pas.AdminChat')
				net.WriteString(pl:Nick())
				net.WriteString(msg)
				local jobColor = (pl.GetJobColor and pl:GetJobColor()) or Color(150, 150, 150)
				net.WriteColor(jobColor)
			net.Send(pas.GetAdmins())
			
			pas.log.Add('Chat', '[ADMIN CHAT] ' .. pl:Nick() .. ': ' .. msg)
			
			return ''
		end
		
		-- Also handle /a specifically (with space after to avoid conflicts)
		if text:sub(1, 3) == '/a ' or text == '/a' then
			
			local msg = text:sub(4)
			msg = string.Trim(msg)
			
			if not pl:HasFlag('m') then
				if msg == "" then
					pas.notify(pl, 'Usage: /a <message>', 1)
					return ''
				end
				
				if pas.reports and pas.reports.Create then
					pas.reports.Create(pl, msg)
				else
					pas.notify(pl, 'You must be a staff member to use admin chat. Use !report <message> to contact staff.', 1)
				end
				return ''
			end
			
			if msg == "" then
				pas.notify(pl, 'Usage: /a <message>', 1)
				return ''
			end
			
			net.Start('pas.AdminChat')
				net.WriteString(pl:Nick())
				net.WriteString(msg)
				local jobColor = (pl.GetJobColor and pl:GetJobColor()) or Color(150, 150, 150)
				net.WriteColor(jobColor)
			net.Send(pas.GetAdmins())
			
			pas.log.Add('Chat', '[ADMIN CHAT] ' .. pl:Nick() .. ': ' .. msg)
			
			return ''
		end
	end)
	
	function pas.GetAdmins()
		local admins = {}
		for k, v in ipairs(player.GetAll()) do
			if v:HasFlag('m') then -- Changed to use flag instead of IsAdmin
				table.insert(admins, v)
			end
		end
		return admins
	end
else
	net.Receive('pas.AdminChat', function()
		local name = net.ReadString()
		local msg = net.ReadString()
		local col = net.ReadColor()
		
		chat.AddText(
			ui.col.PANTHEON,
			'[ADMIN] ',
			col,
			name,
			Color(255, 255, 255),
			': ' .. msg
		)
	end)
end
