-- Report system for PANTHEON
if (SERVER) then
	AddCSLuaFile()
end

pas.reports = pas.reports or {}
pas.reports.Active = pas.reports.Active or {}

if SERVER then
	util.AddNetworkString('pas.ReportCreate')
	util.AddNetworkString('pas.ReportNotify')
	util.AddNetworkString('pas.ReportList')
	util.AddNetworkString('pas.ReportHandle')
	util.AddNetworkString('pas.ReportClaim')
	
	-- Create a new report
	function pas.reports.Create(reporter, message, reported)
		if not IsValid(reporter) then return end
		
		local report = {
			id = #pas.reports.Active + 1,
			reporter = reporter,
			reporterName = reporter:Nick(),
			reporterSteamID = reporter:SteamID(),
			message = message,
			reported = reported,
			reportedName = reported and reported:Nick() or nil,
			reportedSteamID = reported and reported:SteamID() or nil,
			time = os.time(),
			handler = nil,
			handlerName = nil,
			claimed = false
		}
		
		table.insert(pas.reports.Active, report)
		
		-- Get staff members
		local staff = pas.GetStaff and pas.GetStaff() or {}
		print("[PANTHEON DEBUG] Found " .. #staff .. " staff members to notify")
		
		-- Notify all staff
		if #staff > 0 then
			net.Start('pas.ReportNotify')
				net.WriteUInt(report.id, 16)
				net.WriteString(report.reporterName)
				net.WriteString(report.message)
				net.WriteString(report.reportedName or "")
			net.Send(staff)
			print("[PANTHEON DEBUG] Sent notification to staff")
		end
		
		-- Log the report
		if pas.log and pas.log.Add then
			pas.log.Add('Report', report.reporterName .. ' created report #' .. report.id .. ': ' .. message)
		end
		
		-- Notify reporter
		pas.notify(reporter, 'Your report has been submitted to staff (Report #' .. report.id .. ')', 0)
		print("[PANTHEON DEBUG] Notified reporter")
		
		return report
	end
	
	-- Close/handle a report
	function pas.reports.Handle(id, handler, action)
		for k, report in ipairs(pas.reports.Active) do
			if report.id == id then
				report.handler = handler
				report.handlerName = IsValid(handler) and handler:Nick() or "System"
				report.handledTime = os.time()
				report.action = action or "Handled"
				
				-- Notify reporter if still online
				if IsValid(report.reporter) then
					pas.notify(report.reporter, 'Your report (#' .. id .. ') has been handled by ' .. report.handlerName, 0)
				end
				
				-- Log
				pas.log.Add('Report', report.handlerName .. ' handled report #' .. id)
				
				-- Remove from active
				table.remove(pas.reports.Active, k)
				return true
			end
		end
		return false
	end
	
	-- Claim a report
	function pas.reports.Claim(id, handler)
		for k, report in ipairs(pas.reports.Active) do
			if report.id == id then
				report.handler = handler
				report.handlerName = IsValid(handler) and handler:Nick() or "Unknown"
				report.claimed = true
				
				-- Notify all staff
				net.Start('pas.ReportClaim')
					net.WriteUInt(id, 16)
					net.WriteString(report.handlerName)
				net.Send(pas.GetStaff())
				
				pas.log.Add('Report', report.handlerName .. ' claimed report #' .. id)
				return true
			end
		end
		return false
	end
	
	-- Get all active reports
	function pas.reports.GetAll()
		return pas.reports.Active
	end
	
	-- Get staff members
	function pas.GetStaff()
		local staff = {}
		for k, v in ipairs(player.GetAll()) do
			if v:HasFlag('m') then -- Staff flag
				table.insert(staff, v)
			end
		end
		return staff
	end
	
	-- Network handlers
	net.Receive('pas.ReportCreate', function(len, ply)
		local message = net.ReadString()
		local hasTarget = net.ReadBool()
		local target = nil
		
		if hasTarget then
			local targetID = net.ReadUInt(8)
			target = Player(targetID)
		end
		
		pas.reports.Create(ply, message, target)
	end)
	
	net.Receive('pas.ReportHandle', function(len, ply)
		if not ply:HasFlag('m') then return end
		
		local id = net.ReadUInt(16)
		pas.reports.Handle(id, ply)
	end)
	
	net.Receive('pas.ReportClaim', function(len, ply)
		if not ply:HasFlag('m') then return end
		
		local id = net.ReadUInt(16)
		pas.reports.Claim(id, ply)
	end)
	
	net.Receive('pas.ReportList', function(len, ply)
		if not ply:HasFlag('m') then return end
		
		net.Start('pas.ReportList')
			net.WriteUInt(#pas.reports.Active, 8)
			for k, report in ipairs(pas.reports.Active) do
				net.WriteUInt(report.id, 16)
				net.WriteString(report.reporterName)
				net.WriteString(report.message)
				net.WriteString(report.reportedName or "")
				net.WriteBool(report.claimed)
				net.WriteString(report.handlerName or "")
				net.WriteUInt(report.time, 32)
			end
		net.Send(ply)
	end)
	
else
	-- Client-side
	
	-- Open reports menu
	function pas.OpenReportsMenu(reports)
		local frame = ui.CreateFrame('Active Reports', 950, 650, 'tag')
		
		-- Header panel with statistics
		local header = vgui.Create('DPanel', frame)
		header:SetPos(0, 35)
		header:SetSize(950, 50)
		header.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, ui.col.HEADER)
			
			-- Left side - Icon and title
			ui.DrawIcon('warning', 20, h/2, 28, ui.col.PANTHEON)
			draw.SimpleText('Active Reports', 'PANTHEON.20', 58, h/2, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			
			-- Right side - Statistics
			local unclaimedCount = 0
			for _, r in ipairs(reports) do
				if not r.claimed then unclaimedCount = unclaimedCount + 1 end
			end
			
			-- Total count
			draw.RoundedBox(4, w - 280, 10, 90, 30, ColorAlpha(ui.col.PANTHEON, 100))
			draw.SimpleText('Total: ' .. #reports, 'PANTHEON.14', w - 235, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			-- Unclaimed count
			local unclaimedCol = unclaimedCount > 0 and Color(255, 100, 100) or Color(100, 200, 100)
			draw.RoundedBox(4, w - 180, 10, 120, 30, ColorAlpha(unclaimedCol, 100))
			draw.SimpleText('Unclaimed: ' .. unclaimedCount, 'PANTHEON.14', w - 120, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		
		-- Scroll panel for reports
		local scroll = ui.CreateScrollPanel(frame, 15, 95, 920, 490)
		
		if #reports == 0 then
			-- Empty state
			local emptyPanel = vgui.Create('DPanel', scroll)
			emptyPanel:SetPos(0, 150)
			emptyPanel:SetSize(920, 100)
			emptyPanel.Paint = function(self, w, h)
				ui.DrawIcon('info', w/2, 20, 32, ui.col.TEXT_DIM)
				draw.SimpleText('No active reports', 'PANTHEON.20', w/2, 60, ui.col.TEXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText('Reports will appear here when players submit them', 'DermaDefault', w/2, 85, ui.col.TEXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		else
			local y = 0
			for k, report in ipairs(reports) do
				local panel = vgui.Create('DPanel', scroll)
				panel:SetPos(0, y)
				panel:SetSize(900, 120)
				
				local claimed = report.claimed
				local bgColor = claimed and Color(38, 42, 52) or Color(48, 38, 42)
				
				panel.Paint = function(self, w, h)
					-- Background with gradient effect
					draw.RoundedBox(6, 0, 0, w, h, bgColor)
					
					-- Accent line on left
					local accentCol = claimed and Color(100, 150, 255) or Color(255, 100, 100)
					draw.RoundedBox(0, 0, 0, 4, h, accentCol)
					
					-- Header area
					draw.RoundedBox(0, 4, 0, w - 4, 35, ColorAlpha(Color(0, 0, 0), 40))
					
					-- Report ID badge
					local badgeCol = claimed and Color(100, 150, 255) or Color(255, 100, 100)
					draw.RoundedBox(4, 12, 7, 70, 22, badgeCol)
					ui.DrawIcon('tag', 25, 18, 12, color_white)
					draw.SimpleText('#' .. report.id, 'PANTHEON.14', 62, 18, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					
					-- Reporter info
					ui.DrawIcon('user', 95, 18, 14, ui.col.PANTHEON)
					draw.SimpleText(report.reporterName, 'PANTHEON.16', 115, 18, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					
					-- Time stamp
					local timeAgo = os.time() - report.time
					local timeStr = ''
					if timeAgo < 60 then
						timeStr = math.floor(timeAgo) .. 's ago'
					elseif timeAgo < 3600 then
						timeStr = math.floor(timeAgo / 60) .. 'm ago'
					else
						timeStr = math.floor(timeAgo / 3600) .. 'h ago'
					end
					ui.DrawIcon('info', w - 105, 18, 12, ui.col.TEXT_DIM)
					draw.SimpleText(timeStr, 'DermaDefault', w - 88, 18, ui.col.TEXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					
					-- Claimed status in header
					if claimed then
						ui.DrawIcon('administrator', w - 245, 18, 14, Color(100, 255, 100))
						draw.SimpleText('Claimed by ' .. report.handlerName, 'PANTHEON.14', w - 227, 18, Color(150, 255, 150), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
				end
				
				-- Message section
				local msgPanel = vgui.Create('DPanel', panel)
				msgPanel:SetPos(12, 40)
				msgPanel:SetSize(760, 35)
				msgPanel.Paint = function(self, w, h)
					ui.DrawIcon('book', 5, h/2, 14, ui.col.PANTHEON)
					draw.SimpleText('Message:', 'DermaDefault', 24, 5, ui.col.TEXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				end
				
				local msgLabel = vgui.Create('DLabel', msgPanel)
				msgLabel:SetPos(24, 20)
				msgLabel:SetSize(720, 30)
				msgLabel:SetText(report.message)
				msgLabel:SetFont('PANTHEON.14')
				msgLabel:SetTextColor(color_white)
				msgLabel:SetWrap(true)
				msgLabel:SetAutoStretchVertical(true)
				
				-- Reported player section (if exists)
				if report.reportedName ~= "" then
					local targetPanel = vgui.Create('DPanel', panel)
					targetPanel:SetPos(12, 80)
					targetPanel:SetSize(300, 30)
					targetPanel.Paint = function(self, w, h)
						draw.RoundedBox(4, 0, 0, w, h, ColorAlpha(Color(255, 100, 100), 30))
						ui.DrawIcon('user', 10, h/2, 14, Color(255, 150, 150))
						draw.SimpleText('Reported Player:', 'DermaDefault', 30, h/2, ui.col.TEXT_DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						draw.SimpleText(report.reportedName, 'PANTHEON.14', 135, h/2, Color(255, 180, 180), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
				end
				
				-- Action buttons area
				local btnY = 80
				local btnSpacing = 5
				
				-- Handle button (always visible)
				local handleBtn = ui.CreateButton(panel, 'Resolve', 785, btnY, 105, 32, function()
					net.Start('pas.ReportHandle')
						net.WriteUInt(report.id, 16)
					net.SendToServer()
					frame:Close()
				end, 'accept')
				
				-- Claim button (only if unclaimed)
				if not claimed then
					local claimBtn = ui.CreateButton(panel, 'Claim', 672, btnY, 105, 32, function()
						net.Start('pas.ReportClaim')
							net.WriteUInt(report.id, 16)
						net.SendToServer()
						frame:Close()
					end, 'shield')
				end
				
				y = y + 125
			end
		end
		
		-- Footer with refresh button
		local footer = vgui.Create('DPanel', frame)
		footer:SetPos(0, 595)
		footer:SetSize(950, 55)
		footer.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, ui.col.HEADER)
			
			-- Divider line
			surface.SetDrawColor(ui.col.PANTHEON)
			surface.DrawRect(0, 0, w, 2)
		end
		
		-- Refresh button
		local refreshBtn = ui.CreateButton(footer, 'Refresh List', 15, 12, 130, 32, function()
			net.Start('pas.ReportList')
			net.SendToServer()
			frame:Close()
		end, 'send-message')
	end
	
	net.Receive('pas.ReportList', function()
		local count = net.ReadUInt(8)
		local reports = {}
		
		for i = 1, count do
			table.insert(reports, {
				id = net.ReadUInt(16),
				reporterName = net.ReadString(),
				message = net.ReadString(),
				reportedName = net.ReadString(),
				claimed = net.ReadBool(),
				handlerName = net.ReadString(),
				time = net.ReadUInt(32)
			})
		end
		
		pas.OpenReportsMenu(reports)
	end)
	
	net.Receive('pas.ReportNotify', function()
		local id = net.ReadUInt(16)
		local reporter = net.ReadString()
		local message = net.ReadString()
		local reported = net.ReadString()
		
		-- Play notification sound
		surface.PlaySound("buttons/button17.wav")
		
		-- Add chat notification
		chat.AddText(
			ui.col.PANTHEON,
			'[REPORT #' .. id .. '] ',
			Color(255, 150, 0),
			reporter,
			Color(255, 255, 255),
			': ' .. message
		)
		
		if reported ~= "" then
			chat.AddText(
				Color(200, 200, 200),
				'  → About: ',
				Color(255, 100, 100),
				reported
			)
		end
	end)
	
	net.Receive('pas.ReportClaim', function()
		local id = net.ReadUInt(16)
		local handler = net.ReadString()
		
		chat.AddText(
			ui.col.PANTHEON,
			'[REPORT] ',
			Color(100, 255, 100),
			handler,
			Color(255, 255, 255),
			' claimed report #' .. id
		)
	end)
end

-- Commands (SHARED - registered on both client and server)
pas.cmd.Create('report', function(pl, args)
	if CLIENT then return end -- Only execute on server
	
	print("[REPORT DEBUG] Command called by: " .. tostring(pl))
	print("[REPORT DEBUG] Args: " .. table.concat(args or {}, ", "))
	
	local message = table.concat(args, ' ')
	
	if not message or message == '' then
		pas.notify(pl, 'Usage: /report <message>', 1)
		return
	end
	
	print("[REPORT DEBUG] Creating report with message: " .. message)
	pas.reports.Create(pl, message)
end)
	:SetFlag('u')
	:SetHelp('Create a report to notify staff')
	:SetIcon('icon16/flag_red.png')

-- Report a player
pas.cmd.Create('reportplayer', function(pl, args)
	if CLIENT then return end -- Only execute on server
	
	local target = args[1]
	local message = table.concat(args, ' ', 2)
	
	if not target then
		pas.notify(pl, 'Usage: /reportplayer <player> <reason>', 1)
		return
	end
	
	local targets = pas.parser and pas.parser.ParsePlayer and pas.parser.ParsePlayer(target, pl) or {}
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	local targ = targets[1]
	
	if not message or message == '' then
		message = "No reason provided"
	end
	
	pas.reports.Create(pl, message, targ)
end)
	:SetFlag('u')
	:SetHelp('Report a player to staff <player> <reason>')
	:SetIcon('icon16/flag_red.png')
	:AddAlias('rp')

-- Handle report command (staff only)
pas.cmd.Create('handlereport', function(pl, args)
	if CLIENT then return end -- Only execute on server
	
	local id = tonumber(args[1])
	
	if not id then
		pas.notify(pl, 'Usage: /handlereport <id>', 1)
		return
	end
	
	if pas.reports.Handle(id, pl) then
		pas.notify(pl, 'Report #' .. id .. ' has been handled', 0)
	else
		pas.notify(pl, 'Report not found', 1)
	end
end)
	:SetFlag('m')
	:SetHelp('Mark a report as handled <id>')
	:SetIcon('icon16/tick.png')
	:AddAlias('hr')

-- Claim report command (staff only)
pas.cmd.Create('claimreport', function(pl, args)
	if CLIENT then return end -- Only execute on server
	
	local id = tonumber(args[1])
	
	if not id then
		pas.notify(pl, 'Usage: /claimreport <id>', 1)
		return
	end
	
	if pas.reports.Claim(id, pl) then
		pas.notify(pl, 'You claimed report #' .. id, 0)
	else
		pas.notify(pl, 'Report not found', 1)
	end
end)
	:SetFlag('m')
	:SetHelp('Claim a report <id>')
	:SetIcon('icon16/user_go.png')
	:AddAlias('cr')

-- List reports command (staff only)
pas.cmd.Create('reports', function(pl, args)
	if CLIENT then return end -- Only execute on server
	
	-- Send report data to client to open UI
	net.Start('pas.ReportList')
		net.WriteUInt(#pas.reports.Active, 8)
		for k, report in ipairs(pas.reports.Active) do
			net.WriteUInt(report.id, 16)
			net.WriteString(report.reporterName)
			net.WriteString(report.message)
			net.WriteString(report.reportedName or "")
			net.WriteBool(report.claimed)
			net.WriteString(report.handlerName or "")
			net.WriteUInt(report.time, 32)
		end
	net.Send(pl)
end)
	:SetFlag('m')
	:SetHelp('List all active reports')
	:SetIcon('icon16/application_view_list.png')
