-- View Staff Command for PANTHEON
if SERVER then
	AddCSLuaFile()
	
	util.AddNetworkString('pas.ViewStaffData')
	
	-- Server-side: Gather and send staff data
	pas.cmd.Create('viewstaff', function(pl, args)
		-- Gather all staff members
		local staffList = {}
		
		-- Get online staff
		for _, p in ipairs(player.GetAll()) do
			if p:HasFlag('m') then -- Has moderator flag or higher
				table.insert(staffList, {
					name = p:Nick(),
					rank = p:GetUserGroup(),
					steamid = p:SteamID(),
					online = true
				})
			end
		end
		
		-- Send to client
		net.Start('pas.ViewStaffData')
			net.WriteUInt(#staffList, 16)
			for _, staff in ipairs(staffList) do
				net.WriteString(staff.name)
				net.WriteString(staff.rank)
				net.WriteString(staff.steamid)
				net.WriteBool(staff.online)
			end
		net.Send(pl)
	end)
	:SetFlag('u')
	:SetHelp('View online staff members')
	:AddAlias('staff')
	:AddAlias('stafflist')
	
	return
end

-- CLIENT-SIDE CODE
pas = pas or {}

net.Receive('pas.ViewStaffData', function()
	local staffCount = net.ReadUInt(16)
	local staffList = {}
	
	for i = 1, staffCount do
		table.insert(staffList, {
			name = net.ReadString(),
			rank = net.ReadString(),
			steamid = net.ReadString(),
			online = net.ReadBool()
		})
	end
	
	pas.OpenViewStaffMenu(staffList)
end)

function pas.OpenViewStaffMenu(staffData)
	if IsValid(pas.ViewStaffFrame) then
		pas.ViewStaffFrame:Remove()
	end
	
	-- Create main frame
	local frame = ui.CreateFrame('Staff Directory', 1200, 700, 'group')
	pas.ViewStaffFrame = frame
	
	-- Particle system for background
	local particles = {}
	for i = 1, 20 do
		table.insert(particles, {
			x = math.random(0, frame:GetWide()),
			y = math.random(0, frame:GetTall()),
			size = math.random(2, 6),
			speedX = math.Rand(-0.3, 0.3),
			speedY = math.Rand(-0.5, -0.1),
			alpha = math.random(30, 80)
		})
	end
	
	-- Override frame paint to add grid background and particles
	local basePaint = frame.Paint
	frame.Paint = function(self, w, h)
		-- Draw semi-transparent blurred background
		draw.RoundedBox(8, 0, 0, w, h, ColorAlpha(ui.col.BackgroundDark, 240))
		
		-- Draw grid background overlay
		local gridMat = ui.GetIcon('grid-bg')
		if gridMat then
			surface.SetDrawColor(255, 255, 255, 15)
			surface.SetMaterial(gridMat)
			surface.DrawTexturedRect(0, 0, w, h)
		end
		
		-- Draw vignette overlay
		local vignetteMat = ui.GetIcon('vignette')
		if vignetteMat then
			surface.SetDrawColor(0, 0, 0, 60)
			surface.SetMaterial(vignetteMat)
			surface.DrawTexturedRect(0, 0, w, h)
		end
		
		-- Draw and update particles
		for _, p in ipairs(particles) do
			-- Update position
			p.x = p.x + p.speedX
			p.y = p.y + p.speedY
			
			-- Wrap around
			if p.y < -10 then p.y = h + 10 end
			if p.y > h + 10 then p.y = -10 end
			if p.x < -10 then p.x = w + 10 end
			if p.x > w + 10 then p.x = -10 end
			
			-- Draw particle glow first (larger)
			local glowSize = p.size * 3
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, p.alpha * 0.4)
			surface.DrawRect(p.x - glowSize/2, p.y - glowSize/2, glowSize, glowSize)
			
			-- Draw particle core (brighter)
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, p.alpha * 1.5)
			surface.DrawRect(p.x - p.size/2, p.y - p.size/2, p.size, p.size)
		end
		
		-- Draw top header bar
		draw.RoundedBoxEx(8, 0, 0, w, 35, ColorAlpha(ui.col.BackgroundCard, 200), true, true, false, false)
		
		-- Icon and title
		ui.DrawIcon('group', 18, 17, 20, ui.col.PANTHEON)
		draw.SimpleText('Staff Directory', 'PANTHEON.20', 45, 17, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		
		-- Online count indicator
		local onlineCount = 0
		for _, staff in ipairs(staffData) do
			if staff.online then onlineCount = onlineCount + 1 end
		end
		
		-- Pulsing online indicator
		local pulse = math.abs(math.sin(CurTime() * 2)) * 0.3 + 0.7
		local statusColor = Color(100 * pulse, 255 * pulse, 150 * pulse)
		surface.SetDrawColor(statusColor.r, statusColor.g, statusColor.b, 255)
		draw.NoTexture()
		surface.DrawCircle(w - 115, 17, 4, statusColor)
		draw.SimpleText(onlineCount .. ' Online', 'PANTHEON.14', w - 105, 17, statusColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	-- Stats header panel
	local statsHeader = vgui.Create('DPanel', frame)
	statsHeader:SetPos(10, 45)
	statsHeader:SetSize(frame:GetWide() - 20, 80)
	statsHeader.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Top accent line
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, 0, w, 2)
		
		-- Dividers
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 80)
		surface.DrawRect(w/3, 20, 2, h - 40)
		surface.DrawRect(w*2/3, 20, 2, h - 40)
		
		-- Total staff
		local totalStaff = #staffData
		draw.SimpleText('TOTAL STAFF', 'PANTHEON.14', w/6, 22, ui.col.TextDim, TEXT_ALIGN_CENTER)
		draw.SimpleText(tostring(totalStaff), 'PANTHEON.32', w/6, 52, ui.col.PANTHEON, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		
		-- Online staff
		local onlineStaff = 0
		for _, staff in ipairs(staffData) do
			if staff.online then onlineStaff = onlineStaff + 1 end
		end
		draw.SimpleText('ONLINE NOW', 'PANTHEON.14', w/2, 22, ui.col.TextDim, TEXT_ALIGN_CENTER)
		draw.SimpleText(tostring(onlineStaff), 'PANTHEON.32', w/2, 52, Color(100, 255, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		
		-- Offline staff
		local offlineStaff = totalStaff - onlineStaff
		draw.SimpleText('OFFLINE', 'PANTHEON.14', w*5/6, 22, ui.col.TextDim, TEXT_ALIGN_CENTER)
		draw.SimpleText(tostring(offlineStaff), 'PANTHEON.32', w*5/6, 52, Color(150, 150, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	-- Search and filter variables
	local searchText = ""
	local filterRank = "all"
	local showOnlineOnly = false
	
	-- Filter panel
	local filterPanel = vgui.Create('DPanel', frame)
	filterPanel:SetPos(10, 135)
	filterPanel:SetSize(frame:GetWide() - 20, 60)
	filterPanel.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Top accent line
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, 0, w, 2)
	end
	
	-- Search box
	local searchLabel = vgui.Create('DLabel', filterPanel)
	searchLabel:SetPos(10, 15)
	searchLabel:SetSize(60, 30)
	searchLabel:SetText('Search:')
	searchLabel:SetFont('PANTHEON.16')
	searchLabel:SetTextColor(ui.col.TextDim)
	
	local searchBox = ui.CreateTextEntry(filterPanel, 75, 15, 250, 30, "Search staff...")
	
	-- Rank filter dropdown
	local rankLabel = vgui.Create('DLabel', filterPanel)
	rankLabel:SetPos(340, 15)
	rankLabel:SetSize(50, 30)
	rankLabel:SetText('Rank:')
	rankLabel:SetFont('PANTHEON.16')
	rankLabel:SetTextColor(ui.col.TextDim)
	
	local rankCombo = ui.CreateComboBox(filterPanel, 395, 15, 150, 30)
	rankCombo:AddChoice("All Ranks", "all")
	
	-- Add rank choices dynamically
	local rankList = {}
	for _, staff in ipairs(staffData) do
		if not rankList[staff.rank] then
			rankList[staff.rank] = true
			rankCombo:AddChoice(staff.rank, staff.rank)
		end
	end
	
	rankCombo:SetValue("All Ranks")
	
	-- Online filter button
	local onlineBtn = ui.CreateButton(filterPanel, 'Show All', 560, 15, 120, 30, nil, 'group')
	
	-- Refresh button
	local refreshBtn = ui.CreateButton(filterPanel, 'Refresh', filterPanel:GetWide() - 110, 15, 100, 30, function()
		RunConsoleCommand('pas_viewstaff')
	end, 'refresh')
	
	-- Staff list panel
	local staffPanel = ui.CreatePanel(frame, 10, 205, frame:GetWide() - 20, frame:GetTall() - 260)
	staffPanel:SetPaintBackground(false)
	
	staffPanel.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Header with gradient
		draw.RoundedBox(6, 0, 0, w, 40, ui.col.BackgroundCard)
		
		-- Accent line
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, h - 2, w, 2)
		
		-- Icon and title
		ui.DrawIcon('group', 18, 20, 20, ui.col.PANTHEON)
		draw.SimpleText('Staff Members', 'PANTHEON.18', 45, 20, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	-- Staff list
	local staffList = ui.CreateList(staffPanel, 8, 48, staffPanel:GetWide() - 16, staffPanel:GetTall() - 56)
	staffList:AddColumn('Name', 200)
	staffList:AddColumn('Rank', 150)
	staffList:AddColumn('Status', 100)
	staffList:AddColumn('Steam ID', 250)
	staffList:SetMultiSelect(false)
	
	-- Populate staff list function
	local function RefreshStaffDisplay()
		staffList:Clear()
		
		-- Filter staff list
		local displayList = {}
		for _, staff in ipairs(staffData) do
			-- Search filter
			local matchesSearch = searchText == "" or 
				string.find(string.lower(staff.name), searchText, 1, true) or
				string.find(string.lower(staff.rank), searchText, 1, true)
			
			-- Online filter
			local matchesOnline = not showOnlineOnly or staff.online
			
			-- Rank filter  
			local matchesRank = filterRank == "all" or string.lower(staff.rank) == string.lower(filterRank)
			
			if matchesSearch and matchesOnline and matchesRank then
				table.insert(displayList, staff)
			end
		end
		
		-- Sort by online status, then by name
		table.sort(displayList, function(a, b)
			if a.online ~= b.online then return a.online end
			return a.name < b.name
		end)
		
		-- Add staff entries
		for _, staff in ipairs(displayList) do
			local statusText = staff.online and "Online" or "Offline"
			local line = staffList:AddLine(staff.name, staff.rank, statusText, staff.steamid)
			
			-- Store staff data
			line.staffData = staff
			line.isOnline = staff.online
		end
	end
	
	-- Right-click menu
	staffList.OnRowRightClick = function(self, index, line)
		if not line.staffData then return end
		
		local staff = line.staffData
		local menu = DermaMenu()
		menu:SetSkin('PANTHEON')
		
		local copyNameOption = menu:AddOption('Copy Name', function()
			SetClipboardText(staff.name)
			ui.Notify('Name copied to clipboard', NOTIFY_GENERIC, 3)
		end)
		
		copyNameOption.Paint = function(pnl, w, h)
			if pnl:IsHovered() then
				surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 30)
				surface.DrawRect(0, 0, w, h)
			end
			
			local icon = ui.GetIcon('user')
			if icon then
				surface.SetDrawColor(255, 255, 255, 255)
				surface.SetMaterial(icon)
				surface.DrawTexturedRect(10, h/2 - 8, 16, 16)
			end
			draw.SimpleText(pnl:GetText(), 'PANTHEON.14', 32, h/2, ui.col.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		
		local copySteamIDOption = menu:AddOption('Copy Steam ID', function()
			SetClipboardText(staff.steamid)
			ui.Notify('Steam ID copied to clipboard', NOTIFY_GENERIC, 3)
		end)
		
		copySteamIDOption.Paint = function(pnl, w, h)
			if pnl:IsHovered() then
				surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 30)
				surface.DrawRect(0, 0, w, h)
			end
			
			local icon = ui.GetIcon('key')
			if icon then
				surface.SetDrawColor(255, 255, 255, 255)
				surface.SetMaterial(icon)
				surface.DrawTexturedRect(10, h/2 - 8, 16, 16)
			end
			draw.SimpleText(pnl:GetText(), 'PANTHEON.14', 32, h/2, ui.col.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		
		menu:Open()
	end
	
	-- Button actions
	searchBox.OnValueChange = function(self, value)
		searchText = string.lower(value or "")
		RefreshStaffDisplay()
	end
	
	rankCombo.OnSelect = function(self, index, value, data)
		filterRank = data or "all"
		RefreshStaffDisplay()
	end
	
	onlineBtn.DoClick = function()
		showOnlineOnly = not showOnlineOnly
		onlineBtn:SetText(showOnlineOnly and "Online Only" or "Show All")
		RefreshStaffDisplay()
	end
	
	-- Footer panel
	local footerPanel = ui.CreatePanel(frame, 10, frame:GetTall() - 45, frame:GetWide() - 20, 35)
	footerPanel:SetPaintBackground(false)
	
	function footerPanel:Paint(w, h)
		draw.RoundedBox(6, 0, 0, w, h, ui.col.BackgroundDark)
		
		-- Top accent line
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, 0, w, 2)
		
		-- Info text
		draw.SimpleText('Right-click staff members for options', 'PANTHEON.14', 15, h/2, ui.col.TextDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	-- Initial display
	RefreshStaffDisplay()
end

print('[PANTHEON] ViewStaff plugin loaded')
