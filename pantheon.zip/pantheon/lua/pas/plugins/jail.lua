-- Enhanced Jail System for PANTHEON (based on D3A)
if (SERVER) then
	AddCSLuaFile()
end

pas.jail = pas.jail or {}

-- Default jail positions (can be customized per map)
local jailSpots = {
	Vector(0, 0, 0), -- Default positions, should be set per map
}

-- Create jail walls around a player
local function populateJail(JailProps, jailType)
	if (jailType == 1) then -- normal jail
		table.insert(JailProps, {pos = Vector(0,0,-5), ang = Angle(90,0,0), model = "models/props_building_details/Storefront_Template001a_Bars.mdl"})
        table.insert(JailProps, {pos = Vector(0,0,97), ang = Angle(90,0,0), model = "models/props_building_details/Storefront_Template001a_Bars.mdl"})
        table.insert(JailProps, {pos = Vector(21,31,46), ang = Angle(0,90,0), model = "models/props_building_details/Storefront_Template001a_Bars.mdl"})
        table.insert(JailProps, {pos = Vector(21,-31,46), ang = Angle(0,90,0), model = "models/props_building_details/Storefront_Template001a_Bars.mdl"})
        table.insert(JailProps, {pos = Vector(-21,31,46), ang = Angle(0,90,0), model = "models/props_building_details/Storefront_Template001a_Bars.mdl"})
        table.insert(JailProps, {pos = Vector(-21,-31,46), ang = Angle(0,90,0), model = "models/props_building_details/Storefront_Template001a_Bars.mdl"})
        table.insert(JailProps, {pos = Vector(-52,0,46), ang = Angle(0,0,0), model = "models/props_building_details/Storefront_Template001a_Bars.mdl"})
		table.insert(JailProps, {pos = Vector(52,0,46), ang = Angle(0,0,0), model = "models/props_building_details/Storefront_Template001a_Bars.mdl"})
		return 70 -- jail distance
	end
	return 50
end

-- Jail a player
function pas.jail.JailPlayer(target, time, reason, admin)
	if not IsValid(target) or not target:IsPlayer() then return false end
	
	-- Get jail position
	local jailPos = jailSpots[math.random(1, #jailSpots)]
	if jailPos == Vector(0, 0, 0) then
		-- Fallback to player's current position if no jail spots defined
		jailPos = target:GetPos()
	end
	
	target:SetPos(jailPos)
	target:ExitVehicle()

	local JailProps = {}
	local jailDistance = populateJail(JailProps, 1) ^ 2

	target.Jail = true
	target.JailPos = jailPos
	target.JailProps = target.JailProps or {}

	-- Remove existing jail props
	if (target.JailProps[1]) then
		for k, v in ipairs(target.JailProps) do
			if (IsValid(v)) then v:Remove() end
		end
		target.JailProps = {}
	end

	-- Create jail walls
	for k, v in ipairs(JailProps) do
		local prop = ents.Create("prop_physics")
        prop:SetPos(target.JailPos + v.pos)
        prop:SetAngles(v.ang)
        prop:SetModel(v.model)
        prop:Spawn()
        prop:Activate()
		
		-- Make the prop completely solid and unmovable
		local phys = prop:GetPhysicsObject()
		if IsValid(phys) then
			phys:EnableMotion(false)
			phys:SetMaterial("gmod_ice") -- Make it very solid
		end
		
		-- Set proper collision settings
		prop:SetCollisionGroup(COLLISION_GROUP_NONE) -- Use default collision (more solid)
		prop:SetSolid(SOLID_VPHYSICS) -- Ensure it's solid
		prop:SetMoveType(MOVETYPE_NONE) -- Cannot be moved at all
		
		-- Make it unbreakable
		prop:SetHealth(999999)
		prop:SetMaxHealth(999999)

        prop.target = target
		prop.targetPos = target.JailPos
		prop.IsJailWall = true

		target.JailProps[#target.JailProps+1] = prop
	end

	-- Disable certain abilities while jailed
	target:GodEnable() -- Prevent death while jailed

	if (time == 0) then
		-- Indefinite jail
		pas.notify_all(target:Nick() .. " has been jailed indefinitely" .. (reason and (" for: " .. reason) or ""), 1)
		return
	end

	-- Timed jail
	local sid = target:SteamID64()
	pas.notify_all(target:Nick() .. " has been jailed for " .. math.Round(time/60, 1) .. " minutes" .. (reason and (" for: " .. reason) or ""), 1)

	-- Auto-unjail timer
	timer.Create("AutoUnjail" .. sid, time, 1, function()
		timer.Remove("JailWatch" .. sid)

		if (!IsValid(target)) then return end
		if (!target.Jail) then return end

		pas.jail.UnjailPlayer(target)
	end)

	-- Watch for jail breaking (more frequent checks)
	timer.Create("JailWatch" .. sid, 0.1, 0, function()
		if (!IsValid(target)) then
			timer.Remove("JailWatch" .. sid)
			return
		end

		-- Check if player is outside jail area
		if (target:GetPos():DistToSqr(target.JailPos) > jailDistance) then
			-- Force them back to jail center
			target:SetPos(target.JailPos)
			target:SetVelocity(Vector(0, 0, 0)) -- Stop any momentum
		end
		
		-- Additional anti-noclip checks
		if target:GetMoveType() == MOVETYPE_NOCLIP then
			target:SetMoveType(MOVETYPE_WALK)
		end
	end)

	-- Store in database for persistence
	if sql then
		sql.Query("CREATE TABLE IF NOT EXISTS pas_jails ( steamid64 TEXT PRIMARY KEY, duration REAL, reason TEXT )")
		local timeLeft = time > 0 and time or 0
		sql.Query("REPLACE INTO pas_jails ( steamid64, duration, reason ) VALUES ( '" .. sid .. "', " .. timeLeft .. ", '" .. sql.SQLStr(reason or "", true) .. "' )")
	end

	return true
end

-- Unjail a player
function pas.jail.UnjailPlayer(target)
	if not IsValid(target) or not target:IsPlayer() then return false end
	if not target.Jail then return false end

	local sid = target:SteamID64()

	-- Remove timers
	timer.Remove("AutoUnjail" .. sid)
	timer.Remove("JailWatch" .. sid)

	-- Remove jail props
	for k, v in ipairs(target.JailProps or {}) do
		if (IsValid(v)) then v:Remove() end
	end

	-- Reset player state
	target.Jail = nil
	target.JailPos = nil
	target.JailProps = nil
	target:GodDisable()

	-- Respawn player to get them out of jail area
	target:Spawn()

	-- Remove from database
	if sql then
		sql.Query("DELETE FROM pas_jails WHERE steamid64 = '" .. sid .. "'")
	end

	pas.notify_all(target:Nick() .. " has been released from jail", 0)
	return true
end

-- Check if player is jailed
function pas.jail.IsJailed(target)
	return target.Jail == true
end

-- Jail command
pas.cmd.Create('jail', function(pl, args)
	local target = args[1]
	local time = tonumber(args[2]) or 300 -- Default 5 minutes
	local reason = table.concat(args, ' ', 3)
	
	if not target then
		pas.notify(pl, 'Usage: !jail <player> <time_minutes> [reason]', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if pas.jail.JailPlayer(targ, time * 60, reason, pl) then
			pas.notify(pl, 'Jailed ' .. targ:Nick() .. ' for ' .. time .. ' minutes', 0)
			pas.log.Add('Command', pl:Nick() .. ' jailed ' .. targ:Nick() .. ' for ' .. time .. ' minutes' .. (reason and (' - ' .. reason) or ''))
		end
	end
end)
	:SetFlag('m')
	:SetHelp('Jail a player for a specified time')
	:SetIcon('icon16/lock.png')

-- Unjail command
pas.cmd.Create('unjail', function(pl, args)
	local target = args[1]
	
	if not target then
		pas.notify(pl, 'Usage: !unjail <player>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if pas.jail.UnjailPlayer(targ) then
			pas.notify(pl, 'Unjailed ' .. targ:Nick(), 0)
			pas.log.Add('Command', pl:Nick() .. ' unjailed ' .. targ:Nick())
		else
			pas.notify(pl, targ:Nick() .. ' is not jailed', 1)
		end
	end
end)
	:SetFlag('m')
	:SetHelp('Release a player from jail')
	:SetIcon('icon16/lock_open.png')

if SERVER then
	-- Hooks to prevent jailed players from doing certain things
	local jailHooks = {"PlayerNoClip", "PlayerSpawnObject", "CanPlayerEnterVehicle"}
	for k, v in ipairs(jailHooks) do
		hook.Add(v, "PAS.Jail", function(pl) 
			if (pl.Jail) then return false end 
		end)
	end
	
	-- Prevent jail wall damage/removal
	hook.Add("EntityTakeDamage", "PAS.JailWalls", function(ent, dmg)
		if ent.IsJailWall then
			return true -- Block all damage to jail walls
		end
	end)
	
	-- Prevent physgun/toolgun on jail walls
	hook.Add("PhysgunPickup", "PAS.JailWalls", function(pl, ent)
		if ent.IsJailWall then
			return false
		end
	end)
	
	hook.Add("CanTool", "PAS.JailWalls", function(pl, tr, tool)
		local ent = tr.Entity
		if IsValid(ent) and ent.IsJailWall then
			return false
		end
	end)

	-- Keep jailed players in jail on spawn
	hook.Add("PlayerSpawn", "PAS.Jail", function(pl)
		if (pl.Jail) then
			timer.Simple(0.01, function() 
				if IsValid(pl) and pl.JailPos then 
					pl:SetPos(pl.JailPos) 
				end 
			end)
		end
	end)
	
	-- Additional position monitoring (runs every frame)
	hook.Add("Think", "PAS.JailMonitor", function()
		for _, pl in ipairs(player.GetAll()) do
			if IsValid(pl) and pl.Jail and pl.JailPos then
				local dist = pl:GetPos():DistToSqr(pl.JailPos)
				-- Tighter jail boundary - 50^2 = 2500
				if dist > 2500 then
					pl:SetPos(pl.JailPos)
					pl:SetVelocity(Vector(0, 0, 0))
					-- Optional: Damage player for trying to escape
					-- pl:TakeDamage(10)
				end
			end
		end
	end)

	-- Prevent entering vehicles while jailed
	hook.Add("PlayerEnteredVehicle", "PAS.Jail", function(pl)
		if (pl.Jail) then
			pl:ExitVehicle()
		end
	end)

	-- Handle reconnection with active jail time
	hook.Add("PlayerInitialSpawn", "PAS.Jail", function(pl)
		timer.Simple(5, function() -- Wait for player to fully load
			if not IsValid(pl) then return end
			
			local sid = pl:SteamID64()
			local result = sql.Query("SELECT * FROM pas_jails WHERE steamid64 = '" .. sid .. "'")
			
			if result and result[1] then
				local timeLeft = tonumber(result[1].duration) or 0
				local reason = result[1].reason or "Reconnected with active jail time"
				
				if timeLeft > 0 then
					pas.jail.JailPlayer(pl, timeLeft, reason)
				end
			end
		end)
	end)

	-- Save jail time on disconnect
	hook.Add("PlayerDisconnected", "PAS.Jail", function(pl)
		if not IsValid(pl) or not pl.Jail then return end

		local sid = pl:SteamID64()
		local timeLeft = timer.TimeLeft("AutoUnjail" .. sid) or 0

		if timeLeft > 0 then
			sql.Query("REPLACE INTO pas_jails ( steamid64, duration, reason ) VALUES ( '" .. sid .. "', " .. timeLeft .. ", 'Disconnected while jailed' )")
		end
	end)

	-- Initialize jail database
	hook.Add("Initialize", "PAS.Jail", function()
		sql.Query("CREATE TABLE IF NOT EXISTS pas_jails ( steamid64 TEXT PRIMARY KEY, duration REAL, reason TEXT )")
	end)
end