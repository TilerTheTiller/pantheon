-- Admin Menu Command
-- Opens the PANTHEON admin menu interface

if SERVER then
    AddCSLuaFile()
    
    util.AddNetworkString('PANTHEON.OpenMenu')
    
    -- Create the menu command
    pas.cmd.Create('menu', function(pl, args)
        if not IsValid(pl) or not pl:IsPlayer() then
            return
        end
        
        -- Send network message to client to open menu
        net.Start('PANTHEON.OpenMenu')
        net.Send(pl)
    end)
        :SetFlag('a')
        :SetHelp('Open the PANTHEON Admin Menu')
        :SetIcon('icon16/application_view_tile.png')
        :AddAlias('adminmenu')
        :AddAlias('amenu')
end

if CLIENT then
    -- Receive network message to open menu
    net.Receive('PANTHEON.OpenMenu', function()
        if pas.menu and pas.menu.Open then
            pas.menu.Open()
        end
    end)
    
    if ui and ui.col then
        MsgC(ui.col.PANTHEON, '[PANTHEON] ', ui.col.White, 'Menu command registered\n')
    else
        print('[PANTHEON] Menu command registered')
    end
end
