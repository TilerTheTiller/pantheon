-- Entity Limits System for PANTHEON (based on D3A)
if (SERVER) then
	AddCSLuaFile()
end

pas.limits = pas.limits or {}

-- Default limits per rank
pas.limits.Defaults = {
	["founder"] = {
		["effect"] = 999, -- 999 for infinite, anything else is finite
		["npc"] 	= 999,
		["prop"] 	= 999,
		["ragdoll"]= 999,
		["sent"]	= 999,
		["swep"]	= 999,
		["vehicle"]= 999,
	},

	["superadmin"] = {
		["effect"] = 999,
		["npc"] 	= 999,
		["prop"] 	= 999,
		["ragdoll"]= 999,
		["sent"]	= 999,
		["swep"]	= 999,
		["vehicle"]= 999,
	},

	["admin"] = {
		["effect"] = 0,
		["npc"] 	= 20,
		["prop"] 	= 100,
		["ragdoll"]= 10,
		["sent"]	= 10,
		["swep"]	= 5,
		["vehicle"]= 5,
	},

	["moderator"] = {
		["effect"] = 0,
		["npc"] 	= 10,
		["prop"] 	= 85,
		["ragdoll"]= 5,
		["sent"]	= 5,
		["swep"]	= 3,
		["vehicle"]= 3,
	},

	["vip"] = {
		["effect"] = 0,
		["npc"] 	= 5,
		["prop"] 	= 65,
		["ragdoll"]= 3,
		["sent"]	= 3,
		["swep"]	= 2,
		["vehicle"]= 2,
	},

	["user"] = {
		["effect"] = 0,
		["npc"] 	= 3,
		["prop"] 	= 50,
		["ragdoll"]= 2,
		["sent"]	= 2,
		["swep"]	= 1,
		["vehicle"]= 1,
	},
}

function pas.limits.Initialize()
	if sql.TableExists("pas_limits") then
		return
	end

	sql.Query("CREATE TABLE pas_limits ( rank TEXT, effect INTEGER, npc INTEGER, prop INTEGER, ragdoll INTEGER, sent INTEGER, swep INTEGER, vehicle INTEGER )")

	for rank, defs in pairs(pas.limits.Defaults) do
		local keys = {}
		local values = {}
		
		for k, v in pairs(defs) do
			table.insert(keys, k)
			table.insert(values, v)
		end
		
		sql.Query("INSERT INTO pas_limits ( rank, "..table.concat(keys, ", ").." ) VALUES ( '"..rank.."', "..table.concat(values, ", ").." )")
	end
	
	if pas.print then
		pas.print('Entity limits initialized')
	else
		print('[PANTHEON] Entity limits initialized')
	end
end

function pas.limits.InsertRank(rank, limits)
	rank = string.lower(rank)
	if not limits then
		limits = pas.limits.Defaults["user"] -- Default to user limits
	end
	
	local keys = table.GetKeys(limits)
	local values = table.ClearKeys(limits)
	
	sql.Query("INSERT INTO pas_limits ( rank, "..table.concat(keys, ", ").." ) VALUES ( '"..rank.."', "..table.concat(values, ", ").." )")
end

function pas.limits.SetRankLimit(rank, limitType, amount)
	rank = string.lower(rank)
	limitType = string.lower(limitType)
	sql.Query("UPDATE pas_limits SET "..limitType.." = "..amount.." WHERE rank = '"..rank.."'")
end

function pas.limits.RemoveRank(rank)
	rank = string.lower(rank)
	sql.Query("DELETE FROM pas_limits WHERE rank='"..rank.."'")
end

function pas.limits.GetLimit(ply, limitType)
	if not IsValid(ply) or not ply:IsPlayer() then return 0 end
	
	limitType = string.lower(limitType)
	local rank = string.lower(ply:GetUserGroup())
	
	-- Check if SQL is available and table exists
	if not sql or not sql.TableExists("pas_limits") then
		local defaults = pas.limits.Defaults[rank] or pas.limits.Defaults["user"]
		return defaults[limitType] or 0
	end
	
	local result = sql.Query("SELECT "..limitType.." FROM pas_limits WHERE rank='"..rank.."'")
	if result and result[1] then
		return tonumber(result[1][limitType]) or 0
	end
	
	-- Fallback to defaults
	local defaults = pas.limits.Defaults[rank] or pas.limits.Defaults["user"]
	return defaults[limitType] or 0
end

-- Check functions for each entity type
function pas.limits.CheckEffects(ply)
	local limit = pas.limits.GetLimit(ply, "effect")
	if ( limit == 999 ) or ( ply:GetCount("effects") < limit ) then
		return true
	end

	ply:LimitHit("effects")
	return false
end

function pas.limits.CheckNPCs(ply)
	local limit = pas.limits.GetLimit(ply, "npc")
	if ( limit == 999 ) or ( ply:GetCount("npcs") < limit ) then
		return true
	end

	ply:LimitHit("NPCs")
	return false
end

function pas.limits.CheckProps(ply)
	local limit = pas.limits.GetLimit(ply, "prop")
	if ( limit == 999 ) or ( ply:GetCount("props") < limit ) then
		return true
	end

	ply:LimitHit("props")
	return false
end

function pas.limits.CheckRagdolls(ply)
	local limit = pas.limits.GetLimit(ply, "ragdoll")
	if ( limit == 999 ) or ( ply:GetCount("ragdolls") < limit ) then
		return true
	end

	ply:LimitHit("ragdolls")
	return false
end

function pas.limits.CheckSENTs(ply)
	local limit = pas.limits.GetLimit(ply, "sent")
	if ( limit == 999 ) or ( ply:GetCount("sents") < limit ) then
		return true
	end

	ply:LimitHit("SENTs")
	return false
end

function pas.limits.CheckSWEPs(ply)
	local limit = pas.limits.GetLimit(ply, "swep")
	if ( limit == 999 ) or ( ply:GetCount("sweps") < limit ) then
		return true
	end

	ply:LimitHit("SWEPs")
	return false
end

function pas.limits.CheckVehicles(ply)
	local limit = pas.limits.GetLimit(ply, "vehicle")
	if ( limit == 999 ) or ( ply:GetCount("vehicles") < limit ) then
		return true
	end

	ply:LimitHit("vehicles")
	return false
end

-- Commands for managing limits
pas.cmd.Create('setlimit', function(pl, args)
	local rank = args[1]
	local limitType = args[2]
	local amount = tonumber(args[3])
	
	if not rank or not limitType or not amount then
		pas.notify(pl, 'Usage: !setlimit <rank> <type> <amount>', 1)
		pas.notify(pl, 'Types: effect, npc, prop, ragdoll, sent, swep, vehicle', 0)
		return
	end
	
	pas.limits.SetRankLimit(rank, limitType, amount)
	pas.notify(pl, 'Set ' .. limitType .. ' limit for ' .. rank .. ' to ' .. amount, 0)
	pas.log.Add('Command', pl:Nick() .. ' set ' .. limitType .. ' limit for ' .. rank .. ' to ' .. amount)
end)
	:SetFlag('s')
	:SetHelp('Set entity limits for a rank')
	:SetIcon('icon16/cog.png')

pas.cmd.Create('limits', function(pl, args)
	local target = args[1] or pl:Nick()
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	local targ = targets[1]
	
	pas.notify(pl, 'Limits for ' .. targ:Nick() .. ' (' .. targ:GetUserGroup() .. '):', 0)
	local limitTypes = {"prop", "npc", "vehicle", "sent", "ragdoll", "swep", "effect"}
	
	for _, limitType in pairs(limitTypes) do
		local limit = pas.limits.GetLimit(targ, limitType)
		local current = targ:GetCount(limitType .. "s") or targ:GetCount(limitType)
		local limitText = limit == 999 and "∞" or tostring(limit)
		pas.notify(pl, string.upper(string.sub(limitType, 1, 1)) .. string.sub(limitType, 2) .. 's: ' .. current .. '/' .. limitText, 0)
	end
end)
	:SetFlag('m')
	:SetHelp('Check entity limits for a player')
	:SetIcon('icon16/information.png')

if SERVER then
	-- Hook into spawn events to check limits
	hook.Add("PlayerSpawnEffect", "PAS_Limits", pas.limits.CheckEffects)
	hook.Add("PlayerSpawnNPC", "PAS_Limits", pas.limits.CheckNPCs)
	hook.Add("PlayerSpawnProp", "PAS_Limits", pas.limits.CheckProps)
	hook.Add("PlayerSpawnRagdoll", "PAS_Limits", pas.limits.CheckRagdolls)
	hook.Add("PlayerSpawnSENT", "PAS_Limits", pas.limits.CheckSENTs)
	hook.Add("PlayerSpawnSWEP", "PAS_Limits", pas.limits.CheckSWEPs)
	hook.Add("PlayerSpawnVehicle", "PAS_Limits", pas.limits.CheckVehicles)

	-- Initialize after a delay to ensure everything is loaded
	timer.Simple(1, function()
		pas.limits.Initialize()
	end)
end