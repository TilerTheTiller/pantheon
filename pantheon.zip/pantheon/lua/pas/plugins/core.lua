-- Helper function to find empty position (from DarkRP/SAM)
local function FindEmptyPos(pos, ignore)
	local function IsEmpty(vector, ent)
		local point = util.PointContents(vector)
		local valid = point ~= CONTENTS_SOLID
			and point ~= CONTENTS_MOVEABLE
			and point ~= CONTENTS_LADDER
			and point ~= CONTENTS_PLAYERCLIP
			and point ~= CONTENTS_MONSTERCLIP
		if not valid then return false end

		local ents_found = ents.FindInSphere(vector, 35)
		for i = 1, #ents_found do
			local v = ents_found[i]
			if (v:IsNPC() or v:IsPlayer() or v:GetClass() == "prop_physics") and v ~= ent then
				return false
			end
		end

		return true
	end

	local distance, step, area = 600, 30, Vector(16, 16, 64)
	local north_vec, east_vec, up_vec = Vector(0, 0, 0), Vector(0, 0, 0), Vector(0, 0, 0)

	if IsEmpty(pos, ignore) and IsEmpty(pos + area, ignore) then
		return pos
	end

	for j = step, distance, step do
		for i = -1, 1, 2 do
			local k = j * i

			-- North/South
			north_vec.x = k
			if IsEmpty(pos + north_vec, ignore) and IsEmpty(pos + north_vec + area, ignore) then
				return pos + north_vec
			end

			-- East/West
			east_vec.y = k
			if IsEmpty(pos + east_vec, ignore) and IsEmpty(pos + east_vec + area, ignore) then
				return pos + east_vec
			end

			-- Up/Down
			up_vec.z = k
			if IsEmpty(pos + up_vec, ignore) and IsEmpty(pos + up_vec + area, ignore) then
				return pos + up_vec
			end
		end
	end

	return pos
end

-- Kick command
pas.cmd.Create('kick', function(pl, args)
	local target = args[1]
	local reason = table.concat(args, ' ', 2) or 'No reason'
	
	if not target then
		return false -- This will trigger automatic usage display
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found: ' .. target, 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if not pas.ranks.CanTarget(pl, targ) then
			pas.notify(pl, 'You cannot target ' .. targ:Nick(), 1)
			continue
		end
		
		targ:Kick(reason)
		pas.notify_all(pas.Term('PlayerKicked'), targ, pl, reason)
		pas.log.Add('Command', pl:Nick() .. ' kicked ' .. targ:Nick() .. ' - Reason: ' .. reason)
	end
end)
	:AddArg('player', 'target')
	:AddArg('reason', 'reason', true) -- true = optional
	:SetFlag('k')
	:SetHelp('Kick a player from the server')
	:SetIcon('icon16/delete.png')
	:AddAlias('boot')

-- Ban command
pas.cmd.Create('ban', function(pl, args)
	local target = args[1]
	local duration = args[2] or '0'
	local reason = table.concat(args, ' ', 3) or 'No reason'
	
	if not target then
		return false -- This will trigger automatic usage display
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	local time = pas.parser.ParseTime(duration)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found: ' .. target, 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if not pas.ranks.CanTarget(pl, targ) then
			pas.notify(pl, 'You cannot target ' .. targ:Nick(), 1)
			continue
		end
		
		pas.bans.Add(targ:SteamID64(), pl:SteamID64(), reason, time)
		targ:Kick('Banned: ' .. reason)
		
		local timeStr = pas.parser.FormatTime(time)
		pas.notify_all(pas.Term('PlayerBanned'), targ, pl, reason, timeStr)
		pas.log.Add('Command', pl:Nick() .. ' banned ' .. targ:Nick() .. ' for ' .. timeStr .. ' - Reason: ' .. reason)
	end
end)
	:AddArg('player', 'target')
	:AddArg('duration', 'duration', true) -- Optional - defaults to permanent
	:AddArg('reason', 'reason', true) -- Optional
	:SetFlag('b')
	:SetHelp('Ban a player from the server')
	:SetIcon('icon16/stop.png')

-- Unban command
pas.cmd.Create('unban', function(pl, args)
	local steamid = args[1]
	
	if not steamid then
		return false
	end
	
	steamid = pas.InfoTo64(steamid)
	
	pas.bans.Remove(steamid, function()
		local name = pas.data.GetName(steamid) or steamid
		pas.notify_all(pas.Term('PlayerUnbanned'), name, pl)
		pas.log.Add('Ban', pl:Nick() .. ' unbanned ' .. name)
	end)
end)
	:AddArg('steamid', 'steamid')
	:SetFlag('b')
	:SetHelp('Unban a player')
	:SetIcon('icon16/accept.png')

-- Set rank command
pas.cmd.Create('setrank', function(pl, args)
	local target = args[1]
	local rank = args[2]
	
	if not target or not rank then
		return false -- This will trigger automatic usage display
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	local rankObj = pas.ranks.Get(rank)
	
	if not rankObj then
		pas.notify(pl, 'Invalid rank: ' .. rank, 1)
		pas.notify(pl, 'Available ranks: ' .. table.concat(pas.ranks.GetNames(), ', '), 0)
		return
	end
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found: ' .. target, 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if not pas.ranks.CanTarget(pl, targ) then
			pas.notify(pl, 'You cannot target ' .. targ:Nick(), 1)
			continue
		end
		
		pas.data.SetRank(targ, rank, 'user', 0)
		pas.notify_all(pas.Term('RankSet'), pl, targ, rankObj:GetNiceName())
		pas.log.Add('Command', pl:Nick() .. ' set ' .. targ:Nick() .. '\'s rank to ' .. rankObj:GetNiceName())
	end
end)
	:AddArg('player', 'target')
	:AddArg('rank', 'rank')
	:SetFlag('r')
	:SetHelp('Set a player\'s rank')
	:SetIcon('icon16/group_gear.png')
	:AddAlias('setusergroup')

-- Goto command
pas.cmd.Create('goto', function(pl, args)
	local target = args[1]
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	local targ = targets[1]
	
	-- Save last position for return command
	pl.pas_last_pos = pl:GetPos()
	pl.pas_last_ang = pl:EyeAngles()
	
	-- Find empty position near target
	local newPos = FindEmptyPos(targ:GetPos(), pl)
	pl:SetPos(newPos)
	pl:SetEyeAngles((targ:EyePos() - pl:EyePos()):Angle())
	
	pas.notify(pl, 'Teleported to ' .. targ:Nick(), 0)
end)
	:AddArg('player', 'target')
	:SetFlag('m')
	:SetHelp('Teleport to a player')
	:SetIcon('icon16/arrow_right.png')

-- Bring command
pas.cmd.Create('bring', function(pl, args)
	local target = args[1]
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		-- Save last position for return command
		targ.pas_last_pos = targ:GetPos()
		targ.pas_last_ang = targ:EyeAngles()
		
		-- Find empty position near the admin
		local newPos = FindEmptyPos(pl:GetPos(), targ)
		targ:SetPos(newPos)
		targ:SetEyeAngles((pl:EyePos() - targ:EyePos()):Angle())
		
		pas.notify(pl, 'Brought ' .. targ:Nick(), 0)
	end
end)
	:AddArg('player', 'target')
	:SetFlag('m')
	:SetHelp('Bring a player to you')
	:SetIcon('icon16/arrow_left.png')
	:AddAlias('tp')

-- Noclip command
pas.cmd.Create('noclip', function(pl, args)
	if pl:GetMoveType() == MOVETYPE_NOCLIP then
		pl:SetMoveType(MOVETYPE_WALK)
		pas.notify(pl, 'Noclip disabled', 0)
	else
		pl:SetMoveType(MOVETYPE_NOCLIP)
		pas.notify(pl, 'Noclip enabled', 0)
	end
end)
	:SetFlag({'m', 'g'})
	:SetHelp('Toggle noclip')
	:SetIcon('icon16/user_go.png')

-- Slay command
pas.cmd.Create('slay', function(pl, args)
	local target = args[1]
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if not pas.ranks.CanTarget(pl, targ) then
			pas.notify(pl, 'You cannot target ' .. targ:Nick(), 1)
			continue
		end
		
		targ:Kill()
		pas.notify_all(pl:Nick() .. ' slayed ' .. targ:Nick(), 0)
		pas.log.Add('Command', pl:Nick() .. ' slayed ' .. targ:Nick())
	end
end)
	:AddArg('player', 'target')
	:SetFlag('a')
	:SetHelp('Kill a player')
	:SetIcon('icon16/cross.png')
	:AddAlias('kill')

-- God mode command
pas.cmd.Create('god', function(pl, args)
	local target = args[1] or '^'
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	for _, targ in ipairs(targets) do
		if targ:HasGodMode() then
			targ:GodDisable()
			pas.notify(pl, 'God mode disabled for ' .. targ:Nick(), 0)
		else
			targ:GodEnable()
			pas.notify(pl, 'God mode enabled for ' .. targ:Nick(), 0)
		end
	end
end)
	:AddArg('player', 'target', true) -- Optional, defaults to self
	:SetFlag({'a', 'g'})
	:SetHelp('Toggle god mode')
	:SetIcon('icon16/shield.png')

-- Freeze command
pas.cmd.Create('freeze', function(pl, args)
	local target = args[1]
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		targ:Freeze(true)
		pas.notify_all(pl:Nick() .. ' froze ' .. targ:Nick(), 0)
	end
end)
	:AddArg('player', 'target')
	:SetFlag({'m', 'g'})
	:SetHelp('Freeze a player')
	:SetIcon('icon16/lock.png')

-- Unfreeze command
pas.cmd.Create('unfreeze', function(pl, args)
	local target = args[1]
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		targ:Freeze(false)
		pas.notify_all(pl:Nick() .. ' unfroze ' .. targ:Nick(), 0)
	end
end)
	:AddArg('player', 'target')
	:SetFlag('m')
	:SetHelp('Unfreeze a player')
	:SetIcon('icon16/lock_open.png')

-- Create rank command
pas.cmd.Create('createrank', function(pl, args)
	local rankName = args[1]
	local immunity = tonumber(args[2]) or 0
	local flags = args[3] or 'u'
	
	if not rankName then
		return false
	end
	
	-- Check if rank already exists
	if pas.ranks.Get(rankName) then
		pas.notify(pl, 'Rank "' .. rankName .. '" already exists', 1)
		return
	end
	
	-- Find next available ID
	local nextID = 1
	for id = 1, 100 do
		if not pas.ranks.Get(id) then
			nextID = id
			break
		end
	end
	
	-- Parse flags
	local flagList = {}
	if flags and flags ~= '' then
		for flag in string.gmatch(flags, '[^,]+') do
			flag = string.Trim(flag):lower()
			if pas.flags.list[flag] then
				table.insert(flagList, flag)
			end
		end
	end
	
	-- Create the rank
	local newRank = pas.ranks.Create(rankName, nextID)
		:SetImmunity(immunity)
		:SetFlags(flagList)
	
	-- Set privilege levels based on flags
	if table.HasValue(flagList, 's') or table.HasValue(flagList, '*') then
		newRank:SetSuperAdmin(true)
	elseif table.HasValue(flagList, 'a') then
		newRank:SetAdmin(true)
	elseif table.HasValue(flagList, 'v') then
		newRank:SetVIP(true)
	end
	
	-- Log the creation
	pas.notify_all('Rank "' .. rankName .. '" created by ' .. pl:Nick(), 0)
	pas.log.Add('Rank', pl:Nick() .. ' created rank: ' .. rankName .. ' (ID: ' .. nextID .. ', Immunity: ' .. immunity .. ')')
	
	pas.notify(pl, 'Created rank "' .. rankName .. '" with ID ' .. nextID, 0)
	pas.notify(pl, 'Immunity: ' .. immunity .. ', Flags: ' .. table.concat(flagList, ','), 0)
end)
	:AddArg('string', 'rank name')
	:AddArg('number', 'immunity level', true) -- Optional, defaults to 0
	:AddArg('string', 'flags (comma-separated)', true) -- Optional, defaults to 'u'
	:SetFlag('r')
	:SetHelp('Create a new rank')
	:SetIcon('icon16/group_add.png')

-- Update rank command
pas.cmd.Create('updaterank', function(pl, args)
	local rankName = args[1]
	local property = args[2]
	local value = args[3]
	
	if not rankName or not property or not value then
		return false
	end
	
	local rank = pas.ranks.Get(rankName)
	if not rank then
		pas.notify(pl, 'Rank "' .. rankName .. '" not found', 1)
		return
	end
	
	property = property:lower()
	
	if property == 'immunity' then
		local immunity = tonumber(value)
		if not immunity then
			pas.notify(pl, 'Invalid immunity value', 1)
			return
		end
		
		rank:SetImmunity(immunity)
		pas.notify(pl, 'Set immunity for "' .. rankName .. '" to ' .. immunity, 0)
		
	elseif property == 'flags' then
		-- Parse flags
		local flagList = {}
		for flag in string.gmatch(value, '[^,]+') do
			flag = string.Trim(flag):lower()
			if pas.flags.list[flag] then
				table.insert(flagList, flag)
			end
		end
		
		-- Clear existing flags and set new ones
		rank.Flags = {}
		rank:SetFlags(flagList)
		
		pas.notify(pl, 'Updated flags for "' .. rankName .. '" to: ' .. table.concat(flagList, ','), 0)
		
	elseif property == 'vip' then
		local boolVal = tobool(value)
		rank:SetVIP(boolVal)
		pas.notify(pl, 'Set VIP for "' .. rankName .. '" to ' .. tostring(boolVal), 0)
		
	elseif property == 'admin' then
		local boolVal = tobool(value)
		rank:SetAdmin(boolVal)
		pas.notify(pl, 'Set Admin for "' .. rankName .. '" to ' .. tostring(boolVal), 0)
		
	elseif property == 'superadmin' then
		local boolVal = tobool(value)
		rank:SetSuperAdmin(boolVal)
		pas.notify(pl, 'Set SuperAdmin for "' .. rankName .. '" to ' .. tostring(boolVal), 0)
		
	elseif property == 'root' then
		local boolVal = tobool(value)
		rank:SetRoot(boolVal)
		pas.notify(pl, 'Set Root for "' .. rankName .. '" to ' .. tostring(boolVal), 0)
		
	else
		pas.notify(pl, 'Invalid property. Use: immunity, flags, vip, admin, superadmin, root', 1)
		return
	end
	
	-- Log the update
	pas.notify_all('Rank "' .. rankName .. '" updated by ' .. pl:Nick(), 0)
	pas.log.Add('Rank', pl:Nick() .. ' updated rank: ' .. rankName .. ' - ' .. property .. ' = ' .. value)
end)
	:AddArg('rank', 'rank')
	:AddArg('string', 'property (immunity|flags|vip|admin|superadmin|root)')
	:AddArg('string', 'value')
	:SetFlag('r')
	:SetHelp('Update rank properties')
	:SetIcon('icon16/group_edit.png')

-- Delete rank command
pas.cmd.Create('deleterank', function(pl, args)
	local rankName = args[1]
	
	if not rankName then
		return false
	end
	
	local rank = pas.ranks.Get(rankName)
	if not rank then
		pas.notify(pl, 'Rank "' .. rankName .. '" not found', 1)
		return
	end
	
	-- Prevent deletion of essential ranks
	local protectedRanks = {'user', 'superadmin', 'root'}
	for _, protected in ipairs(protectedRanks) do
		if rank:GetName():lower() == protected then
			pas.notify(pl, 'Cannot delete protected rank "' .. rankName .. '"', 1)
			return
		end
	end
	
	-- Check if any players have this rank
	local playersWithRank = {}
	for _, player in ipairs(player.GetAll()) do
		if player:GetRank():lower() == rank:GetName():lower() then
			table.insert(playersWithRank, player:Nick())
		end
	end
	
	if #playersWithRank > 0 then
		pas.notify(pl, 'Cannot delete rank - players still have it:', 1)
		for _, nick in ipairs(playersWithRank) do
			pas.notify(pl, '- ' .. nick, 1)
		end
		pas.notify(pl, 'Change their ranks first using /setrank', 1)
		return
	end
	
	-- Remove from storage
	local rankID = rank:GetID()
	local rankNiceName = rank:GetNiceName()
	
	pas.ranks.Stored[rankID] = nil
	pas.ranks.Stored[rank:GetName()] = nil
	pas.ranks.Stored[rankNiceName] = nil
	
	-- Log the deletion
	pas.notify_all('Rank "' .. rankNiceName .. '" deleted by ' .. pl:Nick(), 0)
	pas.log.Add('Rank', pl:Nick() .. ' deleted rank: ' .. rankNiceName .. ' (ID: ' .. rankID .. ')')
	
	pas.notify(pl, 'Deleted rank "' .. rankNiceName .. '"', 0)
end)
	:AddArg('rank', 'rank')
	:SetFlag('r')
	:SetHelp('Delete a rank')
	:SetIcon('icon16/group_delete.png')
