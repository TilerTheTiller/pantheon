--[[
	PANTHEON - Sitroom System
	Allows staff to set and teleport to sitroom positions
]]--

pas.sitroom = pas.sitroom or {}
pas.sitroom.Positions = pas.sitroom.Positions or {}

-- Load sitroom positions from data
function pas.sitroom.Load()
	if SERVER then
		local data = pas.data.Get('sitroom_positions')
		if data then
			pas.sitroom.Positions = data
			print('[PANTHEON] Loaded ' .. table.Count(data) .. ' sitroom positions')
		end
	end
end

-- Save sitroom positions
function pas.sitroom.Save()
	if SERVER then
		pas.data.Set('sitroom_positions', pas.sitroom.Positions)
	end
end

-- Set a sitroom position
function pas.sitroom.SetPosition(index, pos, ang)
	pas.sitroom.Positions[index] = {
		pos = pos,
		ang = ang or Angle(0, 0, 0)
	}
	pas.sitroom.Save()
end

-- Get a sitroom position
function pas.sitroom.GetPosition(index)
	return pas.sitroom.Positions[index]
end

-- Get all positions
function pas.sitroom.GetAll()
	return pas.sitroom.Positions
end

-- Remove a position
function pas.sitroom.RemovePosition(index)
	pas.sitroom.Positions[index] = nil
	pas.sitroom.Save()
end

-- Teleport player to sitroom position
function pas.sitroom.TeleportTo(pl, index)
	local pos = pas.sitroom.GetPosition(index)
	if not pos then return false end
	
	if pl:InVehicle() then
		pl:ExitVehicle()
	end
	
	pl:SetPos(pos.pos)
	pl:SetEyeAngles(pos.ang)
	
	return true
end

if SERVER then
	-- Load on initialize
	hook.Add('Initialize', 'PANTHEON_Sitroom_Load', function()
		timer.Simple(1, function()
			if pas.data and pas.data.Get then
				pas.sitroom.Load()
			else
				print('[PANTHEON] Sitroom: Data system not ready, skipping load')
			end
		end)
	end)
	
	-- Command: /setsitroom <number> - Set a sitroom position
	if not pas.cmd then
		ErrorNoHalt('[PANTHEON] Sitroom plugin: Commands system not loaded!\n')
		return
	end
	
	pas.cmd.Create('setsitroom', function(pl, args)
		if not pl:IsPlayer() then
			pas.notify(pl, 'Console cannot use this command', 1)
			return
		end
		
		local index = tonumber(args[1])
		
		if not index then
			pas.notify(pl, 'Usage: !setsitroom <number>', 1)
			return
		end
		
		if index < 1 or index > 10 then
			pas.notify(pl, 'Sitroom number must be between 1 and 10', 1)
			return
		end
		
		local pos = pl:GetPos()
		local ang = pl:EyeAngles()
		
		pas.sitroom.SetPosition(index, pos, ang)
		
		pas.notify(pl, 'Sitroom position ' .. index .. ' set', 0)
		pas.log.Add('Command', pl:Nick() .. ' set sitroom position ' .. index)
		
		-- Notify all staff
		for _, v in pairs(player.GetAll()) do
			if v:HasFlag('s') and v ~= pl then
				pas.notify(v, pl:Nick() .. ' set sitroom position ' .. index, 0)
			end
		end
	end)
		:SetFlag('s')
		:SetHelp('Set a sitroom teleport position (1-10)')
		:SetIcon('icon16/house.png')
	
	-- Command: /delsitroom <number> - Delete a sitroom position
	pas.cmd.Create('delsitroom', function(pl, args)
		local index = tonumber(args[1])
		
		if not index then
			pas.notify(pl, 'Usage: !delsitroom <number>', 1)
			return
		end
		
		if not pas.sitroom.GetPosition(index) then
			pas.notify(pl, 'Sitroom position ' .. index .. ' does not exist', 1)
			return
		end
		
		pas.sitroom.RemovePosition(index)
		
		pas.notify(pl, 'Sitroom position ' .. index .. ' removed', 0)
		pas.log.Add('Command', (pl:IsPlayer() and pl:Nick() or 'Console') .. ' removed sitroom position ' .. index)
	end)
		:SetFlag('s')
		:SetHelp('Remove a sitroom position')
		:SetIcon('icon16/house_delete.png')
	
	-- Command: /sitroom [player] - Teleport to random sitroom or bring player to sitroom
	pas.cmd.Create('sitroom', function(pl, args)
		if not pl:IsPlayer() then
			pas.notify(pl, 'Console cannot use this command', 1)
			return
		end
		
		local count = table.Count(pas.sitroom.Positions)
		if count == 0 then
			pas.notify(pl, 'No sitroom positions set. Use !setsitroom <number> to create one', 1)
			return
		end
		
		-- Get random sitroom position
		local availableRooms = {}
		for i = 1, 10 do
			if pas.sitroom.GetPosition(i) then
				table.insert(availableRooms, i)
			end
		end
		
		local index = availableRooms[math.random(#availableRooms)]
		local pos = pas.sitroom.GetPosition(index)
		
		-- Check if bringing another player
		if args[1] then
			if not pl:HasFlag('a') then
				pas.notify(pl, 'You do not have permission to bring players to sitroom', 1)
				return
			end
			
			local targets = pas.parser.ParsePlayer(args[1], pl)
			
			if #targets == 0 then
				pas.notify(pl, 'Player not found', 1)
				return
			end
			
			for _, target in ipairs(targets) do
				if not target:Alive() then
					target:Spawn()
				end
				
				if target:InVehicle() then
					target:ExitVehicle()
				end
				
				target.LastPos = target:GetPos()
				target:SetPos(pos.pos)
				target:SetEyeAngles(pos.ang)
				
				pas.notify(target, pl:Nick() .. ' brought you to sitroom', 0)
			end
			
			-- Also teleport the admin
			pl.LastPos = pl:GetPos()
			pl:SetPos(pos.pos)
			pl:SetEyeAngles(pos.ang)
			
			local targetNames = table.concat(table.GetKeys(targets, function(k, v) return v:Nick() end), ', ')
			pas.notify(pl, 'Brought ' .. targetNames .. ' to sitroom', 0)
			pas.log.Add('Command', pl:Nick() .. ' brought ' .. targetNames .. ' to sitroom')
		else
			-- Just teleport self
			pl.LastPos = pl:GetPos()
			pas.sitroom.TeleportTo(pl, index)
			
			pas.notify(pl, 'Teleported to sitroom', 0)
			pas.log.Add('Command', pl:Nick() .. ' teleported to sitroom')
		end
	end)
		:SetFlag('m')
		:AddAlias('sr')
		:SetHelp('Teleport to a random sitroom or bring a player there')
		:SetIcon('icon16/house_go.png')
	
	-- Command: /listsitrooms - List all sitroom positions
	pas.cmd.Create('listsitrooms', function(pl, args)
		local count = table.Count(pas.sitroom.Positions)
		
		if count == 0 then
			pas.notify(pl, 'No sitroom positions set', 1)
			return
		end
		
		pas.notify(pl, 'Sitroom Positions (' .. count .. '):', 0)
		for i = 1, 10 do
			local pos = pas.sitroom.GetPosition(i)
			if pos then
				local posStr = string.format('%.0f, %.0f, %.0f', pos.pos.x, pos.pos.y, pos.pos.z)
				pas.notify(pl, '  [' .. i .. '] Position: ' .. posStr, 0)
			end
		end
	end)
		:SetFlag('m')
		:SetHelp('List all sitroom positions')
		:SetIcon('icon16/house.png')
end
