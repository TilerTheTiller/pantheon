-- Anti-Cheat Plugin Commands
if (SERVER) then
	AddCSLuaFile()
	util.AddNetworkString('pas.OpenAntiCheat')
end

if CLIENT then
	-- Receive request to open AC viewer
	net.Receive('pas.OpenAntiCheat', function()
		if pas.ac and pas.ac.OpenViewer then
			pas.ac.OpenViewer()
		else
			print('[PANTHEON] Anti-cheat client not loaded yet')
		end
	end)
end

-- Command to open AC viewer
pas.cmd.Create('anticheat', function(pl, args)
	if CLIENT then return end
	
	net.Start('pas.OpenAntiCheat')
	net.Send(pl)
end)
	:SetFlag('m')
	:SetHelp('Open anti-cheat monitor')
	:SetIcon('icon16/shield.png')
	:AddAlias('ac')
	:AddAlias('acmonitor')

-- Command to whitelist player
pas.cmd.Create('acwhitelist', function(pl, args)
	if CLIENT then return end
	
	if not pas.ac or not pas.ac.playerData then
		pas.notify(pl, 'Anti-cheat system not loaded', 1)
		return
	end
	
	if not args[1] then
		pas.notify(pl, 'Usage: /acwhitelist <player>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(args[1], pl)
	if not targets or #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	local target = targets[1]
	
	local data = pas.ac.playerData[target]
	if data then
		data.whitelisted = true
		pas.notify(pl, target:Nick() .. ' whitelisted from anti-cheat', 0)
		pas.log.Add('admin', pl:Nick() .. ' whitelisted ' .. target:Nick() .. ' from anti-cheat', 
			pl:SteamID(), target:SteamID())
	end
end)
	:SetFlag('r')
	:SetHelp('Whitelist player from anti-cheat <player>')
	:SetIcon('icon16/shield_add.png')
	:AddAlias('acwl')

-- Command to reset player AC data
pas.cmd.Create('acreset', function(pl, args)
	if CLIENT then return end
	
	if not pas.ac or not pas.ac.playerData then
		pas.notify(pl, 'Anti-cheat system not loaded', 1)
		return
	end
	
	if not args[1] then
		pas.notify(pl, 'Usage: /acreset <player>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(args[1], pl)
	if not targets or #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	local target = targets[1]
	
	pas.ac.playerData[target] = nil
	timer.Simple(0.1, function()
		if IsValid(target) then
			-- Re-initialize with clean data
			pas.ac.playerData[target] = {
				lastSpeed = 0,
				speedViolations = 0,
				lastSpeedCheck = 0,
				lastAimAngles = Angle(0, 0, 0),
				aimbotSnaps = 0,
				lastAimbotCheck = 0,
				consecutiveJumps = 0,
				lastJumpTime = 0,
				onGround = true,
				messages = {},
				lastMessageTime = 0,
				detections = {},
				totalDetections = 0,
				whitelisted = false
			}
		end
	end)
	
	pas.notify(pl, 'Reset AC data for ' .. target:Nick(), 0)
	pas.log.Add('admin', pl:Nick() .. ' reset AC data for ' .. target:Nick(), 
		pl:SteamID(), target:SteamID())
end)
	:SetFlag('r')
	:SetHelp('Reset player anti-cheat detections <player>')
	:SetIcon('icon16/shield_delete.png')

print('[PANTHEON] Anti-Cheat commands loaded')
