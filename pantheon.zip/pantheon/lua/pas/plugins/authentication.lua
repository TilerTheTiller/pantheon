-- Authentication commands for PANTHEON
if (SERVER) then
	AddCSLuaFile()
end

-- Login command
pas.cmd.Create('pas_login', function(pl, args)
	if CLIENT then return end
	
	-- Check if password system is set up
	if not pl.pas_PasswordLoaded then
		pas.notify(pl, "Loading authentication data, please wait...", 1)
		if pas.auth and pas.auth.LoadPassword then
			pas.auth.LoadPassword(pl)
		end
		return
	end
	
	-- Check if needs setup
	if pas.auth.NeedsSetup(pl) then
		pas.notify(pl, "You need to set up your admin password first.", 1)
		
		net.Start("pas.AuthRequired")
			net.WriteBool(true) -- needs setup
		net.Send(pl)
		return
	end
	
	-- Show login prompt
	net.Start("pas.AuthRequired")
		net.WriteBool(false) -- needs login
	net.Send(pl)
end)
	:SetFlag('u')
	:SetHelp('Log in to authenticate your admin session')
	:SetIcon('icon16/key.png')
	:AddAlias('login')

-- Logout command
pas.cmd.Create('pas_logout', function(pl, args)
	if CLIENT then return end
	
	if pas.auth.IsAuthenticated(pl) then
		pas.auth.Deauthenticate(pl)
	else
		pas.notify(pl, "You are not logged in.", 1)
	end
end)
	:SetFlag('u')
	:SetHelp('Log out of your admin session')
	:SetIcon('icon16/key_delete.png')
	:AddAlias('logout')

-- Change password command
pas.cmd.Create('pas_setpass', function(pl, args)
	if CLIENT then return end
	
	-- This command requires authentication (except for first-time setup)
	if not pas.auth.NeedsSetup(pl) and not pas.auth.IsAuthenticated(pl) then
		pas.notify(pl, "You must be authenticated to change your password. Use /pas_login first.", 1)
		return
	end
	
	local newPass = table.concat(args, " ")
	
	if #newPass < 6 then
		pas.notify(pl, "Password must be at least 6 characters long.", 1)
		pas.notify(pl, "Usage: /pas_setpass <new password>", 1)
		return
	end
	
	-- Save new password
	if pas.auth.SavePassword(pl, newPass) then
		pas.notify(pl, "Password updated successfully!", 0)
		
		-- Log password change
		if pas.log and pas.log.Add then
			pas.log.Add('auth', pl:Nick() .. ' changed their admin password', pl:SteamID())
		end
	end
end)
	:SetFlag('u')
	:SetHelp('Set or change your admin password')
	:SetIcon('icon16/lock_edit.png')
	:AddAlias('setpass')

-- Auth status command
pas.cmd.Create('pas_authstatus', function(pl, args)
	if CLIENT then return end
	
	if not pl.pas_PasswordLoaded then
		pas.notify(pl, "Authentication data not loaded yet.", 1)
		return
	end
	
	if pas.auth.NeedsSetup(pl) then
		pas.notify(pl, "Status: No password set - use /pas_login to set up", 1)
	elseif pas.auth.IsAuthenticated(pl) then
		local elapsed = CurTime() - pl.pas_AuthData.authTime
		local remaining = math.floor((pas.auth.SESSION_TIMEOUT - elapsed) / 60)
		pas.notify(pl, "Status: Authenticated - " .. remaining .. " minutes remaining", 0)
	else
		pas.notify(pl, "Status: Not authenticated - use /pas_login", 1)
	end
end)
	:SetFlag('u')
	:SetHelp('Check your authentication status')
	:SetIcon('icon16/information.png')
	:AddAlias('authstatus')

-- Force re-authentication for a player (admin only)
pas.cmd.Create('pas_forcelogout', function(pl, args)
	if CLIENT then return end
	
	local target = args[1]
	
	if not target then
		pas.notify(pl, 'Usage: !pas_forcelogout <player>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if pas.auth.IsAuthenticated(targ) then
			pas.auth.Deauthenticate(targ)
			pas.notify(pl, 'Forced logout for ' .. targ:Nick(), 0)
			pas.notify(targ, 'You have been logged out by ' .. pl:Nick(), 1)
			
			-- Log action
			if pas.log and pas.log.Add then
				pas.log.Add('auth', pl:Nick() .. ' forced logout for ' .. targ:Nick(), pl:SteamID())
			end
		else
			pas.notify(pl, targ:Nick() .. ' is not logged in', 1)
		end
	end
end)
	:SetFlag('s')
	:SetHelp('Force logout another admin')
	:SetIcon('icon16/lock_delete.png')
	:AddAlias('forcelogout')

pas.print('[PANTHEON] Authentication commands loaded')
