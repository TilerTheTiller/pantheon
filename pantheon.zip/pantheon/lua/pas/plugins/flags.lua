-- PANTHEON Admin System - Flag Management Commands

-- Command to give a flag to a player
pas.cmd.Create('giveflag', function(pl, args)
	local target = args[1]
	local flag = args[2]
	
	if not target or not flag then
		return false
	end
	
	-- Find the target player
	local targetPly = nil
	for _, ply in ipairs(player.GetAll()) do
		if ply:Nick():lower():find(target:lower(), 1, true) or ply:SteamID() == target then
			targetPly = ply
			break
		end
	end
	
	if not targetPly then
		return pas.Notify(pl, 'Player not found!', 1)
	end
	
	-- Check if flag exists
	if not pas.flags.list[flag] then
		return pas.Notify(pl, 'Invalid flag! Valid flags: ' .. table.concat(table.GetKeys(pas.flags.list), ', '), 1)
	end
	
	-- Give the flag
	if targetPly:GiveFlag(flag) then
		pas.Notify(pl, 'Gave flag "' .. flag .. '" to ' .. targetPly:Nick(), 0)
		pas.Notify(targetPly, 'You were given the "' .. flag .. '" flag by ' .. pl:Nick(), 0)
	else
		pas.Notify(pl, 'Failed to give flag!', 1)
	end
end)
	:AddArg('player', 'target')
	:AddArg('flag', 'flag')
	:SetFlag('r')
	:SetHelp('Give a custom flag to a player')
	:SetIcon('icon16/award_star_add.png')
	:AddAlias('gflag')

-- Command to remove a flag from a player
pas.cmd.Create('removeflag', function(pl, args)
	local target = args[1]
	local flag = args[2]
	
	if not target or not flag then
		return false
	end
	
	-- Find the target player
	local targetPly = nil
	for _, ply in ipairs(player.GetAll()) do
		if ply:Nick():lower():find(target:lower(), 1, true) or ply:SteamID() == target then
			targetPly = ply
			break
		end
	end
	
	if not targetPly then
		return pas.Notify(pl, 'Player not found!', 1)
	end
	
	-- Remove the flag
	if targetPly:RemoveFlag(flag) then
		pas.Notify(pl, 'Removed flag "' .. flag .. '" from ' .. targetPly:Nick(), 0)
		pas.Notify(targetPly, 'Your "' .. flag .. '" flag was removed by ' .. pl:Nick(), 1)
	else
		pas.Notify(pl, 'Failed to remove flag!', 1)
	end
end)
	:AddArg('player', 'target')
	:AddArg('flag', 'flag')
	:SetFlag('r')
	:SetHelp('Remove a custom flag from a player')
	:SetIcon('icon16/award_star_delete.png')
	:AddAlias('rflag')

-- Command to list all flags
pas.cmd.Create('listflags', function(pl, args)
	local target = args[1]
	
	if target then
		-- Show flags for a specific player
		local targetPly = nil
		for _, ply in ipairs(player.GetAll()) do
			if ply:Nick():lower():find(target:lower(), 1, true) or ply:SteamID() == target then
				targetPly = ply
				break
			end
		end
		
		if not targetPly then
			return pas.Notify(pl, 'Player not found!', 1)
		end
		
		local flags = targetPly:GetFlags()
		local flagList = {}
		for flag, _ in pairs(flags) do
			local info = pas.flags.GetFlagInfo(flag)
			if info then
				table.insert(flagList, flag .. ' (' .. info.name .. ')')
			else
				table.insert(flagList, flag)
			end
		end
		
		if #flagList == 0 then
			pas.Notify(pl, targetPly:Nick() .. ' has no flags', 0)
		else
			pas.Notify(pl, targetPly:Nick() .. ' flags: ' .. table.concat(flagList, ', '), 0)
		end
	else
		-- Show all available flags
		local flagList = {}
		for flag, info in pairs(pas.flags.list) do
			table.insert(flagList, flag .. ' = ' .. info.name)
		end
		table.sort(flagList)
		
		pas.Notify(pl, 'Available flags:', 0)
		for _, flagInfo in ipairs(flagList) do
			pas.Notify(pl, '  ' .. flagInfo, 0)
		end
	end
end)
	:AddArg('player', 'target', true) -- Optional - shows all flags if omitted
	:SetFlag('a')
	:SetHelp('List all flags or flags for a player')
	:SetIcon('icon16/information.png')
	:AddAlias('lflags')
	:AddAlias('flags')
