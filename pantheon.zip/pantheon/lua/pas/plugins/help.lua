-- Help system for PANTHEON commands
if (SERVER) then
	AddCSLuaFile()
end

-- Simple help command to list available commands
pas.cmd.Create('help', function(pl, args)
	-- Show list of available commands
	pas.notify(pl, '[HELP] Available commands:', 0)
	
	local availableCommands = {}
	for name, command in pairs(pas.cmd.GetTable()) do
		-- Check if player has access to this command
		local hasAccess = false
		if command.Flags then
			for _, flag in ipairs(command.Flags) do
				if pl:HasFlag(flag) then
					hasAccess = true
					break
				end
			end
		elseif command:GetFlag() then
			hasAccess = pl:HasFlag(command:GetFlag())
		else
			hasAccess = true
		end
		
		if hasAccess then
			table.insert(availableCommands, name)
		end
	end
	
	table.sort(availableCommands)
	
	local commandList = table.concat(availableCommands, ', ')
	pas.notify(pl, '[HELP] ' .. commandList, 0)
	pas.notify(pl, '[HELP] Use commands without args to see syntax', 0)
end)
	:SetFlag('u')
	:SetHelp('Show available commands')
	:SetIcon('icon16/help.png')

print('[PANTHEON] Help system loaded')