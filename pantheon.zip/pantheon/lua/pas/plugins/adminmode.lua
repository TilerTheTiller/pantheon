-- Admin Mode Plugin for PANTHEON
if (SERVER) then
	AddCSLuaFile()
end

-- Admin mode toggle command
pas.cmd.Create('adminmode', function(pl, args)
	if not IsValid(pl) or not pl:IsPlayer() then
		if IsValid(pl) then
			pl:ChatPrint("[ERROR] Console cannot use admin mode")
		end
		return
	end
	
	local currentMode = pl:GetAdminMode()
	local newMode = not currentMode
	
	-- Exit noclip if currently noclipping and DISABLING admin mode
	if pl:GetMoveType() == MOVETYPE_NOCLIP and not newMode then
		pl:ConCommand("noclip")
	end
	
	-- Wait a bit for noclip to process
	timer.Simple(0.25, function()
		if not IsValid(pl) then return end
		
		pl:SetAdminMode(newMode)
		
		local modeText = newMode and "now administrating" or "no longer administrating"
		
		-- Notify only valid players via ChatPrint
		for _, v in pairs(player.GetAll()) do
			if IsValid(v) then
				v:ChatPrint("[INFO] " .. pl:Nick() .. " is " .. modeText)
			end
		end
		
		pas.log.Add('Command', pl:Nick() .. ' toggled admin mode ' .. (newMode and 'on' or 'off'))
	end)
end)
	-- No arguments needed
	:SetFlag('a')
	:SetHelp('Toggle admin mode on/off')
	:SetIcon('icon16/shield.png')
	:AddAlias('am')

-- Prevent damage in admin mode (SHARED)
hook.Add("EntityTakeDamage", "PAS.AdminMode.NoDamage", function(target, dmginfo)
	local attacker = dmginfo:GetAttacker()
	if IsValid(attacker) and attacker:IsPlayer() and attacker:GetAdminMode() then
		return true -- Block damage
	end
end)

-- Physgun player pickup immunity check (SERVER)
if SERVER then
	hook.Add("PhysgunPickup", "PAS.PhysgunImmunity", function(pl, ent)
		-- Only check if the entity is a player
		if not IsValid(ent) or not ent:IsPlayer() then return end
		
		-- If the picker has the physgun flag, check immunity
		if pl:HasFlag('p') then
			-- Allow if the picker can target the entity based on immunity
			if pas.ranks.CanTarget(pl, ent) then
				return true -- Allow pickup
			else
				-- Notify admin they cannot pick up this player
				pas.notify(pl, 'You cannot physgun ' .. ent:Nick() .. ' (insufficient immunity)', 1)
				return false -- Prevent pickup
			end
		end
		
		-- If no physgun flag, let default behavior handle it
	end)
	
	-- Freeze/unfreeze players on right click with physgun
	hook.Add("OnPhysgunReload", "PAS.PhysgunFreeze", function(weapon, pl)
		if not IsValid(pl) or not pl:HasFlag('p') then return end
		
		local trace = pl:GetEyeTrace()
		local ent = trace.Entity
		
		-- Only work on players
		if not IsValid(ent) or not ent:IsPlayer() then return end
		
		-- Check immunity
		if not pas.ranks.CanTarget(pl, ent) then
			pas.notify(pl, 'You cannot freeze ' .. ent:Nick() .. ' (insufficient immunity)', 1)
			return false
		end
		
		-- Toggle freeze state
		local isFrozen = ent:IsFrozen()
		
		if isFrozen then
			-- Unfreeze the player
			ent:Freeze(false)
			-- Also ensure movetype is correct
			if ent:GetMoveType() == MOVETYPE_NONE then
				ent:SetMoveType(MOVETYPE_WALK)
			end
		else
			-- Freeze the player
			ent:Freeze(true)
		end
		
		-- Notify both players
		local action = isFrozen and 'unfroze' or 'froze'
		pas.notify(pl, string.upper(string.sub(action, 1, 1)) .. string.sub(action, 2) .. ' ' .. ent:Nick(), 0)
		pas.notify(ent, pl:Nick() .. ' ' .. action .. ' you', isFrozen and 0 or 1)
		pas.log.Add('Physgun', pl:Nick() .. ' ' .. action .. ' ' .. ent:Nick() .. ' with physgun')
		
		return false -- Prevent default physgun reload behavior
	end)
end

-- Add visual indicator for admin mode (CLIENT)
if CLIENT then
	-- Settings
	local showESP = CreateClientConVar("pas_adminmode_esp", "1", true, false, "Show player ESP in admin mode")
	local showIndicator = CreateClientConVar("pas_adminmode_indicator", "1", true, false, "Show admin mode indicator")
	local espDistance = CreateClientConVar("pas_adminmode_esp_distance", "2500", true, false, "Maximum ESP distance")
	
	-- Minimalist ESP for players
	local function DrawPlayerESP()
		local ply = LocalPlayer()
		if not IsValid(ply) or not ply:GetAdminMode() or not showESP:GetBool() then return end
		
		local maxDist = espDistance:GetInt()
		
		for _, target in pairs(player.GetAll()) do
			if not IsValid(target) or target == ply then continue end
			
			local distance = ply:GetPos():Distance(target:GetPos())
			if distance > maxDist then continue end
			
			local pos = target:GetPos() + Vector(0, 0, 75)
			local screenPos = pos:ToScreen()
			
			if screenPos.visible then
				local health = math.Clamp(target:Health(), 0, 100)
				local alpha = math.Clamp(255 * (1 - distance / maxDist), 80, 255)
				
				-- Health color gradient
				local healthPercent = health / 100
				local col = Color(
					255 * (1 - healthPercent),
					255 * healthPercent,
					50,
					alpha
				)
				
				-- Simple name
				draw.SimpleText(target:Nick(), "PANTHEON.14", screenPos.x, screenPos.y - 8, ColorAlpha(Color(255, 255, 255), alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				
				-- Minimal health indicator (single line)
				local lineWidth = 60
				local lineX = screenPos.x - lineWidth/2
				local lineY = screenPos.y + 4
				
				surface.SetDrawColor(0, 0, 0, alpha * 0.6)
				surface.DrawRect(lineX - 1, lineY - 1, lineWidth + 2, 3)
				
				surface.SetDrawColor(col.r, col.g, col.b, alpha)
				surface.DrawRect(lineX, lineY, lineWidth * healthPercent, 1)
			end
		end
	end
	
	-- Minimalist status indicator
	hook.Add("HUDPaint", "PAS.AdminMode.Indicator", function()
		local ply = LocalPlayer()
		if not IsValid(ply) or not ply:GetAdminMode() or not showIndicator:GetBool() then return end
		
		local isNoclip = ply:GetMoveType() == MOVETYPE_NOCLIP
		local isGhost = ply:GetCollisionGroup() ~= COLLISION_GROUP_PLAYER
		
		-- Simple text indicators (bottom left)
		local x = 12
		local y = ScrH() - 12
		local spacing = 20
		
		-- Build status list from bottom to top
		if isGhost then
			draw.SimpleText("GHOST", "PANTHEON.14", x, y, Color(150, 200, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
			y = y - spacing
		end
		
		if isNoclip then
			draw.SimpleText("NOCLIP", "PANTHEON.14", x, y, Color(150, 255, 150), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
			y = y - spacing
		end
		
		-- Admin mode (always shown)
		draw.SimpleText("ADMIN", "PANTHEON.14", x, y, ui.col.PANTHEON_LIGHT, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
		
		-- Subtle bottom accent
		local pulse = math.sin(CurTime() * 2) * 0.3 + 0.7
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 120 * pulse)
		surface.DrawRect(0, ScrH() - 2, ScrW(), 2)
	end)
	
	-- Draw ESP overlay
	hook.Add("HUDPaint", "PAS.AdminMode.ESP", DrawPlayerESP)
	
	-- Minimalist settings panel
	local function OpenAdminModeSettings()
		local frame = ui.components.CreateFrame('Admin Mode', 420, 280, 'shield')
		
		local y = 70
		
		-- ESP Toggle
		local espCheck = vgui.Create('DCheckBoxLabel', frame)
		espCheck:SetPos(20, y)
		espCheck:SetText('Player ESP')
		espCheck:SetFont('PANTHEON.16')
		espCheck:SetTextColor(ui.col.White)
		espCheck:SetValue(showESP:GetBool())
		espCheck.OnChange = function(pnl, val)
			RunConsoleCommand('pas_adminmode_esp', val and '1' or '0')
		end
		espCheck:SizeToContents()
		
		y = y + 30
		
		-- Indicator Toggle
		local indicatorCheck = vgui.Create('DCheckBoxLabel', frame)
		indicatorCheck:SetPos(20, y)
		indicatorCheck:SetText('Status Indicator')
		indicatorCheck:SetFont('PANTHEON.16')
		indicatorCheck:SetTextColor(ui.col.White)
		indicatorCheck:SetValue(showIndicator:GetBool())
		indicatorCheck.OnChange = function(pnl, val)
			RunConsoleCommand('pas_adminmode_indicator', val and '1' or '0')
		end
		indicatorCheck:SizeToContents()
		
		y = y + 40
		
		-- ESP Distance
		local distLabel = vgui.Create('DLabel', frame)
		distLabel:SetPos(20, y)
		distLabel:SetText('ESP Range')
		distLabel:SetFont('PANTHEON.14')
		distLabel:SetTextColor(ui.col.TEXT_DIM)
		distLabel:SizeToContents()
		
		y = y + 20
		
		local distSlider = vgui.Create('DNumSlider', frame)
		distSlider:SetPos(20, y)
		distSlider:SetSize(380, 25)
		distSlider:SetMin(500)
		distSlider:SetMax(5000)
		distSlider:SetDecimals(0)
		distSlider:SetValue(espDistance:GetInt())
		distSlider:SetText('')
		distSlider.OnValueChanged = function(pnl, val)
			RunConsoleCommand('pas_adminmode_esp_distance', tostring(math.Round(val)))
		end
		
		y = y + 50
		
		-- Close button
		ui.components.CreateButton(frame, 'Done', 20, y, 380, 36, function()
			frame:Close()
		end, 'check', 'primary')
	end
	
	-- Console command to open settings
	concommand.Add('pas_adminmode_settings', OpenAdminModeSettings)
end