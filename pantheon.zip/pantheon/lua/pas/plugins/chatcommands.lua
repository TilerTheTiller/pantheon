-- PANTHEON Chat Commands Plugin
if CLIENT then return end

-- Mute chat command (from D3A)
pas.cmd.Create('mutechat', function(pl, args)
	local target = args[1]
	local time = tonumber(args[2]) or 300 -- Default 5 minutes
	
	if not target then
		return false -- This will trigger automatic usage display
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	if #targets == 0 then
		pas.notify(pl, 'Player not found: ' .. target, 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if targ.pas_ChatMuted then
			pas.notify(pl, targ:Nick() .. ' is already chat muted', 1)
			continue
		end
		
		targ.pas_ChatMuted = true
		targ.pas_ChatMuteTime = CurTime() + time
		
		pas.notify(pl, 'Chat muted ' .. targ:Nick() .. ' for ' .. time .. ' seconds', 0)
		pas.chat.Send(targ, 'WARNING', 'You have been chat muted for ' .. time .. ' seconds')
		pas.log.Add('Command', pl:Nick() .. ' chat muted ' .. targ:Nick() .. ' for ' .. time .. ' seconds')
		
		-- Auto-unmute timer
		timer.Create('pas_chatmute_' .. targ:SteamID64(), time, 1, function()
			if IsValid(targ) then
				targ.pas_ChatMuted = nil
				targ.pas_ChatMuteTime = nil
				pas.chat.Send(targ, 'SUCCESS', 'You have been unmuted')
			end
		end)
	end
end)
	:AddArg('player', 'target')
	:AddArg('time_seconds', 'duration', true) -- Optional - defaults to 300
	:SetFlag('m')
	:SetHelp('Mute a player from chat')
	:SetIcon('icon16/comment_delete.png')

-- Unmute chat command
pas.cmd.Create('unmutechat', function(pl, args)
	local target = args[1]
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if not targ.pas_ChatMuted then
			pas.notify(pl, targ:Nick() .. ' is not chat muted', 1)
			continue
		end
		
		targ.pas_ChatMuted = nil
		targ.pas_ChatMuteTime = nil
		timer.Remove('pas_chatmute_' .. targ:SteamID64())
		
		pas.notify(pl, 'Chat unmuted ' .. targ:Nick(), 0)
		pas.chat.Send(targ, 'SUCCESS', 'You have been unmuted')
		pas.log.Add('Command', pl:Nick() .. ' chat unmuted ' .. targ:Nick())
	end
end)
	:AddArg('player', 'target')
	:SetFlag('m')
	:SetHelp('Unmute a player from chat')
	:SetIcon('icon16/comment_add.png')

-- Global OOC command
pas.cmd.Create('ooc', function(pl, args)
	local message = table.concat(args, ' ')
	if message == '' then
		return false
	end
	
	-- Send OOC message to all players
	for _, ply in ipairs(player.GetAll()) do
		if IsValid(ply) then
			ply:ChatPrint('(OOC) ' .. pl:Nick() .. ': ' .. message)
		end
	end
	
	pas.log.Add('Chat', pl:Nick() .. ' (OOC): ' .. message)
end)
	:AddArg('text', 'message')
	:SetFlag('u')
	:SetHelp('Send an out-of-character message')
	:SetIcon('icon16/comment.png')

-- Advertisement command (from D3A)
pas.cmd.Create('advert', function(pl, args)
	local message = table.concat(args, ' ')
	if message == '' then
		return false
	end
	
	-- Check cooldown
	if pl.pas_AdvertCooldown and CurTime() < pl.pas_AdvertCooldown then
		local remaining = math.ceil(pl.pas_AdvertCooldown - CurTime())
		pas.notify(pl, 'You must wait ' .. remaining .. ' seconds before advertising again', 1)
		return
	end
	
	-- Set cooldown (60 seconds)
	pl.pas_AdvertCooldown = CurTime() + 60
	
	-- Send advertisement
	for _, ply in ipairs(player.GetAll()) do
		if IsValid(ply) then
			ply:ChatPrint('[ADVERT] ' .. pl:Nick() .. ': ' .. message)
		end
	end
	
	pas.log.Add('Chat', pl:Nick() .. ' advertised: ' .. message)
end)
	:AddArg('text', 'message')
	:SetFlag('u')
	:SetHelp('Send an advertisement (60s cooldown)')
	:SetIcon('icon16/sound.png')

-- Clear chat command
pas.cmd.Create('clearchat', function(pl, args)
	-- Send empty lines to clear chat for all players
	for i = 1, 50 do
		for _, ply in ipairs(player.GetAll()) do
			if IsValid(ply) then
				ply:ChatPrint(' ')
			end
		end
	end
	
	pas.chat.Send(nil, 'ADMIN', 'Chat cleared by ' .. pl:Nick())
	pas.log.Add('Command', pl:Nick() .. ' cleared chat')
end)
	:SetFlag('a')
	:SetHelp('Clear the chat for all players')
	:SetIcon('icon16/page_white.png')

-- Hook to prevent muted players from chatting
hook.Add('PlayerSay', 'PANTHEON.ChatMute', function(ply, text)
	if ply.pas_ChatMuted then
		if CurTime() > (ply.pas_ChatMuteTime or 0) then
			-- Mute expired
			ply.pas_ChatMuted = nil
			ply.pas_ChatMuteTime = nil
			timer.Remove('pas_chatmute_' .. ply:SteamID64())
		else
			-- Still muted
			local remaining = math.ceil((ply.pas_ChatMuteTime or 0) - CurTime())
			pas.chat.Send(ply, 'WARNING', 'You are chat muted for ' .. remaining .. ' more seconds')
			return ''
		end
	end
end)

-- Help command - list all available commands
pas.cmd.Create('help', function(pl, args)
	local availableCommands = {}
	
	for name, cmd in pairs(pas.cmd.Stored) do
		local hasAccess = true
		
		-- Check if player has access
		if cmd.Flags then
			hasAccess = false
			for _, flag in ipairs(cmd.Flags) do
				if pl:HasFlag(flag) then
					hasAccess = true
					break
				end
			end
		elseif cmd:GetFlag() then
			hasAccess = pl:HasFlag(cmd:GetFlag())
		end
		
		if hasAccess then
			local helpText = cmd:GetHelp() or 'No description'
			table.insert(availableCommands, {name = name, help = helpText, flag = cmd:GetFlag() or 'none'})
		end
	end
	
	table.sort(availableCommands, function(a, b) return a.name < b.name end)
	
	pas.chat.Send(pl, 'INFO', '--- Available Commands ---')
	for _, cmdInfo in ipairs(availableCommands) do
		pas.chat.Send(pl, 'SUCCESS', '/' .. cmdInfo.name .. ' - ' .. cmdInfo.help)
	end
end)
	:SetFlag('u')
	:SetHelp('List all available commands')
	:SetIcon('icon16/help.png')

-- Time command - shows current server time
pas.cmd.Create('time', function(pl, args)
	local serverTime = os.date('%H:%M:%S', os.time())
	pas.chat.Send(pl, 'INFO', 'Server time: ' .. serverTime)
end)
	:SetFlag('u')
	:SetHelp('Shows current server time')
	:SetIcon('icon16/time.png')

-- Players command - shows online players
pas.cmd.Create('players', function(pl, args)
	local players = player.GetAll()
	pas.chat.Send(pl, 'INFO', 'Players online: ' .. #players .. '/' .. game.MaxPlayers())
	
	for _, ply in ipairs(players) do
		local steamid = ply:SteamID()
		local nick = ply:Nick()
		pas.chat.Send(pl, 'SUCCESS', '  ' .. nick .. ' (' .. steamid .. ')')
	end
end)
	:SetFlag('u')
	:SetHelp('Shows list of online players')
	:SetIcon('icon16/group.png')

-- Chat tags management command
pas.cmd.Create('chattags', function(pl, args)
	local action = args[1]
	
	if not action then
		return false
	end
	
	if action == 'reload' then
		-- Reload configuration
		include('pas/core/ui/chattags_config.lua')
		pas.chat.SyncTags() -- Sync to all clients
		pas.chat.Send(pl, 'SUCCESS', 'Chat tags configuration reloaded and synced!')
		
	elseif action == 'sync' then
		-- Manually sync tags to all clients
		pas.chat.SyncTags()
		pas.chat.Send(pl, 'SUCCESS', 'Chat tags synced to all clients!')
		
	elseif action == 'toggle' then
		local rank = args[2]
		if not rank then
			pas.chat.Send(pl, 'ERROR', 'Usage: /chattags toggle <rank>')
			return
		end
		
		rank = rank:lower()
		local tag = pas.chat.tags.GetTag(rank)
		
		if not tag then
			pas.chat.Send(pl, 'ERROR', 'Rank "' .. rank .. '" not found!')
			return
		end
		
		tag.enabled = not tag.enabled
		pas.chat.SyncTags() -- Sync changes to clients
		pas.chat.Send(pl, 'SUCCESS', 'Chat tag for "' .. rank .. '" ' .. (tag.enabled and 'enabled' or 'disabled') .. '!')
		
	elseif action == 'settext' then
		local rank = args[2]
		local text = args[3] or ''
		
		if not rank then
			pas.chat.Send(pl, 'ERROR', 'Usage: /chattags settext <rank> <text>')
			return
		end
		
		rank = rank:lower()
		pas.chat.tags.SetTagText(rank, text)
		pas.chat.SyncTags() -- Sync changes to clients
		pas.chat.Send(pl, 'SUCCESS', 'Chat tag text for "' .. rank .. '" set to "' .. text .. '"!')
		
	elseif action == 'list' then
		pas.chat.Send(pl, 'INFO', '=== CHAT TAGS CONFIGURATION ===')
		
		-- Sort ranks by priority (highest first)
		local sortedRanks = {}
		for rankName, config in pairs(pas.chat.tags.config) do
			table.insert(sortedRanks, {name = rankName, config = config})
		end
		
		table.sort(sortedRanks, function(a, b) 
			return a.config.priority > b.config.priority 
		end)
		
		for _, rankData in ipairs(sortedRanks) do
			local name = rankData.name
			local config = rankData.config
			local status = config.enabled and 'ENABLED' or 'DISABLED'
			local tag = config.tag ~= '' and config.tag or '[NO TAG]'
			
			pas.chat.Send(pl, 'INFO', name:upper() .. ': ' .. tag .. ' (' .. status .. ') [Priority: ' .. config.priority .. ']')
		end
		
	else
		pas.chat.Send(pl, 'INFO', 'Usage: /chattags <action> [args]')
		pas.chat.Send(pl, 'INFO', 'Actions:')
		pas.chat.Send(pl, 'INFO', '  reload - Reload configuration file')
		pas.chat.Send(pl, 'INFO', '  sync - Sync tags to all clients')
		pas.chat.Send(pl, 'INFO', '  toggle <rank> - Toggle tag visibility')
		pas.chat.Send(pl, 'INFO', '  settext <rank> <text> - Set tag text')
		pas.chat.Send(pl, 'INFO', '  list - Show all configured tags')
	end
end)
	:AddArg('string', 'action (reload|sync|toggle|settext|list)')
	:AddArg('string', 'rank', true) -- Optional
	:AddArg('text', 'text', true) -- Optional
	:SetFlag('s') -- Super admin only
	:SetHelp('Manage chat tags configuration')
	:SetIcon('icon16/tag.png')

-- Test command to display a player's rank tag
pas.cmd.Create('myrank', function(pl, args)
	local rank = pl:GetRank()
	local rankTag = pas.chat.tags.GetPlayerTag(pl)
	
	if rankTag and rankTag.enabled and rankTag.tag ~= '' then
		pas.chat.Send(pl, 'INFO', 'Your rank: ' .. rank .. ' - Tag: ' .. rankTag.tag)
	else
		pas.chat.Send(pl, 'INFO', 'Your rank: ' .. rank .. ' - No tag configured or disabled')
	end
end)
	:SetFlag('u')
	:SetHelp('Shows your current rank and chat tag')
	:SetIcon('icon16/user.png')

-- Debug command to test chat with tags
pas.cmd.Create('testchat', function(pl, args)
	local message = table.concat(args, ' ')
	if message == '' then
		message = 'This is a test message with rank tags!'
	end
	
	-- Simulate a chat message with tags
	pas.chat.SendChatWithTags(pl, message, false)
	pas.chat.Send(pl, 'SUCCESS', 'Test chat message sent!')
end)
	:AddArg('text', 'message', true) -- Optional - has default
	:SetFlag('m')
	:SetHelp('Test the chat tag system')
	:SetIcon('icon16/comments.png')

-- Clean up timers on disconnect
hook.Add('PlayerDisconnected', 'PANTHEON.ChatMuteCleanup', function(ply)
	timer.Remove('pas_chatmute_' .. ply:SteamID64())
end)

print('[PANTHEON] Chat commands loaded')