-- Fun admin commands for PANTHEON (integrated from SAM)
if (SERVER) then
	AddCSLuaFile()
end

-- Slap command
local slapSounds = {}
for i = 1, 6 do
	slapSounds[i] = "physics/body/body_medium_impact_hard" .. i .. ".wav"
end

pas.cmd.Create('slap', function(pl, args)
	local target = args[1]
	local damage = tonumber(args[2]) or 0
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if not pas.ranks.CanTarget(pl, targ) then
			pas.notify(pl, 'You cannot target ' .. targ:Nick(), 1)
			continue
		end
		
		if targ:Alive() and not targ:IsFlagSet(FL_FROZEN) then
			targ:ExitVehicle()
			targ:SetVelocity(Vector(math.random(-100, 100), math.random(-100, 100), math.random(200, 400)))
			targ:EmitSound(slapSounds[math.random(1, 6)], 60, math.random(80, 120))
			
			if damage > 0 then
				targ:TakeDamage(damage, pl, pl)
			end
			
			if damage > 0 then
				pas.notify_all(pl:Nick() .. ' slapped ' .. targ:Nick() .. ' for ' .. damage .. ' damage')
			else
				pas.notify_all(pl:Nick() .. ' slapped ' .. targ:Nick())
			end
		end
	end
end)
	:AddArg('player', 'target')
	:AddArg('damage', 'damage', true) -- Optional - defaults to 0
	:SetFlag('a')
	:SetHelp('Slap a player [damage]')
	:SetIcon('icon16/hand.png')

-- HP command
pas.cmd.Create('hp', function(pl, args)
	local target = args[1]
	local amount = tonumber(args[2]) or 100
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	amount = math.Clamp(amount, 1, 2147483647)
	
	for _, targ in ipairs(targets) do
		targ:SetHealth(amount)
		pas.notify(pl, 'Set ' .. targ:Nick() .. '\'s health to ' .. amount, 0)
	end
end)
	:AddArg('player', 'target')
	:AddArg('health', 'amount', true) -- Optional - defaults to 100
	:SetFlag('a')
	:SetHelp('Set a player\'s health')
	:SetIcon('icon16/heart.png')
	:AddAlias('sethp')
	:AddAlias('health')

-- Armor command
pas.cmd.Create('armor', function(pl, args)
	local target = args[1]
	local amount = tonumber(args[2]) or 100
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	amount = math.Clamp(amount, 1, 2147483647)
	
	for _, targ in ipairs(targets) do
		targ:SetArmor(amount)
		pas.notify(pl, 'Set ' .. targ:Nick() .. '\'s armor to ' .. amount, 0)
	end
end)
	:AddArg('player', 'target')
	:AddArg('armor', 'amount', true) -- Optional - defaults to 100
	:SetFlag('a')
	:SetHelp('Set a player\'s armor')
	:SetIcon('icon16/shield_add.png')
	:AddAlias('setarmor')

-- Ignite command
pas.cmd.Create('ignite', function(pl, args)
	local target = args[1]
	local duration = tonumber(args[2]) or 60
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if not pas.ranks.CanTarget(pl, targ) then
			pas.notify(pl, 'You cannot target ' .. targ:Nick(), 1)
			continue
		end
		
		if targ:IsOnFire() then
			targ:Extinguish()
		end
		
		targ:Ignite(duration)
		pas.notify_all(pl:Nick() .. ' ignited ' .. targ:Nick() .. ' for ' .. duration .. ' seconds')
	end
end)
	:AddArg('player', 'target')
	:AddArg('time_seconds', 'duration', true) -- Optional - defaults to 60
	:SetFlag('a')
	:SetHelp('Set a player on fire [duration]')
	:SetIcon('icon16/fire.png')

-- Extinguish/Unignite command
pas.cmd.Create('extinguish', function(pl, args)
	local target = args[1] or '^'
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	for _, targ in ipairs(targets) do
		targ:Extinguish()
		pas.notify(pl, 'Extinguished ' .. targ:Nick(), 0)
	end
end)
	:AddArg('player', 'target', true) -- Optional - defaults to self
	:SetFlag('a')
	:SetHelp('Extinguish a player')
	:SetIcon('icon16/water.png')
	:AddAlias('unignite')

-- Strip weapons command
pas.cmd.Create('strip', function(pl, args)
	local target = args[1]
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		targ:StripWeapons()
		pas.notify_all(pl:Nick() .. ' stripped ' .. targ:Nick() .. '\'s weapons')
	end
end)
	:AddArg('player', 'target')
	:SetFlag('a')
	:SetHelp('Strip a player\'s weapons')
	:SetIcon('icon16/gun.png')

-- Respawn command
pas.cmd.Create('respawn', function(pl, args)
	local target = args[1] or '^'
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	for _, targ in ipairs(targets) do
		targ:Spawn()
		pas.notify(pl, 'Respawned ' .. targ:Nick(), 0)
	end
end)
	:AddArg('player', 'target', true) -- Optional - defaults to self
	:SetFlag('a')
	:SetHelp('Respawn a player')
	:SetIcon('icon16/arrow_refresh.png')

-- Cloak command
pas.cmd.Create('cloak', function(pl, args)
	local target = args[1] or '^'
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	for _, targ in ipairs(targets) do
		targ:SetNoDraw(true)
		targ:SetNotSolid(true)
		targ:DrawWorldModel(false)
		targ:DrawShadow(false)
		
		-- Store original color for uncloak
		targ.pas_original_color = targ:GetColor()
		targ:SetColor(ColorAlpha(targ:GetColor(), 0))
		targ:SetRenderMode(RENDERMODE_TRANSALPHA)
		
		pas.notify(pl, 'Cloaked ' .. targ:Nick(), 0)
	end
end)
	:AddArg('player', 'target', true) -- Optional - defaults to self
	:SetFlag('a')
	:SetHelp('Make a player invisible')
	:SetIcon('icon16/user_gray.png')
	:SetIcon('icon16/user_gray.png')

-- Uncloak command
pas.cmd.Create('uncloak', function(pl, args)
	local target = args[1] or '^'
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	for _, targ in ipairs(targets) do
		targ:SetNoDraw(false)
		targ:SetNotSolid(false)
		targ:DrawWorldModel(true)
		targ:DrawShadow(true)
		
		if targ.pas_original_color then
			targ:SetColor(targ.pas_original_color)
			targ.pas_original_color = nil
		else
			targ:SetColor(Color(255, 255, 255, 255))
		end
		targ:SetRenderMode(RENDERMODE_NORMAL)
		
		pas.notify(pl, 'Uncloaked ' .. targ:Nick(), 0)
	end
end)
	:AddArg('player', 'target', true) -- Optional - defaults to self
	:SetFlag('a')
	:SetHelp('Make a player visible')
	:SetIcon('icon16/user.png')

-- Jail command
local jailProps = {
	Vector(0, 0, -5), Angle(90, 0, 0),
	Vector(0, 0, 97), Angle(90, 0, 0),
	Vector(21, 31, 46), Angle(0, 90, 0),
	Vector(21, -31, 46), Angle(0, 90, 0),
	Vector(-21, 31, 46), Angle(0, 90, 0),
	Vector(-21, -31, 46), Angle(0, 90, 0),
	Vector(-52, 0, 46), Angle(0, 0, 0),
	Vector(52, 0, 46), Angle(0, 0, 0)
}

local function CreateJail(ply)
	if not IsValid(ply) then return end
	
	ply:ExitVehicle()
	ply:SetMoveType(MOVETYPE_WALK)
	
	ply.pas_jail_pos = ply:GetPos()
	ply.pas_jailed = true
	
	-- Remove old jail if exists
	if ply.pas_jail_props then
		for _, prop in ipairs(ply.pas_jail_props) do
			if IsValid(prop) then
				prop:Remove()
			end
		end
	end
	
	ply.pas_jail_props = {}
	for i = 1, #jailProps, 2 do
		local jail = ents.Create("prop_physics")
		jail:SetModel("models/props_building_details/Storefront_Template001a_Bars.mdl")
		jail:SetPos(ply.pas_jail_pos + jailProps[i])
		jail:SetAngles(jailProps[i + 1])
		jail:SetMoveType(MOVETYPE_NONE)
		jail:Spawn()
		jail:GetPhysicsObject():EnableMotion(false)
		jail.pas_jail_wall = true
		table.insert(ply.pas_jail_props, jail)
	end
	
	-- Watch timer to keep player in jail
	timer.Create("PAS.Jail." .. ply:SteamID(), 0.5, 0, function()
		if not IsValid(ply) or not ply.pas_jailed then
			timer.Remove("PAS.Jail." .. ply:SteamID())
			return
		end
		
		if ply:GetPos():DistToSqr(ply.pas_jail_pos) > 4900 then
			ply:SetPos(ply.pas_jail_pos)
		end
		
		-- Recreate jail if destroyed
		if not IsValid(ply.pas_jail_props[1]) then
			CreateJail(ply)
		end
	end)
end

local function RemoveJail(ply)
	if not IsValid(ply) then return end
	
	ply.pas_jailed = false
	
	if ply.pas_jail_props then
		for _, prop in ipairs(ply.pas_jail_props) do
			if IsValid(prop) then
				prop:Remove()
			end
		end
		ply.pas_jail_props = nil
	end
	
	timer.Remove("PAS.Jail." .. ply:SteamID())
	timer.Remove("PAS.Unjail." .. ply:SteamID())
end

pas.cmd.Create('jail', function(pl, args)
	local target = args[1]
	local duration = tonumber(args[2]) or 0
	local reason = table.concat(args, ' ', 3) or 'No reason'
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if not pas.ranks.CanTarget(pl, targ) then
			pas.notify(pl, 'You cannot target ' .. targ:Nick(), 1)
			continue
		end
		
		CreateJail(targ)
		
		if duration > 0 then
			timer.Create("PAS.Unjail." .. targ:SteamID(), duration * 60, 1, function()
				if IsValid(targ) then
					RemoveJail(targ)
					pas.notify(targ, 'You have been released from jail', 0)
				end
			end)
			pas.notify_all(pl:Nick() .. ' jailed ' .. targ:Nick() .. ' for ' .. duration .. ' minutes - ' .. reason)
		else
			pas.notify_all(pl:Nick() .. ' jailed ' .. targ:Nick() .. ' - ' .. reason)
		end
	end
end)
	:AddArg('player', 'target')
	:AddArg('time_minutes', 'duration', true) -- Optional - defaults to permanent
	:AddArg('reason', 'reason', true) -- Optional - defaults to 'No reason'
	:SetFlag('a')
	:SetHelp('Jail a player [duration] [reason]')
	:SetIcon('icon16/lock.png')

pas.cmd.Create('unjail', function(pl, args)
	local target = args[1] or '^'
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	for _, targ in ipairs(targets) do
		RemoveJail(targ)
		pas.notify_all(pl:Nick() .. ' unjailed ' .. targ:Nick())
	end
end)
	:AddArg('player', 'target', true) -- Optional - defaults to self
	:SetFlag('a')
	:SetHelp('Unjail a player')
	:SetIcon('icon16/lock_open.png')

-- Buddha mode (can't die, stays at 1 HP)
pas.cmd.Create('buddha', function(pl, args)
	local target = args[1] or '^'
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	for _, targ in ipairs(targets) do
		targ.pas_buddha = true
		pas.notify(pl, 'Buddha mode enabled for ' .. targ:Nick(), 0)
	end
end)
	:AddArg('player', 'target', true) -- Optional - defaults to self
	:SetFlag('a')
	:SetHelp('Enable buddha mode (can\'t die)')
	:SetIcon('icon16/heart_add.png')

pas.cmd.Create('unbuddha', function(pl, args)
	local target = args[1] or '^'
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	for _, targ in ipairs(targets) do
		targ.pas_buddha = nil
		pas.notify(pl, 'Buddha mode disabled for ' .. targ:Nick(), 0)
	end
end)
	:AddArg('player', 'target', true) -- Optional - defaults to self
	:SetFlag('a')
	:SetHelp('Disable buddha mode')
	:SetIcon('icon16/heart_delete.png')

-- Buddha mode damage hook
if SERVER then
	hook.Add("EntityTakeDamage", "PAS.BuddhaMode", function(ply, dmg)
		if ply.pas_buddha and ply:Health() - dmg:GetDamage() <= 0 then
			ply:SetHealth(1)
			return true
		end
	end)
	
	-- Prevent jailed players from doing things
	hook.Add("PlayerNoClip", "PAS.Jail", function(ply)
		if ply.pas_jailed then
			return false
		end
	end)
	
	hook.Add("CanPlayerSuicide", "PAS.Jail", function(ply)
		if ply.pas_jailed then
			return false
		end
	end)
	
	hook.Add("PlayerEnteredVehicle", "PAS.Jail", function(ply)
		if ply.pas_jailed then
			timer.Simple(0, function()
				if IsValid(ply) then
					ply:ExitVehicle()
				end
			end)
		end
	end)
	
	-- Respawn jailed players at jail position
	hook.Add("PlayerSpawn", "PAS.Jail", function(ply)
		if ply.pas_jailed and ply.pas_jail_pos then
			timer.Simple(0.1, function()
				if IsValid(ply) then
					ply:SetPos(ply.pas_jail_pos)
				end
			end)
		end
	end)
	
	-- Clean up jail on disconnect
	hook.Add("PlayerDisconnected", "PAS.Jail", function(ply)
		if ply.pas_jailed then
			RemoveJail(ply)
		end
	end)
end
