﻿-- PANTHEON Admin System - Gamemaster Commands
-- Commands for gamemasters to manage NPCs and game environment

-- Store NPC default settings
local npcDefaults = {
    weapon = "tfa_swch_e5",
    health = 100,
    damage = 10,
    firerate = 1.0
}

-- Store per-player notarget status
local playerNoTarget = {}

-- Store custom NPC settings per class
local npcSettings = {}

-- Hook to apply custom settings when NPCs spawn
hook.Add("OnEntityCreated", "PAS_ApplyNPCSettings", function(ent)
    if not IsValid(ent) or not ent:IsNPC() then return end
    
    local class = ent:GetClass()
    -- Use custom settings if they exist, otherwise use defaults
    local settings = npcSettings[class] or npcDefaults
    
    -- Apply custom settings with a slight delay to ensure NPC is fully initialized
    timer.Simple(0.1, function()
        if not IsValid(ent) then return end
        
        -- Set health
        if settings.health then
            if ent.SetMaxHealth then
                ent:SetMaxHealth(settings.health)
            end
            ent:SetHealth(settings.health)
        end
        
        if SERVER then
            -- Remove all weapon entities parented to the NPC (for default weapons)
            for _, child in ipairs(ent:GetChildren()) do
                if IsValid(child) and child:IsWeapon() then
                    child:Remove()
                end
            end
            
            -- Give the new weapon after a short delay to avoid removing it
            if settings.weapon and settings.weapon ~= "" and ent.Give then
                timer.Simple(0.05, function()
                    if not IsValid(ent) then return end
                    ent:Give(settings.weapon)
                    if ent.SetCurrentWeaponProficiency then
                        ent:SetCurrentWeaponProficiency(WEAPON_PROFICIENCY_PERFECT)
                    end
                end)
            end
        end
        
        -- Store damage and firerate for later use
        ent.pas_CustomDamage = settings.damage
        ent.pas_CustomFireRate = settings.firerate

        -- Try to set the damage keyvalue for supported NPCs
        if ent.KeyValue and settings.damage then
            ent:KeyValue("damage", tostring(settings.damage))
        elseif ent.SetKeyValue and settings.damage then
            ent:SetKeyValue("damage", tostring(settings.damage))
        end
    end)
end)

-- Hook to override damage from NPCs
hook.Add("EntityTakeDamage", "PAS_NPCDamageOverride", function(target, dmg)
    local attacker = dmg:GetAttacker()
    
    if not IsValid(attacker) or not attacker:IsNPC() then return end
    
    -- Apply custom damage if set
    if attacker.pas_CustomDamage then
        dmg:SetDamage(attacker.pas_CustomDamage)
    end
end)

-- Hook to control NPC fire rate
hook.Add("EntityFireBullets", "PAS_NPCFireRateControl", function(ent, data)
    if not IsValid(ent) or not ent:IsNPC() then return end
    
    -- Check if this NPC has a custom fire rate
    if not ent.pas_CustomFireRate then return end
    
    -- Track last fire time
    ent.pas_LastFireTime = ent.pas_LastFireTime or 0
    local currentTime = CurTime()
    
    -- If not enough time has passed, block the shot and suppress firing temporarily
    if currentTime - ent.pas_LastFireTime < ent.pas_CustomFireRate then
        -- Try to suppress the weapon temporarily
        local weapon = ent:GetActiveWeapon()
        if IsValid(weapon) then
            weapon:SetNextPrimaryFire(currentTime + (ent.pas_CustomFireRate - (currentTime - ent.pas_LastFireTime)))
        end
        return false -- Block the bullet
    end
    
    -- Update last fire time
    ent.pas_LastFireTime = currentTime
end)

-- Hook to prevent NPCs from targeting players with notarget enabled
hook.Add("Think", "PAS_NoTargetUpdate", function()
    for _, ply in ipairs(player.GetAll()) do
        if playerNoTarget[ply:SteamID()] then
            -- Make player invisible/ignored by NPCs
            if not ply:IsFlagSet(FL_NOTARGET) then
                ply:AddFlags(FL_NOTARGET)
            end
        else
            if ply:IsFlagSet(FL_NOTARGET) then
                ply:RemoveFlags(FL_NOTARGET)
            end
        end
    end
end)

-- Clean up notarget status when player disconnects
hook.Add("PlayerDisconnected", "PAS_CleanupNoTarget", function(ply)
    playerNoTarget[ply:SteamID()] = nil
end)

-- NOTARGET COMMAND
pas.cmd.Create("notarget", function(pl, args)
    local target = args[1] or "^"
    
    local targets = pas.parser.ParsePlayer(target, pl)
    
    if not targets or #targets == 0 then
        pas.notify(pl, "Player not found", 1)
        return
    end
    
    for _, targ in ipairs(targets) do
        local steamID = targ:SteamID()
        if playerNoTarget[steamID] then
            -- Disable notarget
            playerNoTarget[steamID] = nil
            if targ:IsFlagSet(FL_NOTARGET) then
                targ:RemoveFlags(FL_NOTARGET)
            end
            pas.notify(pl, "Disabled notarget for " .. targ:Nick(), 0)
            if targ ~= pl then
                pas.notify(targ, "NPCs can now target you", 0)
            end
        else
            -- Enable notarget
            playerNoTarget[steamID] = true
            if not targ:IsFlagSet(FL_NOTARGET) then
                targ:AddFlags(FL_NOTARGET)
            end
            pas.notify(pl, "Enabled notarget for " .. targ:Nick(), 0)
            if targ ~= pl then
                pas.notify(targ, "NPCs can no longer target you", 0)
            end
        end
    end
end)
    :AddArg("player", "target", true)
    :SetFlag({"m", "g"})
    :SetHelp("Toggle NPC targeting for a player")
    :SetIcon("icon16/shield.png")

-- NPC CONFIGURATION COMMANDS
pas.cmd.Create("npcsetweapon", function(pl, args)
    local class = args[1]
    local weapon = args[2]
    
    if not class or not weapon then
        pas.notify(pl, "Usage: /npcsetweapon <npc_class> <weapon>", 1)
        return
    end
    
    if not weapons.Get(weapon) then
        pas.notify(pl, "Warning: " .. weapon .. " is not a registered SWEP. It may still work for NPCs if it is a default HL2 weapon.", 1)
    end
    
    if not npcSettings[class] then
        npcSettings[class] = {
            weapon = weapon,
            health = npcDefaults.health,
            damage = npcDefaults.damage,
            firerate = npcDefaults.firerate
        }
    else
        npcSettings[class].weapon = weapon
    end
    
    pas.notify_all("NPC weapon for " .. class .. " set to " .. weapon .. " by " .. pl:Nick(), 0)
    pas.log.Add("Command", pl:Nick() .. " set NPC weapon for " .. class .. " to " .. weapon)
end)
    :AddArg("string", "npc class")
    :AddArg("string", "weapon class")
    :SetFlag({"m", "g"})
    :SetHelp("Set weapon for specific NPC class")
    :SetIcon("icon16/gun.png")

pas.cmd.Create("npcsetdamage", function(pl, args)
    local class = args[1]
    local damage = tonumber(args[2])
    
    if not class or not damage then
        pas.notify(pl, "Usage: /npcsetdamage <npc_class> <damage>", 1)
        return
    end
    
    if damage < 0 or damage > 1000 then
        pas.notify(pl, "Damage must be between 0 and 1000", 1)
        return
    end
    
    if not npcSettings[class] then
        npcSettings[class] = {
            weapon = npcDefaults.weapon,
            health = npcDefaults.health,
            damage = damage,
            firerate = npcDefaults.firerate
        }
    else
        npcSettings[class].damage = damage
    end
    
    pas.notify_all("NPC damage for " .. class .. " set to " .. damage .. " by " .. pl:Nick(), 0)
    pas.log.Add("Command", pl:Nick() .. " set NPC damage for " .. class .. " to " .. damage)
end)
    :AddArg("string", "npc class")
    :AddArg("number", "damage amount")
    :SetFlag({"m", "g"})
    :SetHelp("Set damage for specific NPC class")
    :SetIcon("icon16/bomb.png")

pas.cmd.Create("npcsetfirerate", function(pl, args)
    local class = args[1]
    local firerate = tonumber(args[2])
    
    if not class or not firerate then
        pas.notify(pl, "Usage: /npcsetfirerate <npc_class> <firerate>", 1)
        return
    end
    
    if firerate < 0.1 or firerate > 10.0 then
        pas.notify(pl, "Fire rate must be between 0.1 and 10.0", 1)
        return
    end
    
    if not npcSettings[class] then
        npcSettings[class] = {
            weapon = npcDefaults.weapon,
            health = npcDefaults.health,
            damage = npcDefaults.damage,
            firerate = firerate
        }
    else
        npcSettings[class].firerate = firerate
    end
    
    pas.notify_all("NPC fire rate for " .. class .. " set to " .. firerate .. " by " .. pl:Nick(), 0)
    pas.log.Add("Command", pl:Nick() .. " set NPC fire rate for " .. class .. " to " .. firerate)
end)
    :AddArg("string", "npc class")
    :AddArg("number", "fire rate")
    :SetFlag({"m", "g"})
    :SetHelp("Set fire rate for specific NPC class")
    :SetIcon("icon16/time.png")

pas.cmd.Create("npcsethealth", function(pl, args)
    local class = args[1]
    local health = tonumber(args[2])
    
    if not class or not health then
        pas.notify(pl, "Usage: /npcsethealth <npc_class> <health>", 1)
        return
    end
    
    if health < 1 or health > 10000 then
        pas.notify(pl, "Health must be between 1 and 10000", 1)
        return
    end
    
    if not npcSettings[class] then
        npcSettings[class] = {
            weapon = npcDefaults.weapon,
            health = health,
            damage = npcDefaults.damage,
            firerate = npcDefaults.firerate
        }
    else
        npcSettings[class].health = health
    end
    
    pas.notify_all("NPC health for " .. class .. " set to " .. health .. " by " .. pl:Nick(), 0)
    pas.log.Add("Command", pl:Nick() .. " set NPC health for " .. class .. " to " .. health)
end)
    :AddArg("string", "npc class")
    :AddArg("number", "health amount")
    :SetFlag({"m", "g"})
    :SetHelp("Set health for specific NPC class")
    :SetIcon("icon16/heart.png")

pas.cmd.Create("clearnpcstats", function(pl, args)
    local class = args[1]
    
    if not class then
        pas.notify(pl, "Usage: /clearnpcstats <npc_class>", 1)
        return
    end
    
    if npcSettings[class] then
        npcSettings[class] = nil
        pas.notify_all("NPC stats for " .. class .. " cleared by " .. pl:Nick(), 0)
        pas.log.Add("Command", pl:Nick() .. " cleared NPC stats for " .. class)
    else
        pas.notify(pl, "No custom settings found for " .. class, 1)
    end
end)
    :AddArg("string", "npc class")
    :SetFlag({"m", "g"})
    :SetHelp("Clear custom stats for a specific NPC class")
    :SetIcon("icon16/arrow_refresh.png")

pas.cmd.Create("clearallnpcstats", function(pl, args)
    npcSettings = {}
    
    pas.notify_all("All NPC stats cleared by " .. pl:Nick(), 0)
    pas.log.Add("Command", pl:Nick() .. " cleared all NPC stats")
end)
    :SetFlag({"m", "g"})
    :SetHelp("Clear all custom NPC stats")
    :SetIcon("icon16/arrow_refresh.png")

pas.cmd.Create("npcstatus", function(pl, args)
    pas.notify(pl, "=== Current NPC Settings ===", 0)
    
    local count = 0
    for class, settings in pairs(npcSettings) do
        count = count + 1
        pas.notify(pl, "--- " .. class .. " ---", 0)
        pas.notify(pl, "Weapon: " .. (settings.weapon or "default"), 0)
        pas.notify(pl, "Health: " .. (settings.health or "default"), 0)
        pas.notify(pl, "Damage: " .. (settings.damage or "default"), 0)
        pas.notify(pl, "Fire Rate: " .. (settings.firerate or "default"), 0)
    end
    
    if count == 0 then
        pas.notify(pl, "No custom NPC settings configured", 0)
        pas.notify(pl, "Defaults:", 0)
        pas.notify(pl, "Weapon: " .. npcDefaults.weapon, 0)
        pas.notify(pl, "Health: " .. npcDefaults.health, 0)
        pas.notify(pl, "Damage: " .. npcDefaults.damage, 0)
        pas.notify(pl, "Fire Rate: " .. npcDefaults.firerate, 0)
    end
    
    local noTargetCount = 0
    for _ in pairs(playerNoTarget) do
        noTargetCount = noTargetCount + 1
    end
    pas.notify(pl, "Players with NotTarget: " .. noTargetCount, 0)
end)
    :SetFlag({"m", "g"})
    :SetHelp("Show current NPC configuration")
    :SetIcon("icon16/information.png")

print("[PANTHEON] Gamemaster commands loaded - NPC management system active")
