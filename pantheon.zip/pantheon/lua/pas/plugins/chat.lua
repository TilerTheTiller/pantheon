-- Chat and messaging admin commands for PANTHEON
if (SERVER) then
	AddCSLuaFile()
end

-- Mute command
pas.cmd.Create('mute', function(pl, args)
	local target = args[1]
	local duration = tonumber(args[2]) or 0
	local reason = table.concat(args, ' ', 3) or 'No reason'
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if not pas.ranks.CanTarget(pl, targ) then
			pas.notify(pl, 'You cannot target ' .. targ:Nick(), 1)
			continue
		end
		
		targ.pas_muted = true
		
		if duration > 0 then
			timer.Create("PAS.Unmute." .. targ:SteamID(), duration * 60, 1, function()
				if IsValid(targ) then
					targ.pas_muted = false
					pas.notify(targ, 'You have been unmuted', 0)
				end
			end)
			pas.notify_all(pl:Nick() .. ' muted ' .. targ:Nick() .. ' for ' .. duration .. ' minutes - ' .. reason, 0)
		else
			pas.notify_all(pl:Nick() .. ' muted ' .. targ:Nick() .. ' - ' .. reason, 0)
		end
		
		pas.log.Add('Mute', pl:Nick() .. ' muted ' .. targ:Nick() .. ' - Reason: ' .. reason)
	end
end)
	:AddArg('player', 'target')
	:AddArg('time_minutes', 'duration', true) -- Optional - defaults to permanent
	:AddArg('reason', 'reason', true) -- Optional - defaults to 'No reason'
	:SetFlag('m')
	:SetHelp('Mute a player [duration] [reason]')
	:SetIcon('icon16/sound_mute.png')

-- Unmute command
pas.cmd.Create('unmute', function(pl, args)
	local target = args[1]
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		targ.pas_muted = false
		timer.Remove("PAS.Unmute." .. targ:SteamID())
		
		pas.notify_all(pl:Nick() .. ' unmuted ' .. targ:Nick(), 0)
		pas.log.Add('Mute', pl:Nick() .. ' unmuted ' .. targ:Nick())
	end
end)
	:AddArg('player', 'target')
	:SetFlag('m')
	:SetHelp('Unmute a player')
	:SetIcon('icon16/sound.png')

-- Gag command (blocks voice chat)
pas.cmd.Create('gag', function(pl, args)
	local target = args[1]
	local duration = tonumber(args[2]) or 0
	local reason = table.concat(args, ' ', 3) or 'No reason'
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if not pas.ranks.CanTarget(pl, targ) then
			pas.notify(pl, 'You cannot target ' .. targ:Nick(), 1)
			continue
		end
		
		targ.pas_gagged = true
		targ:SetNWBool("pas_gagged", true)
		
		if duration > 0 then
			timer.Create("PAS.Ungag." .. targ:SteamID(), duration * 60, 1, function()
				if IsValid(targ) then
					targ.pas_gagged = false
					targ:SetNWBool("pas_gagged", false)
					pas.notify(targ, 'You have been ungagged', 0)
				end
			end)
			pas.notify_all(pl:Nick() .. ' gagged ' .. targ:Nick() .. ' for ' .. duration .. ' minutes - ' .. reason, 0)
		else
			pas.notify_all(pl:Nick() .. ' gagged ' .. targ:Nick() .. ' - ' .. reason, 0)
		end
		
		pas.log.Add('Gag', pl:Nick() .. ' gagged ' .. targ:Nick() .. ' - Reason: ' .. reason)
	end
end)
	:AddArg('player', 'target')
	:AddArg('time_minutes', 'duration', true) -- Optional - defaults to permanent
	:AddArg('reason', 'reason', true) -- Optional - defaults to 'No reason'
	:SetFlag('m')
	:SetHelp('Gag a player (block voice chat) [duration] [reason]')
	:SetIcon('icon16/sound_mute.png')

-- Ungag command
pas.cmd.Create('ungag', function(pl, args)
	local target = args[1]
	
	if not target then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		targ.pas_gagged = false
		targ:SetNWBool("pas_gagged", false)
		timer.Remove("PAS.Ungag." .. targ:SteamID())
		
		pas.notify_all(pl:Nick() .. ' ungagged ' .. targ:Nick(), 0)
		pas.log.Add('Gag', pl:Nick() .. ' ungagged ' .. targ:Nick())
	end
end)
	:AddArg('player', 'target')
	:SetFlag('m')
	:SetHelp('Ungag a player')
	:SetIcon('icon16/sound.png')

-- MOTD/Message command
pas.cmd.Create('motd', function(pl, args)
	local target = args[1]
	
	if not target then
		-- Show to self
		pas.notify(pl, 'Opening MOTD...', 0)
		-- You can implement your MOTD system here
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		pas.notify(pl, 'Showed MOTD to ' .. targ:Nick(), 0)
		-- Implement MOTD display to target
	end
end)
	:AddArg('player', 'target', true) -- Optional - defaults to self
	:SetFlag('u')
	:SetHelp('Show MOTD [player]')
	:SetIcon('icon16/information.png')

-- Private message command
pas.cmd.Create('pm', function(pl, args)
	local target = args[1]
	local message = table.concat(args, ' ', 2)
	
	if not target or not message or message == '' then
		return false
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	local targ = targets[1]
	
	-- Send to target
	pas.notify(targ, '[PM from ' .. pl:Nick() .. '] ' .. message, 3)
	
	-- Confirm to sender
	pas.notify(pl, '[PM to ' .. targ:Nick() .. '] ' .. message, 3)
	
	pas.log.Add('PM', pl:Nick() .. ' -> ' .. targ:Nick() .. ': ' .. message)
end)
	:AddArg('player', 'target')
	:AddArg('text', 'message')
	:SetFlag('u')
	:SetHelp('Send a private message <player> <message>')
	:SetIcon('icon16/email.png')
	:AddAlias('msg')

-- Server say command
pas.cmd.Create('say', function(pl, args)
	local message = table.concat(args, ' ')
	
	if not message or message == '' then
		return false
	end
	
	-- Broadcast message to all players
	for _, ply in ipairs(player.GetAll()) do
		ply:ChatPrint('SERVER | ' .. message)
	end
	
	pas.log.Add('Say', pl:Nick() .. ' broadcasted: ' .. message)
end)
	:AddArg('text', 'message')
	:SetFlag('m')
	:SetHelp('Broadcast a message to all players')
	:SetIcon('icon16/comment.png')
	:AddAlias('broadcast')

-- Center say command
pas.cmd.Create('csay', function(pl, args)
	local message = table.concat(args, ' ')
	
	if not message or message == '' then
		return false
	end
	
	-- Send center message to all players
	net.Start("PAS.CenterMessage")
		net.WriteString(message)
	net.Broadcast()
	
	pas.log.Add('CSay', pl:Nick() .. ' center broadcasted: ' .. message)
end)
	:AddArg('text', 'message')
	:SetFlag('m')
	:SetHelp('Display a center message to all players')
	:SetIcon('icon16/comment.png')

if SERVER then
	util.AddNetworkString("PAS.CenterMessage")
	
	-- Mute chat hook
	hook.Add("PlayerSay", "PAS.Mute", function(ply, text)
		if ply.pas_muted then
			pas.notify(ply, 'You are muted', 1)
			return ""
		end
	end)
	
	-- Gag voice hook
	hook.Add("PlayerCanHearPlayersVoice", "PAS.Gag", function(listener, talker)
		if talker:GetNWBool("pas_gagged", false) then
			return false
		end
	end)
	
	-- Clean up timers on disconnect
	hook.Add("PlayerDisconnected", "PAS.ChatCommands", function(ply)
		timer.Remove("PAS.Unmute." .. ply:SteamID())
		timer.Remove("PAS.Ungag." .. ply:SteamID())
	end)
end

if CLIENT then
	net.Receive("PAS.CenterMessage", function()
		local message = net.ReadString()
		
		-- Display center message
		local centerPanel = vgui.Create("DPanel")
		centerPanel:SetSize(ScrW() * 0.6, 100)
		centerPanel:SetPos(ScrW() * 0.2, ScrH() * 0.4)
		centerPanel.Paint = function(self, w, h)
			draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 0, 200))
			draw.SimpleText(message, "DermaLarge", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		
		timer.Simple(5, function()
			if IsValid(centerPanel) then
				centerPanel:Remove()
			end
		end)
	end)
end
