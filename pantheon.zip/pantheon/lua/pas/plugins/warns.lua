-- Pantheon Warns Plugin
-- Commands for the warning system

-- Warn command
pas.cmd.Create('warn', function(pl, args)
	if not args[1] then
		return false -- This will trigger automatic usage display
	end
	
	local target = pas.FindPlayer(args[1])
	if not IsValid(target) then
		pas.notify(pl, 'Player not found: ' .. args[1], 1)
		return
	end
	
	local reason = table.concat(args, ' ', 2)
	if not reason or reason:Trim() == '' then
		pas.notify(pl, 'Please provide a warning reason', 1)
		return
	end
	
	if SERVER then
	pas.warns.Add(target:SteamID(), pl:SteamID(), reason, 'general', function(success, message)
			if success then
				pas.notify(pl, 'Successfully warned ' .. target:Nick(), 0)
			else
				pas.notify(pl, 'Failed to warn player: ' .. (message or 'Unknown error'), 1)
			end
		end)
	end
end)
	:AddArg('player', 'target')
	:AddArg('reason', 'reason')
	:SetFlag({'w', 'm', 's', 'a'})
	:SetHelp('Warn a player')
	:SetIcon('icon16/error.png')

-- Unwarn command (remove warning)
pas.cmd.Create('unwarn', function(pl, args)
	if not args[1] then
		return false -- This will trigger automatic usage display
	end
	
	if CLIENT then return end
	
	-- Check if it's a number (warning ID)
	local warn_id = tonumber(args[1])
	if warn_id then
		local reason = table.concat(args, ' ', 2) or 'Removed by admin'
	pas.warns.Remove(warn_id, pl:SteamID(), reason, function(success, message)
			if success then
				pas.notify(pl, 'Successfully removed warning ID: ' .. warn_id, 0)
			else
				pas.notify(pl, 'Failed to remove warning: ' .. (message or 'Unknown error'), 1)
			end
		end)
		return
	end
	
	-- Otherwise treat as player name - remove their most recent warning
	local target = pas.FindPlayer(args[1])
	if not IsValid(target) then
		pas.notify(pl, 'Player not found: ' .. args[1], 1)
		return
	end
	
	pas.warns.Get(target:SteamID(), true, function(warns)
		if not warns or #warns == 0 then
			pas.notify(pl, target:Nick() .. ' has no active warnings', 1)
			return
		end
		
		-- Remove the most recent warning
		local most_recent = warns[1]
		local reason = table.concat(args, ' ', 2) or 'Removed by admin'
	pas.warns.Remove(most_recent.id, pl:SteamID(), reason, function(success, message)
			if success then
				pas.notify(pl, 'Successfully removed most recent warning from ' .. target:Nick(), 0)
			else
				pas.notify(pl, 'Failed to remove warning: ' .. (message or 'Unknown error'), 1)
			end
		end)
	end)
end)
	:AddArg('player_or_id', 'target')
	:SetFlag({'w', 'm', 's', 'a'})
	:SetHelp('Remove a warning from a player or by warning ID')
	:SetIcon('icon16/tick.png')

-- Check warnings command
pas.cmd.Create('checkwarns', function(pl, args)
	local target = pl -- Default to self
	
	if args[1] then
		-- Check if player has permission to check others
		if pl:HasFlag('w') or pl:HasFlag('m') then
			target = pas.FindPlayer(args[1])
			if not IsValid(target) then
				pas.notify(pl, 'Player not found: ' .. args[1], 1)
				return
			end
		else
			pas.notify(pl, 'You can only check your own warnings', 1)
			return
		end
	end
	
	if SERVER then
		pas.warns.Get(target:SteamID(), true, function(warns)
			if not warns or #warns == 0 then
				if target == pl then
					pas.notify(pl, 'You have no active warnings', 0)
				else
					pas.notify(pl, target:Nick() .. ' has no active warnings', 0)
				end
				return
			end
			
			-- Send warns info to chat
			local target_name = (target == pl) and "You" or target:Nick()
			pas.notify(pl, target_name .. (target == pl and " have " or " has ") .. #warns .. ' active warning(s):', 0)
			
			for i, warn in ipairs(warns) do
				if i <= 5 then -- Limit to 5 most recent to avoid spam
					local date_str = os.date('%m/%d/%Y', warn.timestamp)
					local admin_name = warn.admin_name or 'Unknown Admin'
					pas.notify(pl, '#' .. warn.id .. ' (' .. date_str .. ') by ' .. admin_name .. ': ' .. warn.reason, 0)
				end
			end
			
			if #warns > 5 then
				pas.notify(pl, '... and ' .. (#warns - 5) .. ' more. Use /warns menu for full list.', 0)
			end
		end)
	end
end)
	:AddAlias('warnings')
	:AddAlias('mywarns')
	:SetFlag('u')
	:SetHelp('Check warnings for yourself or another player')
	:SetIcon('icon16/information.png')

-- Warns menu command
pas.cmd.Create('warns', function(pl, args)
	-- On client, just open the menu directly
	if CLIENT then
		if pas.warns and pas.warns.OpenMenu and type(pas.warns.OpenMenu) == "function" then
			pas.warns.OpenMenu()
		else
			ErrorNoHalt('[PANTHEON WARNS] OpenMenu function not available!\n')
		end
		return
	end
	
	-- On server, send network message to client
	if SERVER then
		net.Start('pas.warns.open_menu')
		net.Send(pl)
	end
end)
	:SetFlag({'w', 'm', 's', 'a'})
	:SetHelp('Open the warnings management menu')
	:SetIcon('icon16/application_form.png')

-- Clear all warnings command
pas.cmd.Create('clearwarns', function(pl, args)
	if not args[1] then
		pas.notify(pl, 'Usage: /clearwarns <player>', 1)
		return
	end
	
	local target = pas.FindPlayer(args[1])
	if not IsValid(target) then
		pas.notify(pl, 'Player not found: ' .. args[1], 1)
		return
	end
	
	if SERVER then
		pas.warns.Clear(target:SteamID(), pl:SteamID(), function(success, message)
			if success then
				pas.notify(pl, 'Successfully cleared all warnings for ' .. target:Nick(), 0)
			else
				pas.notify(pl, 'Failed to clear warnings: ' .. (message or 'Unknown error'), 1)
			end
		end)
	end
end)
	:SetFlag({'w', 's'})
	:SetHelp('Clear all warnings from a player')
	:SetIcon('icon16/bin.png')

pas.print('[PANTHEON] Warns plugin loaded')