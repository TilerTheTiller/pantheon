-- Utility admin commands for PANTHEON (integrated from SAM)
if (SERVER) then
	AddCSLuaFile()
end

-- Find empty position helper function (from DarkRP/SAM)
local function FindEmptyPos(pos, ignore)
	local function IsEmpty(vector, ent)
		local point = util.PointContents(vector)
		local valid = point ~= CONTENTS_SOLID
			and point ~= CONTENTS_MOVEABLE
			and point ~= CONTENTS_LADDER
			and point ~= CONTENTS_PLAYERCLIP
			and point ~= CONTENTS_MONSTERCLIP
		if not valid then return false end

		local ents_found = ents.FindInSphere(vector, 35)
		for i = 1, #ents_found do
			local v = ents_found[i]
			if (v:IsNPC() or v:IsPlayer() or v:GetClass() == "prop_physics") and v ~= ent then
				return false
			end
		end

		return true
	end

	local distance, step, area = 600, 30, Vector(16, 16, 64)
	local north_vec, east_vec, up_vec = Vector(0, 0, 0), Vector(0, 0, 0), Vector(0, 0, 0)

	if IsEmpty(pos, ignore) and IsEmpty(pos + area, ignore) then
		return pos
	end

	for j = step, distance, step do
		for i = -1, 1, 2 do
			local k = j * i

			-- North/South
			north_vec.x = k
			if IsEmpty(pos + north_vec, ignore) and IsEmpty(pos + north_vec + area, ignore) then
				return pos + north_vec
			end

			-- East/West
			east_vec.y = k
			if IsEmpty(pos + east_vec, ignore) and IsEmpty(pos + east_vec + area, ignore) then
				return pos + east_vec
			end

			-- Up/Down
			up_vec.z = k
			if IsEmpty(pos + up_vec, ignore) and IsEmpty(pos + up_vec + area, ignore) then
				return pos + up_vec
			end
		end
	end

	return pos
end

-- Map change command
pas.cmd.Create('map', function(pl, args)
	local mapName = args[1]
	local gamemode = args[2]
	
	if not mapName then
		pas.notify(pl, 'Usage: !map <mapname> [gamemode]', 1)
		return
	end
	
	if gamemode then
		pas.notify_all(pl:Nick() .. ' is changing map to ' .. mapName .. ' with gamemode ' .. gamemode, 0)
		RunConsoleCommand("gamemode", gamemode)
	else
		pas.notify_all(pl:Nick() .. ' is changing map to ' .. mapName, 0)
	end
	
	if #player.GetHumans() == 0 then
		RunConsoleCommand("changelevel", mapName)
	else
		timer.Create("PAS.MapChange", 10, 1, function()
			RunConsoleCommand("changelevel", mapName)
		end)
	end
	
	pas.log.Add('Command', pl:Nick() .. ' changed map to ' .. mapName)
end)
	:SetFlag('s')
	:SetHelp('Change the map [gamemode]')
	:SetIcon('icon16/world.png')

-- Map restart command
pas.cmd.Create('maprestart', function(pl, args)
	pas.notify_all(pl:Nick() .. ' is restarting the map', 0)
	
	if #player.GetHumans() == 0 then
		RunConsoleCommand("changelevel", game.GetMap())
	else
		timer.Create("PAS.MapRestart", 10, 1, function()
			RunConsoleCommand("changelevel", game.GetMap())
		end)
	end
	
	pas.log.Add('Command', pl:Nick() .. ' restarted the map')
end)
	:SetFlag('s')
	:SetHelp('Restart the current map')
	:SetIcon('icon16/arrow_refresh.png')

-- Map reset (cleanup) command
pas.cmd.Create('mapreset', function(pl, args)
	game.CleanUpMap()
	pas.notify_all(pl:Nick() .. ' cleaned up the map', 0)
	pas.log.Add('Command', pl:Nick() .. ' cleaned up the map')
end)
	:SetFlag('s')
	:SetHelp('Clean up the map (remove props, ragdolls, etc)')
	:SetIcon('icon16/broom.png')
	:AddAlias('cleanup')

-- Give weapon/entity command
pas.cmd.Create('give', function(pl, args)
	local target = args[1]
	local weapon = args[2]
	
	if not weapon then
		pas.notify(pl, 'Usage: !give <player> <weapon/entity>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		targ:Give(weapon)
		pas.notify(pl, 'Gave ' .. weapon .. ' to ' .. targ:Nick(), 0)
	end
	
	pas.log.Add('Command', pl:Nick() .. ' gave ' .. weapon .. ' to targets')
end)
	:SetFlag('s')
	:SetHelp('Give a weapon/entity to a player')
	:SetIcon('icon16/award_star_add.png')

-- Exit vehicle command
pas.cmd.Create('exitvehicle', function(pl, args)
	local target = args[1]
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if targ:InVehicle() then
			targ:ExitVehicle()
			pas.notify(pl, 'Ejected ' .. targ:Nick() .. ' from vehicle', 0)
		else
			pas.notify(pl, targ:Nick() .. ' is not in a vehicle', 1)
		end
	end
end)
	:SetFlag('m')
	:SetHelp('Force a player to exit their vehicle')
	:SetIcon('icon16/car_delete.png')
	:AddAlias('exit')

-- Clear decals command
pas.cmd.Create('cleardecals', function(pl, args)
	net.Start("PAS.ClearDecals")
	net.Broadcast()
	
	pas.notify_all(pl:Nick() .. ' cleared all decals and ragdolls', 0)
	pas.log.Add('Command', pl:Nick() .. ' cleared decals')
end)
	:SetFlag('m')
	:SetHelp('Clear all decals and ragdolls')
	:SetIcon('icon16/paintbrush.png')

if CLIENT then
	net.Receive("PAS.ClearDecals", function()
		game.RemoveRagdolls()
		RunConsoleCommand("r_cleardecals")
	end)
else
	util.AddNetworkString("PAS.ClearDecals")
end

-- Stop sound command
pas.cmd.Create('stopsound', function(pl, args)
	net.Start("PAS.StopSound")
	net.Broadcast()
	
	pas.notify_all(pl:Nick() .. ' stopped all sounds', 0)
	pas.log.Add('Command', pl:Nick() .. ' stopped sounds')
end)
	:SetFlag('m')
	:SetHelp('Stop all sounds for all players')
	:SetIcon('icon16/sound_mute.png')

if CLIENT then
	net.Receive("PAS.StopSound", function()
		RunConsoleCommand("stopsound")
	end)
else
	util.AddNetworkString("PAS.StopSound")
end

-- Return to last teleport location
pas.cmd.Create('return', function(pl, args)
	local target = args[1] or '^'
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	for _, targ in ipairs(targets) do
		if targ.pas_last_pos then
			targ:SetPos(targ.pas_last_pos)
			targ:SetEyeAngles(targ.pas_last_ang or Angle(0, 0, 0))
			pas.notify(pl, 'Returned ' .. targ:Nick() .. ' to their last location', 0)
			
			targ.pas_last_pos = nil
			targ.pas_last_ang = nil
		else
			pas.notify(pl, targ:Nick() .. ' has no return location', 1)
		end
	end
end)
	:SetFlag('m')
	:SetHelp('Return a player to their last teleport location')
	:SetIcon('icon16/arrow_undo.png')

-- Set model command
pas.cmd.Create('setmodel', function(pl, args)
	local target = args[1]
	local model = args[2]
	
	if not model then
		pas.notify(pl, 'Usage: !setmodel <player> <model>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		targ:SetModel(model)
		pas.notify(pl, 'Set ' .. targ:Nick() .. '\'s model to ' .. model, 0)
	end
end)
	:SetFlag('s')
	:SetHelp('Set a player\'s model')
	:SetIcon('icon16/user_edit.png')

-- Give ammo command
pas.cmd.Create('giveammo', function(pl, args)
	local target = args[1]
	local amount = tonumber(args[2]) or 99999
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	amount = math.Clamp(amount, 0, 99999)
	if amount == 0 then amount = 99999 end
	
	for _, targ in ipairs(targets) do
		for _, wep in ipairs(targ:GetWeapons()) do
			if wep:GetPrimaryAmmoType() ~= -1 then
				targ:GiveAmmo(amount, wep:GetPrimaryAmmoType(), true)
			end
			if wep:GetSecondaryAmmoType() ~= -1 then
				targ:GiveAmmo(amount, wep:GetSecondaryAmmoType(), true)
			end
		end
		pas.notify(pl, 'Gave ' .. amount .. ' ammo to ' .. targ:Nick(), 0)
	end
end)
	:SetFlag('s')
	:SetHelp('Give ammo to a player [amount]')
	:SetIcon('icon16/package.png')

-- Scale player command
pas.cmd.Create('scale', function(pl, args)
	local target = args[1]
	local scale = tonumber(args[2]) or 1
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	scale = math.Clamp(scale, 0.1, 2.5)
	
	for _, targ in ipairs(targets) do
		targ:SetModelScale(scale)
		targ:SetViewOffset(Vector(0, 0, 64 * scale))
		targ:SetViewOffsetDucked(Vector(0, 0, 28 * scale))
		targ.pas_scaled = true
		
		pas.notify(pl, 'Set ' .. targ:Nick() .. '\'s scale to ' .. scale, 0)
	end
end)
	:SetFlag('a')
	:SetHelp('Scale a player\'s size [0.1-2.5]')
	:SetIcon('icon16/zoom.png')

-- Reset scale on spawn
if SERVER then
	hook.Add("PlayerSpawn", "PAS.Scale", function(ply)
		if ply.pas_scaled then
			ply.pas_scaled = nil
			ply:SetModelScale(1)
			ply:SetViewOffset(Vector(0, 0, 64))
			ply:SetViewOffsetDucked(Vector(0, 0, 28))
		end
	end)
end

-- Freeze props command
pas.cmd.Create('freezeprops', function(pl, args)
	local count = 0
	for _, prop in ipairs(ents.FindByClass("prop_physics")) do
		local phys = prop:GetPhysicsObject()
		if IsValid(phys) then
			phys:EnableMotion(false)
			count = count + 1
		end
	end
	
	pas.notify_all(pl:Nick() .. ' froze ' .. count .. ' props', 0)
	pas.log.Add('Command', pl:Nick() .. ' froze all props')
end)
	:SetFlag('m')
	:SetHelp('Freeze all props on the map')
	:SetIcon('icon16/box.png')

-- Unfreeze props command
pas.cmd.Create('unfreezeprops', function(pl, args)
	local count = 0
	for _, prop in ipairs(ents.FindByClass("prop_physics")) do
		local phys = prop:GetPhysicsObject()
		if IsValid(phys) then
			phys:EnableMotion(true)
			count = count + 1
		end
	end
	
	pas.notify_all(pl:Nick() .. ' unfroze ' .. count .. ' props', 0)
	pas.log.Add('Command', pl:Nick() .. ' unfroze all props')
end)
	:SetFlag('m')
	:SetHelp('Unfreeze all props on the map')
	:SetIcon('icon16/box.png')

