-- Utility commands for PANTHEON
if (SERVER) then
	AddCSLuaFile()
end

-- Cleanup command
pas.cmd.Create('cleanup', function(pl, args)
	game.CleanUpMap()
	pas.notify_all(pl:Nick() .. ' cleaned up the map', 0)
	pas.log.Add('Command', pl:Nick() .. ' used cleanup')
end)
	:SetFlag('a')
	:SetHelp('Clean up all entities on the map')
	:SetIcon('icon16/bin.png')

-- Respawn command
pas.cmd.Create('respawn', function(pl, args)
	local target = args[1] or '^'
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	for _, targ in ipairs(targets) do
		targ:Spawn()
		pas.notify(pl, 'Respawned ' .. targ:Nick(), 0)
	end
end)
	:SetFlag('a')
	:SetHelp('Respawn a player')
	:SetIcon('icon16/user_add.png')

-- Set health command
pas.cmd.Create('sethealth', function(pl, args)
	local target = args[1]
	local health = tonumber(args[2]) or 100
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		targ:SetHealth(health)
		pas.notify(pl, 'Set ' .. targ:Nick() .. '\'s health to ' .. health, 0)
	end
end)
	:SetFlag('a')
	:SetHelp('Set a player\'s health')
	:SetIcon('icon16/heart.png')
	:AddAlias('hp')

-- Set armor command
pas.cmd.Create('setarmor', function(pl, args)
	local target = args[1]
	local armor = tonumber(args[2]) or 100
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		targ:SetArmor(armor)
		pas.notify(pl, 'Set ' .. targ:Nick() .. '\'s armor to ' .. armor, 0)
	end
end)
	:SetFlag('a')
	:SetHelp('Set a player\'s armor')
	:SetIcon('icon16/shield.png')
	:AddAlias('armor')

-- Strip weapons command
pas.cmd.Create('strip', function(pl, args)
	local target = args[1]
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		targ:StripWeapons()
		pas.notify(pl, 'Stripped ' .. targ:Nick() .. '\'s weapons', 0)
	end
end)
	:SetFlag('a')
	:SetHelp('Strip a player\'s weapons')
	:SetIcon('icon16/gun.png')

-- Bring command (enhanced from D3A)
pas.cmd.Create('bring', function(pl, args)
	if not pl:IsPlayer() then
		pas.notify(pl, 'Console cannot use bring command', 1)
		return
	end
	
	local target = args[1]
	
	if not target then
		pas.notify(pl, 'Usage: !bring <player>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	local bringPos = pl:GetPos()
	local str = pl:Nick() .. " teleported "
	
	for k, targ in ipairs(targets) do
		if not targ:Alive() then
			targ:Spawn()
		end
		
		if targ:InVehicle() then
			targ:ExitVehicle()
		end
		
		-- Find empty position near admin
		local pos = pas.FindEmptyPos(bringPos, {targ}, 600, 30, Vector(16, 16, 64))
		targ.LastPos = targ:GetPos()
		targ:SetPos(pos)
		
		-- Build notification string
		if (targets[k+2]) then
			str = str .. targ:Nick() .. ", "
		elseif (targets[k+1]) then
			str = str .. targ:Nick() .. " and "
		else
			str = str .. targ:Nick() .. "."
		end
		
		pas.notify(targ, pl:Nick() .. " teleported you to them", 0)
	end
	
	-- Notify all staff
	for _, v in pairs(player.GetAll()) do 
		if v:HasFlag('m') then 
			pas.notify(v, str, 0)
		end 
	end
	
	pas.log.Add('Command', str)
end)
	:SetFlag('a')
	:SetHelp('Teleport players to you')
	:SetIcon('icon16/arrow_down.png')

-- Goto command
pas.cmd.Create('goto', function(pl, args)
	if not pl:IsPlayer() then
		pas.notify(pl, 'Console cannot use goto command', 1)
		return
	end
	
	local target = args[1]
	
	if not target then
		pas.notify(pl, 'Usage: !goto <player>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	local targ = targets[1]
	
	if pl:InVehicle() then
		pl:ExitVehicle()
	end
	
	-- Find safe position near target
	local pos = pas.FindEmptyPos(targ:GetPos(), {pl}, 600, 30, Vector(16, 16, 64))
	pl.LastPos = pl:GetPos()
	pl:SetPos(pos)
	
	pas.notify(pl, 'Teleported to ' .. targ:Nick(), 0)
	pas.log.Add('Command', pl:Nick() .. ' teleported to ' .. targ:Nick())
end)
	:SetFlag('a')
	:SetHelp('Teleport to a player')
	:SetIcon('icon16/arrow_right.png')

-- Return command (go back to last position)
pas.cmd.Create('return', function(pl, args)
	if not pl:IsPlayer() then
		pas.notify(pl, 'Console cannot use return command', 1)
		return
	end
	
	if not pl.LastPos then
		pas.notify(pl, 'No previous position saved', 1)
		return
	end
	
	if pl:InVehicle() then
		pl:ExitVehicle()
	end
	
	local returnPos = pl.LastPos
	pl.LastPos = pl:GetPos() -- Update last position before moving
	pl:SetPos(returnPos)
	
	pas.notify(pl, 'Returned to previous position', 0)
	pas.log.Add('Command', pl:Nick() .. ' used return')
end)
	:SetFlag('a')
	:SetHelp('Return to your previous position')
	:SetIcon('icon16/arrow_undo.png')

-- Freeze command
pas.cmd.Create('freeze', function(pl, args)
	local target = args[1]
	
	if not target then
		pas.notify(pl, 'Usage: !freeze <player>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		local frozen = targ:IsFrozen()
		targ:Freeze(not frozen)
		
		local action = frozen and 'unfroze' or 'froze'
		pas.notify(pl, string.upper(string.sub(action, 1, 1)) .. string.sub(action, 2) .. ' ' .. targ:Nick(), 0)
		pas.notify(targ, pl:Nick() .. ' ' .. action .. ' you', frozen and 0 or 1)
		pas.log.Add('Command', pl:Nick() .. ' ' .. action .. ' ' .. targ:Nick())
	end
end)
	:SetFlag('m')
	:SetHelp('Freeze/unfreeze a player')
	:SetIcon('icon16/stop.png')

-- Slay command
pas.cmd.Create('slay', function(pl, args)
	local target = args[1]
	
	if not target then
		pas.notify(pl, 'Usage: !slay <player>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		if targ:Alive() then
			targ:Kill()
			pas.notify(pl, 'Slayed ' .. targ:Nick(), 0)
			pas.notify(targ, 'You were slayed by ' .. pl:Nick(), 1)
			pas.log.Add('Command', pl:Nick() .. ' slayed ' .. targ:Nick())
		else
			pas.notify(pl, targ:Nick() .. ' is already dead', 1)
		end
	end
end)
	:SetFlag('a')
	:SetHelp('Kill a player')
	:SetIcon('icon16/cross.png')

-- God mode command
pas.cmd.Create('god', function(pl, args)
	local target = args[1]
	
	if not target then
		pas.notify(pl, 'Usage: !god <player>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		local hasGod = targ:HasGodMode()
		
		if hasGod then
			targ:GodDisable()
		else
			targ:GodEnable()
		end
		
		local action = hasGod and 'disabled' or 'enabled'
		pas.notify(pl, string.upper(string.sub(action, 1, 1)) .. string.sub(action, 2) .. ' god mode for ' .. targ:Nick(), 0)
		pas.notify(targ, pl:Nick() .. ' ' .. action .. ' god mode for you', hasGod and 1 or 0)
		pas.log.Add('Command', pl:Nick() .. ' ' .. action .. ' god mode for ' .. targ:Nick())
	end
end)
	:SetFlag('a')
	:SetHelp('Toggle god mode for a player')
	:SetIcon('icon16/shield.png')

-- Ghost command (invisibility)
pas.cmd.Create('ghost', function(pl, args)
	local target = args[1]
	
	if not target then
		pas.notify(pl, 'Usage: !ghost <player>', 1)
		return
	end
	
	local targets = pas.parser.ParsePlayer(target, pl)
	
	if #targets == 0 then
		pas.notify(pl, 'Player not found', 1)
		return
	end
	
	for _, targ in ipairs(targets) do
		local isGhost = targ:GetNWBool('PANTHEON_Ghost', false)
		
		if isGhost then
			-- Make visible
			targ:SetNWBool('PANTHEON_Ghost', false)
			targ:SetRenderMode(RENDERMODE_NORMAL)
			targ:SetColor(Color(255, 255, 255, 255))
			targ:DrawShadow(true)
			
			-- Make player solid again
			targ:SetCollisionGroup(COLLISION_GROUP_PLAYER)
		else
			-- Make invisible
			targ:SetNWBool('PANTHEON_Ghost', true)
			targ:SetRenderMode(RENDERMODE_TRANSALPHA)
			targ:SetColor(Color(255, 255, 255, 0))
			targ:DrawShadow(false)
			
			-- Make player non-solid
			targ:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
		end
		
		local action = isGhost and 'disabled' or 'enabled'
		pas.notify(pl, string.upper(string.sub(action, 1, 1)) .. string.sub(action, 2) .. ' ghost mode for ' .. targ:Nick(), 0)
		pas.notify(targ, pl:Nick() .. ' ' .. action .. ' ghost mode for you', isGhost and 1 or 0)
		pas.log.Add('Command', pl:Nick() .. ' ' .. action .. ' ghost mode for ' .. targ:Nick())
	end
end)
	:SetFlag({'g', 'm'})
	:SetHelp('Toggle ghost mode (invisibility) for a player')
	:SetIcon('icon16/user_gray.png')
	:AddAlias('invis')
