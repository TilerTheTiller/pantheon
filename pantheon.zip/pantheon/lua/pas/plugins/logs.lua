-- Logs viewer command for PANTHEON
if (SERVER) then
	AddCSLuaFile()
	util.AddNetworkString('pas.OpenLogs')
end

if CLIENT then
	-- Receive request to open logs viewer
	net.Receive('pas.OpenLogs', function()
		if pas.log and pas.log.OpenViewer then
			pas.log.OpenViewer()
		else
			print('[PANTHEON] Error: Logging system not initialized yet')
		end
	end)
end

-- Command to open logs viewer
pas.cmd.Create('logs', function(pl, args)
	if CLIENT then return end
	
	-- Tell client to open the logs viewer
	net.Start('pas.OpenLogs')
	net.Send(pl)
end)
	-- No arguments needed - just opens the logs viewer
	:SetFlag('m')
	:SetHelp('Open the logs viewer')
	:SetIcon('icon16/book.png')
	:AddAlias('viewlogs')

print('[PANTHEON] Logs commands loaded')
