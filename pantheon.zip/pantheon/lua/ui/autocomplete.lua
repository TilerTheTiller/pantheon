-- PANTHEON Autocomplete Scroll Panel
-- Custom optimized scroll panel for chat command autocomplete

if SERVER then
	AddCSLuaFile()
	return
end

local PANEL = {}

function PANEL:Init()
	self.items = {}
	self.selectedIndex = 0
	self.scrollOffset = 0
	self.itemHeight = 25
	self.visibleItems = 8
	self.hoverFraction = 0
	
	-- Scrollbar
	self.scrollBar = vgui.Create('DPanel', self)
	self.scrollBar:SetWide(4)
	self.scrollBar:SetVisible(false)
	
	function self.scrollBar:Paint(w, h)
		-- Track
		surface.SetDrawColor(0, 0, 0, 100)
		surface.DrawRect(0, 0, w, h)
		
		-- Thumb
		local parent = self:GetParent()
		if parent and #parent.items > parent.visibleItems then
			local thumbHeight = math.max(20, h * (parent.visibleItems / #parent.items))
			local thumbY = (h - thumbHeight) * (parent.scrollOffset / (#parent.items - parent.visibleItems))
			
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 200)
			surface.DrawRect(0, thumbY, w, thumbHeight)
		end
	end
end

function PANEL:Clear()
	self.items = {}
	self.selectedIndex = 0
	self.scrollOffset = 0
end

function PANEL:AddItem(data)
	table.insert(self.items, data)
	self:UpdateScrollBar()
end

function PANEL:SetItemHeight(height)
	self.itemHeight = height
end

function PANEL:SetVisibleItems(count)
	self.visibleItems = count
	self:UpdateScrollBar()
end

function PANEL:GetSelectedIndex()
	return self.selectedIndex
end

function PANEL:SetSelectedIndex(index)
	self.selectedIndex = math.Clamp(index, 0, #self.items)
	
	-- Auto-scroll to keep selected item visible
	if self.selectedIndex > 0 then
		if self.selectedIndex - 1 < self.scrollOffset then
			self.scrollOffset = self.selectedIndex - 1
		elseif self.selectedIndex - 1 >= self.scrollOffset + self.visibleItems then
			self.scrollOffset = self.selectedIndex - self.visibleItems
		end
	end
	
	self.scrollOffset = math.Clamp(self.scrollOffset, 0, math.max(0, #self.items - self.visibleItems))
end

function PANEL:Navigate(direction)
	local newIndex = self.selectedIndex + direction
	
	-- Wrap around
	if newIndex < 1 then
		newIndex = #self.items
	elseif newIndex > #self.items then
		newIndex = 1
	end
	
	self:SetSelectedIndex(newIndex)
end

function PANEL:GetSelectedItem()
	if self.selectedIndex > 0 and self.selectedIndex <= #self.items then
		return self.items[self.selectedIndex]
	end
	return nil
end

function PANEL:UpdateScrollBar()
	if #self.items > self.visibleItems then
		self.scrollBar:SetVisible(true)
	else
		self.scrollBar:SetVisible(false)
		self.scrollOffset = 0
	end
end

function PANEL:OnMouseWheeled(delta)
	if #self.items <= self.visibleItems then return end
	
	self.scrollOffset = self.scrollOffset - delta
	self.scrollOffset = math.Clamp(self.scrollOffset, 0, #self.items - self.visibleItems)
	
	return true
end

function PANEL:OnCursorMoved(x, y)
	if #self.items == 0 then return end
	
	local itemIndex = math.floor(y / self.itemHeight) + self.scrollOffset + 1
	
	if itemIndex >= 1 and itemIndex <= #self.items then
		self.hoveredIndex = itemIndex
	else
		self.hoveredIndex = nil
	end
end

function PANEL:OnCursorExited()
	self.hoveredIndex = nil
end

function PANEL:OnMousePressed(keyCode)
	if keyCode == MOUSE_LEFT and self.hoveredIndex then
		self:SetSelectedIndex(self.hoveredIndex)
		
		if self.OnItemSelected then
			self:OnItemSelected(self.hoveredIndex, self.items[self.hoveredIndex])
		end
		
		return true
	end
end

function PANEL:Paint(w, h)
	-- Background with blur
	draw.Blur(self, 4)
	surface.SetDrawColor(0, 0, 0, 240)
	surface.DrawRect(0, 0, w, h)
	
	-- Border
	surface.SetDrawColor(ui.col.PANTHEON)
	surface.DrawOutlinedRect(0, 0, w, h)
	
	-- Draw items
	local y = 0
	local visibleCount = 0
	
	for i = self.scrollOffset + 1, math.min(self.scrollOffset + self.visibleItems, #self.items) do
		local item = self.items[i]
		visibleCount = visibleCount + 1
		
		-- Background
		local isSelected = (i == self.selectedIndex)
		local isHovered = (i == self.hoveredIndex)
		
		if isSelected then
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 200)
			surface.DrawRect(2, y + 2, w - 4, self.itemHeight - 4)
		elseif isHovered then
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 100)
			surface.DrawRect(2, y + 2, w - 4, self.itemHeight - 4)
		end
		
		-- Custom paint function if provided
		if self.PaintItem then
			self:PaintItem(item, i, 5, y + 2, w - 10, self.itemHeight - 4, isSelected, isHovered)
		else
			-- Default rendering
			local text = tostring(item.text or item.name or item)
			draw.SimpleText(text, 'PANTHEON.Chat', 8, y + self.itemHeight / 2, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		
		y = y + self.itemHeight
	end
	
	-- Empty state
	if #self.items == 0 then
		draw.SimpleText('No matches found', 'PANTHEON.ChatSmall', w / 2, h / 2, Color(150, 150, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	-- Scroll indicator (top)
	if self.scrollOffset > 0 then
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		local triSize = 6
		surface.DrawPoly({
			{x = w / 2 - triSize, y = 8},
			{x = w / 2 + triSize, y = 8},
			{x = w / 2, y = 2}
		})
	end
	
	-- Scroll indicator (bottom)
	if self.scrollOffset < #self.items - self.visibleItems then
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		local triSize = 6
		surface.DrawPoly({
			{x = w / 2 - triSize, y = h - 8},
			{x = w / 2 + triSize, y = h - 8},
			{x = w / 2, y = h - 2}
		})
	end
end

function PANEL:PerformLayout(w, h)
	-- Position scrollbar
	self.scrollBar:SetPos(w - 6, 2)
	self.scrollBar:SetTall(h - 4)
end

function PANEL:Think()
	-- Smooth scroll animations could go here
end

derma.DefineControl('pantheon_autocomplete', 'PANTHEON Autocomplete Panel', PANEL, 'EditablePanel')

print('[✓] UI: Autocomplete panel loaded')
