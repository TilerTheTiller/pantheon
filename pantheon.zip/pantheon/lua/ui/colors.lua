-- PANTHEON Color Scheme
if (SERVER) then
	AddCSLuaFile()
end

ui = ui or {}
ui.col = ui.col or {}

-- Primary PANTHEON Colors (Dark Theme)
ui.col.PANTHEON 		= Color(138, 43, 226)  -- Purple Primary
ui.col.PANTHEON_DARK 	= Color(75, 0, 130)    -- Dark Purple
ui.col.PANTHEON_LIGHT 	= Color(186, 85, 211)  -- Light Purple

-- Dark Theme Background Colors (Blurred)
ui.col.Background 		= Color(18, 18, 22, 245)    -- Main dark background
ui.col.BackgroundDark 	= Color(14, 14, 18, 245)    -- Darker panels
ui.col.BackgroundLight 	= Color(26, 26, 30, 245)    -- Lighter panels
ui.col.BackgroundCard 	= Color(24, 24, 28, 245)    -- Card backgrounds

-- Blur Settings
ui.col.BlurStrength 	= 8                         -- Default blur amount

-- UI Element Colors (Dark Theme)
ui.col.Outline 			= Color(66, 66, 66)         -- Subtle borders
ui.col.OutlineHovered 	= Color(138, 43, 226)       -- Purple hover borders
ui.col.Hover 			= Color(52, 52, 52, 255)    -- Hover backgrounds
ui.col.Button 			= Color(48, 48, 48)         -- Button background
ui.col.ButtonHover 		= Color(138, 43, 226)       -- Purple button hover
ui.col.ButtonActive 	= Color(75, 0, 130)         -- Active button state

-- Close Button Colors
ui.col.Close 			= Color(255, 100, 100)
ui.col.CloseBackground 	= Color(40, 40, 40)
ui.col.CloseHovered 	= Color(255, 50, 50)

-- Dark Theme Text Colors
ui.col.White 			= Color(255, 255, 255)
ui.col.OffWhite 		= Color(240, 240, 240)
ui.col.Black 			= Color(0, 0, 0)
ui.col.FlatBlack 		= Color(10, 10, 10)
ui.col.Grey 			= Color(150, 150, 150)
ui.col.DarkGrey 		= Color(80, 80, 80)

ui.col.TEXT 			= Color(255, 255, 255)    -- Primary text (white)
ui.col.TEXT_DIM 		= Color(160, 160, 160)    -- Secondary text
ui.col.TEXT_MUTED 		= Color(120, 120, 120)    -- Muted text
ui.col.HEADER 			= Color(48, 48, 52)       -- Header backgrounds
ui.col.BORDER 			= Color(66, 66, 66)       -- Border colors

-- Status Colors (Dark Theme Compatible)
ui.col.Red 				= Color(244, 67, 54)      -- Error/Danger
ui.col.Green 			= Color(76, 175, 80)      -- Success
ui.col.Blue 			= Color(33, 150, 243)     -- Info
ui.col.Yellow 			= Color(255, 193, 7)      -- Warning
ui.col.Orange 			= Color(255, 152, 0)      -- Alert

-- Enhanced Material Design Colors
ui.col.MaterialRed 		= Color(244, 67, 54)      -- Primary Red
ui.col.MaterialGreen 	= Color(76, 175, 80)      -- Primary Green
ui.col.MaterialBlue 	= Color(33, 150, 243)     -- Primary Blue
ui.col.MaterialIndigo 	= Color(63, 81, 181)      -- Primary Indigo
ui.col.MaterialOrange 	= Color(255, 152, 0)      -- Primary Orange
ui.col.MaterialTeal 	= Color(0, 150, 136)      -- Primary Teal
ui.col.MaterialPurple 	= Color(156, 39, 176)     -- Primary Purple
ui.col.MaterialYellow 	= Color(255, 235, 59)     -- Primary Yellow

-- Dark Theme Text Colors
ui.col.TextPrimary 		= Color(255, 255, 255)    -- Primary text (white on dark)
ui.col.TextSecondary 	= Color(160, 160, 160)    -- Secondary text
ui.col.TextDisabled 	= Color(100, 100, 100)    -- Disabled text
ui.col.TextHint 		= Color(120, 120, 120)    -- Hint text

-- Table/List Colors (for DListView styling)
ui.col.TableHeader 		= Color(56, 56, 60)       -- Table header background
ui.col.TableRow 		= Color(44, 44, 44)       -- Table row background
ui.col.TableRowAlt 		= Color(48, 48, 52)       -- Alternate row background
ui.col.TableRowHover 	= Color(138, 43, 226, 30) -- Row hover overlay

-- Helper function
function ui.col.Alpha(color, alpha)
	return Color(color.r, color.g, color.b, alpha)
end

-- Global helper for theme
function ColorAlpha(color, alpha)
	if not color then return Color(255, 255, 255, alpha or 255) end
	return Color(color.r, color.g, color.b, alpha)
end
