-- PANTHEON Derma Skin
if (SERVER) then
	AddCSLuaFile()
	-- Add Funnel Sans font family to resource downloads
	local funnelSansFonts = {
		"resource/fonts/FunnelSans-Regular.ttf",
		"resource/fonts/FunnelSans-Bold.ttf",
		"resource/fonts/FunnelSans-SemiBold.ttf",
		"resource/fonts/FunnelSans-Medium.ttf",
		"resource/fonts/FunnelSans-Light.ttf",
		"resource/fonts/FunnelSans-ExtraBold.ttf",
		"resource/fonts/FunnelSans-Italic.ttf",
		"resource/fonts/FunnelSans-BoldItalic.ttf",
		"resource/fonts/FunnelSans-SemiBoldItalic.ttf",
		"resource/fonts/FunnelSans-MediumItalic.ttf",
		"resource/fonts/FunnelSans-LightItalic.ttf",
		"resource/fonts/FunnelSans-ExtraBoldItalic.ttf"
	}
	
	for _, fontFile in ipairs(funnelSansFonts) do
		if file.Exists(fontFile, "GAME") then
			resource.AddFile(fontFile)
		end
	end
	return
end

-- Load custom font on client
if (CLIENT) then
	-- Ensure fonts are loaded after client initialization
	hook.Add("Initialize", "PANTHEON_LoadFonts", function()
		-- Small delay to ensure font files are loaded
		timer.Simple(0.5, function()
			print("[PANTHEON] Loading Funnel Sans fonts...")
			
			-- Recreate all PANTHEON fonts with Funnel Sans
			local fonts = {
				{name = "PANTHEON.Title", size = 28, weight = 700},
				{name = "PANTHEON.32", size = 32, weight = 700},
				{name = "PANTHEON.24", size = 24, weight = 600},
				{name = "PANTHEON.20", size = 20, weight = 500},
				{name = "PANTHEON.18", size = 18, weight = 500},
				{name = "PANTHEON.16", size = 16, weight = 400},
				{name = "PANTHEON.14", size = 14, weight = 400},
				{name = "PANTHEON.12", size = 12, weight = 400},
				{name = "PANTHEON.11", size = 11, weight = 400},
				{name = "PANTHEON.10", size = 10, weight = 400}
			}
			
			for _, font in ipairs(fonts) do
				surface.CreateFont(font.name, {
					font = "Funnel Sans",
					size = font.size,
					weight = font.weight,
					extended = true,
					antialias = true
				})
			end
			
			print("[PANTHEON] Funnel Sans fonts loaded successfully!")
		end)
	end)
end

local SKIN 	= {
	PrintName 	= 'PANTHEON',
	Author 	 	= 'PANTHEON Admin System'
}

local color_pantheon 		= ui.col.PANTHEON
local color_pantheon_dark 	= ui.col.PANTHEON_DARK
local color_background 		= ui.col.Background
local color_bg_dark 		= ui.col.BackgroundDark
local color_bg_light 		= ui.col.BackgroundLight
local color_outline 		= ui.col.Outline
local color_outline_hovered = ui.col.OutlineHovered
local color_hover 			= ui.col.Hover
local color_button 			= ui.col.Button
local color_button_hover	= ui.col.ButtonHover
local color_button_active 	= ui.col.ButtonActive
local color_close 			= ui.col.Close
local color_close_bg 		= ui.col.CloseBackground
local color_close_hover 	= ui.col.CloseHovered

local color_offwhite 		= ui.col.OffWhite
local color_flat_black 		= ui.col.FlatBlack
local color_black 			= ui.col.Black
local color_white 			= ui.col.White
local color_grey 			= ui.col.Grey
local color_red 			= ui.col.Red

-- Font registration using Funnel Sans
surface.CreateFont('PANTHEON.Title', {
	font = 'Funnel Sans',
	size = 28,
	weight = 700,
	extended = true,
	antialias = true
})

surface.CreateFont('PANTHEON.32', {
	font = 'Funnel Sans',
	size = 32,
	weight = 700,
	extended = true,
	antialias = true
})

surface.CreateFont('PANTHEON.24', {
	font = 'Funnel Sans',
	size = 24,
	weight = 600,
	extended = true,
	antialias = true
})

surface.CreateFont('PANTHEON.20', {
	font = 'Funnel Sans',
	size = 20,
	weight = 500,
	extended = true,
	antialias = true
})

surface.CreateFont('PANTHEON.18', {
	font = 'Funnel Sans',
	size = 18,
	weight = 500,
	extended = true,
	antialias = true
})

surface.CreateFont('PANTHEON.16', {
	font = 'Funnel Sans',
	size = 16,
	weight = 400,
	extended = true,
	antialias = true
})

surface.CreateFont('PANTHEON.14', {
	font = 'Funnel Sans',
	size = 14,
	weight = 400,
	extended = true,
	antialias = true
})

surface.CreateFont('PANTHEON.12', {
	font = 'Funnel Sans',
	size = 12,
	weight = 400,
	extended = true,
	antialias = true
})

surface.CreateFont('PANTHEON.11', {
	font = 'Funnel Sans',
	size = 11,
	weight = 400,
	extended = true,
	antialias = true
})

surface.CreateFont('PANTHEON.10', {
	font = 'Funnel Sans',
	size = 10,
	weight = 400,
	extended = true,
	antialias = true
})

-- Frames (Dark Theme with Blur)
function SKIN:PaintFrame(self, w, h)
	-- Blurred dark background
	draw.BlurredPanel(self, 8, Color(18, 18, 22), 245)
	
	-- Enhanced shadow effect for depth
	draw.Shadow(0, 0, w, h, 16, 140)
	
	-- Subtle dark frame outline
	surface.SetDrawColor(color_outline.r, color_outline.g, color_outline.b, 150)
	surface.DrawOutlinedRect(0, 0, w, h, 1)
	
	-- Dark title bar with purple accent
	draw.RoundedBoxEx(8, 0, 0, w, 32, ColorAlpha(color_bg_dark, 240), true, true, false, false)
	
	-- Purple accent line under title
	surface.SetDrawColor(color_pantheon.r, color_pantheon.g, color_pantheon.b, 255)
	surface.DrawRect(0, 32, w, 2)
	
	-- Subtle purple glow on title bar
	surface.SetDrawColor(color_pantheon.r, color_pantheon.g, color_pantheon.b, 30)
	surface.DrawRect(0, 0, w, 34)
end

function SKIN:PaintPanel(self, w, h)
	-- Blurred dark background
	draw.BlurredPanel(self, 5, Color(24, 24, 28), 245)
	
	-- Subtle border
	surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
	surface.DrawOutlinedRect(0, 0, w, h, 1)
end

function SKIN:PaintShadow() end

-- Enhanced Buttons (Dark Theme)
function SKIN:PaintButton(self, w, h)
	if (not self.m_bBackground) then return end

	-- Enhanced hover animation
	self.HoverFraction = self.HoverFraction or 0
	self.HoverFraction = Lerp(FrameTime() * 10, self.HoverFraction, self.Hovered and 1 or 0)
	
	local bgColor = ui.col.Button
	local borderColor = ui.col.Outline
	
	if self:GetDisabled() then
		bgColor = ColorAlpha(ui.col.Button, 100)
		borderColor = ColorAlpha(ui.col.Outline, 100)
	elseif (self.Active == true) then
		bgColor = ui.col.ButtonActive
		borderColor = ui.col.OutlineHovered
	elseif self.HoverFraction > 0 then
		-- Enhanced purple hover effect
		bgColor = Color(
			ui.col.Button.r + (ui.col.PANTHEON.r - ui.col.Button.r) * self.HoverFraction,
			ui.col.Button.g + (ui.col.PANTHEON.g - ui.col.Button.g) * self.HoverFraction,
			ui.col.Button.b + (ui.col.PANTHEON.b - ui.col.Button.b) * self.HoverFraction,
			255
		)
		borderColor = ColorAlpha(ui.col.PANTHEON, 200 * self.HoverFraction + 100 * (1 - self.HoverFraction))
	end
	
	-- Modern dark rounded button
	draw.RoundedBox(6, 0, 0, w, h, bgColor)
	
	-- Enhanced border
	surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, borderColor.a or 255)
	surface.DrawOutlinedRect(0, 0, w, h, 1)
	
	-- Purple glow effect on hover
	if self.HoverFraction > 0 then
		-- Outer glow
		for i = 1, 3 do
			local glowAlpha = (15 * self.HoverFraction) * (1 - (i / 3))
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, glowAlpha)
			surface.DrawOutlinedRect(-i, -i, w + i*2, h + i*2, 1)
		end
		
		-- Inner highlight
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 20 * self.HoverFraction)
		surface.DrawRect(2, 2, w - 4, h - 4)
	end

	self:SetTextColor(ui.col.White)

	if (not self.fontset) then
		self:SetFont('PANTHEON.16')
		self.fontset = true
	end
end

function SKIN:PaintAvatarImage(self, w, h)
	if self.Hovered then
		draw.RoundedBox(4, 0, 0, w, h, ColorAlpha(color_hover, 150))
	end
end

-- Close Button                                               
function SKIN:PaintWindowCloseButton(panel, w, h)
	if (not panel.m_bBackground) then return end

	-- Smooth hover animation
	panel.HoverFraction = panel.HoverFraction or 0
	panel.HoverFraction = Lerp(FrameTime() * 10, panel.HoverFraction, panel.Hovered and 1 or 0)
	
	local bgColor = ColorAlpha(color_close_bg, 255)
	if panel.HoverFraction > 0 then
		bgColor = ColorAlpha(color_close_hover, 200 + 55 * panel.HoverFraction)
	end
	
	-- Rounded close button
	draw.RoundedBox(4, 2, 2, w - 4, h - 4, bgColor)
	
	-- X icon with smooth scaling
	local scale = 1 + panel.HoverFraction * 0.2
	local xX = math.floor((w / 2) - 4 * scale)
	local xY = math.floor((h / 2) - 4 * scale)
	local xSize = math.floor(8 * scale)
	
	surface.SetDrawColor(color_white.r, color_white.g, color_white.b, 255)
	surface.DrawLine(xX, xY, xX + xSize, xY + xSize)
	surface.DrawLine(xX, xY + xSize, xX + xSize, xY)
end

-- Scrollbar
function SKIN:PaintVScrollBar(self, w, h) 
	-- Thin modern track
	draw.RoundedBox(4, w - 6, 0, 6, h, ColorAlpha(color_bg_dark, 100))
end

function SKIN:PaintButtonUp(self, w, h) end
function SKIN:PaintButtonDown(self, w, h) end
function SKIN:PaintButtonLeft(self, w, h) end
function SKIN:PaintButtonRight(self, w, h) end

function SKIN:PaintScrollBarGrip(self, w, h)
	-- Initialize hover animation
	self.HoverFraction = self.HoverFraction or 0
	self.HoverFraction = Lerp(FrameTime() * 6, self.HoverFraction, self.Hovered and 1 or 0)
	
	local gripColor = ColorAlpha(color_pantheon, 180 + 75 * self.HoverFraction)
	draw.RoundedBox(3, 2, 0, w - 4, h, gripColor)
end

function SKIN:PaintScrollPanel(self, w, h)
	-- Blurred dark background
	draw.BlurredPanel(self, 4, Color(28, 28, 32), 240)
	
	-- Subtle border
	surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
	surface.DrawOutlinedRect(0, 0, w, h, 1)
end

function SKIN:PaintUIScrollBar(self, w, h)
	draw.RoundedBox(4, 0, self.scrollButton.y, w, self.height, color_pantheon)
end

-- Slider
function SKIN:PaintUISlider(self, w, h)
	SKIN:PaintPanel(self, w, h)
	draw.Box(1, 1, self:GetValue() * w - self:GetValue() * 16, h - 2, color_pantheon)
end

-- Enhanced Text Entry (Dark Theme)
function SKIN:PaintTextEntry(self, w, h)
	-- Enhanced focus animation
	self.FocusFraction = self.FocusFraction or 0
	self.FocusFraction = Lerp(FrameTime() * 10, self.FocusFraction, self:HasFocus() and 1 or 0)
	
	-- Dark input background
	draw.RoundedBox(4, 0, 0, w, h, ui.col.BackgroundLight)
	
	-- Enhanced border with purple focus effect
	local borderColor = ui.col.Outline
	if self.FocusFraction > 0 then
		borderColor = Color(
			ui.col.Outline.r + (ui.col.PANTHEON.r - ui.col.Outline.r) * self.FocusFraction,
			ui.col.Outline.g + (ui.col.PANTHEON.g - ui.col.Outline.g) * self.FocusFraction,
			ui.col.Outline.b + (ui.col.PANTHEON.b - ui.col.Outline.b) * self.FocusFraction,
			200 + 55 * self.FocusFraction
		)
	end
	
	surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, borderColor.a)
	surface.DrawOutlinedRect(0, 0, w, h, 1)
	
	-- Enhanced glow when focused
	if self.FocusFraction > 0 then
		-- Outer glow
		for i = 1, 2 do
			local glowAlpha = (20 * self.FocusFraction) * (1 - (i / 2))
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, glowAlpha)
			surface.DrawOutlinedRect(-i, -i, w + i*2, h + i*2, 1)
		end
		
		-- Inner highlight
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 15 * self.FocusFraction)
		surface.DrawRect(1, 1, w - 2, h - 2)
	end

	self:DrawTextEntryText(ui.col.White, ui.col.PANTHEON, ui.col.White)
end

-- Enhanced List View (Dark Theme with Blur)
function SKIN:PaintUIListView(self, w, h) 
	-- Blurred dark background
	draw.BlurredPanel(self, 5, Color(22, 22, 26), 245)
	
	-- Subtle border
	surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 80)
	surface.DrawOutlinedRect(0, 0, w, h, 1)
end

function SKIN:PaintListView(self, w, h) 
	-- Blurred dark background
	draw.BlurredPanel(self, 5, Color(22, 22, 26), 245)
	
	-- Subtle border
	surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 80)
	surface.DrawOutlinedRect(0, 0, w, h, 1)
end

function SKIN:PaintListViewLine(self, w, h)
	-- Enhanced hover animation
	self.HoverFraction = self.HoverFraction or 0
	self.HoverFraction = Lerp(FrameTime() * 12, self.HoverFraction, (self:IsSelected() or self:IsHovered()) and 1 or 0)
	
	-- Dark theme row backgrounds
	local bgColor = ui.col.TableRow
	if self.m_bAlt then
		bgColor = ui.col.TableRowAlt
	end
	
	-- Enhanced hover and selection effects
	if self:IsSelected() then
		bgColor = ColorAlpha(ui.col.PANTHEON, 180)
	elseif self.HoverFraction > 0 then
		-- Smooth purple hover effect
		local hoverColor = ColorAlpha(ui.col.PANTHEON, 60 * self.HoverFraction)
		bgColor = Color(
			bgColor.r + (hoverColor.r - bgColor.r) * self.HoverFraction,
			bgColor.g + (hoverColor.g - bgColor.g) * self.HoverFraction,
			bgColor.b + (hoverColor.b - bgColor.b) * self.HoverFraction,
			255
		)
	end
	
	-- Draw row background
	draw.RoundedBox(0, 0, 0, w, h, bgColor)
	
	-- Enhanced separator line
	if not (self:IsSelected() or self:IsHovered()) then
		surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
		surface.DrawRect(0, h - 1, w, 1)
	end
	
	-- Left accent bar for selected items
	if self:IsSelected() then
		surface.SetDrawColor(ui.col.PANTHEON_LIGHT.r, ui.col.PANTHEON_LIGHT.g, ui.col.PANTHEON_LIGHT.b, 255)
		surface.DrawRect(0, 0, 3, h)
	end

	-- Enhanced text styling for columns
	for k, v in ipairs(self.Columns) do
		if self:IsSelected() then
			v:SetTextColor(ui.col.White)
			v:SetFont('PANTHEON.16')
		elseif self.HoverFraction > 0.3 then
			local textColor = Color(
				ui.col.TEXT.r,
				ui.col.TEXT.g, 
				ui.col.TEXT.b,
				255 * (0.7 + 0.3 * self.HoverFraction)
			)
			v:SetTextColor(textColor)
			v:SetFont('PANTHEON.16')
		else
			v:SetTextColor(ui.col.TEXT_DIM)
			v:SetFont('PANTHEON.14')
		end
	end
end

-- Enhanced List View Header
function SKIN:PaintListViewLabel(self, w, h)
	-- Dark header background with gradient
	local col1 = ui.col.TableHeader
	local col2 = ColorAlpha(ui.col.PANTHEON, 30)
	
	-- Gradient background
	surface.SetDrawColor(col1.r, col1.g, col1.b, col1.a)
	surface.DrawRect(0, 0, w, h/2)
	surface.SetDrawColor(col2.r, col2.g, col2.b, col2.a)
	surface.DrawRect(0, h/2, w, h/2)
	
	-- Purple accent line at bottom
	surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 200)
	surface.DrawRect(0, h-2, w, 2)
	
	-- Header text
	self:SetTextColor(ui.col.White)
	self:SetFont('PANTHEON.16')
end

-- Checkbox
function SKIN:PaintCheckBox(self, w, h)
	-- Initialize animation
	self.CheckFraction = self.CheckFraction or 0
	self.CheckFraction = Lerp(FrameTime() * 10, self.CheckFraction, self:GetChecked() and 1 or 0)
	
	local borderColor = self:GetChecked() and color_pantheon or color_outline
	draw.RoundedBox(4, 0, 0, w, h, color_button)
	
	surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, 255)
	surface.DrawOutlinedRect(0, 0, w, h)

	if self.CheckFraction > 0 then 
		local size = (w - 8) * self.CheckFraction
		local offset = (w - 8 - size) / 2 + 4
		draw.RoundedBox(2, offset, offset, size, size, ColorAlpha(color_pantheon, 255 * self.CheckFraction))
	end
end

-- Tabs
function SKIN:PaintTabButton(self, w, h)
	-- Initialize hover animation
	self.HoverFraction = self.HoverFraction or 0
	self.HoverFraction = Lerp(FrameTime() * 8, self.HoverFraction, (self.Hovered or self.Active) and 1 or 0)
	
	draw.RoundedBox(0, 0, 0, w, h, color_background)

	self:SetTextColor(color_white)
	self:SetFont('PANTHEON.18')

	if self.Active then
		-- Active tab indicator
		draw.RoundedBox(0, 0, h - 3, w, 3, color_pantheon)
	elseif self.HoverFraction > 0 then
		-- Hover effect
		surface.SetDrawColor(color_pantheon.r, color_pantheon.g, color_pantheon.b, 100 * self.HoverFraction)
		surface.DrawRect(0, h - 2, w, 2)
	end
end

function SKIN:PaintTabListPanel(self, w, h)
	draw.RoundedBox(6, 149, 0, w - 149, h, color_background)
end

-- ComboBox
function SKIN:PaintComboBox(self, w, h)
	if IsValid(self.Menu) and (not self.Menu.SkinSet) then
		self.Menu:SetSkin('PANTHEON')
		self.Menu.SkinSet = true
	end

	self:SetTextColor(((self.Hovered or self.Depressed or self:IsMenuOpen()) and color_white or color_offwhite))

	draw.OutlinedBox(0, 0, w, h, ((self.Hovered or self.Depressed or self:IsMenuOpen()) and color_button_hover or color_button), 
		((self.Hovered or self.Depressed or self:IsMenuOpen()) and color_outline_hovered or color_outline))
end

function SKIN:PaintComboDownArrow(self, w, h)
	surface.SetDrawColor(color_pantheon)
	draw.NoTexture()
	surface.DrawPoly({
		{x = 0, y = w * .5},
		{x = h, y = 0},
		{x = h, y = w}
	})
end

-- DMenu (Context Menus with Blur)
function SKIN:PaintMenu(self, w, h)
	-- Blurred dark background
	draw.BlurredPanel(self, 7, Color(20, 20, 24), 250)
	
	-- Enhanced shadow for depth
	draw.Shadow(0, 0, w, h, 8, 80)
	
	-- Subtle border
	surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 100)
	surface.DrawOutlinedRect(0, 0, w, h, 1)
end

function SKIN:PaintMenuOption(self, w, h)
	if (not self.FontSet) then
		self:SetFont('PANTHEON.18')
		self:SetTextInset(5, 0)
		self.FontSet = true
	end
	
	-- Initialize hover animation
	self.HoverFraction = self.HoverFraction or 0
	self.HoverFraction = Lerp(FrameTime() * 10, self.HoverFraction, (self.Hovered or self.Highlight) and 1 or 0)
	
	self:SetTextColor(color_white)
	
	if self.HoverFraction > 0 then
		draw.Box(0, 0, w, h + 1, ColorAlpha(color_pantheon, 180 * self.HoverFraction))
	end
	
	-- Subtle separator
	if self.HoverFraction < 0.3 then
		surface.SetDrawColor(color_outline.r, color_outline.g, color_outline.b, 30)
		surface.DrawRect(5, h, w - 10, 1)
	end
end

-- DPropertySheet
function SKIN:PaintPropertySheet(self, w, h)
	local activeTab = self:GetActiveTab()
	if activeTab then
		draw.Box(0, activeTab:GetTall(), w, h - activeTab:GetTall(), color_bg_light)
	else
		draw.Box(0, 0, w, h, color_bg_light)
	end
end

function SKIN:PaintTab(self, w, h)
	local active = self:GetPropertySheet():GetActiveTab() == self
	
	if (active) then
		self:SetTextColor(color_white)
		draw.Box(0, 0, w, h, color_pantheon)
	elseif (self:IsHovered()) then
		self:SetTextColor(color_white)
		draw.Box(0, 0, w, h, color_button_hover)
	else
		self:SetTextColor(color_grey)
		draw.Box(0, 0, w, h, color_button)
	end
	
	self:SetFont('PANTHEON.16')
end

-- Progress Bar
function SKIN:PaintProgress(self, w, h)
	-- Initialize animation
	self.ProgressFraction = self.ProgressFraction or 0
	local targetFraction = self:GetFraction()
	self.ProgressFraction = Lerp(FrameTime() * 5, self.ProgressFraction, targetFraction)
	
	draw.RoundedBox(4, 0, 0, w, h, color_bg_dark)
	
	if self.ProgressFraction > 0 then
		local fillWidth = (w - 4) * self.ProgressFraction
		draw.RoundedBox(3, 2, 2, fillWidth, h - 4, color_pantheon)
		
		-- Subtle shine effect
		surface.SetDrawColor(255, 255, 255, 30)
		surface.DrawRect(2, 2, fillWidth, (h - 4) / 2)
	end
end

-- Category Header
function SKIN:PaintCategoryButton(self, w, h)
	if self:GetExpanded() then
		draw.Box(0, 0, w, h, color_pantheon_dark)
	else
		draw.Box(0, 0, w, h, color_button)
	end
	
	self:SetTextColor(color_white)
	self:SetFont('PANTHEON.18')
end

-- Number Wang
function SKIN:PaintNumberWang(self, w, h)
	draw.OutlinedBox(0, 0, w, h, color_bg_light, color_outline)
end

derma.DefineSkin('PANTHEON', 'PANTHEON Admin System Derma Skin', SKIN)
