--[[
    PANTHEON - Advanced Layout System
    Flexbox and Grid layout systems for responsive UI
]]--

if SERVER then
    AddCSLuaFile()
    return
end

ui = ui or {}
ui.layout = ui.layout or {}

--[[
    Flex Layout Container
]]--
local FLEX_CONTAINER = {}
FLEX_CONTAINER.__index = FLEX_CONTAINER

function FLEX_CONTAINER:New(parent)
    local container = setmetatable({}, self)
    
    container.panel = vgui.Create('DPanel', parent)
    container.panel.Paint = function() end -- Transparent by default
    
    container.children = {}
    container.properties = {
        direction = 'row', -- row, column
        justify = 'flex-start', -- flex-start, center, flex-end, space-between, space-around
        align = 'stretch', -- stretch, flex-start, center, flex-end
        gap = 0,
        padding = {top = 0, right = 0, bottom = 0, left = 0}
    }
    
    return container
end

function FLEX_CONTAINER:SetDirection(direction)
    self.properties.direction = direction
    self:UpdateLayout()
    return self
end

function FLEX_CONTAINER:SetJustifyContent(justify)
    self.properties.justify = justify
    self:UpdateLayout()
    return self
end

function FLEX_CONTAINER:SetAlignItems(align)
    self.properties.align = align
    self:UpdateLayout()
    return self
end

function FLEX_CONTAINER:SetGap(gap)
    self.properties.gap = gap
    self:UpdateLayout()
    return self
end

function FLEX_CONTAINER:SetPadding(top, right, bottom, left)
    if type(top) == 'table' then
        self.properties.padding = top
    else
        right = right or top
        bottom = bottom or top
        left = left or right
        self.properties.padding = {top = top, right = right, bottom = bottom, left = left}
    end
    self:UpdateLayout()
    return self
end

function FLEX_CONTAINER:AddChild(child, flexProperties)
    flexProperties = flexProperties or {}
    
    table.insert(self.children, {
        panel = child,
        flex = flexProperties.flex or 0,
        minWidth = flexProperties.minWidth or 0,
        minHeight = flexProperties.minHeight or 0,
        maxWidth = flexProperties.maxWidth or math.huge,
        maxHeight = flexProperties.maxHeight or math.huge
    })
    
    self:UpdateLayout()
    return self
end

function FLEX_CONTAINER:UpdateLayout()
    if not IsValid(self.panel) then return end
    
    local w, h = self.panel:GetSize()
    local padding = self.properties.padding
    
    local availableWidth = w - padding.left - padding.right
    local availableHeight = h - padding.top - padding.bottom
    
    if self.properties.direction == 'row' then
        self:LayoutRow(availableWidth, availableHeight)
    else
        self:LayoutColumn(availableWidth, availableHeight)
    end
end

function FLEX_CONTAINER:LayoutRow(availableWidth, availableHeight)
    local children = self.children
    local gap = self.properties.gap
    local padding = self.properties.padding
    
    local totalFlex = 0
    local fixedWidth = 0
    
    for _, child in ipairs(children) do
        if child.flex > 0 then
            totalFlex = totalFlex + child.flex
        else
            fixedWidth = fixedWidth + child.panel:GetWide()
        end
    end
    
    local totalGaps = (#children - 1) * gap
    fixedWidth = fixedWidth + totalGaps
    local flexSpace = math.max(0, availableWidth - fixedWidth)
    
    local currentX = padding.left
    
    for _, child in ipairs(children) do
        local childWidth, childHeight
        
        if child.flex > 0 and totalFlex > 0 then
            childWidth = math.floor((flexSpace * child.flex) / totalFlex)
        else
            childWidth = child.panel:GetWide()
        end
        
        childWidth = math.max(child.minWidth, math.min(child.maxWidth, childWidth))
        
        local alignSelf = self.properties.align
        if alignSelf == 'stretch' then
            childHeight = availableHeight
        else
            childHeight = child.panel:GetTall()
        end
        
        childHeight = math.max(child.minHeight, math.min(child.maxHeight, childHeight))
        
        local yPos = padding.top
        if alignSelf == 'center' then
            yPos = padding.top + (availableHeight - childHeight) / 2
        elseif alignSelf == 'flex-end' then
            yPos = padding.top + availableHeight - childHeight
        end
        
        child.panel:SetPos(currentX, yPos)
        child.panel:SetSize(childWidth, childHeight)
        
        currentX = currentX + childWidth + gap
    end
end

function FLEX_CONTAINER:LayoutColumn(availableWidth, availableHeight)
    local children = self.children
    local gap = self.properties.gap
    local padding = self.properties.padding
    
    local totalFlex = 0
    local fixedHeight = 0
    
    for _, child in ipairs(children) do
        if child.flex > 0 then
            totalFlex = totalFlex + child.flex
        else
            fixedHeight = fixedHeight + child.panel:GetTall()
        end
    end
    
    local totalGaps = (#children - 1) * gap
    fixedHeight = fixedHeight + totalGaps
    local flexSpace = math.max(0, availableHeight - fixedHeight)
    
    local currentY = padding.top
    
    for _, child in ipairs(children) do
        local childWidth, childHeight
        
        if child.flex > 0 and totalFlex > 0 then
            childHeight = math.floor((flexSpace * child.flex) / totalFlex)
        else
            childHeight = child.panel:GetTall()
        end
        
        childHeight = math.max(child.minHeight, math.min(child.maxHeight, childHeight))
        
        local alignSelf = self.properties.align
        if alignSelf == 'stretch' then
            childWidth = availableWidth
        else
            childWidth = child.panel:GetWide()
        end
        
        childWidth = math.max(child.minWidth, math.min(child.maxWidth, childWidth))
        
        local xPos = padding.left
        if alignSelf == 'center' then
            xPos = padding.left + (availableWidth - childWidth) / 2
        elseif alignSelf == 'flex-end' then
            xPos = padding.left + availableWidth - childWidth
        end
        
        child.panel:SetPos(xPos, currentY)
        child.panel:SetSize(childWidth, childHeight)
        
        currentY = currentY + childHeight + gap
    end
end

function FLEX_CONTAINER:SetSize(w, h)
    self.panel:SetSize(w, h)
    self:UpdateLayout()
    return self
end

function FLEX_CONTAINER:SetPos(x, y)
    self.panel:SetPos(x, y)
    return self
end

function FLEX_CONTAINER:GetPanel()
    return self.panel
end

--[[
    Factory Functions
]]--

function ui.CreateFlexContainer(parent, direction)
    local container = FLEX_CONTAINER:New(parent)
    if direction then
        container:SetDirection(direction)
    end
    return container
end

function ui.CreateCenteredContainer(parent, maxWidth)
    local container = ui.CreateFlexContainer(parent, 'column')
    container:SetJustifyContent('center')
        :SetAlignItems('center')
    
    if maxWidth and IsValid(parent) then
        container.panel.Think = function(self)
            if not IsValid(parent) then return end
            local parentWidth = parent:GetWide()
            local width = math.min(maxWidth, parentWidth)
            local x = (parentWidth - width) / 2
            
            self:SetPos(x, 0)
            self:SetWide(width)
        end
    end
    
    return container
end

MsgC(ui.col.PANTHEON, '[PANTHEON] ', ui.col.White, 'Advanced Layout System loaded\n')
