-- PANTHEON UI Utilities
if (SERVER) then
	AddCSLuaFile()
	return
end

ui = ui or {}

-- Enhanced animation system
ui.animations = ui.animations or {}

-- Smooth easing functions for better animations
ui.easings = {
	linear = function(t) return t end,
	easeInQuad = function(t) return t * t end,
	easeOutQuad = function(t) return t * (2 - t) end,
	easeInOutQuad = function(t) return t < 0.5 and 2 * t * t or -1 + (4 - 2 * t) * t end,
	easeInCubic = function(t) return t * t * t end,
	easeOutCubic = function(t) return (t - 1) * (t - 1) * (t - 1) + 1 end,
	easeInOutCubic = function(t) return t < 0.5 and 4 * t * t * t or (t - 1) * (2 * t - 2) * (2 * t - 2) + 1 end,
	easeOutElastic = function(t)
		if t == 0 or t == 1 then return t end
		local p = 0.3
		local s = p / 4
		return math.pow(2, -10 * t) * math.sin((t - s) * (2 * math.pi) / p) + 1
	end
}

-- Advanced animation helper
function ui.Animate(obj, prop, target, duration, easing, callback)
	duration = duration or 0.3
	easing = easing or ui.easings.easeOutQuad
	
	local animId = tostring(obj) .. "_" .. prop
	local startValue = obj[prop] or 0
	local startTime = CurTime()
	
	ui.animations[animId] = {
		obj = obj,
		prop = prop,
		start = startValue,
		target = target,
		duration = duration,
		startTime = startTime,
		easing = easing,
		callback = callback
	}
end

-- Animation think hook
hook.Add("Think", "PANTHEON_UI_Animations", function()
	local currentTime = CurTime()
	for animId, anim in pairs(ui.animations) do
		-- Safety check: ensure anim is a table
		if type(anim) ~= "table" then
			ui.animations[animId] = nil
			continue
		end
		
		if not IsValid(anim.obj) then
			ui.animations[animId] = nil
			continue
		end
		
		local elapsed = currentTime - anim.startTime
		local progress = math.min(elapsed / anim.duration, 1)
		
		if progress >= 1 then
			anim.obj[anim.prop] = anim.target
			if anim.callback then anim.callback() end
			ui.animations[animId] = nil
		else
			local easedProgress = anim.easing(progress)
			anim.obj[anim.prop] = anim.start + (anim.target - anim.start) * easedProgress
		end
	end
end)

-- Enhanced blur with performance optimization
function draw.Blur(panel, amount, passes)
	amount = amount or 3
	passes = passes or 2
	
	local x, y = panel:LocalToScreen(0, 0)
	local w, h = panel:GetSize()
	local scrW, scrH = ScrW(), ScrH()
	
	-- Skip blur if panel is too small or offscreen
	if w < 10 or h < 10 or x > scrW or y > scrH or x + w < 0 or y + h < 0 then
		return
	end
	
	surface.SetDrawColor(255, 255, 255)
	surface.SetMaterial(Material("pp/blurscreen"))
	
	for i = 1, passes do
		Material("pp/blurscreen"):SetFloat("$blur", (i / passes) * amount)
		Material("pp/blurscreen"):Recompute()
		
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(x * -1, y * -1, scrW, scrH)
	end
end

-- Blurred dark background helper
function draw.BlurredPanel(panel, blurAmount, bgColor, bgAlpha)
	blurAmount = blurAmount or 6
	bgColor = bgColor or Color(18, 18, 22)
	bgAlpha = bgAlpha or 240
	
	-- Apply blur effect
	draw.Blur(panel, blurAmount, 3)
	
	-- Apply solid dark overlay
	local w, h = panel:GetSize()
	surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, bgAlpha)
	surface.DrawRect(0, 0, w, h)
end

-- Optimized blur for background panels (cached)
local blurCache = {}
function draw.CachedBlur(panel, amount, passes, cacheKey)
	cacheKey = cacheKey or tostring(panel)
	
	-- Check if we should update cache (every 0.1 seconds)
	local currentTime = CurTime()
	if blurCache[cacheKey] and (currentTime - blurCache[cacheKey].time) < 0.1 then
		return
	end
	
	blurCache[cacheKey] = {time = currentTime}
	draw.Blur(panel, amount, passes)
end

-- Enhanced glow effect
function draw.Glow(x, y, w, h, size, col, intensity)
	size = size or 8
	intensity = intensity or 1
	col = col or Color(255, 255, 255, 50)
	
	for i = 1, size do
		local alpha = col.a * (1 - (i / size)) * intensity
		surface.SetDrawColor(col.r, col.g, col.b, alpha)
		surface.DrawOutlinedRect(x - i, y - i, w + i * 2, h + i * 2)
	end
end

-- Animated gradient background
function draw.AnimatedGradient(x, y, w, h, col1, col2, direction, speed)
	direction = direction or "horizontal" -- "horizontal", "vertical", "diagonal"
	speed = speed or 1
	
	local time = CurTime() * speed
	local offset = (math.sin(time) + 1) * 0.5 -- 0 to 1
	
	-- Create animated color blend
	local r = col1.r + (col2.r - col1.r) * offset
	local g = col1.g + (col2.g - col1.g) * offset  
	local b = col1.b + (col2.b - col1.b) * offset
	local a = col1.a and (col1.a + ((col2.a or 255) - col1.a) * offset) or 255
	
	local blendedColor = Color(r, g, b, a)
	draw.RoundedBox(0, x, y, w, h, blendedColor)
end

function draw.Box(x, y, w, h, col)
	if not col then col = Color(255, 255, 255) end
	surface.SetDrawColor(col.r or col[1], col.g or col[2], col.b or col[3], col.a or col[4] or 255)
	surface.DrawRect(x, y, w, h)
end

-- Don't override draw.RoundedBox - GMod has a built-in one
-- Just add our helper if it doesn't exist
if not draw.RoundedBox then
	function draw.RoundedBox(borderRadius, x, y, w, h, col)
		if not col then col = Color(255, 255, 255) end
		surface.SetDrawColor(col.r or col[1], col.g or col[2], col.b or col[3], col.a or col[4] or 255)
		surface.DrawRect(x, y, w, h)
	end
end

function draw.OutlinedBox(x, y, w, h, fill, outline)
	if not fill then fill = Color(255, 255, 255) end
	if not outline then outline = Color(0, 0, 0) end
	surface.SetDrawColor(fill.r or fill[1], fill.g or fill[2], fill.b or fill[3], fill.a or fill[4] or 255)
	surface.DrawRect(x, y, w, h)
	surface.SetDrawColor(outline.r or outline[1], outline.g or outline[2], outline.b or outline[3], outline.a or outline[4] or 255)
	surface.DrawOutlinedRect(x, y, w, h)
end

-- Don't override draw.RoundedBoxEx - GMod has a built-in one
-- Just add shadow helper
function draw.Shadow(x, y, w, h, size, alpha)
	size = size or 5
	alpha = alpha or 100
	
	for i = 1, size do
		local a = alpha * (1 - (i / size))
		surface.SetDrawColor(0, 0, 0, a)
		surface.DrawOutlinedRect(x - i, y - i, w + i * 2, h + i * 2)
	end
end

-- Note: These just use the built-in draw library functions
-- No need to redefine them

function draw.NoTexture()
	surface.SetMaterial(Material("vgui/white"))
end

function draw.Circle(x, y, radius, segments, col)
	segments = segments or 32
	local circle = {}
	
	for i = 0, segments do
		local angle = math.rad((i / segments) * -360)
		table.insert(circle, {
			x = x + math.sin(angle) * radius,
			y = y + math.cos(angle) * radius
		})
	end
	
	surface.SetDrawColor(col)
	draw.NoTexture()
	surface.DrawPoly(circle)
end

function draw.OutlinedCircle(x, y, radius, segments, col)
	segments = segments or 32
	
	for i = 0, segments - 1 do
		local angle = math.rad((i / segments) * -360)
		local angle2 = math.rad(((i + 1) / segments) * -360)
		
		surface.SetDrawColor(col)
		surface.DrawLine(
			x + math.sin(angle) * radius,
			y + math.cos(angle) * radius,
			x + math.sin(angle2) * radius,
			y + math.cos(angle2) * radius
		)
	end
end

-- UI Helper functions
function ui.CreateFrame(title, w, h, icon)
	local frame = vgui.Create('DFrame')
	frame:SetTitle('')  -- We'll draw custom title with icon
	frame:SetSize(w or 800, h or 600)
	frame:Center()
	frame:MakePopup()
	frame:SetSkin('PANTHEON')
	frame:ShowCloseButton(false)  -- Hide default close button
	
	-- Store custom title and icon
	frame.CustomTitle = title or 'PANTHEON'
	frame.CustomIcon = icon
	frame.OpenAnimation = 0
	frame.PulseAnimation = 0
	
	-- Dark theme entrance animation
	frame:SetAlpha(0)
	frame:MoveTo(frame.x, frame.y - 30, 0.3, 0, 0.5, function()
		frame:SetAlpha(255)
	end)
	ui.Animate(frame, "OpenAnimation", 1, 0.3, ui.easings.easeOutCubic)
	
	-- Enhanced paint with blur and dark background
	local oldPaint = frame.Paint
	frame.Paint = function(self, fw, fh)
		-- Blurred dark background
		draw.BlurredPanel(self, 8, Color(18, 18, 22), 245)
		
		if oldPaint then oldPaint(self, fw, fh) end
		
		-- Subtle pulse animation for header
		self.PulseAnimation = (self.PulseAnimation or 0) + FrameTime() * 1.5
		local pulse = math.sin(self.PulseAnimation) * 0.1 + 0.9
		
		-- Dark theme title bar with purple gradient
		local titleHeight = 34
		local col1 = ColorAlpha(ui.col.PANTHEON, 255)
		local col2 = ColorAlpha(ui.col.PANTHEON_DARK, 255)
		draw.AnimatedGradient(0, 0, fw, titleHeight, col1, col2, "horizontal", 0.3)
		
		-- Enhanced purple glow effect
		draw.Glow(0, 0, fw, titleHeight, 4, ColorAlpha(ui.col.PANTHEON, 40 * pulse), pulse)
		
		-- Draw icon if provided with entrance animation
		local scale = self.OpenAnimation or 1
		if self.CustomIcon and ui and ui.DrawIcon then
			ui.DrawIcon(self.CustomIcon, 35, 17, 22 * scale, ColorAlpha(ui.col.White, 255 * scale))
			draw.SimpleText(self.CustomTitle, 'PANTHEON.18', 62, 17, ColorAlpha(ui.col.White, 255 * scale), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		else
			draw.SimpleText(self.CustomTitle, 'PANTHEON.18', 12, 17, ColorAlpha(ui.col.White, 255 * scale), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		
		-- Bright accent line with animation
		surface.SetDrawColor(ui.col.PANTHEON_LIGHT.r, ui.col.PANTHEON_LIGHT.g, ui.col.PANTHEON_LIGHT.b, 200 * pulse)
		surface.DrawRect(0, titleHeight - 2, fw, 2)
	end
	
	-- Create enhanced close button with hover effects
	local closeBtn = vgui.Create('DButton', frame)
	closeBtn:SetText('')
	closeBtn:SetSize(28, 28)
	closeBtn:SetPos(frame:GetWide() - 33, 3)
	closeBtn.HoverFraction = 0
	closeBtn.ClickAnimation = 0
	
	closeBtn.Paint = function(self, bw, bh)
		-- Smooth hover and click animations
		self.HoverFraction = Lerp(FrameTime() * 15, self.HoverFraction, self:IsHovered() and 1 or 0)
		self.ClickAnimation = Lerp(FrameTime() * 20, self.ClickAnimation, 0)
		
		-- Background with smooth transition
		local alpha = 30 + self.HoverFraction * 120
		local bgColor = ColorAlpha(Color(244, 67, 54), alpha)
		local scale = 1 - self.ClickAnimation * 0.1
		local offset = (1 - scale) * bw * 0.5
		
		draw.RoundedBox(6, offset, offset, bw * scale, bh * scale, bgColor)
		
		-- Glow effect on hover
		if self.HoverFraction > 0 then
			draw.Glow(0, 0, bw, bh, 2, ColorAlpha(Color(244, 67, 54), 50 * self.HoverFraction))
		end
		
		-- X icon with smooth scaling
		local iconScale = 0.8 + self.HoverFraction * 0.2 - self.ClickAnimation * 0.1
		local iconColor = ColorAlpha(Color(255, 255, 255), 200 + self.HoverFraction * 55)
		
		if ui and ui.DrawIcon then
			ui.DrawIcon('close', bw/2, bh/2, 14 * iconScale, iconColor)
		else
			-- Fallback X with enhanced styling
			surface.SetFont('PANTHEON.16')
			local tw, th = surface.GetTextSize('×')
			draw.SimpleText('×', 'PANTHEON.16', bw/2, bh/2, iconColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	
	closeBtn.DoClick = function(self)
		self.ClickAnimation = 1
		
		-- Enhanced close animation
		ui.Animate(frame, "OpenAnimation", 0, 0.2, ui.easings.easeInCubic, function()
			frame:MoveTo(frame.x, frame.y - 30, 0.2, 0, 0, function()
				frame:Close()
			end)
		end)
	end
	
	-- Store close button reference
	frame.CloseButton = closeBtn
	
	return frame
end

function ui.CreateButton(parent, text, x, y, w, h, callback, icon, style)
	local btn = vgui.Create('DButton', parent)
	btn:SetText('')  -- We'll draw custom text with icon
	btn:SetPos(x or 0, y or 0)
	btn:SetSize(w or 100, h or 30)
	
	btn.CustomText = text or ''
	btn.CustomIcon = icon
	btn.Style = style or 'primary' -- primary, secondary, success, warning, danger
	btn.HoverFraction = 0
	btn.ClickAnimation = 0
	btn.RippleAnimations = {}
	
	-- Style colors
	local styleColors = {
		primary = {bg = ui.col.PANTHEON or Color(63, 81, 181), text = Color(255, 255, 255)},
		secondary = {bg = Color(108, 117, 125), text = Color(255, 255, 255)},
		success = {bg = Color(40, 167, 69), text = Color(255, 255, 255)},
		warning = {bg = Color(255, 193, 7), text = Color(0, 0, 0)},
		danger = {bg = Color(220, 53, 69), text = Color(255, 255, 255)}
	}
	
	-- Override paint completely with enhanced effects
	btn.Paint = function(self, bw, bh)
		-- Smooth animations
		self.HoverFraction = Lerp(FrameTime() * 12, self.HoverFraction, self:IsHovered() and 1 or 0)
		self.ClickAnimation = Lerp(FrameTime() * 25, self.ClickAnimation, 0)
		
		local colors = styleColors[self.Style] or styleColors.primary
		
		-- Enhanced background with depth
		local bgColor = ColorAlpha(colors.bg, 240 + self.HoverFraction * 15)
		local shadowOffset = 1 + self.HoverFraction * 2
		
		-- Drop shadow
		draw.RoundedBox(6, 0, shadowOffset, bw, bh, ColorAlpha(Color(0, 0, 0), 30 + self.HoverFraction * 20))
		
		-- Main button background
		draw.RoundedBox(6, 0, 0, bw, bh - shadowOffset, bgColor)
		
		-- Enhanced glow effect
		if self.HoverFraction > 0 then
			draw.Glow(0, 0, bw, bh - shadowOffset, 4, ColorAlpha(colors.bg, 60 * self.HoverFraction), self.HoverFraction)
		end
		
		-- Material design elevation effect
		local elevationAlpha = 15 + self.HoverFraction * 25
		surface.SetDrawColor(255, 255, 255, elevationAlpha)
		surface.DrawRect(1, 1, bw - 2, (bh - shadowOffset) / 3)
		
		-- Button scale for click animation
		local scale = 1 - self.ClickAnimation * 0.05
		local scaleOffset = (1 - scale) * 0.5
		
		-- Ripple effects
		for i = #self.RippleAnimations, 1, -1 do
			local ripple = self.RippleAnimations[i]
			ripple.progress = ripple.progress + FrameTime() * 3
			
			if ripple.progress >= 1 then
				table.remove(self.RippleAnimations, i)
			else
				local rippleAlpha = (1 - ripple.progress) * 100
				local rippleRadius = ripple.progress * math.max(bw, bh) * 0.8
				
				surface.SetDrawColor(255, 255, 255, rippleAlpha)
				draw.Circle(ripple.x, ripple.y, rippleRadius, 32, Color(255, 255, 255, rippleAlpha))
			end
		end
		
		-- Draw icon and text with enhanced positioning
		local textColor = ColorAlpha(colors.text, 255)
		
		if self.CustomIcon and ui and ui.DrawIcon then
			local iconSize = math.min(bh - 12, 20) * scale
			local totalWidth = iconSize + 8 + surface.GetTextSize(self.CustomText)
			local startX = (bw - totalWidth) / 2
			
			ui.DrawIcon(self.CustomIcon, startX + iconSize/2, (bh - shadowOffset) / 2, iconSize, textColor)
			draw.SimpleText(self.CustomText, 'PANTHEON.16', startX + iconSize + 8, (bh - shadowOffset) / 2, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		else
			draw.SimpleText(self.CustomText, 'PANTHEON.16', bw / 2, (bh - shadowOffset) / 2, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	
	-- Enhanced click handling with ripple effect
	btn.DoClick = function(self)
		self.ClickAnimation = 1
		
		-- Add ripple effect at mouse position
		local mx, my = self:CursorPos()
		table.insert(self.RippleAnimations, {x = mx, y = my, progress = 0})
		
		-- Play subtle click sound
		surface.PlaySound('ui/buttonclick.wav')
		
		if callback then
			callback()
		end
	end
	
	return btn
end

-- Helper function to create icon-only buttons
function ui.CreateIconButton(parent, icon, x, y, size, callback, tooltip, style)
	local btn = ui.CreateButton(parent, '', x, y, size or 32, size or 32, callback, icon, style)
	
	if tooltip then
		btn:SetTooltip(tooltip)
	end
	
	return btn
end

-- Helper function for admin action buttons
function ui.CreateAdminIconButton(parent, icon, x, y, size, callback, tooltip, style)
	return ui.CreateIconButton(parent, icon, x, y, size, callback, tooltip, style or 'primary')
end

function ui.CreatePanel(parent, x, y, w, h, title, icon)
	local panel = vgui.Create('DPanel', parent)
	panel:SetPos(x or 0, y or 0)
	panel:SetSize(w or 100, h or 100)
	panel:SetSkin('PANTHEON')
	
	panel.CustomTitle = title
	panel.CustomIcon = icon
	panel.HoverFraction = 0
	panel.AppearAnimation = 0
	
	-- Entrance animation
	ui.Animate(panel, "AppearAnimation", 1, 0.5, ui.easings.easeOutCubic)
	
	if title or icon then
		-- Enhanced card with blur
		local oldPaint = panel.Paint
		panel.Paint = function(self, pw, ph)
			-- Smooth hover animation
			self.HoverFraction = Lerp(FrameTime() * 8, self.HoverFraction, self:IsHovered() and 1 or 0)
			
			-- Material Design card elevation
			local elevation = 2 + self.HoverFraction * 6
			local shadowAlpha = 20 + self.HoverFraction * 15
			
			-- Drop shadow with multiple layers for depth
			for i = 1, elevation do
				local alpha = shadowAlpha * (1 - (i / elevation)) * 0.3
				draw.RoundedBox(8, i, i, pw, ph, ColorAlpha(Color(0, 0, 0), alpha))
			end
			
			-- Blurred dark background
			draw.BlurredPanel(self, 6, Color(24, 24, 28), 245)
			
			-- Subtle border
			surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 80)
			surface.DrawOutlinedRect(0, 0, pw, ph, 1)
			
			-- Enhanced header with gradient
			local headerHeight = 48
			local col1 = ColorAlpha(ui.col.BackgroundDark or Color(248, 249, 250), 255)
			local col2 = ColorAlpha(ui.col.BackgroundLight or Color(255, 255, 255), 255)
			draw.AnimatedGradient(1, 1, pw - 2, headerHeight - 1, col1, col2, "vertical", 0.3)
			
			-- Header border radius
			draw.RoundedBoxEx(8, 1, 1, pw - 2, headerHeight - 1, Color(0, 0, 0, 0), true, true, false, false)
			
			-- Accent line under header
			surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 100 + self.HoverFraction * 100)
			surface.DrawRect(12, headerHeight, pw - 24, 1)
			
			-- Draw icon and title with enhanced styling
			local scale = self.AppearAnimation or 1
			if self.CustomIcon and ui and ui.DrawIcon then
				local iconColor = ColorAlpha(ui.col.PANTHEON or Color(63, 81, 181), 255 * scale)
				ui.DrawIcon(self.CustomIcon, 30, headerHeight/2, 20 * scale, iconColor)
				
				local titleColor = ColorAlpha(ui.col.TextPrimary or Color(50, 50, 50), 255 * scale)
				draw.SimpleText(self.CustomTitle or '', 'PANTHEON.18', 58, headerHeight/2, titleColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			elseif self.CustomTitle then
				local titleColor = ColorAlpha(ui.col.TextPrimary or Color(50, 50, 50), 255 * scale)
				draw.SimpleText(self.CustomTitle, 'PANTHEON.18', 16, headerHeight/2, titleColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			
			-- Subtle inner border for polish
			surface.SetDrawColor(255, 255, 255, 50)
			surface.DrawOutlinedRect(0, 0, pw, ph, 1)
		end
	else
		-- Simple card without header
		panel.Paint = function(self, pw, ph)
			self.HoverFraction = Lerp(FrameTime() * 8, self.HoverFraction, self:IsHovered() and 1 or 0)
			
			-- Material Design card elevation
			local elevation = 1 + self.HoverFraction * 3
			local shadowAlpha = 15 + self.HoverFraction * 10
			
			-- Drop shadow
			for i = 1, elevation do
				local alpha = shadowAlpha * (1 - (i / elevation)) * 0.4
				draw.RoundedBox(6, i, i, pw, ph, ColorAlpha(Color(0, 0, 0), alpha))
			end
			
			-- Blurred dark background
			draw.BlurredPanel(self, 5, Color(26, 26, 30), 245)
			
			-- Subtle border
			surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
			surface.DrawOutlinedRect(0, 0, pw, ph, 1)
		end
	end
	
	return panel
end

-- Helper function for Material Design cards
function ui.CreateMaterialCard(parent, x, y, w, h, title, icon, content)
	local card = ui.CreatePanel(parent, x, y, w, h, title, icon)
	
	if content then
		local contentPanel = vgui.Create('DPanel', card)
		contentPanel:SetPos(8, title and 56 or 8)
		contentPanel:SetSize(w - 16, h - (title and 64 or 16))
		contentPanel.Paint = function() end -- Transparent
		
		content(contentPanel)
	end
	
	return card
end

-- Helper function for admin panels with enhanced styling
function ui.CreateMaterialAdminPanel(parent, title, icon, x, y, w, h)
	local panel = ui.CreateMaterialCard(parent, x, y, w, h, title, icon)
	
	-- Add subtle admin accent
	local oldPaint = panel.Paint
	panel.Paint = function(self, pw, ph)
		oldPaint(self, pw, ph)
		
		-- Admin accent stripe
		surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 150)
		surface.DrawRect(0, 0, 4, ph)
	end
	
	return panel
end

function ui.CreateScrollPanel(parent, x, y, w, h, title, icon)
	local scroll = vgui.Create('DScrollPanel', parent)
	scroll:SetPos(x or 0, y or 0)
	scroll:SetSize(w or 100, h or 100)
	scroll:SetSkin('PANTHEON')
	
	scroll.CustomTitle = title
	scroll.CustomIcon = icon
	
	return scroll
end

function ui.CreateListView(parent, x, y, w, h)
	-- Use PantheonList for custom styling
	local list = vgui.Create('PantheonList', parent)
	if not list then
		ErrorNoHalt("[PANTHEON] Failed to create PantheonList! Falling back to DListView\n")
		list = vgui.Create('DListView', parent)
	end
	list:SetPos(x or 0, y or 0)
	list:SetSize(w or 100, h or 100)
	if list.SetMultiSelect then
		list:SetMultiSelect(false)
	end
	
	return list
end

-- Enhanced function for creating dark theme log lists like in the screenshot
function ui.CreateLogListView(parent, x, y, w, h)
	-- Use new PantheonList for logs
	local list = vgui.Create('PantheonList', parent)
	list:SetPos(x or 0, y or 0)
	list:SetSize(w or 100, h or 100)
	list:SetMultiSelect(false)
	
	return list
end

function ui.CreateTextEntry(parent, x, y, w, h, placeholder)
	local entry = vgui.Create('DTextEntry', parent)
	entry:SetPos(x or 0, y or 0)
	entry:SetSize(w or 100, h or 25)
	entry:SetSkin('PANTHEON')
	
	if placeholder then
		entry:SetPlaceholderText(placeholder)
	end
	
	return entry
end

function ui.CreateCheckBox(parent, label, x, y)
	local checkbox = vgui.Create('DCheckBoxLabel', parent)
	checkbox:SetText(label or '')
	checkbox:SetPos(x or 0, y or 0)
	checkbox:SetSkin('PANTHEON')
	checkbox:SizeToContents()
	
	return checkbox
end

function ui.CreateComboBox(parent, x, y, w, h)
	local combo = vgui.Create('DComboBox', parent)
	combo:SetPos(x or 0, y or 0)
	combo:SetSize(w or 100, h or 25)
	combo:SetSkin('PANTHEON')
	
	return combo
end

-- Notification helper
function ui.Notify(text, type, duration)
	notification.AddLegacy(text, type or NOTIFY_GENERIC, duration or 5)
	surface.PlaySound('buttons/button15.wav')
end

-- Screen utilities
function ui.ScreenScale(size)
	return size * (ScrH() / 1080)
end

function ui.GetScreenCenter()
	return ScrW() / 2, ScrH() / 2
end
