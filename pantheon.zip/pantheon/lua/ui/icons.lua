-- ============================================================================
-- PANTHEON Material Design Icon System
-- ============================================================================
-- PNG-based icon library with fallback system and Material Design mappings
-- Uses PNG materials for maximum compatibility with Garry's Mod
-- ============================================================================

if SERVER then
	AddCSLuaFile()
	return
end

-- ============================================================================
-- Initialize UI namespace
-- ============================================================================
ui = ui or {}
ui.icons = ui.icons or {}
ui.icons.materials = ui.icons.materials or {}
ui.icons.list = ui.icons.list or {}

-- ============================================================================
-- Icon Aliases - Map missing icons to available ones
-- ============================================================================
local iconAliases = {
	-- User/Admin Icons
	['delete-button'] = 'delete',
	['administrator'] = 'user',
	['moderator'] = 'user',
	['admin'] = 'user',
	['root'] = 'user',
	['group'] = 'users',
	
	-- Communication
	['chat'] = 'comments',
	['inbox'] = 'mail',
	['message'] = 'mail',
	['send-message'] = 'mail',
	['send'] = 'mail',
	['broadcast'] = 'megaphone',
	
	-- Info/Status
	['information'] = 'info',
	['info-circle'] = 'info',
	['question'] = 'info',
	['question-circle'] = 'info',
	['help'] = 'info',
	['exclamation'] = 'warning',
	['error'] = 'warning',
	['exclamation-triangle'] = 'warning',
	['circle-exclamation'] = 'warning',
	['circle-check'] = 'accept',
	['success'] = 'accept',
	['check'] = 'accept',
	['thumbs-up'] = 'accept',
	['circle-xmark'] = 'delete',
	['close'] = 'delete',
	['x'] = 'delete',
	['times'] = 'delete',
	['thumbs-down'] = 'delete',
	['priority'] = 'arrow-up',
	['flag'] = 'arrow-up',
	
	-- Files/Documents  
	['file'] = 'breifcase',
	['folder'] = 'breifcase',
	['folder-open'] = 'breifcase',
	['clipboard'] = 'breifcase',
	['clipboard-list'] = 'breifcase',
	['book'] = 'breifcase',
	['briefcase'] = 'breifcase',
	['save'] = 'breifcase',
	
	-- Settings/Tools
	['settings'] = 'gear',
	['cog'] = 'gear',
	['code'] = 'gear',
	['terminal'] = 'gear',
	['tools'] = 'wrench',
	['edit'] = 'wrench',
	
	-- Actions
	['sliders'] = 'equilizer',
	['filter'] = 'equilizer',
	['adjustments'] = 'equilizer',
	['chart'] = 'equilizer',
	['chart-line'] = 'equilizer',
	['chart-bar'] = 'equilizer',
	['gauge'] = 'equilizer',
	['equalizer'] = 'equilizer',
	['refresh'] = 'arrow-right',
	['reload'] = 'arrow-right',
	['sync'] = 'arrow-right',
	['redo'] = 'arrow-right',
	['cancel'] = 'arrow-left',
	['undo'] = 'arrow-left',
	['history'] = 'arrow-left',
	
	-- Charts/Analytics
	['dashboard'] = 'home',
	['app'] = 'home',
	['stats'] = 'leaderboard',
	['scoreboard'] = 'leaderboard',
	
	-- UI Elements
	['sort'] = 'arrow-up',
	['arrow_up'] = 'arrow-up',
	['arrow_down'] = 'arrow-down',
	
	-- Media/Volume
	['speaker'] = 'volume-up',
	['volume-high'] = 'volume-up',
	['sound'] = 'volume-up',
	['volume-low'] = 'volume-down',
	['volume-mute'] = 'mute',
	
	-- Ratings
	['grade'] = 'star',
	['favorite'] = 'star',
	['rank'] = 'trophy',
	['achievement'] = 'trophy',
	['reward'] = 'trophy',
	
	-- Time/Calendar
	['timer'] = 'calendar',
	['event'] = 'calendar',
	
	-- Location/Contact
	['location'] = 'map',
	['phone'] = 'comments',
	
	-- System/Server
	['plane'] = 'fire',
	['cloud'] = 'breifcase',
	['database'] = 'breifcase',
	['server'] = 'breifcase',
	
	-- Actions (additional)
	['add'] = 'add-user',
	['remove'] = 'delete',
	['clear'] = 'delete',
	['cut'] = 'delete',
	
	-- Special/Custom (SWRP specific)
	['badge'] = 'shield',
	['inventory'] = 'backpack',
	['bag'] = 'backpack',
	['loot'] = 'backpack',
	['plan'] = 'gear',
	['blueprint'] = 'gear',
	['schematic'] = 'gear',
	['money'] = 'coins',
	['coin'] = 'coins',
	['credits'] = 'coins',
	['currency'] = 'coins',
	['wallet'] = 'coins',
	['tag'] = 'tags',
	['battle'] = 'warning',
	['combat'] = 'warning',
	['fight'] = 'warning',
	['weapon'] = 'warning',
	['access'] = 'unlock',
	['comment'] = 'comments',
	['list'] = 'breifcase',
	['logs'] = 'breifcase',
	['menu'] = 'gear',
	['menu-bar'] = 'gear',
	['play'] = 'music',
	['paste'] = 'breifcase',
	
	-- Chevrons/Angles
	['chevron-left'] = 'arrow-left',
	['chevron-right'] = 'arrow-right',
	['chevron-up'] = 'arrow-up',
	['chevron-down'] = 'arrow-down',
	['expand-down'] = 'arrow-down',
	['expand-up'] = 'arrow-up',
	
	-- Shopping
	['shop'] = 'shopping-bag',
	['store'] = 'shopping-bag',
}

-- ============================================================================
-- Icon Loading with Fallback
-- ============================================================================

-- Core icons that should exist (only the ones that actually exist as PNG files)
local coreIcons = {
	'accept', 'add-user', 'arrow-down', 'arrow-left', 'arrow-right', 'arrow-up',
	'backpack', 'bell', 'breifcase', 'calendar', 'coins', 'comments',
	'delete', 'equilizer', 'fire', 'gavel', 'gear', 'heart',
	'home', 'info', 'key', 'leaderboard', 'lock', 'mail',
	'map', 'megaphone', 'money', 'music', 'mute', 'shield',
	'shopping-bag', 'star', 'tags', 'trophy', 'unlock', 'user',
	'users', 'vignette', 'volume-down', 'volume-up', 'wallet', 'warning', 'wrench',
}

-- Try to load an icon from materials
local function loadIconMaterial(iconName)
	-- Check if we should use an alias first
	if iconAliases[iconName] then
		iconName = iconAliases[iconName]
	end
	
	-- Try primary path first (DO NOT include "materials/" prefix - GMod adds it automatically)
	local mat = Material("ui/" .. iconName .. ".png", "smooth mips")
	if mat and not mat:IsError() then
		return mat
	end
	
	-- Try without extension
	mat = Material("ui/" .. iconName, "smooth mips")
	if mat and not mat:IsError() then
		return mat
	end
	
	-- Try fallback path (SWRP pui folder)
	mat = Material("pui/ui/" .. iconName .. ".png", "smooth mips")
	if mat and not mat:IsError() then
		return mat
	end
	
	-- Log failure only once per icon
	if not ui.icons.failedIcons then
		ui.icons.failedIcons = {}
	end
	
	if not ui.icons.failedIcons[iconName] then
		print("[PANTHEON Icons] Failed to load icon: " .. iconName .. " from ui/" .. iconName .. ".png")
		ui.icons.failedIcons[iconName] = true
	end
	
	return nil
end

-- Load all core icons immediately
local loadedCount = 0
local failedCount = 0

for _, iconName in ipairs(coreIcons) do
	local mat = loadIconMaterial(iconName)
	if mat then
		ui.icons.materials[iconName] = mat
		ui.icons.list[iconName] = iconName
		loadedCount = loadedCount + 1
	else
		failedCount = failedCount + 1
	end
end

-- Also load all the aliased icons so they're available immediately
for aliasName, targetName in pairs(iconAliases) do
	if not ui.icons.materials[aliasName] then
		local mat = loadIconMaterial(targetName)
		if mat then
			ui.icons.materials[aliasName] = mat
			ui.icons.list[aliasName] = aliasName
			loadedCount = loadedCount + 1
		end
	end
end

-- Preload icon materials on first frame to avoid race conditions
hook.Add("HUDPaint", "PANTHEON_PreloadIcons", function()
	-- Force material precache by attempting to draw them off-screen
	for iconName, mat in pairs(ui.icons.materials) do
		if mat and not mat:IsError() then
			surface.SetDrawColor(255, 255, 255, 0)
			surface.SetMaterial(mat)
			surface.DrawTexturedRect(-100, -100, 1, 1)
		end
	end
	
	-- Remove this hook after first frame
	hook.Remove("HUDPaint", "PANTHEON_PreloadIcons")
	print("[PANTHEON Icons] Precached " .. table.Count(ui.icons.materials) .. " icon materials")
end)

print("[PANTHEON Icons] Loaded " .. loadedCount .. " icons, " .. failedCount .. " failed on initialization")

-- Store the load function globally for later use
ui.icons.loadIconMaterial = loadIconMaterial

-- ============================================================================
-- Material Design Mappings (for backward compatibility)
-- ============================================================================
ui.icons.materialDesign = {
	-- All icons map to themselves or their aliases
	['accept'] = 'accept',
	['add-user'] = 'add-user',
	['arrow-down'] = 'arrow-down',
	['arrow-left'] = 'arrow-left',
	['arrow-right'] = 'arrow-right',
	['arrow-up'] = 'arrow-up',
	['backpack'] = 'backpack',
	['bell'] = 'bell',
	['breifcase'] = 'breifcase',
	['briefcase'] = 'breifcase',
	['calendar'] = 'calendar',
	['coins'] = 'coins',
	['comments'] = 'comments',
	['delete'] = 'delete',
	['equilizer'] = 'equilizer',
	['equalizer'] = 'equilizer',
	['fire'] = 'fire',
	['gavel'] = 'gavel',
	['gear'] = 'gear',
	['heart'] = 'heart',
	['home'] = 'home',
	['info'] = 'info',
	['key'] = 'key',
	['leaderboard'] = 'leaderboard',
	['lock'] = 'lock',
	['mail'] = 'mail',
	['map'] = 'map',
	['megaphone'] = 'megaphone',
	['money'] = 'money',
	['music'] = 'music',
	['mute'] = 'mute',
	['shield'] = 'shield',
	['shopping-bag'] = 'shopping-bag',
	['star'] = 'star',
	['tags'] = 'tags',
	['trophy'] = 'trophy',
	['unlock'] = 'unlock',
	['user'] = 'user',
	['users'] = 'users',
	['vignette'] = 'vignette',
	['volume-down'] = 'volume-down',
	['volume-up'] = 'volume-up',
	['wallet'] = 'wallet',
	['warning'] = 'warning',
	['wrench'] = 'wrench',
}

-- Apply aliases to materialDesign mapping
for aliasName, targetName in pairs(iconAliases) do
	ui.icons.materialDesign[aliasName] = targetName
end

-- ============================================================================
-- Icon Retrieval Functions
-- ============================================================================

-- Get icon material with fallback
function ui.GetIcon(iconName)
	-- Try to get existing material
	if ui.icons.materials[iconName] then
		return ui.icons.materials[iconName]
	end
	
	-- Check if there's an alias for this icon
	local resolvedName = iconName
	if iconAliases[iconName] then
		resolvedName = iconAliases[iconName]
		-- Check if the aliased icon is already loaded
		if ui.icons.materials[resolvedName] then
			return ui.icons.materials[resolvedName]
		end
	end
	
	-- Try to load it (this handles aliases internally)
	if ui.icons.loadIconMaterial then
		local mat = ui.icons.loadIconMaterial(resolvedName)
		if mat then
			ui.icons.materials[iconName] = mat  -- Cache under original name
			ui.icons.list[iconName] = iconName
			return mat
		end
	end
	
	-- Return nil if not found
	return nil
end

-- Check if icon exists
function ui.HasIcon(iconName)
	return ui.GetIcon(iconName) ~= nil
end

-- Check if Material Design icon exists (backward compatibility)
function ui.HasMaterialDesignIcon(iconName)
	return ui.icons.materialDesign[iconName] ~= nil
end

-- ============================================================================
-- Drawing Functions
-- ============================================================================

-- Draw icon with material
function ui.DrawIcon(iconName, x, y, size, color)
	size = size or 24
	color = color or Color(255, 255, 255)
	
	-- Try to get the material directly first
	local icon = ui.icons.materials[iconName]
	
	-- If not cached, try to load it
	if not icon or icon:IsError() then
		icon = ui.GetIcon(iconName)
	end
	
	-- Still not found? Return false
	if not icon or icon:IsError() then
		return false
	end
	
	surface.SetDrawColor(color)
	surface.SetMaterial(icon)
	surface.DrawTexturedRect(x - size/2, y - size/2, size, size)
	
	return true
end

-- Draw icon with fallback (tries alias if icon not found)
function ui.DrawIconWithFallback(iconName, x, y, size, color)
	return ui.DrawIcon(iconName, x, y, size, color)
end

-- ============================================================================
-- Icon Button Helper
-- ============================================================================

function ui.CreateIconButton(parent, iconName, x, y, size, callback, tooltip)
	size = size or 32
	
	local btn = vgui.Create('DButton', parent)
	btn:SetPos(x, y)
	btn:SetSize(size, size)
	btn:SetText('')
	btn:SetTooltip(tooltip or '')
	
	btn.iconName = iconName
	btn.iconSize = math.floor(size * 0.6)
	btn.HoverFraction = 0
	btn.PressedFraction = 0
	
	btn.Paint = function(self, w, h)
		self.HoverFraction = Lerp(FrameTime() * 12, self.HoverFraction, self:IsHovered() and 1 or 0)
		self.PressedFraction = Lerp(FrameTime() * 15, self.PressedFraction, self:IsDown() and 1 or 0)
		
		-- Background
		local bgAlpha = self.HoverFraction * 0.08 + self.PressedFraction * 0.12
		if bgAlpha > 0 then
			local bgColor = ColorAlpha(ui.col and ui.col.PANTHEON or Color(100, 149, 237), bgAlpha * 255)
			draw.RoundedBox(w / 2, 0, 0, w, h, bgColor)
		end
		
		-- Icon
		local iconAlpha = 180 + self.HoverFraction * 75
		local iconColor = ColorAlpha(Color(255, 255, 255), iconAlpha)
		local scale = 1 - self.PressedFraction * 0.05
		local scaledSize = self.iconSize * scale
		
		ui.DrawIcon(self.iconName, w / 2, h / 2, scaledSize, iconColor)
	end
	
	if callback then
		btn.DoClick = callback
	end
	
	return btn
end

-- ============================================================================
-- Initialization
-- ============================================================================

local loadedCount = table.Count(ui.icons.materials)
local mappingCount = table.Count(ui.icons.materialDesign)

print('[PANTHEON] Material Design icon system initialized')
print('[PANTHEON] Using PNG materials instead of Unicode fonts for compatibility')
print('[PANTHEON] UI Icons library loaded (' .. loadedCount .. ' PNG materials, ' .. mappingCount .. ' Material Design mappings)')
