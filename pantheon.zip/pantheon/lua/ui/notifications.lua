--[[
    PANTHEON - Enhanced Notification System
    Material Design notification system with animations and queue management
    
    Adapted from Star Wars RP notification system
    Features: 
    - Modern Material Design styling
    - Smooth animations with easing
    - Queue management
    - Multiple notification types
    - Hover to pause auto-dismiss
]]--

if (SERVER) then
    AddCSLuaFile()
    return
end

ui = ui or {}
ui.notifications = ui.notifications or {}

-- Notification queue and settings
ui.notifications.queue = {}
ui.notifications.active = {}
ui.notifications.maxActive = 5
ui.notifications.spacing = 10
ui.notifications.baseY = 20
ui.notifications.defaultDuration = 6
ui.notifications.animationDuration = 0.5

-- Notification types with PANTHEON styling
ui.notifications.types = {
    success = {
        icon = 'accept',
        color = Color(34, 197, 94), -- Modern green
        bgColor = Color(34, 197, 94, 240),
        sound = 'buttons/button14.wav'
    },
    error = {
        icon = 'warning',
        color = Color(239, 68, 68), -- Modern red
        bgColor = Color(239, 68, 68, 240),
        sound = 'buttons/button10.wav'
    },
    warning = {
        icon = 'warning',
        color = Color(251, 146, 60), -- Modern orange
        bgColor = Color(251, 146, 60, 240),
        sound = 'buttons/button17.wav'
    },
    info = {
        icon = 'information',
        color = Color(59, 130, 246), -- Modern blue
        bgColor = Color(59, 130, 246, 240),
        sound = 'buttons/button15.wav'
    },
    default = {
        icon = 'letter-p',
        color = ui.col.PANTHEON or Color(138, 43, 226),
        bgColor = Color(138, 43, 226, 240),
        sound = 'buttons/button15.wav'
    }
}

--[[
    Notification Class
]]--
local NOTIFICATION = {}
NOTIFICATION.__index = NOTIFICATION

function NOTIFICATION:New(message, type, duration, options)
    local notif = setmetatable({}, self)
    
    -- Default options
    options = options or {}
    
    -- Properties
    notif.id = "notif_" .. tostring(notif):sub(8) .. "_" .. CurTime()
    notif.message = message or "Notification"
    notif.type = type or 'default'
    notif.duration = duration or ui.notifications.defaultDuration
    notif.options = options
    
    -- Get type config
    notif.config = ui.notifications.types[notif.type] or ui.notifications.types.default
    
    -- State
    notif.createdTime = CurTime()
    notif.dismissTime = notif.createdTime + notif.duration
    notif.x = ScrW() + 400 -- Start offscreen
    notif.targetX = ScrW() - 420 -- Target position
    notif.y = 0
    notif.width = 390
    notif.height = 0 -- Will be calculated based on text
    notif.alpha = 0
    notif.slideProgress = 0
    notif.fadeProgress = 0
    notif.dismissed = false
    notif.hovered = false
    notif.hoverFraction = 0
    notif.bounceOffset = 0
    notif.pulseAnimation = 0
    
    -- Animation states
    notif.animationState = 'entering' -- entering, visible, exiting
    
    -- Calculate height based on text
    notif:CalculateHeight()
    
    return notif
end

function NOTIFICATION:CalculateHeight()
    surface.SetFont('PANTHEON.16')
    local textW, textH = surface.GetTextSize(self.message)
    
    -- Calculate wrapped text height
    local maxWidth = self.width - 100 -- Account for icon and padding
    local lines = math.ceil(textW / maxWidth)
    
    -- Base height + text height + padding (slightly taller for better spacing)
    self.height = math.max(68, 24 + (lines * 20) + 24)
end

function NOTIFICATION:Update()
    if self.dismissed then return end
    
    local currentTime = CurTime()
    local dt = FrameTime()
    
    -- Pulse animation for visual interest
    self.pulseAnimation = (self.pulseAnimation or 0) + dt * 2
    
    -- Check if should auto-dismiss
    if not self.hovered and currentTime >= self.dismissTime and self.animationState == 'visible' then
        self:Dismiss()
    end
    
    -- Update hover state
    local mx, my = gui.MousePos()
    local isHovered = mx >= self.x and mx <= self.x + self.width and 
                     my >= self.y and my <= self.y + self.height
    
    if isHovered ~= self.hovered then
        self.hovered = isHovered
        if isHovered then
            -- Pause auto-dismiss on hover
            local timeLeft = self.dismissTime - currentTime
            self.pausedTimeLeft = timeLeft
        else
            -- Resume auto-dismiss
            if self.pausedTimeLeft then
                self.dismissTime = currentTime + self.pausedTimeLeft
                self.pausedTimeLeft = nil
            end
        end
    end
    
    -- Smooth hover animation with slight scale effect
    self.hoverFraction = Lerp(dt * 12, self.hoverFraction, self.hovered and 1 or 0)
    
    -- Subtle bounce on entrance
    if self.animationState == 'entering' and self.slideProgress > 0.7 then
        local bounceProgress = (self.slideProgress - 0.7) / 0.3
        self.bounceOffset = math.sin(bounceProgress * math.pi) * 8 * (1 - bounceProgress)
    else
        self.bounceOffset = Lerp(dt * 10, self.bounceOffset, 0)
    end
    
    -- Animation state machine
    if self.animationState == 'entering' then
        self.slideProgress = Lerp(dt * 10, self.slideProgress, 1)
        self.fadeProgress = Lerp(dt * 12, self.fadeProgress, 1)
        
        -- Apply smooth easing
        local easedProgress = ui.easings.easeOutCubic(self.slideProgress)
        self.x = ScrW() + 400 + (self.targetX - (ScrW() + 400)) * easedProgress
        self.alpha = 255 * self.fadeProgress
        
        -- Transition to visible state
        if self.slideProgress >= 0.99 and self.fadeProgress >= 0.99 then
            self.animationState = 'visible'
            self.slideProgress = 1
            self.fadeProgress = 1
            self.x = self.targetX
            self.alpha = 255
        end
        
    elseif self.animationState == 'visible' then
        -- Smooth position adjustment with spring-like motion
        self.x = Lerp(dt * 10, self.x, self.targetX)
        self.alpha = 255
        
    elseif self.animationState == 'exiting' then
        self.slideProgress = Lerp(dt * 12, self.slideProgress, 0)
        self.fadeProgress = Lerp(dt * 14, self.fadeProgress, 0)
        
        -- Apply smooth easing
        local easedProgress = ui.easings.easeInCubic(self.slideProgress)
        self.x = ScrW() + 400 + (self.targetX - (ScrW() + 400)) * easedProgress
        self.alpha = 255 * self.fadeProgress
        
        -- Mark as dismissed when animation complete
        if self.slideProgress <= 0.01 and self.fadeProgress <= 0.01 then
            self.dismissed = true
            self.alpha = 0
        end
    end
end

function NOTIFICATION:Draw()
    if self.alpha <= 0 then return end
    
    local x, y = self.x + self.bounceOffset, self.y
    local w, h = self.width, self.height
    local alpha = self.alpha
    
    -- Scale effect on hover
    local scale = 1 + (self.hoverFraction * 0.02)
    local scaleOffsetX = (w * (1 - scale)) / 2
    local scaleOffsetY = (h * (1 - scale)) / 2
    
    x = x - scaleOffsetX
    y = y - scaleOffsetY
    w = w * scale
    h = h * scale
    
    -- Modern layered shadow with blur effect
    local shadowSize = 12 + self.hoverFraction * 8
    local shadowAlpha = (40 + self.hoverFraction * 30) * (alpha / 255)
    
    -- Outer soft shadow (multiple layers for depth)
    for i = shadowSize, 1, -1 do
        local shadowA = shadowAlpha * (1 - (i / shadowSize)) * 0.35
        surface.SetDrawColor(0, 0, 0, shadowA)
        draw.RoundedBox(10, x - i, y - i, w + i * 2, h + i * 2, Color(0, 0, 0, shadowA))
    end
    
    -- Glass morphism background effect
    local bgColor = ColorAlpha(Color(28, 28, 32), alpha * 0.96)
    draw.RoundedBox(12, x, y, w, h, bgColor)
    
    -- Subtle gradient overlay for depth
    local gradientTop = ColorAlpha(Color(48, 48, 52), alpha * 0.6)
    draw.RoundedBoxEx(12, x, y, w, h/2, gradientTop, true, true, false, false)
    
    -- Frosted glass effect border
    surface.SetDrawColor(255, 255, 255, 12 * (alpha / 255))
    surface.DrawOutlinedRect(x, y, w, h, 1)
    
    -- Inner glow for glass effect
    surface.SetDrawColor(255, 255, 255, 5 * (alpha / 255))
    draw.RoundedBox(11, x + 1, y + 1, w - 2, h - 2, Color(255, 255, 255, 5 * (alpha / 255)))
    
    -- Modern left accent bar (ultra-thin, elegant)
    local accentColor = ColorAlpha(self.config.color, alpha)
    draw.RoundedBoxEx(12, x, y, 3, h, accentColor, true, false, true, false)
    
    -- Subtle animated top glow line
    local pulseGlow = math.abs(math.sin(self.pulseAnimation)) * 0.3 + 0.7
    local topGlowColor = ColorAlpha(self.config.color, alpha * 0.5 * pulseGlow)
    draw.RoundedBoxEx(12, x, y, w, 2, topGlowColor, true, true, false, false)
    
    -- Animated shimmer effect on hover
    if self.hoverFraction > 0 then
        -- Soft glow overlay
        local glowAlpha = 20 * self.hoverFraction * (alpha / 255)
        surface.SetDrawColor(self.config.color.r, self.config.color.g, self.config.color.b, glowAlpha)
        draw.RoundedBox(12, x, y, w, h, Color(self.config.color.r, self.config.color.g, self.config.color.b, glowAlpha))
        
        -- Animated shimmer sweep
        local shimmerPos = (CurTime() * 180) % (w + 120) - 60
        local shimmerWidth = 40
        for i = 0, shimmerWidth do
            local shimmerAlpha = (35 * self.hoverFraction * (alpha / 255)) * (1 - (i / shimmerWidth))
            surface.SetDrawColor(255, 255, 255, shimmerAlpha)
            surface.DrawRect(x + shimmerPos + i, y, 1, h)
        end
    end
    
    -- Modern icon with layered background circles
    local iconX = x + 32
    local iconY = y + h / 2
    local iconSize = 18 + self.hoverFraction * 3
    
    -- Outer icon background (subtle)
    local iconOuterBg = ColorAlpha(self.config.color, (35 + self.hoverFraction * 20) * (alpha / 255))
    draw.Circle(iconX, iconY, (iconSize + 14) / 2, 32, iconOuterBg)
    
    -- Middle icon background with glow
    local iconMidBg = ColorAlpha(self.config.color, (70 + self.hoverFraction * 50) * (alpha / 255))
    draw.Circle(iconX, iconY, (iconSize + 8) / 2, 32, iconMidBg)
    
    -- Icon inner circle (bright white)
    local iconColor = ColorAlpha(Color(255, 255, 255), (235 + self.hoverFraction * 20) * (alpha / 255))
    draw.Circle(iconX, iconY, iconSize / 2, 28, iconColor)
    
    -- Icon pulse effect
    if self.animationState == 'entering' and self.fadeProgress < 1 then
        local pulseFade = 1 - self.fadeProgress
        local pulseSize = iconSize + (pulseFade * 15)
        draw.Circle(iconX, iconY, pulseSize / 2, 32, ColorAlpha(self.config.color, (100 * pulseFade) * (alpha / 255)))
    end
    
    -- Message text with premium typography
    local textX = x + 68
    local textY = y + h / 2
    local textColor = ColorAlpha(Color(248, 248, 252), alpha)
    local textShadowColor = ColorAlpha(Color(0, 0, 0), alpha * 0.6)
    
    surface.SetFont('PANTHEON.16')
    
    -- Word wrap the text (vertically centered)
    local maxWidth = w - 110
    local words = string.Explode(" ", self.message)
    local line = ""
    local lines = {}
    
    for i, word in ipairs(words) do
        local testLine = line .. (line == "" and "" or " ") .. word
        local testWidth = surface.GetTextSize(testLine)
        
        if testWidth > maxWidth and line ~= "" then
            table.insert(lines, line)
            line = word
        else
            line = testLine
        end
    end
    
    if line ~= "" then
        table.insert(lines, line)
    end
    
    -- Calculate vertical centering
    local totalTextHeight = #lines * 20
    local startY = textY - (totalTextHeight / 2)
    
    -- Draw all lines with enhanced shadow
    for i, lineText in ipairs(lines) do
        local lineY = startY + (i - 1) * 20
        
        -- Text shadow for depth (double shadow)
        draw.SimpleText(lineText, 'PANTHEON.16', textX + 1, lineY + 1, textShadowColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        
        -- Main text with slight anti-aliasing effect
        draw.SimpleText(lineText, 'PANTHEON.16', textX, lineY, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end
    
    -- Ultra-sleek progress bar with gradient and glow
    if self.animationState == 'visible' and not self.hovered then
        local currentTime = CurTime()
        local totalDuration = self.duration
        local elapsed = currentTime - self.createdTime
        local progress = math.Clamp(elapsed / totalDuration, 0, 1)
        
        local progressY = y + h - 4
        local progressWidth = (w - 12) * (1 - progress)
        
        if progressWidth > 0 then
            -- Progress background track (subtle)
            draw.RoundedBoxEx(6, x + 6, progressY, w - 12, 4, ColorAlpha(Color(35, 35, 40), alpha * 0.4), false, false, true, true)
            
            -- Animated gradient progress bar
            local progressColor = ColorAlpha(self.config.color, alpha * 0.95)
            draw.RoundedBoxEx(6, x + 6, progressY, progressWidth, 4, progressColor, false, false, true, true)
            
            -- Progress bar glow (pulsing)
            local glowPulse = math.abs(math.sin(self.pulseAnimation * 1.5)) * 0.4 + 0.6
            surface.SetDrawColor(self.config.color.r, self.config.color.g, self.config.color.b, (70 * glowPulse) * (alpha / 255))
            draw.RoundedBoxEx(6, x + 6, progressY - 2, progressWidth, 8, Color(self.config.color.r, self.config.color.g, self.config.color.b, (40 * glowPulse) * (alpha / 255)), false, false, true, true)
            
            -- Leading edge highlight
            if progressWidth > 10 then
                surface.SetDrawColor(255, 255, 255, 60 * (alpha / 255))
                surface.DrawRect(x + 6 + progressWidth - 3, progressY, 3, 4)
            end
        end
    end
    
    -- Elegant close button on hover (fades in smoothly)
    if self.hoverFraction > 0.2 then
        local closeX = x + w - 30
        local closeY = y + 14
        local closeSize = 18
        local closeAlpha = math.min((self.hoverFraction - 0.2) / 0.8, 1) -- Smooth fade from 20% to 100%
        
        -- Close button background with hover detection
        local mx, my = gui.MousePos()
        local closeHovered = mx >= closeX and mx <= closeX + closeSize and my >= closeY and my <= closeY + closeSize
        local closeBgAlpha = closeHovered and 30 or 15
        
        surface.SetDrawColor(255, 255, 255, closeBgAlpha * closeAlpha * (alpha / 255))
        draw.RoundedBox(5, closeX, closeY, closeSize, closeSize, Color(255, 255, 255, closeBgAlpha * closeAlpha * (alpha / 255)))
        
        -- Close button border
        surface.SetDrawColor(255, 255, 255, 8 * closeAlpha * (alpha / 255))
        surface.DrawOutlinedRect(closeX, closeY, closeSize, closeSize, 1)
        
        -- X icon with anti-aliased appearance
        local iconAlpha = (closeHovered and 220 or 160) * closeAlpha * (alpha / 255)
        surface.SetDrawColor(255, 255, 255, iconAlpha)
        -- Draw thicker X
        for i = 0, 1 do
            surface.DrawLine(closeX + 5 + i, closeY + 5, closeX + closeSize - 5 + i, closeY + closeSize - 5)
            surface.DrawLine(closeX + 5 + i, closeY + closeSize - 5, closeX + closeSize - 5 + i, closeY + 5)
        end
        
        -- Handle click
        if closeHovered then
            if input.IsMouseDown(MOUSE_LEFT) and not self.closeClicked then
                self.closeClicked = true
                self:Dismiss()
            elseif not input.IsMouseDown(MOUSE_LEFT) then
                self.closeClicked = false
            end
        end
    end
end

function NOTIFICATION:Dismiss()
    if self.animationState ~= 'exiting' then
        self.animationState = 'exiting'
        self.slideProgress = 1
        self.fadeProgress = 1
    end
end

function NOTIFICATION:SetTargetY(y)
    self.targetY = y
end

--[[
    Notification Manager
]]--

-- Add a notification to the queue
function ui.notifications.Add(message, type, duration, options)
    local notif = NOTIFICATION:New(message, type, duration, options)
    
    -- Add to queue
    table.insert(ui.notifications.queue, notif)
    
    -- Play sound
    if notif.config.sound then
        surface.PlaySound(notif.config.sound)
    end
    
    -- Process queue
    ui.notifications.ProcessQueue()
    
    return notif
end

-- Process notification queue
function ui.notifications.ProcessQueue()
    -- Remove dismissed notifications from active
    for i = #ui.notifications.active, 1, -1 do
        if ui.notifications.active[i].dismissed then
            table.remove(ui.notifications.active, i)
        end
    end
    
    -- Move notifications from queue to active
    while #ui.notifications.active < ui.notifications.maxActive and #ui.notifications.queue > 0 do
        local notif = table.remove(ui.notifications.queue, 1)
        table.insert(ui.notifications.active, notif)
    end
    
    -- Update Y positions
    local currentY = ui.notifications.baseY
    for i, notif in ipairs(ui.notifications.active) do
        notif.targetY = currentY
        notif.y = Lerp(FrameTime() * 8, notif.y or currentY, currentY)
        currentY = currentY + notif.height + ui.notifications.spacing
    end
end

-- Update all active notifications
hook.Add("HUDPaint", "PANTHEON_UI_Notifications", function()
    for i, notif in ipairs(ui.notifications.active) do
        notif:Update()
        notif:Draw()
    end
    
    ui.notifications.ProcessQueue()
end)

--[[
    Convenience Functions
]]--

-- Show success notification
function ui.notifications.Success(message, duration)
    return ui.notifications.Add(message, 'success', duration)
end

-- Show error notification
function ui.notifications.Error(message, duration)
    return ui.notifications.Add(message, 'error', duration)
end

-- Show warning notification
function ui.notifications.Warning(message, duration)
    return ui.notifications.Add(message, 'warning', duration)
end

-- Show info notification
function ui.notifications.Info(message, duration)
    return ui.notifications.Add(message, 'info', duration)
end

-- Clear all notifications
function ui.notifications.Clear()
    for i, notif in ipairs(ui.notifications.active) do
        notif:Dismiss()
    end
    ui.notifications.queue = {}
end

--[[
    Network Integration
    Receive notifications from server
]]--
net.Receive("pas.NotifyEnhanced", function()
    local message = net.ReadString()
    local notifType = net.ReadString()
    local duration = net.ReadUInt(8)
    
    -- Show the notification using the new system
    ui.notifications.Add(message, notifType, duration)
end)

MsgC(ui.col.PANTHEON, '[PANTHEON] ', ui.col.White, 'Enhanced notification system loaded\n')
