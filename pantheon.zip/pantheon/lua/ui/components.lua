--[[
    PANTHEON - Modern UI Component Library
    Centralized UI component creation with glassmorphism and dark theme
    All Pantheon UI should use these components for consistency
]]--

if SERVER then
    AddCSLuaFile()
    return
end

ui = ui or {}
ui.components = ui.components or {}

--[[
    ============================================================================
    GLASSMORPHISM FRAME
    Modern blurred frame with dark theme
    ============================================================================
]]--
function ui.components.CreateFrame(title, width, height, icon)
    local frame = vgui.Create('DFrame')
    frame:SetTitle('')
    frame:SetSize(width or 800, height or 600)
    frame:Center()
    frame:MakePopup()
    frame:SetSkin('PANTHEON')
    frame:ShowCloseButton(false)
    
    -- Store custom properties
    frame.PantheonTitle = title or 'PANTHEON'
    frame.PantheonIcon = icon
    frame.OpenAnimation = 0
    frame.PulseAnimation = 0
    
    -- Entrance animation
    frame:SetAlpha(0)
    frame:MoveTo(frame.x, frame.y - 30, 0.3, 0, 0.5, function()
        frame:SetAlpha(255)
    end)
    ui.Animate(frame, "OpenAnimation", 1, 0.3, ui.easings.easeOutCubic)
    
    -- Override paint for blur effect
    frame.Paint = function(self, fw, fh)
        -- Blurred dark background
        draw.BlurredPanel(self, ui.col.BlurStrength or 8, Color(18, 18, 22), 245)
        
        -- Enhanced shadow for depth
        draw.Shadow(0, 0, fw, fh, 16, 140)
        
        -- Subtle border
        surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 120)
        surface.DrawOutlinedRect(0, 0, fw, fh, 1)
        
        -- Pulse animation for header
        self.PulseAnimation = (self.PulseAnimation or 0) + FrameTime() * 1.5
        local pulse = math.sin(self.PulseAnimation) * 0.1 + 0.9
        
        -- Dark theme title bar with purple gradient
        local titleHeight = 34
        local col1 = ColorAlpha(ui.col.PANTHEON, 255)
        local col2 = ColorAlpha(ui.col.PANTHEON_DARK, 255)
        draw.AnimatedGradient(0, 0, fw, titleHeight, col1, col2, "horizontal", 0.3)
        
        -- Enhanced purple glow effect
        draw.Glow(0, 0, fw, titleHeight, 4, ColorAlpha(ui.col.PANTHEON, 40 * pulse), pulse)
        
        -- Draw icon and title with entrance animation
        local scale = self.OpenAnimation or 1
        if self.PantheonIcon and ui.DrawIcon then
            ui.DrawIcon(self.PantheonIcon, 35, 17, 22 * scale, ColorAlpha(ui.col.White, 255 * scale))
            draw.SimpleText(self.PantheonTitle, 'PANTHEON.18', 62, 17, ColorAlpha(ui.col.White, 255 * scale), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        else
            draw.SimpleText(self.PantheonTitle, 'PANTHEON.18', 12, 17, ColorAlpha(ui.col.White, 255 * scale), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        
        -- Bright accent line with animation
        surface.SetDrawColor(ui.col.PANTHEON_LIGHT.r, ui.col.PANTHEON_LIGHT.g, ui.col.PANTHEON_LIGHT.b, 200 * pulse)
        surface.DrawRect(0, titleHeight - 2, fw, 2)
    end
    
    -- Enhanced close button
    local closeBtn = vgui.Create('DButton', frame)
    closeBtn:SetText('')
    closeBtn:SetSize(28, 28)
    closeBtn:SetPos(frame:GetWide() - 33, 3)
    closeBtn.HoverFraction = 0
    closeBtn.ClickAnimation = 0
    
    closeBtn.Paint = function(self, bw, bh)
        self.HoverFraction = Lerp(FrameTime() * 15, self.HoverFraction, self:IsHovered() and 1 or 0)
        self.ClickAnimation = Lerp(FrameTime() * 20, self.ClickAnimation, 0)
        
        local alpha = 30 + self.HoverFraction * 120
        local bgColor = ColorAlpha(Color(244, 67, 54), alpha)
        local scale = 1 - self.ClickAnimation * 0.1
        local offset = (1 - scale) * bw * 0.5
        
        draw.RoundedBox(6, offset, offset, bw * scale, bh * scale, bgColor)
        
        if self.HoverFraction > 0 then
            draw.Glow(0, 0, bw, bh, 2, ColorAlpha(Color(244, 67, 54), 50 * self.HoverFraction))
        end
        
        -- X icon
        surface.SetFont('PANTHEON.16')
        draw.SimpleText('×', 'PANTHEON.16', bw/2, bh/2, ColorAlpha(Color(255, 255, 255), 200 + self.HoverFraction * 55), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    
    closeBtn.DoClick = function(self)
        self.ClickAnimation = 1
        ui.Animate(frame, "OpenAnimation", 0, 0.2, ui.easings.easeInCubic, function()
            frame:MoveTo(frame.x, frame.y - 30, 0.2, 0, 0, function()
                frame:Close()
            end)
        end)
    end
    
    frame.CloseButton = closeBtn
    return frame
end

--[[
    ============================================================================
    GLASSMORPHISM PANEL
    Modern blurred panel with optional header
    ============================================================================
]]--
function ui.components.CreatePanel(parent, x, y, width, height, title, icon)
    local panel = vgui.Create('DPanel', parent)
    panel:SetPos(x or 0, y or 0)
    panel:SetSize(width or 200, height or 200)
    
    panel.PantheonTitle = title
    panel.PantheonIcon = icon
    panel.HoverFraction = 0
    panel.AppearAnimation = 0
    
    -- Entrance animation
    ui.Animate(panel, "AppearAnimation", 1, 0.5, ui.easings.easeOutCubic)
    
    -- Blurred dark paint
    panel.Paint = function(self, pw, ph)
        self.HoverFraction = Lerp(FrameTime() * 8, self.HoverFraction, self:IsHovered() and 1 or 0)
        
        -- Shadow for depth
        local elevation = 2 + self.HoverFraction * 4
        local shadowAlpha = 20 + self.HoverFraction * 15
        
        for i = 1, elevation do
            local alpha = shadowAlpha * (1 - (i / elevation)) * 0.3
            draw.RoundedBox(8, i, i, pw, ph, ColorAlpha(Color(0, 0, 0), alpha))
        end
        
        -- Blurred dark background
        draw.BlurredPanel(self, 6, ui.col.BackgroundCard or Color(24, 24, 28), 245)
        
        -- Subtle border
        surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 70)
        surface.DrawOutlinedRect(0, 0, pw, ph, 1)
        
        -- If has title, draw header
        if self.PantheonTitle then
            local headerHeight = 48
            
            -- Header background
            surface.SetDrawColor(ui.col.BackgroundDark.r, ui.col.BackgroundDark.g, ui.col.BackgroundDark.b, 180)
            draw.RoundedBoxEx(8, 1, 1, pw - 2, headerHeight - 1, Color(ui.col.BackgroundDark.r, ui.col.BackgroundDark.g, ui.col.BackgroundDark.b, 180), true, true, false, false)
            
            -- Accent line
            surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 120 + self.HoverFraction * 80)
            surface.DrawRect(12, headerHeight, pw - 24, 1)
            
            -- Icon and title
            local scale = self.AppearAnimation or 1
            if self.PantheonIcon and ui.DrawIcon then
                ui.DrawIcon(self.PantheonIcon, 30, headerHeight/2, 20 * scale, ColorAlpha(ui.col.PANTHEON, 255 * scale))
                draw.SimpleText(self.PantheonTitle, 'PANTHEON.18', 58, headerHeight/2, ColorAlpha(ui.col.White, 255 * scale), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            else
                draw.SimpleText(self.PantheonTitle, 'PANTHEON.18', 16, headerHeight/2, ColorAlpha(ui.col.White, 255 * scale), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
        end
    end
    
    return panel
end

--[[
    ============================================================================
    GLASSMORPHISM BUTTON
    Modern button with enhanced effects
    ============================================================================
]]--
function ui.components.CreateButton(parent, text, x, y, width, height, callback, icon, style)
    local btn = vgui.Create('DButton', parent)
    btn:SetText('')
    btn:SetPos(x or 0, y or 0)
    btn:SetSize(width or 100, height or 30)
    
    btn.PantheonText = text or ''
    btn.PantheonIcon = icon
    btn.Style = style or 'primary'
    btn.HoverFraction = 0
    btn.ClickAnimation = 0
    btn.RippleAnimations = {}
    
    -- Style colors
    local styleColors = {
        primary = {bg = ui.col.PANTHEON, text = Color(255, 255, 255)},
        secondary = {bg = Color(108, 117, 125), text = Color(255, 255, 255)},
        success = {bg = Color(40, 167, 69), text = Color(255, 255, 255)},
        warning = {bg = Color(255, 193, 7), text = Color(0, 0, 0)},
        danger = {bg = Color(220, 53, 69), text = Color(255, 255, 255)},
        glass = {bg = Color(255, 255, 255, 30), text = Color(255, 255, 255)}
    }
    
    btn.Paint = function(self, bw, bh)
        self.HoverFraction = Lerp(FrameTime() * 12, self.HoverFraction, self:IsHovered() and 1 or 0)
        self.ClickAnimation = Lerp(FrameTime() * 25, self.ClickAnimation, 0)
        
        local colors = styleColors[self.Style] or styleColors.primary
        
        -- Background
        local bgColor = ColorAlpha(colors.bg, 240 + self.HoverFraction * 15)
        local shadowOffset = 1 + self.HoverFraction * 2
        
        -- Shadow
        draw.RoundedBox(6, 0, shadowOffset, bw, bh, ColorAlpha(Color(0, 0, 0), 30 + self.HoverFraction * 20))
        
        -- Main button
        draw.RoundedBox(6, 0, 0, bw, bh - shadowOffset, bgColor)
        
        -- Glow on hover
        if self.HoverFraction > 0 then
            draw.Glow(0, 0, bw, bh - shadowOffset, 4, ColorAlpha(colors.bg, 60 * self.HoverFraction), self.HoverFraction)
        end
        
        -- Ripple effects
        for i = #self.RippleAnimations, 1, -1 do
            local ripple = self.RippleAnimations[i]
            ripple.progress = ripple.progress + FrameTime() * 3
            
            if ripple.progress >= 1 then
                table.remove(self.RippleAnimations, i)
            else
                local rippleAlpha = (1 - ripple.progress) * 100
                local rippleRadius = ripple.progress * math.max(bw, bh) * 0.8
                draw.Circle(ripple.x, ripple.y, rippleRadius, 32, ColorAlpha(Color(255, 255, 255), rippleAlpha))
            end
        end
        
        -- Text and icon
        local textColor = ColorAlpha(colors.text, 255)
        
        if self.PantheonIcon and ui.DrawIcon then
            local iconSize = math.min(bh - 12, 20)
            local totalWidth = iconSize + 8 + surface.GetTextSize(self.PantheonText)
            local startX = (bw - totalWidth) / 2
            
            ui.DrawIcon(self.PantheonIcon, startX + iconSize/2, (bh - shadowOffset) / 2, iconSize, textColor)
            draw.SimpleText(self.PantheonText, 'PANTHEON.16', startX + iconSize + 8, (bh - shadowOffset) / 2, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        else
            draw.SimpleText(self.PantheonText, 'PANTHEON.16', bw / 2, (bh - shadowOffset) / 2, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
    
    btn.DoClick = function(self)
        self.ClickAnimation = 1
        local mx, my = self:CursorPos()
        table.insert(self.RippleAnimations, {x = mx, y = my, progress = 0})
        surface.PlaySound('ui/buttonclick.wav')
        
        if callback then callback() end
    end
    
    return btn
end

--[[
    ============================================================================
    GLASSMORPHISM SCROLL PANEL
    Modern scrollable panel with blur
    ============================================================================
]]--
function ui.components.CreateScrollPanel(parent, x, y, width, height)
    local scroll = vgui.Create('DScrollPanel', parent)
    scroll:SetPos(x or 0, y or 0)
    scroll:SetSize(width or 200, height or 200)
    scroll:SetSkin('PANTHEON')
    
    scroll.Paint = function(self, sw, sh)
        -- Blurred dark background
        draw.BlurredPanel(self, 4, ui.col.BackgroundDark or Color(28, 28, 32), 240)
        
        -- Subtle border
        surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
        surface.DrawOutlinedRect(0, 0, sw, sh, 1)
    end
    
    return scroll
end

--[[
    ============================================================================
    MODERN TEXT ENTRY
    Enhanced text input with glassmorphism
    ============================================================================
]]--
function ui.components.CreateTextEntry(parent, x, y, width, height, placeholder)
    local entry = vgui.Create('DTextEntry', parent)
    entry:SetPos(x or 0, y or 0)
    entry:SetSize(width or 200, height or 30)
    entry:SetFont('PANTHEON.16')
    entry:SetTextColor(ui.col.White)
    entry:SetCursorColor(ui.col.PANTHEON)
    
    if placeholder then
        entry:SetPlaceholderText(placeholder)
        entry:SetPlaceholderColor(ui.col.TextDisabled or Color(100, 100, 100))
    end
    
    entry.FocusFraction = 0
    
    entry.Paint = function(self, ew, eh)
        self.FocusFraction = Lerp(FrameTime() * 10, self.FocusFraction, self:HasFocus() and 1 or 0)
        
        -- Blurred dark background
        draw.BlurredPanel(self, 3, ui.col.BackgroundLight or Color(26, 26, 30), 240)
        
        -- Border with focus effect
        local borderColor = ui.col.Outline
        if self.FocusFraction > 0 then
            borderColor = Color(
                ui.col.Outline.r + (ui.col.PANTHEON.r - ui.col.Outline.r) * self.FocusFraction,
                ui.col.Outline.g + (ui.col.PANTHEON.g - ui.col.Outline.g) * self.FocusFraction,
                ui.col.Outline.b + (ui.col.PANTHEON.b - ui.col.Outline.b) * self.FocusFraction,
                200 + 55 * self.FocusFraction
            )
        end
        
        surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, borderColor.a)
        surface.DrawOutlinedRect(0, 0, ew, eh, 1)
        
        -- Glow when focused
        if self.FocusFraction > 0 then
            for i = 1, 2 do
                local glowAlpha = (20 * self.FocusFraction) * (1 - (i / 2))
                surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, glowAlpha)
                surface.DrawOutlinedRect(-i, -i, ew + i*2, eh + i*2, 1)
            end
        end
        
        self:DrawTextEntryText(ui.col.White, ui.col.PANTHEON, ui.col.White)
    end
    
    return entry
end

--[[
    ============================================================================
    CUSTOM LIST VIEW
    Modern list with blur effects and enhanced styling
    ============================================================================
]]--

local PANTHEON_LIST = {}

function PANTHEON_LIST:Init()
    self.Columns = {}
    self.Lines = {}
    self.ColumnWidths = {}
    self.Sorted = {}
    self.HeaderHeight = 28
    self.LineHeight = 32
    self.Padding = 8
    self.HoveredLine = nil
    self.SelectedLine = nil
    self.MultiSelect = false
    self.AlternateColors = true
    
    -- Create header panel
    self.Header = vgui.Create('DPanel', self)
    self.Header:Dock(TOP)
    self.Header:SetTall(self.HeaderHeight)
    self.Header.Paint = function(pnl, w, h)
        -- Dark header with gradient
        surface.SetDrawColor(ui.col.TableHeader.r, ui.col.TableHeader.g, ui.col.TableHeader.b, 220)
        surface.DrawRect(0, 0, w, h)
        
        -- Purple accent bottom line
        surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 180)
        surface.DrawRect(0, h - 2, w, 2)
        
        -- Subtle gradient overlay
        surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 20)
        surface.DrawRect(0, 0, w, h)
    end
    
    -- Create scroll panel for lines
    self.Scroll = vgui.Create('DScrollPanel', self)
    self.Scroll:Dock(FILL)
    self.Scroll.Paint = function(pnl, w, h)
        -- Blurred dark background
        draw.BlurredPanel(pnl, 4, Color(22, 22, 26), 245)
    end
    
    -- Custom scrollbar
    local sbar = self.Scroll:GetVBar()
    sbar:SetWide(8)
    sbar.Paint = function(pnl, w, h)
        draw.RoundedBox(4, 0, 0, w, h, ColorAlpha(ui.col.BackgroundDark, 100))
    end
    sbar.btnGrip.Paint = function(pnl, w, h)
        pnl.HoverFraction = Lerp(FrameTime() * 8, pnl.HoverFraction or 0, pnl:IsHovered() and 1 or 0)
        local gripColor = ColorAlpha(ui.col.PANTHEON, 180 + 75 * pnl.HoverFraction)
        draw.RoundedBox(4, 2, 0, w - 4, h, gripColor)
    end
    sbar.btnUp.Paint = function() end
    sbar.btnDown.Paint = function() end
end

function PANTHEON_LIST:AddColumn(name, width)
    width = width or 100
    
    local col = vgui.Create('DButton', self.Header)
    col:SetText('')
    col.ColumnName = name
    col.ColumnID = #self.Columns + 1
    col.Width = width
    col.HoverFraction = 0
    col.SortAsc = true
    
    col.Paint = function(pnl, w, h)
        pnl.HoverFraction = Lerp(FrameTime() * 10, pnl.HoverFraction, pnl:IsHovered() and 1 or 0)
        
        -- Hover effect
        if pnl.HoverFraction > 0 then
            surface.SetDrawColor(ui.col.PANTHEON.r, ui.col.PANTHEON.g, ui.col.PANTHEON.b, 40 * pnl.HoverFraction)
            surface.DrawRect(0, 0, w, h)
        end
        
        -- Column divider
        surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 60)
        surface.DrawRect(w - 1, 4, 1, h - 8)
        
        -- Text
        draw.SimpleText(pnl.ColumnName, 'PANTHEON.16', 12, h/2, ui.col.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        
        -- Sort indicator
        if self.SortColumn == pnl.ColumnID then
            local arrow = pnl.SortAsc and '▲' or '▼'
            draw.SimpleText(arrow, 'PANTHEON.14', w - 12, h/2, ui.col.PANTHEON, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        end
    end
    
    col.DoClick = function(pnl)
        if self.SortColumn == pnl.ColumnID then
            pnl.SortAsc = not pnl.SortAsc
        else
            self.SortColumn = pnl.ColumnID
            pnl.SortAsc = true
        end
        self:SortByColumn(pnl.ColumnID, pnl.SortAsc)
    end
    
    table.insert(self.Columns, col)
    self.ColumnWidths[#self.Columns] = width
    self:InvalidateLayout()
    
    return col
end

function PANTHEON_LIST:AddLine(...)
    local args = {...}
    local line = vgui.Create('DButton', self.Scroll)
    line:Dock(TOP)
    line:DockMargin(0, 0, 0, 1)
    line:SetTall(self.LineHeight)
    line:SetText('')
    line.Values = args
    line.LineID = #self.Lines + 1
    line.Selected = false
    line.HoverFraction = 0
    line.ParentList = self
    
    line.DefaultPaint = function(pnl, w, h)
        pnl.HoverFraction = Lerp(FrameTime() * 12, pnl.HoverFraction, (pnl:IsHovered() or pnl.Selected) and 1 or 0)
        
        -- Background
        local bgColor = ui.col.TableRow
        if pnl.ParentList.AlternateColors and pnl.LineID % 2 == 0 then
            bgColor = ui.col.TableRowAlt
        end
        
        if pnl.Selected then
            bgColor = ColorAlpha(ui.col.PANTHEON, 180)
        elseif pnl.HoverFraction > 0 then
            bgColor = Color(
                bgColor.r + (ui.col.PANTHEON.r - bgColor.r) * pnl.HoverFraction * 0.3,
                bgColor.g + (ui.col.PANTHEON.g - bgColor.g) * pnl.HoverFraction * 0.3,
                bgColor.b + (ui.col.PANTHEON.b - bgColor.b) * pnl.HoverFraction * 0.3,
                255
            )
        end
        
        surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, bgColor.a or 255)
        surface.DrawRect(0, 0, w, h)
        
        -- Left accent bar for selected
        if pnl.Selected then
            surface.SetDrawColor(ui.col.PANTHEON_LIGHT.r, ui.col.PANTHEON_LIGHT.g, ui.col.PANTHEON_LIGHT.b, 255)
            surface.DrawRect(0, 0, 3, h)
        end
        
        -- Separator line
        if not pnl.Selected then
            surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 40)
            surface.DrawRect(0, h - 1, w, 1)
        end
        
        -- Draw column values
        local xPos = pnl.ParentList.Padding
        for i, value in ipairs(pnl.Values) do
            if pnl.ParentList.ColumnWidths[i] then
                local textColor = pnl.Selected and ui.col.White or ui.col.TEXT_DIM
                local font = pnl.Selected and 'PANTHEON.16' or 'PANTHEON.14'
                
                draw.SimpleText(tostring(value), font, xPos, h/2, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                xPos = xPos + pnl.ParentList.ColumnWidths[i]
            end
        end
    end
    
    line.Paint = line.DefaultPaint
    
    line.DoClick = function(pnl)
        if self.MultiSelect and input.IsKeyDown(KEY_LSHIFT) then
            pnl.Selected = not pnl.Selected
        else
            -- Deselect all others
            for _, l in ipairs(self.Lines) do
                if l ~= pnl then
                    l.Selected = false
                end
            end
            pnl.Selected = true
            self.SelectedLine = pnl
        end
        
        if self.OnRowSelected then
            self:OnRowSelected(pnl.LineID, pnl)
        end
    end
    
    line.DoRightClick = function(pnl)
        if self.OnRowRightClick then
            self:OnRowRightClick(pnl.LineID, pnl)
        end
    end
    
    -- DListView compatibility methods
    line.GetColumnText = function(pnl, colID)
        if pnl.Values[colID] then
            return tostring(pnl.Values[colID])
        end
        return ""
    end
    
    line.SetColumnText = function(pnl, colID, text)
        if pnl.Values[colID] then
            pnl.Values[colID] = text
        end
    end
    
    line.IsSelected = function(pnl)
        return pnl.Selected
    end
    
    table.insert(self.Lines, line)
    return line
end

function PANTHEON_LIST:Clear()
    for _, line in ipairs(self.Lines) do
        line:Remove()
    end
    self.Lines = {}
    self.SelectedLine = nil
end

function PANTHEON_LIST:GetSelected()
    local selected = {}
    for _, line in ipairs(self.Lines) do
        if line.Selected then
            table.insert(selected, line)
        end
    end
    return selected
end

function PANTHEON_LIST:GetSelectedLine()
    return self.SelectedLine
end

function PANTHEON_LIST:GetLine(lineID)
    return self.Lines[lineID]
end

function PANTHEON_LIST:GetColumnText(lineID, colID)
    local line = self.Lines[lineID]
    if line and line.Values[colID] then
        return tostring(line.Values[colID])
    end
    return ""
end

function PANTHEON_LIST:SetMultiSelect(enabled)
    self.MultiSelect = enabled
end

function PANTHEON_LIST:SortByColumn(colID, ascending)
    table.sort(self.Lines, function(a, b)
        local valA = a.Values[colID]
        local valB = b.Values[colID]
        
        -- Try to convert to numbers for proper sorting
        local numA = tonumber(valA)
        local numB = tonumber(valB)
        
        if numA and numB then
            return ascending and numA < numB or numA > numB
        else
            return ascending and tostring(valA) < tostring(valB) or tostring(valA) > tostring(valB)
        end
    end)
    
    -- Reorder visually
    for i, line in ipairs(self.Lines) do
        line.LineID = i
        line:SetZPos(i)
    end
end

function PANTHEON_LIST:PerformLayout(w, h)
    -- Layout header columns
    local xPos = 0
    for i, col in ipairs(self.Columns) do
        col:SetPos(xPos, 0)
        col:SetSize(self.ColumnWidths[i], self.HeaderHeight)
        xPos = xPos + self.ColumnWidths[i]
    end
end

function PANTHEON_LIST:Paint(w, h)
    -- Outer border
    surface.SetDrawColor(ui.col.Outline.r, ui.col.Outline.g, ui.col.Outline.b, 100)
    surface.DrawOutlinedRect(0, 0, w, h, 1)
end

vgui.Register('PantheonList', PANTHEON_LIST, 'DPanel')

--[[
    ============================================================================
    CREATE PANTHEON LIST
    ============================================================================
]]--
function ui.components.CreateList(parent, x, y, width, height)
    local list = vgui.Create('PantheonList', parent)
    list:SetPos(x or 0, y or 0)
    list:SetSize(width or 400, height or 300)
    
    return list
end

--[[
    ============================================================================
    CONVENIENCE FUNCTIONS
    ============================================================================
]]--

-- Alias for backward compatibility
ui.CreateFrame = ui.components.CreateFrame
ui.CreatePanel = ui.components.CreatePanel
ui.CreateButton = ui.components.CreateButton
ui.CreateScrollPanel = ui.components.CreateScrollPanel
ui.CreateTextEntry = ui.components.CreateTextEntry
ui.CreateList = ui.components.CreateList

MsgC(ui.col.PANTHEON, '[PANTHEON] ', ui.col.White, 'UI Components library loaded with custom list support\n')
