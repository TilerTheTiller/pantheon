--[[
    PANTHEON - Advanced Animation System
    Timeline-based animations with comprehensive easing functions
]]--

if SERVER then
    AddCSLuaFile()
    return
end

ui = ui or {}
ui.animations = ui.animations or {}

-- Global animation registry
ui.animations.active = {}
ui.animations.nextId = 1

-- Already defined in util.lua, but ensure they exist globally
ui.easings = ui.easings or {}

--[[
    Extended Easing Functions
    Additional easing functions beyond what's in util.lua
]]--
local extendedEasings = {
    -- Quartic
    easeInQuart = function(t) return t * t * t * t end,
    easeOutQuart = function(t) 
        local t1 = t - 1
        return 1 - t1 * t1 * t1 * t1 
    end,
    easeInOutQuart = function(t) 
        return t < 0.5 and 8 * t * t * t * t or 1 - 8 * (t - 1) * (t - 1) * (t - 1) * (t - 1) 
    end,
    
    -- Quintic
    easeInQuint = function(t) return t * t * t * t * t end,
    easeOutQuint = function(t) 
        local t1 = t - 1
        return 1 + t1 * t1 * t1 * t1 * t1 
    end,
    easeInOutQuint = function(t) 
        return t < 0.5 and 16 * t * t * t * t * t or 1 + 16 * (t - 1) * (t - 1) * (t - 1) * (t - 1) * (t - 1) 
    end,
    
    -- Sinusoidal
    easeInSine = function(t) return 1 - math.cos(t * math.pi / 2) end,
    easeOutSine = function(t) return math.sin(t * math.pi / 2) end,
    easeInOutSine = function(t) return -(math.cos(math.pi * t) - 1) / 2 end,
    
    -- Exponential
    easeInExpo = function(t) return t == 0 and 0 or math.pow(2, 10 * (t - 1)) end,
    easeOutExpo = function(t) return t == 1 and 1 or 1 - math.pow(2, -10 * t) end,
    easeInOutExpo = function(t)
        if t == 0 then return 0 end
        if t == 1 then return 1 end
        return t < 0.5 and math.pow(2, 20 * t - 10) / 2 or (2 - math.pow(2, -20 * t + 10)) / 2
    end,
    
    -- Circular
    easeInCirc = function(t) return 1 - math.sqrt(1 - t * t) end,
    easeOutCirc = function(t) return math.sqrt(1 - (t - 1) * (t - 1)) end,
    easeInOutCirc = function(t) 
        return t < 0.5 and (1 - math.sqrt(1 - 4 * t * t)) / 2 or (math.sqrt(1 - (-2 * t + 2) * (-2 * t + 2)) + 1) / 2 
    end,
    
    -- Back
    easeInBack = function(t, s)
        s = s or 1.70158
        return t * t * ((s + 1) * t - s)
    end,
    easeOutBack = function(t, s)
        s = s or 1.70158
        local t1 = t - 1
        return t1 * t1 * ((s + 1) * t1 + s) + 1
    end,
    easeInOutBack = function(t, s)
        s = (s or 1.70158) * 1.525
        return t < 0.5 and (t * t * ((s + 1) * t - s)) * 2 or ((t - 2) * (t - 2) * ((s + 1) * (t - 2) + s) + 2) / 2
    end,
    
    -- Bounce
    easeOutBounce = function(t)
        if t < 1 / 2.75 then
            return 7.5625 * t * t
        elseif t < 2 / 2.75 then
            t = t - 1.5 / 2.75
            return 7.5625 * t * t + 0.75
        elseif t < 2.5 / 2.75 then
            t = t - 2.25 / 2.75
            return 7.5625 * t * t + 0.9375
        else
            t = t - 2.625 / 2.75
            return 7.5625 * t * t + 0.984375
        end
    end
}

extendedEasings.easeInBounce = function(t)
    return 1 - extendedEasings.easeOutBounce(1 - t)
end

extendedEasings.easeInOutBounce = function(t)
    return t < 0.5 and extendedEasings.easeInBounce(t * 2) * 0.5 or extendedEasings.easeOutBounce(t * 2 - 1) * 0.5 + 0.5
end

-- Merge extended easings with existing ones
for name, func in pairs(extendedEasings) do
    if not ui.easings[name] then
        ui.easings[name] = func
    end
end

--[[
    Timeline System for Sequenced Animations
]]--
local TIMELINE = {}
TIMELINE.__index = TIMELINE

function TIMELINE:New()
    local timeline = setmetatable({}, self)
    timeline.animations = {}
    timeline.duration = 0
    timeline.playing = false
    timeline.completed = false
    timeline.paused = false
    timeline.callbacks = {}
    return timeline
end

function TIMELINE:To(target, properties, duration, time, options)
    time = time or self.duration
    duration = duration or 0.3
    options = options or {}
    
    table.insert(self.animations, {
        type = 'to',
        target = target,
        properties = properties,
        duration = duration,
        startTime = time,
        options = options
    })
    
    self.duration = math.max(self.duration, time + duration)
    return self
end

function TIMELINE:Set(target, properties, time)
    time = time or self.duration
    
    table.insert(self.animations, {
        type = 'set',
        target = target,
        properties = properties,
        duration = 0,
        startTime = time
    })
    
    return self
end

function TIMELINE:Call(callback, time)
    time = time or self.duration
    
    table.insert(self.callbacks, {
        callback = callback,
        time = time,
        called = false
    })
    
    return self
end

function TIMELINE:Play()
    if self.playing then return self end
    
    self.playing = true
    self.completed = false
    self.startTime = CurTime()
    
    -- Start all animations with proper timing
    for _, anim in ipairs(self.animations) do
        if anim.type == 'to' then
            local opts = table.Copy(anim.options)
            opts.delay = anim.startTime
            ui.Animate(anim.target, anim.properties, anim.duration, opts.easing or ui.easings.easeOutQuad, opts.onComplete)
        elseif anim.type == 'set' then
            timer.Simple(anim.startTime, function()
                for prop, value in pairs(anim.properties) do
                    if type(anim.target) == 'table' then
                        anim.target[prop] = value
                    end
                end
            end)
        end
    end
    
    -- Set completion timer
    timer.Simple(self.duration, function()
        self:Complete()
    end)
    
    return self
end

function TIMELINE:Complete()
    if self.completed then return end
    self.playing = false
    self.completed = true
end

function TIMELINE:Stop()
    self.playing = false
    return self
end

function ui.CreateTimeline()
    return TIMELINE:New()
end

--[[
    Predefined Animation Sequences
]]--

-- Fade in animation
function ui.FadeIn(target, duration, options)
    options = options or {}
    local startAlpha = options.from or 0
    local endAlpha = options.to or 255
    
    if IsValid(target) then
        target:SetAlpha(startAlpha)
        target:AlphaTo(endAlpha, duration or 0.3, 0, options.onComplete)
    end
end

-- Fade out animation
function ui.FadeOut(target, duration, options)
    options = options or {}
    local endAlpha = options.to or 0
    
    if IsValid(target) then
        target:AlphaTo(endAlpha, duration or 0.3, 0, options.onComplete)
    end
end

-- Slide in animation
function ui.SlideIn(target, direction, distance, duration, options)
    if not IsValid(target) then return end
    
    direction = direction or 'left'
    distance = distance or 100
    duration = duration or 0.3
    options = options or {}
    
    local startX, startY = target:GetPos()
    local endX, endY = startX, startY
    
    if direction == 'left' then
        startX = startX - distance
    elseif direction == 'right' then
        startX = startX + distance
    elseif direction == 'up' then
        startY = startY - distance
    elseif direction == 'down' then
        startY = startY + distance
    end
    
    target:SetPos(startX, startY)
    target:MoveTo(endX, endY, duration, 0, -1, options.onComplete)
end

-- Pulse animation
function ui.Pulse(target, scale, duration)
    if not IsValid(target) then return end
    
    scale = scale or 1.1
    duration = duration or 1
    
    local originalW, originalH = target:GetSize()
    local newW = originalW * scale
    local newH = originalH * scale
    
    -- Create repeating pulse
    local function pulse()
        if not IsValid(target) then return end
        target:SizeTo(newW, newH, duration * 0.5, 0, -1, function()
            if not IsValid(target) then return end
            target:SizeTo(originalW, originalH, duration * 0.5, 0, -1, pulse)
        end)
    end
    
    pulse()
end

MsgC(ui.col.PANTHEON, '[PANTHEON] ', ui.col.White, 'Advanced Animation System loaded\n')
