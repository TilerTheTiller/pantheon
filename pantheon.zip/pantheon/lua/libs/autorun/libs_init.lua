-- LIBS Autorun - PANTHEON Library System
-- Automatically loads the LIBS library system

-- Send to clients
if SERVER then
	AddCSLuaFile('libs/init.lua')
end

-- Load LIBS
include('libs/init.lua')

MsgC(Color(138, 43, 226), '[LIBS] ', Color(255, 255, 255), 'Autorun loaded successfully\n')
