--[[
	OLIBS - XFN (Extended Functions)
	Utility functions for PANTHEON
]]

xfn = {}

-- Table functions
function table.IsEmpty(tbl)
	return next(tbl) == nil
end

function table.Copy(tbl, seen)
	if not istable(tbl) then return tbl end
	
	seen = seen or {}
	if seen[tbl] then return seen[tbl] end
	
	local copy = {}
	seen[tbl] = copy
	
	for k, v in pairs(tbl) do
		if istable(v) then
			copy[k] = table.Copy(v, seen)
		else
			copy[k] = v
		end
	end
	return copy
end

function table.Merge(dest, source, seen)
	seen = seen or {}
	
	-- Prevent circular reference
	if seen[source] then return dest end
	seen[source] = true
	
	for k, v in pairs(source) do
		if istable(v) and istable(dest[k]) then
			table.Merge(dest[k], v, seen)
		else
			dest[k] = v
		end
	end
	return dest
end

function table.Random(tbl)
	local keys = {}
	for k in pairs(tbl) do
		table.insert(keys, k)
	end
	if #keys == 0 then return nil end
	local key = keys[math.random(#keys)]
	return tbl[key], key
end

function table.Filter(tbl, func)
	local result = {}
	for k, v in pairs(tbl) do
		if func(v, k) then
			result[k] = v
		end
	end
	return result
end

function table.Map(tbl, func)
	local result = {}
	for k, v in pairs(tbl) do
		result[k] = func(v, k)
	end
	return result
end

-- String functions
function string.Split(str, delimiter)
	local result = {}
	local pattern = string.format("([^%s]+)", delimiter)
	str:gsub(pattern, function(c)
		table.insert(result, c)
	end)
	return result
end

function string.Trim(str)
	return str:match("^%s*(.-)%s*$")
end

function string.StartsWith(str, prefix)
	return str:sub(1, #prefix) == prefix
end

function string.EndsWith(str, suffix)
	return suffix == "" or str:sub(-#suffix) == suffix
end

-- Math functions
function math.Clamp(val, min, max)
	if val < min then return min end
	if val > max then return max end
	return val
end

function math.Round(num, decimals)
	local mult = 10 ^ (decimals or 0)
	return math.floor(num * mult + 0.5) / mult
end

-- Player functions
function player.GetBySteamID(steamid)
	for k, v in ipairs(player.GetAll()) do
		if v:SteamID() == steamid then
			return v
		end
	end
	return nil
end

function player.GetBySteamID64(steamid64)
	for k, v in ipairs(player.GetAll()) do
		if v:SteamID64() == steamid64 then
			return v
		end
	end
	return nil
end

function player.GetByName(name)
	name = name:lower()
	for k, v in ipairs(player.GetAll()) do
		if v:Nick():lower():find(name, 1, true) then
			return v
		end
	end
	return nil
end

-- Entity functions
local ENTITY = FindMetaTable('Entity')
if ENTITY then
	if (SERVER) then
		function ENTITY:SetBVar(key, value)
			self._BVars = self._BVars or {}
			self._BVars[key] = value
		end

		function ENTITY:GetBVar(key, default)
			if not self._BVars then return default end
			return self._BVars[key] or default
		end
		
		function ENTITY:SetNetVar(key, value)
			self['nw_' .. key] = value
			if nw and nw.SetGlobal then
				self:SetNWString(key, value)
			end
		end
		
		function ENTITY:GetNetVar(key, default)
			return self['nw_' .. key] or self:GetNWString(key, default) or default
		end
	else
		-- Client side BVars are not synced
		function ENTITY:SetBVar(key, value)
			self._BVars = self._BVars or {}
			self._BVars[key] = value
		end

		function ENTITY:GetBVar(key, default)
			if not self._BVars then return default end
			return self._BVars[key] or default
		end
		
		function ENTITY:GetNetVar(key, default)
			return self:GetNWString(key, default) or default
		end
	end
end

-- Hash ID for players
local PLAYER = FindMetaTable('Player')
if (SERVER) and PLAYER then
	function PLAYER:HashID()
		return util.SHA256(self:SteamID64() .. os.time())
	end
end
