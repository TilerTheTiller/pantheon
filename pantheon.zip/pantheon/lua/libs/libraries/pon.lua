--[[
	OLIBS - PON (Primitive Object Notation)
	Simplified data serialization
]]

pon = {}

local type = type
local pairs = pairs
local tonumber = tonumber
local tostring = tostring
local string_format = string.format
local string_gsub = string.gsub
local table_concat = table.concat
local math_huge = math.huge

-- Encode Lua value to PON string
function pon.encode(tbl, pretty)
	if type(tbl) ~= "table" then
		return tostring(tbl)
	end
	
	local result = {}
	local indent = pretty and 1 or 0
	
	local function encode_value(val, depth)
		local t = type(val)
		
		if t == "string" then
			return string_format("%q", val)
		elseif t == "number" then
			if val == math_huge then
				return "math.huge"
			elseif val == -math_huge then
				return "-math.huge"
			elseif val ~= val then
				return "0/0"
			else
				return tostring(val)
			end
		elseif t == "boolean" then
			return tostring(val)
		elseif t == "table" then
			return encode_table(val, depth + 1)
		else
			return "nil"
		end
	end
	
	local function encode_table(tbl, depth)
		local result = {}
		local indentStr = pretty and string.rep("  ", depth) or ""
		local innerIndent = pretty and string.rep("  ", depth + 1) or ""
		
		table.insert(result, "{")
		
		for k, v in pairs(tbl) do
			if pretty then
				table.insert(result, "\n" .. innerIndent)
			end
			
			if type(k) == "string" and k:match("^[%a_][%w_]*$") then
				table.insert(result, k .. " = ")
			else
				table.insert(result, "[" .. encode_value(k, depth) .. "] = ")
			end
			
			table.insert(result, encode_value(v, depth))
			table.insert(result, ",")
			
			if not pretty then
				table.insert(result, " ")
			end
		end
		
		if pretty and #result > 1 then
			table.insert(result, "\n" .. indentStr)
		end
		
		table.insert(result, "}")
		
		return table.concat(result)
	end
	
	return encode_table(tbl, 0)
end

-- Decode PON string to Lua value
function pon.decode(str)
	if not str or str == "" then
		return nil
	end
	
	local func = CompileString("return " .. str, "pon.decode")
	if type(func) == "string" then
		return nil, func
	end
	
	local success, result = pcall(func)
	if not success then
		return nil, result
	end
	
	return result
end

-- Aliases
pon.toString = pon.encode
pon.fromString = pon.decode
