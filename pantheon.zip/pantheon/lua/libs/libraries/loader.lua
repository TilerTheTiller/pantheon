-- ═══════════════════════════════════════════════════════════════════════════
--  PANTHEON File Loader System v3.0
--  Advanced modular file loading with dependency resolution, caching, and hooks
-- ═══════════════════════════════════════════════════════════════════════════

loader = loader or {}
loader.VERSION = "3.0.0"

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Configuration                                                ║
-- ╚═══════════════════════════════════════════════════════════════╝

loader.config = {
	verbose = false,              -- Enable detailed logging
	benchmarking = true,          -- Track file load times
	colorOutput = true,           -- Use colored console output
	throwErrors = false,          -- Throw errors instead of catching them
	maxDepth = 10,               -- Maximum directory recursion depth
	maxRetries = 3,              -- Maximum retries for failed loads
	cacheEnabled = true,         -- Enable result caching
	hotReload = false,           -- Enable file watching for hot reload
	deferredLoading = false      -- Enable deferred loading queue
}

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Internal State                                               ║
-- ╚═══════════════════════════════════════════════════════════════╝

loader._internal = {
	cache = {},                  -- Cached file results
	loading = {},                -- Currently loading files (circular dependency detection)
	dependencies = {},           -- Dependency graph
	loadOrder = {},              -- Order files were loaded
	benchmarks = {},             -- Active benchmarks
	errors = {},                 -- Error log
	warnings = {},               -- Warning log
	watchers = {},               -- File watchers for hot reload
	deferred = {},               -- Deferred loading queue
	hooks = {},                  -- Registered loader hooks
	metadata = {},               -- File metadata (size, load time, etc.)
	stats = {                    -- Cumulative statistics
		totalLoads = 0,
		totalErrors = 0,
		totalTime = 0,
		cacheHits = 0,
		cacheMisses = 0
	}
}

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Color Palette                                                ║
-- ╚═══════════════════════════════════════════════════════════════╝

loader.colors = {
	primary = Color(138, 43, 226),    -- PANTHEON Purple
	success = Color(46, 204, 113),    -- Green
	warning = Color(241, 196, 15),    -- Yellow
	error = Color(231, 76, 60),       -- Red
	info = Color(52, 152, 219),       -- Blue
	debug = Color(149, 165, 166),     -- Gray
	white = Color(255, 255, 255),
	dim = Color(189, 195, 199)        -- Dimmed white
}

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Utility Functions                                            ║
-- ╚═══════════════════════════════════════════════════════════════╝

-- Normalize path separators for cross-platform compatibility
function loader.normalizePath(path)
	if not path then return '' end
	path = string.gsub(path, '\\', '/')
	path = string.gsub(path, '/+', '/')  -- Remove duplicate slashes
	return path
end

-- Determine realm from filename suffix
function loader.getRealm(filename)
	if not filename then return 'shared' end
	if string.find(filename, '_sv%.lua$') then return 'server' end
	if string.find(filename, '_cl%.lua$') then return 'client' end
	if string.find(filename, '_sh%.lua$') then return 'shared' end
	return 'shared'
end

-- Check if file should load in current realm
function loader.shouldLoad(realm)
	if realm == 'shared' then return true end
	if realm == 'server' then return SERVER end
	if realm == 'client' then return CLIENT end
	return true
end

-- Check if file exists
function loader.fileExists(path)
	path = loader.normalizePath(path)
	
	-- Try LUA path first (addons)
	if file.Exists(path, 'LUA') then
		loader.verbose('File found in LUA: ' .. path)
		return true
	end
	
	-- Try GAME path (gamemode)
	if file.Exists(path, 'GAME') then
		loader.verbose('File found in GAME: ' .. path)
		return true
	end
	
	-- Try with lua/ prefix if not already present
	if not path:find('^lua/') then
		local luaPath = 'lua/' .. path
		if file.Exists(luaPath, 'GAME') then
			loader.verbose('File found with lua/ prefix: ' .. luaPath)
			return true
		end
	end
	
	loader.verbose('File NOT found: ' .. path .. ' (tried LUA, GAME, and lua/ prefix)')
	return false
end

-- Get file size (if available)
function loader.getFileSize(path)
	path = loader.normalizePath(path)
	local size = file.Size(path, 'LUA')
	if not size or size == -1 then
		size = file.Size(path, 'GAME') or 0
	end
	return size
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Logging System                                               ║
-- ╚═══════════════════════════════════════════════════════════════╝

function loader.print(color, prefix, ...)
	if not loader.config.colorOutput then
		print(prefix, ...)
		return
	end
	
	local args = {...}
	local msg = table.concat(args, ' ')
	MsgC(color or loader.colors.primary, prefix, loader.colors.white, msg, '\n')
end

function loader.verbose(...)
	if loader.config.verbose then
		loader.print(loader.colors.debug, '[LOADER:VERBOSE] ', ...)
	end
end

function loader.info(...)
	loader.print(loader.colors.info, '[LOADER] ', ...)
end

function loader.success(...)
	loader.print(loader.colors.success, '[LOADER:OK] ', ...)
end

function loader.warn(msg, context)
	loader.print(loader.colors.warning, '[LOADER:WARN] ', msg)
	table.insert(loader._internal.warnings, {
		msg = msg,
		context = context,
		time = os.time(),
		realm = SERVER and 'server' or 'client'
	})
end

function loader.error(msg, err, context)
	loader.print(loader.colors.error, '[LOADER:ERROR] ', msg)
	if err then
		loader.print(loader.colors.error, '  └─ ', tostring(err))
	end
	
	table.insert(loader._internal.errors, {
		msg = msg,
		error = err,
		context = context,
		time = os.time(),
		realm = SERVER and 'server' or 'client',
		stack = debug.traceback()
	})
	
	loader._internal.stats.totalErrors = loader._internal.stats.totalErrors + 1
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Benchmarking System                                          ║
-- ╚═══════════════════════════════════════════════════════════════╝

function loader.startBenchmark(name)
	if loader.config.benchmarking then
		loader._internal.benchmarks[name] = SysTime()
	end
end

function loader.endBenchmark(name)
	if loader.config.benchmarking and loader._internal.benchmarks[name] then
		local elapsed = (SysTime() - loader._internal.benchmarks[name]) * 1000
		loader._internal.benchmarks[name] = nil
		loader.verbose(string.format('Benchmark [%s]: %.3fms', name, elapsed))
		return elapsed
	end
	return 0
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Hook System                                                  ║
-- ╚═══════════════════════════════════════════════════════════════╝

function loader.addHook(hookName, identifier, callback)
	if not loader._internal.hooks[hookName] then
		loader._internal.hooks[hookName] = {}
	end
	
	loader._internal.hooks[hookName][identifier] = callback
	loader.verbose('Registered hook: ' .. hookName .. '.' .. identifier)
end

function loader.removeHook(hookName, identifier)
	if loader._internal.hooks[hookName] then
		loader._internal.hooks[hookName][identifier] = nil
	end
end

function loader.callHook(hookName, ...)
	if not loader._internal.hooks[hookName] then return end
	
	local results = {}
	for identifier, callback in pairs(loader._internal.hooks[hookName]) do
		local success, result = pcall(callback, ...)
		if success then
			table.insert(results, result)
		else
			loader.error('Hook error: ' .. hookName .. '.' .. identifier, result)
		end
	end
	
	return results
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Cache Management                                             ║
-- ╚═══════════════════════════════════════════════════════════════╝

function loader.getCache(path)
	if not loader.config.cacheEnabled then return nil end
	
	local cached = loader._internal.cache[path]
	if cached then
		loader._internal.stats.cacheHits = loader._internal.stats.cacheHits + 1
		return cached
	end
	
	loader._internal.stats.cacheMisses = loader._internal.stats.cacheMisses + 1
	return nil
end

function loader.setCache(path, value)
	if loader.config.cacheEnabled then
		loader._internal.cache[path] = value
	end
end

function loader.clearCache(pattern)
	if pattern then
		local cleared = 0
		for path, _ in pairs(loader._internal.cache) do
			if path:match(pattern) then
				loader._internal.cache[path] = nil
				cleared = cleared + 1
			end
		end
		loader.verbose('Cleared ' .. cleared .. ' cache entries matching: ' .. pattern)
	else
		loader._internal.cache = {}
		loader.info('Cache cleared completely')
	end
end

function loader.getCacheSize()
	return table.Count(loader._internal.cache)
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Dependency Management                                        ║
-- ╚═══════════════════════════════════════════════════════════════╝

function loader.registerDependency(file, dependencies)
	file = loader.normalizePath(file)
	
	if type(dependencies) == 'string' then
		dependencies = {dependencies}
	end
	
	loader._internal.dependencies[file] = dependencies
	loader.verbose('Registered dependencies for: ' .. file)
end

function loader.getDependencies(file)
	file = loader.normalizePath(file)
	return loader._internal.dependencies[file] or {}
end

function loader.hasDependency(file, dependency)
	local deps = loader.getDependencies(file)
	for _, dep in ipairs(deps) do
		if dep == dependency then return true end
	end
	return false
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Core Loading Functions                                       ║
-- ╚═══════════════════════════════════════════════════════════════╝

-- Low-level file include with realm handling
function loader.includeFile(path, realm)
	path = loader.normalizePath(path)
	realm = realm or loader.getRealm(path)
	
	-- Send to clients if on server
	if SERVER then
		if realm == 'shared' or realm == 'client' then
			-- Check file existence before AddCSLuaFile
			if not loader.fileExists(path) then
				local err = 'File does not exist (server trying to send to client): ' .. path
				loader.error(err)
				
				-- Log what paths we tried
				MsgC(Color(231, 76, 60), '[LOADER ERROR] Failed to find file for client transmission:\n')
				MsgC(Color(231, 76, 60), '  Path: ', Color(255, 255, 255), path, '\n')
				MsgC(Color(231, 76, 60), '  Tried LUA path: ', Color(255, 255, 255), tostring(file.Exists(path, 'LUA')), '\n')
				MsgC(Color(231, 76, 60), '  Tried GAME path: ', Color(255, 255, 255), tostring(file.Exists(path, 'GAME')), '\n')
				
				error(err)
			end
			
			AddCSLuaFile(path)
			loader.verbose('AddCSLuaFile: ' .. path)
			MsgC(Color(46, 204, 113), '[LOADER] AddCSLuaFile: ', Color(255, 255, 255), path, '\n')
		end
	end
	
	-- Include on appropriate realm
	if loader.shouldLoad(realm) then
		-- Check file existence before attempting to load
		if not loader.fileExists(path) then
			local err = 'File does not exist: ' .. path
			loader.error(err)
			error(err)
		end
		return include(path)
	end
	
	return nil
end

-- Main loading function with full feature set
function loader.load(path, options)
	path = loader.normalizePath(path)
	options = options or {}
	
	local realm = options.realm or loader.getRealm(path)
	local cache = options.cache ~= false
	local force = options.force or false
	local silent = options.silent or false
	local retries = options.retries or 0
	
	-- Call pre-load hook
	loader.callHook('PreLoad', path, options)
	
	-- Check cache
	if cache and not force then
		local cached = loader.getCache(path)
		if cached ~= nil then
			loader.verbose('Cache hit: ' .. path)
			return cached
		end
	end
	
	-- Check if file exists
	if not loader.fileExists(path) then
		loader.error('File not found: ' .. path)
		return nil
	end
	
	-- Detect circular dependencies
	if loader._internal.loading[path] then
		loader.error('Circular dependency detected: ' .. path)
		return nil
	end
	
	-- Load dependencies first
	local deps = loader.getDependencies(path)
	for _, dep in ipairs(deps) do
		dep = loader.normalizePath(dep)
		if not loader.getCache(dep) then
			loader.verbose('Loading dependency: ' .. dep .. ' for ' .. path)
			loader.load(dep, options)
		end
	end
	
	-- Mark as loading
	loader._internal.loading[path] = true
	loader.startBenchmark(path)
	
	-- Attempt to load file
	local success, result = pcall(loader.includeFile, path, realm)
	
	local loadTime = loader.endBenchmark(path)
	loader._internal.loading[path] = nil
	
	-- Handle load failure
	if not success then
		-- Retry if configured
		if retries > 0 and retries < loader.config.maxRetries then
			loader.warn('Retrying load (' .. (retries + 1) .. '/' .. loader.config.maxRetries .. '): ' .. path)
			timer.Simple(0.1, function()
				local newOpts = table.Copy(options)
				newOpts.retries = retries + 1
				loader.load(path, newOpts)
			end)
			return nil
		end
		
		loader.error('Failed to load: ' .. path, result, {realm = realm, retries = retries})
		
		if loader.config.throwErrors then
			error(result)
		end
		
		-- Call error hook
		loader.callHook('LoadError', path, result, options)
		
		return nil
	end
	
	-- Cache result
	if cache then
		loader.setCache(path, result)
	end
	
	-- Track load order and metadata
	table.insert(loader._internal.loadOrder, path)
	loader._internal.metadata[path] = {
		realm = realm,
		loadTime = loadTime,
		size = loader.getFileSize(path),
		timestamp = os.time(),
		retries = retries
	}
	
	-- Update statistics
	loader._internal.stats.totalLoads = loader._internal.stats.totalLoads + 1
	loader._internal.stats.totalTime = loader._internal.stats.totalTime + loadTime
	
	if not silent then
		loader.verbose(string.format('Loaded: %s [%s] (%.3fms)', path, realm, loadTime))
	end
	
	-- Call post-load hook
	loader.callHook('PostLoad', path, result, options)
	
	return result
end

-- Load multiple files sequentially
function loader.loadFiles(files, options)
	local results = {}
	for i, file in ipairs(files) do
		results[i] = loader.load(file, options)
	end
	return results
end

-- Load all files in a directory
function loader.loadDir(path, options)
	path = loader.normalizePath(path)
	options = options or {}
	
	local recursive = options.recursive ~= false
	local exclude = options.exclude or {}
	local filter = options.filter  -- Custom filter function
	local maxDepth = options.maxDepth or loader.config.maxDepth
	local currentDepth = options._depth or 0
	local sortOrder = options.sortOrder or 'alphabetical'  -- 'alphabetical', 'size', 'custom'
	local sortFunc = options.sortFunc
	
	if currentDepth >= maxDepth then
		loader.warn('Max directory depth reached: ' .. path)
		return {}
	end
	
	loader.verbose('Scanning directory: ' .. path)
	
	local results = {}
	local files, folders = file.Find(path .. '/*', 'LUA')
	
	-- Try GAME path if LUA path doesn't exist (for dedicated servers)
	if not files or #files == 0 then
		files, folders = file.Find(path .. '/*', 'GAME')
	end
	
	if not files or #files == 0 then
		loader.warn('Directory not found or empty: ' .. path)
		return {}
	end
	
	-- Sort files
	if sortOrder == 'alphabetical' then
		table.sort(files)
	elseif sortOrder == 'size' and not sortFunc then
		table.sort(files, function(a, b)
			local sizeA = loader.getFileSize(path .. '/' .. a)
			local sizeB = loader.getFileSize(path .. '/' .. b)
			return sizeA < sizeB
		end)
	elseif sortFunc then
		table.sort(files, sortFunc)
	end
	
	if folders then
		table.sort(folders)
	else
		folders = {}
	end
	
	-- Load files
	for _, filename in ipairs(files) do
		if filename:match('%.lua$') then
			local fullPath = path .. '/' .. filename
			local shouldExclude = false
			
			-- Check exclusions
			for _, pattern in ipairs(exclude) do
				if fullPath:match(pattern) or filename:match(pattern) then
					shouldExclude = true
					loader.verbose('Excluded: ' .. fullPath)
					break
				end
			end
			
			-- Check custom filter
			if not shouldExclude and filter and not filter(fullPath, filename) then
				shouldExclude = true
				loader.verbose('Filtered: ' .. fullPath)
			end
			
			if not shouldExclude then
				table.insert(results, loader.load(fullPath, options))
			end
		end
	end
	
	-- Load subdirectories if recursive
	if recursive then
		for _, folder in ipairs(folders) do
			if folder ~= '.' and folder ~= '..' then
				local subOptions = table.Copy(options)
				subOptions._depth = currentDepth + 1
				local subResults = loader.loadDir(path .. '/' .. folder, subOptions)
				table.Add(results, subResults)
			end
		end
	end
	
	loader.verbose(string.format('Loaded %d file(s) from: %s', #results, path))
	return results
end

-- Load a module (directory with init.lua or auto-discovery)
function loader.loadModule(modulePath, options)
	modulePath = loader.normalizePath(modulePath)
	options = options or {}
	
	-- Try loading module/init.lua
	local initPath = modulePath .. '/init.lua'
	if loader.fileExists(initPath) then
		loader.verbose('Loading module via init.lua: ' .. modulePath)
		return loader.load(initPath, options)
	end
	
	-- Try loading module/module.lua or module/[dirname].lua
	local moduleName = string.GetFileFromFilename(modulePath)
	if moduleName then
		local modPath = modulePath .. '/' .. moduleName .. '.lua'
		if loader.fileExists(modPath) then
			loader.verbose('Loading module via ' .. moduleName .. '.lua: ' .. modulePath)
			return loader.load(modPath, options)
		end
	end
	
	-- Fall back to loading entire directory
	loader.verbose('Loading module via directory scan: ' .. modulePath)
	return loader.loadDir(modulePath, options)
end

-- Reload a file (clear cache and load again)
function loader.reload(path, options)
	path = loader.normalizePath(path)
	
	-- Clear from cache
	loader._internal.cache[path] = nil
	
	-- Clear metadata
	loader._internal.metadata[path] = nil
	
	loader.info('Reloading: ' .. path)
	
	-- Force load
	local opts = options or {}
	opts.force = true
	
	return loader.load(path, opts)
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Realm-Specific Convenience Functions                        ║
-- ╚═══════════════════════════════════════════════════════════════╝

function loader.loadShared(path, options)
	options = options or {}
	options.realm = 'shared'
	return loader.load(path, options)
end

function loader.loadServer(path, options)
	options = options or {}
	options.realm = 'server'
	return loader.load(path, options)
end

function loader.loadClient(path, options)
	options = options or {}
	options.realm = 'client'
	return loader.load(path, options)
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Statistics & Reporting                                       ║
-- ╚═══════════════════════════════════════════════════════════════╝

function loader.getStats()
	return {
		version = loader.VERSION,
		filesLoaded = #loader._internal.loadOrder,
		cacheSize = loader.getCacheSize(),
		errors = #loader._internal.errors,
		warnings = #loader._internal.warnings,
		loadOrder = loader._internal.loadOrder,
		totalLoads = loader._internal.stats.totalLoads,
		totalErrors = loader._internal.stats.totalErrors,
		totalTime = loader._internal.stats.totalTime,
		averageTime = loader._internal.stats.totalLoads > 0 and 
		             (loader._internal.stats.totalTime / loader._internal.stats.totalLoads) or 0,
		cacheHits = loader._internal.stats.cacheHits,
		cacheMisses = loader._internal.stats.cacheMisses,
		cacheHitRate = (loader._internal.stats.cacheHits + loader._internal.stats.cacheMisses) > 0 and
		               (loader._internal.stats.cacheHits / (loader._internal.stats.cacheHits + loader._internal.stats.cacheMisses) * 100) or 0
	}
end

function loader.getMetadata(path)
	path = loader.normalizePath(path)
	return loader._internal.metadata[path]
end

function loader.printReport()
	local stats = loader.getStats()
	
	loader.print(loader.colors.primary, '\n╔════════════════════════════════════════════════════════════╗')
	loader.print(loader.colors.primary, '║         PANTHEON Loader v' .. loader.VERSION .. ' - Statistics            ║')
	loader.print(loader.colors.primary, '╠════════════════════════════════════════════════════════════╣')
	loader.print(loader.colors.info, '  Files Loaded:      ', tostring(stats.filesLoaded))
	loader.print(loader.colors.info, '  Total Loads:       ', tostring(stats.totalLoads))
	loader.print(loader.colors.info, '  Cache Size:        ', tostring(stats.cacheSize))
	loader.print(loader.colors.info, '  Cache Hit Rate:    ', string.format('%.1f%%', stats.cacheHitRate))
	loader.print(loader.colors.info, '  Total Load Time:   ', string.format('%.2fms', stats.totalTime))
	loader.print(loader.colors.info, '  Average Load Time: ', string.format('%.3fms', stats.averageTime))
	
	if stats.warnings > 0 then
		loader.print(loader.colors.warning, '  Warnings:          ', tostring(stats.warnings))
	end
	
	if stats.errors > 0 then
		loader.print(loader.colors.error, '  Errors:            ', tostring(stats.errors))
		loader.print(loader.colors.primary, '╠════════════════════════════════════════════════════════════╣')
		for i, err in ipairs(loader._internal.errors) do
			if i <= 5 then  -- Show only first 5 errors
				loader.print(loader.colors.error, '  ' .. i .. '. ', err.msg)
			end
		end
		if stats.errors > 5 then
			loader.print(loader.colors.dim, '  ... and ' .. (stats.errors - 5) .. ' more errors')
		end
	else
		loader.print(loader.colors.success, '  Errors:            ', '0')
	end
	
	loader.print(loader.colors.primary, '╚════════════════════════════════════════════════════════════╝\n')
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Advanced Features                                            ║
-- ╚═══════════════════════════════════════════════════════════════╝

-- Deferred loading queue
function loader.defer(path, options)
	table.insert(loader._internal.deferred, {path = path, options = options})
	loader.verbose('Deferred loading: ' .. path)
end

function loader.processDeferredQueue()
	local count = #loader._internal.deferred
	if count == 0 then return 0 end
	
	loader.info('Processing ' .. count .. ' deferred file(s)')
	
	for _, item in ipairs(loader._internal.deferred) do
		loader.load(item.path, item.options)
	end
	
	loader._internal.deferred = {}
	return count
end

-- Get load order for debugging
function loader.getLoadOrder()
	return loader._internal.loadOrder
end

-- Check if file is loaded
function loader.isLoaded(path)
	path = loader.normalizePath(path)
	return loader.getCache(path) ~= nil
end

-- Get all errors
function loader.getErrors()
	return loader._internal.errors
end

-- Get all warnings
function loader.getWarnings()
	return loader._internal.warnings
end

-- ╔═══════════════════════════════════════════════════════════════╗
-- ║  Initialization                                               ║
-- ╚═══════════════════════════════════════════════════════════════╝

-- Console commands for debugging
concommand.Add('loader_verbose', function(ply, cmd, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	
	local newState = args[1] == '1' or args[1] == 'true' or args[1] == 'on'
	loader.config.verbose = newState
	
	local msg = 'Loader verbose mode: ' .. (newState and 'ENABLED' or 'DISABLED')
	if IsValid(ply) then
		ply:ChatPrint(msg)
	else
		print(msg)
	end
end)

concommand.Add('loader_stats', function(ply, cmd, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	loader.printReport()
end)

concommand.Add('loader_errors', function(ply, cmd, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	
	local errors = loader.getErrors()
	loader.info('Total errors: ' .. #errors)
	
	for i, err in ipairs(errors) do
		loader.print(loader.colors.error, '[' .. i .. '] ', err.msg)
		if err.error then
			loader.print(loader.colors.dim, '  └─ ', tostring(err.error))
		end
	end
end)

loader.success('PANTHEON Loader v' .. loader.VERSION .. ' initialized')

return loader
