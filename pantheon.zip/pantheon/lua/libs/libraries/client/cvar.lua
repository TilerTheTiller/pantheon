--[[
	OLIBS - CVar Helper
	Client-side console variable helpers
]]

if (SERVER) then return end

cvar = {}

function cvar.Get(name, default)
	local cv = GetConVar(name)
	if not cv then return default end
	return cv:GetString()
end

function cvar.GetInt(name, default)
	local cv = GetConVar(name)
	if not cv then return default end
	return cv:GetInt()
end

function cvar.GetFloat(name, default)
	local cv = GetConVar(name)
	if not cv then return default end
	return cv:GetFloat()
end

function cvar.GetBool(name, default)
	local cv = GetConVar(name)
	if not cv then return default end
	return cv:GetBool()
end

function cvar.Set(name, value)
	RunConsoleCommand(name, tostring(value))
end
