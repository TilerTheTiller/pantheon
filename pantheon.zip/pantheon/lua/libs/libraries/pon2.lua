--[[
	OLIBS - PON2 (Extended PON)
	Additional serialization functions
]]

pon2 = pon2 or {}

-- Encode with compression
function pon2.encode(tbl)
	local str = pon.encode(tbl)
	return util.Compress(str)
end

-- Decode with decompression
function pon2.decode(str)
	if not str or str == "" then return nil end
	local decompressed = util.Decompress(str)
	if not decompressed then return nil end
	return pon.decode(decompressed)
end

-- File operations
if (SERVER) then
	function pon2.save(path, tbl)
		local str = pon.encode(tbl, true)
		file.Write(path, str)
	end
	
	function pon2.load(path)
		if not file.Exists(path, "DATA") then
			return nil
		end
		local str = file.Read(path, "DATA")
		return pon.decode(str)
	end
end
