--[[
	OLIBS - SHA2 Hashing
	SHA256 hashing functions
]]

if (CLIENT) then return end

sha2 = {}

-- Use built-in util.SHA256
function sha2.sha256(str)
	return util.SHA256(str)
end

function sha2.hash(str)
	return util.SHA256(str)
end
