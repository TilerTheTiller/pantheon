--[[
	OLIBS - MySQL Wrapper
	Simplified MySQL library for PANTHEON
]]

if (CLIENT) then return end

ptmysql = {}

local queue = {}
local connected = false

function ptmysql.newdb(host, user, pass, database, port)
	local db = {
		host = host,
		user = user,
		pass = pass,
		database = database,
		port = port or 3306,
		connection = nil
	}
	
	-- Try to require mysqloo
	local success, mysqloo = pcall(require, "mysqloo")
	local errorMsg = nil
	
	if not success then
		errorMsg = tostring(mysqloo)
		MsgC(Color(255, 165, 0), '[MySQL] ', Color(255, 255, 255), 'Failed to load "mysqloo": ' .. errorMsg .. '\n')
		
		-- Try alternative name
		local success2, result = pcall(require, "MySQLOO")
		if success2 then
			success = true
			mysqloo = result
			errorMsg = nil
			MsgC(Color(0, 255, 0), '[MySQL] ', Color(255, 255, 255), 'Loaded MySQLOO successfully!\n')
		else
			MsgC(Color(255, 165, 0), '[MySQL] ', Color(255, 255, 255), 'Failed to load "MySQLOO": ' .. tostring(result) .. '\n')
			
			-- Try gmsv_mysqloo
			local success3, result3 = pcall(require, "gmsv_mysqloo")
			if success3 then
				success = true
				mysqloo = result3
				errorMsg = nil
				MsgC(Color(0, 255, 0), '[MySQL] ', Color(255, 255, 255), 'Loaded gmsv_mysqloo successfully!\n')
			else
				MsgC(Color(255, 165, 0), '[MySQL] ', Color(255, 255, 255), 'Failed to load "gmsv_mysqloo": ' .. tostring(result3) .. '\n')
			end
		end
	else
		MsgC(Color(0, 255, 0), '[MySQL] ', Color(255, 255, 255), 'Loaded mysqloo successfully!\n')
	end
	
	if not success or not mysqloo then
		MsgC(Color(255, 165, 0), '[MySQL] ', Color(255, 255, 255), 'MySQLOO module not available!\n')
		MsgC(Color(255, 165, 0), '[MySQL] ', Color(255, 255, 255), 'Tried: "mysqloo", "MySQLOO", "gmsv_mysqloo"\n')
		MsgC(Color(255, 165, 0), '[MySQL] ', Color(255, 255, 255), 'Make sure MySQLOO is installed in garrysmod/lua/bin/\n')
		if errorMsg and errorMsg ~= "true" and errorMsg ~= "false" then
			MsgC(Color(255, 165, 0), '[MySQL] ', Color(255, 255, 255), 'Last error: ' .. errorMsg .. '\n')
		end
		MsgC(Color(255, 165, 0), '[MySQL] ', Color(255, 255, 255), 'Using SQLite fallback for local storage.\n')
		
		-- SQLite fallback
		db.useSQLite = true
		
		-- Create tables
		sql.Query("CREATE TABLE IF NOT EXISTS pas_users (steamid TEXT PRIMARY KEY, name TEXT, firstjoined INTEGER, lastseen INTEGER, playtime INTEGER)")
		sql.Query("CREATE TABLE IF NOT EXISTS pas_players (steamid TEXT PRIMARY KEY, usergroup TEXT, custom_flags TEXT, password_hash TEXT, password_salt TEXT, last_auth_time INTEGER DEFAULT 0)")
		sql.Query("CREATE TABLE IF NOT EXISTS pas_ranks (steamid TEXT, sv_id TEXT, rank INTEGER, expire_rank INTEGER, expire_time INTEGER, PRIMARY KEY (steamid, sv_id))")
		sql.Query("CREATE TABLE IF NOT EXISTS pas_bans (steamid TEXT PRIMARY KEY, admin TEXT, reason TEXT, time INTEGER, expire INTEGER)")
		sql.Query("CREATE TABLE IF NOT EXISTS pas_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, message TEXT, time INTEGER)")
		sql.Query("CREATE TABLE IF NOT EXISTS pas_keys (Date INTEGER, Key TEXT PRIMARY KEY)")
		sql.Query("CREATE TABLE IF NOT EXISTS pas_auth (steamid TEXT PRIMARY KEY, password_hash TEXT NOT NULL, password_salt TEXT NOT NULL, last_auth_time INTEGER DEFAULT 0, created_at INTEGER DEFAULT 0)")
		-- Create rank definitions table for new rank management system
		sql.Query("CREATE TABLE IF NOT EXISTS pas_rank_definitions (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, display_name TEXT NOT NULL, color TEXT DEFAULT '#FFFFFF', flags TEXT DEFAULT '', immunity INTEGER DEFAULT 0, inheritance TEXT DEFAULT 'user', is_global INTEGER DEFAULT 0, is_admin INTEGER DEFAULT 0, is_superadmin INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)")
		
		connected = true
		
		-- Call hook to notify that database is ready
		hook.Call("pas_DatabaseReady", nil)
		
		function db:query(str, params, callback)
			-- Support both old and new signatures
			-- Old: db:query(str, callback)
			-- New: db:query(str, params, callback)
			
			local actualParams = nil
			local actualCallback = nil
			
			if type(params) == "function" then
				-- Old signature: second arg is callback
				actualCallback = params
			elseif type(params) == "table" then
				-- New signature: second arg is params, third is callback
				actualParams = params
				actualCallback = callback
			end
			
		-- Replace parameters if provided
		if actualParams then
			for i, param in ipairs(actualParams) do
				-- Handle different types properly
				local escaped
				if type(param) == "number" then
					escaped = tostring(param)
				else
					escaped = sql.SQLStr(param)
				end
				str = str:gsub("%?", escaped, 1)
			end
		end
		
		local result = sql.Query(str)
		
		if actualCallback and type(actualCallback) == "function" then
			timer.Simple(0, function()
				actualCallback(result or {})
			end)
		end
	end		function db:query_ex(str, params, callback)
			-- Simple parameter replacement
			for i, param in ipairs(params) do
				str = str:gsub("%?", sql.SQLStr(param), 1)
			end
			
			local result = sql.Query(str)
			if callback then
				timer.Simple(0, function()
					callback(result or {})
				end)
			end
		end
		
		function db:query_sync(str, params)
			if params then
				for i, param in ipairs(params) do
					str = str:gsub("%?", sql.SQLStr(param), 1)
				end
			end
			
			return sql.Query(str) or {}
		end
		
		return db
	end
	
	-- Use MySQLOO
	db.connection = mysqloo.connect(host, user, pass, database, port)
	
	function db.connection:onConnected()
		MsgC(Color(0, 255, 0), '[OLIBS MySQL] ', Color(255, 255, 255), 'Connected to MySQL server\n')
		connected = true
		
		-- Process queued queries
		for i, query in ipairs(queue) do
			db:query(query.str, query.callback)
		end
		queue = {}
	end
	
	function db.connection:onConnectionFailed(err)
		MsgC(Color(255, 0, 0), '[OLIBS MySQL] ', Color(255, 255, 255), 'Connection failed: ' .. err .. '\n')
	end
	
	db.connection:connect()
	
	function db:query(str, params, callback)
		-- Support both old and new signatures
		-- Old: db:query(str, callback)
		-- New: db:query(str, params, callback)
		
		local actualParams = nil
		local actualCallback = nil
		
		if type(params) == "function" then
			-- Old signature: second arg is callback
			actualCallback = params
		elseif type(params) == "table" then
			-- New signature: second arg is params, third is callback
			actualParams = params
			actualCallback = callback
		end
		
		-- Replace parameters if provided
		if actualParams then
			for i, param in ipairs(actualParams) do
				-- Handle different types properly
				local escaped
				if type(param) == "number" then
					escaped = tostring(param)
				else
					escaped = "'" .. self.connection:escape(tostring(param)) .. "'"
				end
				str = str:gsub("%?", escaped, 1)
			end
		end
		
		if not connected then
			table.insert(queue, {str = str, callback = actualCallback})
			return
		end
		
		local query = self.connection:query(str)
		
		function query:onSuccess(data)
			if actualCallback and type(actualCallback) == "function" then
				actualCallback(data)
			end
		end
		
		function query:onError(err)
			MsgC(Color(255, 0, 0), '[OLIBS MySQL] ', Color(255, 255, 255), 'Query error: ' .. err .. '\n')
			MsgC(Color(255, 0, 0), '[OLIBS MySQL] ', Color(255, 255, 255), 'Query: ' .. str .. '\n')
		end
		
		query:start()
	end
	
	function db:query_ex(str, params, callback)
		-- Replace ? with escaped parameters
		for i, param in ipairs(params) do
			local escaped = self.connection:escape(tostring(param))
			str = str:gsub("%?", "'" .. escaped .. "'", 1)
		end
		
		self:query(str, callback)
	end
	
	function db:query_sync(str, params)
		-- Synchronous query (blocks)
		local result = {}
		local done = false
		
		if params then
			for i, param in ipairs(params) do
				local escaped = self.connection:escape(tostring(param))
				str = str:gsub("%?", "'" .. escaped .. "'", 1)
			end
		end
		
		local query = self.connection:query(str)
		
		function query:onSuccess(data)
			result = data
			done = true
		end
		
		function query:onError(err)
			done = true
		end
		
		query:start()
		
		-- Wait for completion (with timeout)
		local timeout = SysTime() + 5
		while not done and SysTime() < timeout do
			timer.Simple(0, function() end) -- Process timers
		end
		
		return result
	end
	
	return db
end
