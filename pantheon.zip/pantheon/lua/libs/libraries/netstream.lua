--[[
	OLIBS - NetStream
	Simplified streaming system for large data transfers
]]

local txnid = 0
local BLOCK_SIZE = 2^16-2^10
local BLOCK_SIZE_m1 = BLOCK_SIZE - 1

if SERVER then 
	util.AddNetworkString('ons')
end

function net.WriteStream(data, targs)
	txnid = (txnid + 1) % 0xFFFF

	local count = 0
	local iter = function()
		local seg = data:sub(count, count + BLOCK_SIZE_m1)
		count = count + BLOCK_SIZE
		return seg
	end

	local function send()
		local block = iter()

		if block and block ~= "" then
			block = util.Compress(block)
			local size = block:len()
			
			net.Start('ons')
				net.WriteUInt(txnid, 16)
				net.WriteUInt(size, 16)
				net.WriteData(block, size)
			if SERVER then
				net.Send(targs)
			else
				net.SendToServer()
			end
			
			timer.Simple(0.1, send)
		end
	end

	net.WriteUInt(txnid, 16)
	net.WriteUInt(math.ceil(data:len() / BLOCK_SIZE), 16)
	
	timer.Simple(0.1, send)
end

local buckets = {}

if SERVER then
	function net.ReadStream(src, callback)
		if not src then
			error('stream source must be provided to receive a stream from a player')
		end
		if not callback then
			error('callback must be provided for stream read completion')
		end
		if not buckets[src] then buckets[src] = {} end
		buckets[src][net.ReadUInt(16)] = {len=net.ReadUInt(16), callback=callback}
	end
	
	net.Receive('ons', function(_, pl)
		local txnid = net.ReadUInt(16)
		if not buckets[pl] or not buckets[pl][txnid] then
			return
		end

		local bucket = buckets[pl][txnid]
		local size = net.ReadUInt(16)
		local data = net.ReadData(size)
		data = util.Decompress(data)

		bucket[#bucket+1] = data

		if #bucket == bucket.len then
			buckets[pl][txnid] = nil
			bucket.callback(table.concat(bucket))
		end
	end)
else
	function net.ReadStream(callback)
		if not callback then
			error('callback must be provided for stream read completion')
		end
		buckets[net.ReadUInt(16)] = {len=net.ReadUInt(16), callback=callback}
	end
	
	net.Receive('ons', function()
		local txnid = net.ReadUInt(16)
		if not buckets[txnid] then
			return
		end

		local bucket = buckets[txnid]
		local size = net.ReadUInt(16)
		local data = net.ReadData(size)
		data = util.Decompress(data)

		bucket[#bucket+1] = data

		if #bucket == bucket.len then
			buckets[txnid] = nil
			bucket.callback(table.concat(bucket))
		end
	end)
end
