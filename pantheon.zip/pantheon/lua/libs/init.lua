-- LIBS - PANTHEON Library System v2.0
-- Enhanced library management with advanced loader

libs = libs or {
	BadModules = {},
	Version = "2.0.0",
	StartTime = SysTime()
}

_R = debug.getregistry()

-- Load the advanced loader first
if SERVER then
	AddCSLuaFile('libs/libraries/loader.lua')
end
include('libs/libraries/loader.lua')

-- Configure loader for LIBS
loader.config.verbose = false
loader.config.benchmarking = true

-- Backward compatibility functions
libs.IncludeSV = (SERVER) and include or function() end
libs.IncludeCL = (SERVER) and AddCSLuaFile or include
libs.IncludeSH = function(f) return libs.IncludeCL(f) or libs.IncludeSV(f) end

-- Enhanced directory scanning
function libs.LoadDir(...)
	local ret = {}
	for _, dir in ipairs({...}) do
		local files, folders = file.Find('libs/' .. dir .. '/*', 'LUA')
		
		-- Process files
		for _, f in ipairs(files) do
			if f:match('%.lua$') and f ~= 'loader.lua' then -- Skip loader.lua
				local moduleName = f:sub(1, -5) -- Remove .lua
				ret[moduleName] = 'libs/' .. dir .. '/' .. f
			end
		end
		
		-- Process folders (look for init.lua or folder_name.lua)
		for _, f in ipairs(folders) do
			if f ~= 'client' and f ~= 'server' and f ~= '.' and f ~= '..' then
				local initPath = 'libs/' .. dir .. '/' .. f .. '/init.lua'
				local namedPath = 'libs/' .. dir .. '/' .. f .. '/' .. f .. '.lua'
				
				if file.Exists(initPath, 'LUA') then
					ret[f] = initPath
				elseif file.Exists(namedPath, 'LUA') then
					ret[f] = namedPath
				end
			end
		end
	end
	return ret
end

-- Scan for modules
local modules = {
	Shared = libs.LoadDir('libraries'),
	Server = SERVER and libs.LoadDir('libraries/server') or {},
	Client = libs.LoadDir('libraries/client'),
	Loaded = {},
	LoadOrder = {}
}

-- Send client files
if SERVER then
	for name, path in pairs(modules.Shared) do
		AddCSLuaFile(path)
	end
	for name, path in pairs(modules.Client) do
		AddCSLuaFile(path)
	end
end

-- Enhanced require function with loader integration
_require = _require or require
function require(name)
	-- Check if it's a LIBS module
	local libPath = modules.Shared[name] or modules.Server[name] or modules.Client[name]
	
	if libPath and not modules.Loaded[name] and not libs.BadModules[name] then
		modules.Loaded[name] = true
		table.insert(modules.LoadOrder, name)
		
		-- Use loader for better error handling
		local success, result = pcall(function()
			return loader.load(libPath, {cache = true})
		end)
		
		if not success then
			libs.BadModules[name] = true
			loader.error('Failed to load module: ' .. name, result)
			return nil
		end
		
		loader.verbose('Module loaded: ' .. name)
		return result
		
	elseif not modules.Loaded[name] and not libs.BadModules[name] then
		-- Fall back to original require
		return _require(name)
	end
	
	return nil
end

-- Auto-load core libraries
local coreLibs = {'loader', 'netstream', 'nw', 'xfn', 'pon', 'pon2'}
for _, lib in ipairs(coreLibs) do
	if modules.Shared[lib] and lib ~= 'loader' then -- loader already loaded
		require(lib)
	end
end

-- Load realm-specific libraries
if SERVER then
	if modules.Server['ptmysql'] then require('ptmysql') end
	if modules.Server['sha2'] then require('sha2') end
else
	if modules.Client['cvar'] then require('cvar') end
end

-- Statistics
function libs.GetStats()
	return {
		version = libs.Version,
		modulesLoaded = #modules.LoadOrder,
		badModules = table.Count(libs.BadModules),
		loadTime = (SysTime() - libs.StartTime) * 1000,
		loadOrder = modules.LoadOrder
	}
end

-- Print initialization
local stats = libs.GetStats()
MsgC(Color(138, 43, 226), '[LIBS] ', Color(255, 255, 255), 
	string.format('Library system v%s initialized (%d modules in %.2fms)\n', 
		libs.Version, stats.modulesLoaded, stats.loadTime)
)
