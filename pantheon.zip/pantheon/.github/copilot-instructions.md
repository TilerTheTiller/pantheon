# GitHub Copilot Instructions for PANTHEON Admin System

## Project Overview
PANTHEON is a comprehensive admin system for Garry's Mod (GLua) built with a modular architecture, custom loader system, and extensive UI framework. Version: 2.0.0

## Core Architecture

### File Naming Conventions
- `_sh.lua` - Shared (runs on both client and server)
- `_sv.lua` - Server-only
- `_cl.lua` - Client-only
- Files without suffix default to shared

### Realm-Specific Code
Always use appropriate realm guards:
```lua
if SERVER then
    -- Server-only code
end

if CLIENT then
    -- Client-only code
end
```

### Module Loading System
PANTHEON uses a custom loader system (`loader`) with dependency management:

```lua
-- Load shared file
pas.include_sh('pas/core/module_sh.lua')

-- Load server file
pas.include_sv('pas/core/module_sv.lua')

-- Load client file
pas.include_cl('pas/core/module_cl.lua')

-- Load entire directory
pas.include_dir('core/util', {
    recursive = true,
    exclude = {'old_*'},
    cache = true
})
```

**Critical:** When creating new modules that depend on others, ensure dependencies are loaded first in `core_init.lua`.

## Namespace Organization

### Global Tables
- `pas` - Main namespace for PANTHEON systems
- `loader` - File loading and dependency management
- `PLAYER` - Player metatable (`FindMetaTable('Player')`)
- `ui` - UI framework and components

### Key Subsystems
- `pas.cmd` - Command system (MUST be loaded before plugins)
- `pas.ranks` - Rank/group management
- `pas.flags` - Permission flag system
- `pas.log` - Logging system
- `pas.notify` - Notification system
- `pas.terms` - Terminology/language system
- `pas.data` - Server-side data persistence

## Command System

### Creating Commands
Commands MUST use the builder pattern with method chaining:

```lua
pas.cmd.Create('commandname', function(pl, args)
    -- Validate player
    if not IsValid(pl) or not pl:IsPlayer() then
        return
    end
    
    -- Command logic here
    local target = args[1]
    
    -- Return false to show usage on invalid input
    if not target then
        return false
    end
end)
    :SetFlag('a')  -- Required permission flag
    :SetHelp('Description of what this command does')
    :SetIcon('icon16/star.png')
    :AddAlias('cmd')  -- Alternative command name
    :AddArg('player', 'target')  -- Add argument definition
```

### Command Validation
- Always validate `pl` with `IsValid(pl)` and `pl:IsPlayer()`
- Return `false` to trigger automatic usage message
- Use `pas.notify(pl, message, type)` for feedback
  - Type 0: Success (green)
  - Type 1: Error (red)
  - Type 2: Warning (yellow)

### Multiple Permission Flags
```lua
:SetFlag({'a', 'g'})  -- Requires either 'a' OR 'g' flag
```

## Permission System

### Checking Permissions
```lua
-- Check if player has flag
if pl:HasFlag('a') then
    -- Admin action
end

-- Check immunity/targeting (for commands affecting other players)
if pas.ranks.CanTarget(admin, target) then
    -- Can perform action on target
else
    pas.notify(admin, 'Insufficient immunity', 1)
    return
end
```

### Common Flags
- `u` - User (default, everyone)
- `a` - Admin
- `s` - Superadmin
- `p` - Physgun
- `g` - Gamemaster
- Custom flags can be defined per-server

## Player Meta Functions

### Admin Mode
```lua
pl:SetAdminMode(true/false)
pl:GetAdminMode()
```

### Flags
```lua
pl:HasFlag('a')
pl:GiveFlag('flag')
pl:TakeFlag('flag')
```

### Rank/Group
```lua
pl:GetUserGroup()
pl:SetUserGroup('group')
pl:GetImmunity()
```

## Networking

### NetStream (for large data)
Use for transferring data > 64KB:

```lua
-- Server to client
netstream.Start(player, 'ChannelName', largeData)

-- Client to server
netstream.Start('ChannelName', largeData)

-- Receive
netstream.Hook('ChannelName', function(pl, data)
    -- Handle data
end)
```

### Standard Networking
```lua
-- Server
if SERVER then
    util.AddNetworkString('pas.EventName')
end

net.Start('pas.EventName')
    net.WriteString(data)
net.Send(player)

-- Client receives
net.Receive('pas.EventName', function()
    local data = net.ReadString()
end)
```

## UI Framework

### Creating UI Components
Use the PANTHEON UI framework for consistency:

```lua
if CLIENT then
    local frame = ui.components.CreateFrame('Title', width, height, 'icon_name')
    
    local button = ui.components.CreateButton(
        parent, 
        'Label', 
        x, y, width, height,
        function() 
            -- Click handler
        end,
        'icon_name',
        'primary'  -- or 'secondary', 'danger', 'success'
    )
end
```

### Colors
Access theme colors via `ui.col`:
```lua
ui.col.PANTHEON           -- Primary purple (138, 43, 226)
ui.col.PANTHEON_LIGHT     -- Lighter purple
ui.col.PANTHEON_DARK      -- Darker purple
ui.col.White
ui.col.TEXT_DIM           -- Dimmed text
```

### Fonts
Use PANTHEON fonts:
```lua
'PANTHEON.12'  -- Small
'PANTHEON.14'  -- Regular
'PANTHEON.16'  -- Medium
'PANTHEON.18'  -- Large
'PANTHEON.24'  -- Title
```

## Logging System

### Adding Logs
```lua
pas.log.Add('Category', 'Admin ' .. pl:Nick() .. ' did action on ' .. target:Nick())
```

Common categories:
- `'Command'` - Command execution
- `'Physgun'` - Physgun actions
- `'Join'` / `'Leave'` - Player connection
- `'Admin'` - Administrative actions
- `'Chat'` - Chat events

## Database Integration (Server-only)

### MySQL Queries
```lua
if SERVER then
    pas.db.Query([[
        SELECT * FROM tablename WHERE id = ?
    ]], {playerId}, function(data, success, error)
        if success then
            -- Handle data
        else
            ErrorNoHalt('Database error: ' .. tostring(error))
        end
    end)
end
```

### Data Persistence
```lua
-- Save player data
pas.data.Set(pl, 'key', value)

-- Load player data
local value = pas.data.Get(pl, 'key', defaultValue)
```

## Hooks and Callbacks

### Common Hooks
```lua
-- System loaded
hook.Add('PANTHEON_Loaded', 'Identifier', function()
    -- Post-initialization
end)

-- Player authenticated
hook.Add('PAS.PlayerAuthenticated', 'Identifier', function(pl)
    -- Player has loaded ranks/flags
end)
```

### Hook Naming Convention
Use format: `'PAS.ModuleName.ActionName'`

Example: `'PAS.AdminMode.NoDamage'`

## Error Handling

### PCalled Functions
```lua
local success, result = pcall(function()
    -- Risky operation
end)

if not success then
    pas.print('[ERROR] Operation failed: ' .. tostring(result))
    ErrorNoHalt(result)
end
```

### Validation Pattern
```lua
-- Always validate entities
if not IsValid(entity) then return end

-- Validate players specifically
if not IsValid(pl) or not pl:IsPlayer() then return end

-- Validate tables
if not data or type(data) ~= 'table' then return end
```

## Plugin Development

### Plugin Structure
```lua
-- plugins/myplugin.lua
if SERVER then
    AddCSLuaFile()
end

-- Define commands (requires pas.cmd)
pas.cmd.Create('mycommand', function(pl, args)
    -- Implementation
end)
    :SetFlag('a')
    :SetHelp('Description')

-- Define hooks
hook.Add('HookName', 'PAS.MyPlugin.HookName', function(...)
    -- Hook logic
end)
```

### Plugin Dependencies
Plugins that use `pas.cmd` depend on the Commands system being loaded first. Check `core_init.lua` to ensure proper load order.

## Best Practices

### Code Style
1. Use tabs for indentation (Garry's Mod convention)
2. Local variables for performance: `local var = value`
3. Descriptive variable names: `targetPlayer` not `tp`
4. Comment complex logic blocks
5. Use consistent spacing around operators

### Performance
1. Cache frequently accessed values:
   ```lua
   local plyPos = pl:GetPos()
   ```
2. Use `LocalPlayer()` on client instead of `player.GetAll()[1]`
3. Avoid creating tables in loops
4. Use `continue` to skip loop iterations early

### Security
1. **NEVER** trust client input - validate on server
2. Check permissions before executing admin actions
3. Sanitize SQL inputs (use parameterized queries)
4. Validate entity existence before use

### Notifications
```lua
-- Single player
pas.notify(pl, 'Message', 0)  -- Success
pas.notify(pl, 'Error!', 1)   -- Error
pas.notify(pl, 'Warning', 2)  -- Warning

-- All players (server-side)
for _, v in pairs(player.GetAll()) do
    pas.notify(v, 'Server message', 0)
end
```

### Console Output
```lua
-- Colored output
pas.print('Message')  -- Purple [PANTHEON] prefix

-- Manual coloring
MsgC(Color(255, 100, 100), '[ERROR] ', Color(255, 255, 255), 'Message\n')
```

## Common Patterns

### Player Iterator
```lua
for _, pl in pairs(player.GetAll()) do
    if not IsValid(pl) then continue end
    -- Process player
end
```

### Delayed Execution
```lua
timer.Simple(1, function()
    if not IsValid(pl) then return end
    -- Delayed action
end)
```

### Finding Players
```lua
-- By name/partial match (use pas utility)
local target = pas.util.FindPlayer(searchString)

-- By SteamID
local target = player.GetBySteamID('STEAM_0:X:XXXXXX')

-- By UserID
local target = player.GetByID(userid)
```

### Client Convars
```lua
if CLIENT then
    local cvar = CreateClientConVar(
        'pas_setting_name',
        '1',           -- Default value
        true,          -- Should save
        false,         -- Not userdata
        'Description'
    )
    
    -- Get value
    local value = cvar:GetBool()  -- or GetInt(), GetFloat(), GetString()
end
```

## Testing and Debugging

### Debug Prints
```lua
if developer mode or pas.config.debug then
    print('[DEBUG]', variable)
    PrintTable(tableVar)
end
```

### Error Reporting
```lua
-- Non-fatal error
ErrorNoHalt('[PANTHEON] Warning: ' .. message .. '\n')

-- Fatal error (stops execution)
error('[PANTHEON] Critical: ' .. message)
```

## Module Dependencies

When creating new core modules, declare dependencies in `core_init.lua`:
```lua
{
    name = 'ModuleName',
    load = function()
        pas.include_sh('pas/core/module/module_sh.lua')
        -- Realm-specific includes
    end,
    deps = {'Dependency1', 'Dependency2'}
}
```

Load order (current):
1. Notifications, Terms, Data, Utilities, Player Meta
2. Flags (depends on Player Meta)
3. Ranks (depends on Flags)
4. Authentication (depends on Ranks, Flags)
5. Commands (depends on Authentication, Flags) - **MUST load before plugins**
6. Everything else (UI, Logging, Warnings, etc.)

## GLua-Specific Notes

- Garry's Mod uses Lua 5.1 (not LuaJIT)
- `continue` keyword is available in Garry's Mod
- `include()` returns file results
- `AddCSLuaFile()` sends file to clients (call on server)
- Vectors: `Vector(x, y, z)`
- Colors: `Color(r, g, b, a)`
- Use `:` for method calls: `player:GetPos()`
- Use `.` for static calls: `player.GetAll()`

## When Generating Code
1. Check realm requirements (SERVER/CLIENT/SHARED)
2. Validate entities before use
3. Use PANTHEON conventions (pas.cmd, pas.notify, etc.)
4. Include permission checks for admin actions
5. Add error handling (pcall for risky operations)
6. Log important actions via pas.log
7. Use immunity checks for player-targeting commands
8. Prefer builder pattern for commands
9. Use PANTHEON UI framework for interfaces
10. Follow existing code style and patterns
